/*
 */
package rumpel;
class Top {
    int j;
}
/**
 */
public class Humpel extends Top{
    int foo() {
        return super.j;
    }
}
