package jt108;

import java.util.*;
class T {
	int bar() {
		return 0;
	}
}

public class Test extends T {	
	void foo() {
		class X {
         	   int baz() {
         	       return Test.super.bar();
         	   }
        	}	
	}		
}
