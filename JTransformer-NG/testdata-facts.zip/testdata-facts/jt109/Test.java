/*
 */
package jt109;
class Test {
	    public char UNICODE_CHARACTER_FIELD = '\uffff';
	    public Character c;

}

