package jt103;
class Umpf{
    int nein=2;
}
public class Pumpel extends Umpf {
    int ja=0;
	private int foo() {
        return this.ja;
      }
    private int bar() {
        return ja;
      }
    private int baz() {
        return nein;
      }
    private int bang() {
        return super.nein;
      }
}
