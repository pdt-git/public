package jt136;
public class Test {
    boolean r = new Object() instanceof String;
}
