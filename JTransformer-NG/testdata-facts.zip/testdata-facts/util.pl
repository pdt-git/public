count(Goal,Count):-
    nb_setval(my_counter,0),
    (	(	Goal,
    		nb_getval(my_counter,I),
    		succ(I,II),
    		nb_setval(my_counter,II),
    		fail
    	)
    ; 	nb_getval(my_counter,Count),
    	nb_delete(my_counter)
    ).
