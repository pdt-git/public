package initializer;

public class InitializeMe {
    {
        ;
    }
    static {
        ;
    }
    {
        ;
    }
    static {
        ;
    }
}
