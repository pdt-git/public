package jt108b;

import java.util.*;
class T {
	int bar=42;	
}

public class Test extends T {	
	void foo() {		
		class X {
         	   int baz() {
         	       return Test.super.bar;
         	   }
        	}

	}		
}
