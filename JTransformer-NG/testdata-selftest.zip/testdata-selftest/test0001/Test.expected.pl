local2FQN(lId(19), fqn('java.io.PrintStream', 'println', ['java.lang.String'])).
local2FQN(lId(11), fqn('java.lang.Object')).
local2FQN(lId(10), fqn('java.lang.Object', '<init>', [])).
local2FQN(lId(14), fqn('java.lang.String')).
local2FQN(lId(22), fqn('java.lang.System')).
local2FQN(lId(21), fqn('java.lang.System', 'out')).
local2FQN(lId(4), fqn('java.util')).
local2FQN(lId(1), fqn('test0001')).
local2FQN(lId(3), fqn('test0001.Test')).
local2FQN(lId(7), fqn('test0001.Test', '<init>', [])).
local2FQN(lId(5), fqn('test0001.Test', 'main', ['java.lang.String[]'])).

:- inTe(toplevelT(lId(0), lId(1), '/testproject/test0001/Test.java', [lId(2), lId(3)])).
:- inTe(projectLocationT(lId(0), 'testproject', '')).
:- inTe(slT(lId(0), 0, 146)).
:- inTe(packageT(lId(1), 'test0001')).
:- inTe(packageT(lId(4), 'java.util')).
:- inTe(importT(lId(2), lId(0), lId(4))).
:- inTe(slT(lId(2), 18, 19)).
:- inTe(methodDefT(lId(7), lId(3), '<init>', [], type(basic, void, 0), [], lId(6))).
:- inTe(modifierT(lId(7), public)).
:- inTe(modifierT(lId(7), synthetic)).
:- inTe(blockT(lId(6), lId(7), lId(7), [lId(8)])).
:- inTe(execT(lId(8), lId(6), lId(7), lId(9))).
:- inTe(applyT(lId(9), lId(8), lId(7), 'null', 'super', [], fqn('java.lang.Object', '<init>', []))).
:- inTe(classDefT(lId(3), lId(1), 'Test', [lId(7), lId(5)])).
:- inTe(modifierT(lId(3), 'public')).
:- inTe(slT(lId(3), 38, 108)).
:- inTe(extendsT(lId(3), lId(11))).
:- inTe(methodDefT(lId(5), lId(3), 'main', [lId(12)], type(basic, void, 0), [], lId(13))).
:- inTe(slT(lId(5), 59, 85)).
:- inTe(modifierT(lId(5), 'public')).
:- inTe(modifierT(lId(5), 'static')).
:- inTe(paramDefT(lId(12), lId(5), type(class, lId(14), 1), 'args')).
:- inTe(slT(lId(12), 83, 13)).
:- inTe(blockT(lId(13), lId(5), lId(5), [lId(15)])).
:- inTe(slT(lId(13), 98, 46)).
:- inTe(execT(lId(15), lId(13), lId(5), lId(16))).
:- inTe(slT(lId(15), 102, 39)).
:- inTe(applyT(lId(16), lId(15), lId(5), lId(17), 'println', [lId(18)], lId(19))).
:- inTe(slT(lId(16), 102, 38)).
:- inTe(getFieldT(lId(17), lId(16), lId(5), lId(20), 'out', lId(21))).
:- inTe(slT(lId(17), 102, 10)).
:- inTe(identT(lId(20), lId(17), lId(5), 'System', lId(22))).
:- inTe(operationT(lId(18), lId(16), lId(5), [lId(23), lId(24)], '+', 0)).
:- inTe(slT(lId(18), 121, 18)).
:- inTe(literalT(lId(23), lId(18), lId(5), type(class, lId(14), 0), 'Hello')).
:- inTe(slT(lId(23), 121, 7)).
:- inTe(literalT(lId(24), lId(18), lId(5), type(class, lId(14), 0), ' world')).
:- inTe(slT(lId(24), 131, 8)).
:- retractLocalSymtab.

