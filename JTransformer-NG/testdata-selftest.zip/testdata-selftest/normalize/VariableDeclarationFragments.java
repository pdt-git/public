package normalize;
public class VariableDeclarationFragments{
    int a, b=0, c;
}
