package normalize;
public class NoOps{
	public void foo(){
		;
	}
}
