package normalize;
public class NormalizeTest                     //lala
/* bumbab*/{
	
	/**
	 * some "jav//adoc"
	 * @param args
	 */
	public static void main(String[] args){


		// schnulle//r///***/
		//blub
		System.
			out.
					println("Juhu, /*ich*/ bin so //cool!");
	}


}/* /* /* /* 
bramburtsch
*/
