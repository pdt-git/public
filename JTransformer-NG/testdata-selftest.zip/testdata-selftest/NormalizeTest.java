public class NormalizeTest                     //lala
/* bumbab*/{
	
	/**
	 * some javadoc
	 * @param args
	 */
	public static void main(String[] args){


		// schnuller
		//blub
		System.
			out.
					println("Juhu, ich bin so cool!");
	}


}
