package test0295;

public class Test {
	public List g() {
		return null;
	}
	public void foo() {
		g();
	}
}
