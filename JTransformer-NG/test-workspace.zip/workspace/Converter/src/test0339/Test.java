package test0339;

public class Test {
	public static interface X {
		int doQuery(boolean x);
	}

	public void setX(boolean x) {
 		{
		z
	}
}