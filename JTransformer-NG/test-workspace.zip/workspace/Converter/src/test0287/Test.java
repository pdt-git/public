package test0287;

public class Test {
	String[] tab = /**/new String[3]/**/;
}
