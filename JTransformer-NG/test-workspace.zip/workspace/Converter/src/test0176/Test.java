package test0176;
import java.util.*;
public class Test {
	int i = 0;
	int foo() {
		return this.i;
	}
}