package test0060;
import java.util.*;
public class Test {

	public static void main(String[] args) {
		int i = 2;
		int j = 3;
		int n = i / j;
	}
}