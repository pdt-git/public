package test0277;

public class Test {
	public void foo() {
	}
}

