package test0111;
import java.util.*;
public class Test {
	public int foo(int i ) {
		return 2\u003B
	}

}