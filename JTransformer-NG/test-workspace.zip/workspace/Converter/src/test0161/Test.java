package test0161;
import java.util.*;

public class Test implements Cloneable {
}