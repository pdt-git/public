package test0005;
import java.util.*;
public class Test {
	public static void main(String[] args) {
		System.out.println(new java.lang.Object() {});
	}
}