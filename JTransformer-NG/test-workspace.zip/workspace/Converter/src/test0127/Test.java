package test0127;
import java.util.*;
public class Test {
	public void foo(int i) {
		for (String tab[] = null;; ++i) {}
	}

}