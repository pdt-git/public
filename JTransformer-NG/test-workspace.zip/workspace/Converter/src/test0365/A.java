package test0365
;
/* Regression test for bug 11529 */
public class A {
	void theMethod() {
		for (int i = 0; i < 5; ++i) {
		}
	}
}