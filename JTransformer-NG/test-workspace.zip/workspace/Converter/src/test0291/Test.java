package test0291;

public class Test {
	bar() {}
}
