package test0364;
/* Regression test for bug 11529 */
public class A {
	void theMethod() {
		int local;
/*		for (int i = 0; i < 5; ++i) {
		}*/
	}
}