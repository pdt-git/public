package test0098;
import java.util.*;
public class Test {
	public void foo(int i ) {
		;
	}

}