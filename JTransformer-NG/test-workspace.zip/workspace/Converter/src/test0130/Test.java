package test0130;
import java.util.*;
public class Test {
  public int x= 10, y[] = null, i, j[][];
}