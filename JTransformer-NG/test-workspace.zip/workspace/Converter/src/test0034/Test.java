package test0034;
import java.util.*;
public class Test {

	public static void main(String[] args) {
		double d = 1.0;
		byte b = (byte) d;
	}
}