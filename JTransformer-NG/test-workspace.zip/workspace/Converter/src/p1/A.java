package p1;

public class A {

	public static void foo() {
	}
}
