package test0029;
import java.util.*;
public class Test {

	public static void main(String[] args) {
		int i = 0;
		i--;
	}
}