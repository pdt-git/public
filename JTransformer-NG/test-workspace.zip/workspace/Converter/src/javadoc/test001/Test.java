/** 
 * Comment 1
 */
package test001;

/** 
 * Comment 2
 */
public class B {
p
}


