package javadoc.test007;
public class Test {
/** 
 * @see #foo()
 * @see Test#foo()
 * @see javadoc.test007.Test#foo()
 */
public void foo() {}
}
