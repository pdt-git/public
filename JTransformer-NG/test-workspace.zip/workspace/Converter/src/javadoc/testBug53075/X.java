class X {
/**
 * @link aggregates
 * [... some more ...]
 * @linkplain plain aggregates
 */
void foo();
}
