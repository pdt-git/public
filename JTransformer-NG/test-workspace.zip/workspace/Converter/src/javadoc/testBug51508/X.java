package javadoc.testBug51508;
/**
 * @see java
 * @see java.util
 */
public class X {
}
