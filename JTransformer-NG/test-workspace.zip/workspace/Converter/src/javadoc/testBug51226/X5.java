package javadoc.testBug51226;
\u002F**
 * Test
 *\u002F
public class X {
}
