package javadoc.testBug51226;
/\u002A\u002A
 \u002A Test
 \u002A/
public class X {
}
