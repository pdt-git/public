package javadoc.testBug51226;
\u002F**
 * Test
 */
public class X {
}
