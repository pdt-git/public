package javadoc.testBug51226;
/*\u002A
 * Test
 */
public class X {
}
