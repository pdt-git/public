package javadoc.testBug51226;
\u002F\u002A\u002A
 \u002A Test
 \u002A\u002F
public class X {
}
