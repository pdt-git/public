package javadoc.test003;
public class Test {
/** 
 * {@link Exception}
 * @see Exception
 */
public void foo() {}
}