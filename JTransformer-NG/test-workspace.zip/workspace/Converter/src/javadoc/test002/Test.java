package javadoc.test002;
import java.util.*;
public class Test {
/** 
 * @see Vector
 * @see java.util.Vector
 */
public void foo() {
}
}