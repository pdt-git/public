package testBug48489;
import java.util.*;
public class Test {
	/**
	 * Javadoc
	 */
	public static void main(String[] args) {
		System.out./* */println("Hello" + " world");
	}
}