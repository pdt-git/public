package javadoc.testBug48489;
import java.util.*;
public class TestA {
	/**
	 * Javadoc comment
	 */
	public static void main(String[] args) {
		/* method main */
		System.out.println("Hello" + " world"); // comment
	}
}