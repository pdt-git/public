package javadoc.test010;
public class Test {
int val;
/** 
 * {@link java.util.Vector#Vector()}
 * @param name {@link java.lang.String inline tag}
 * @see Object {@link java.lang.String inline tag} leading comment
 */
public void gee(String name) {}
}
