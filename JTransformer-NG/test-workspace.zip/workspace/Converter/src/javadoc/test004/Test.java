package javadoc.test004;
import java.util.*;
public class Test {
/** 
 * @see #foo(Vector)
 * @see Test#foo(Vector)
 * @see javadoc.test004.Test#foo(Vector)
 */
public void foo(Vector v) {
	Vector vs;
}
}