package javadoc.test006;
public class Test {
/** 
 * @see String
 * @see StringBuffer#StringBuffer(String)
 * @see java.lang.String
 * @see java.lang.StringBuffer#StringBuffer(java.lang.String)
 */
public void foo() {
	}
}