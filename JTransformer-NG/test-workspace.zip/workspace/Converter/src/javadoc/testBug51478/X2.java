package javadoc.testBug51478;
/**
 * {@inheritDoc}
 */
public class X {
}
