package javadoc.testBug51478;
/**
 * {@inheritDoc}
 * @deprecated
 */
public class X {
}
