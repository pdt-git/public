package javadoc.testBug51478;
/**
 * @deprecated
 */
public class X {
}
