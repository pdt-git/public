package javadoc.testBug50898;
public class Test {
    /**			
     * @see G.Inner
     */
    public void foo() {
    }
}