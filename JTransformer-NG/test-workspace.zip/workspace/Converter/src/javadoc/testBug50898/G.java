package javadoc.testBug50898;
public class G {
	private static class Inner {}
}