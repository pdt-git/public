package javadoc.test106;
public class Test { //  C0 */ //  C0b */
	//  C1 */ //  C1b */
	//  C2 */ //  C2b */

	void foo() {} //  C3 */ //  C3b */
	//  C4 */ //  C4b */
	//  C5 */ //  C5b */

	void bar() {}
	//  C6 */ //  C6b */
	//  C7 */ //  C7b */
}
