package javadoc.testBug55223;
public class TestB {
	/**
	 * Returns all of the filter elements of this shortcut as a List of String Pairs.
	 * 
	 * @return all of the filter elements of this shortcut, or <code>null</code> if not
	 *  specified
	 */
	public /* <Pair> */ Object getFilters() { return null; }
}
