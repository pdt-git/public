package javadoc.test105;
public class TestB2 { /*  C0 */ //  C1 */
	/*  C2 */ //  C3 */
	/*  C4 */ //  C5 */

	void foo() {} /*  C6 */ //  C7 */
	/*  C8 */ //  C9 */
	/*  C10 */ //  C11 */

	void bar() {}
	/*  C12 */ //  C13 */
	/*  C14 */ //  C15 */
}
