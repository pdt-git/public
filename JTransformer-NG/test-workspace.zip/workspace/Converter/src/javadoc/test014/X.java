package javadoc.test014;
public class X {
	public static final String COMPILER_PB_INVALID_JAVADOC = ".compiler.problem.invalidJavadoc"; //$NON-NLS-1$
	/**
	 * Possible  configurable option ID.
	 * @see #COMPILER_PB_INVALID_JAVADOC
	 * @deprecated
	 * TODO (frederic) remove after 3.0 M6
	 */
	public static final String COMPILER_PB_INVALID_ANNOTATION = COMPILER_PB_INVALID_JAVADOC;
}
