package javadoc.testBug51770;
/**
 * @see <a href="http://www.ibm.com">Valid URL</a>
 */
public class X {
}
