package javadoc.testBug51770;
/**
 * @see "Test class X"
 */
public class X {
}
