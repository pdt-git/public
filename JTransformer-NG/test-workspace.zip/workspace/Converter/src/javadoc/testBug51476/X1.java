package javadoc.testBug51770;
/**
 * @see "Test class X"
 * @see <a href="http://www.ibm.com">Valid URL</a>
 */
public class X {
}
