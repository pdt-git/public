package javadoc.testBug51650;
public class X {
  /**
   * @see Exception
   * {@link Exception}
   */
  public void foo() {
  }
}
