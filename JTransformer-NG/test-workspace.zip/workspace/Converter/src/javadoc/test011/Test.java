package javadoc.test011;
public class Test {
	/** @deprecated *//
	public Test(int myParam) { }
}
