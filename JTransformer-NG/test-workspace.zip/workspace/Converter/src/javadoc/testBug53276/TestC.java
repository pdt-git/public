package javadoc.testBug53276;
public class TestC {

	/**
	 * Returns the progress monitor. It there is no progress monitor the monitor\
	 * is set to the <code>NullProgressMonitor</code>.
	 * 
	 * @return the progress monitor
	 */
	public Object foo() {}
}

