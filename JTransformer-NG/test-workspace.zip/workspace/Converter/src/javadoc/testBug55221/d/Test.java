package javadoc.testBug55221.d;
public class Test {
	/**
	 * Javadoc comment
	 */// Line comment
	boolean foo() { return false; }
}