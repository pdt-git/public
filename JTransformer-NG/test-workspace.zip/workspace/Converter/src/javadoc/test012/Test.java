package javadoc.test012;
public class Test {
int val;
	/** 
	 * Leading comment {@link java.util.Vector#Vector()} trailing comment.
	 */
	public void foo() {}
}
