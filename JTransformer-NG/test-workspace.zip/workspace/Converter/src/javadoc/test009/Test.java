package javadoc.test009;
public class Test {
/** 
 * @see #foo(Object[] obj,String[][][] str)
 */
public void foo(Object[] o1,String[][][] s3) {}
/** 
 * @see #foo(java.util.Vector[] v1,java.util.Vector[][][] v2)
 */
public void foo(java.util.Vector[] v1,java.util.Vector[][][] v3) {}
/** 
 * @see #foo(int[] array1,char[][][] array2)
 */
public void foo(int[] a1,char[][][] a3) {}
}