package javadoc.testBug51363;
\u002F\u002FUnicode comment\u000D\u000Apublic class Test {
	\u002F\u002FUnicode comment\u000Dvoid foo() {}
}