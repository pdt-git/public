package javadoc.test005;
import java.util.Vector;
public class Test {
/** 
 * @see Test#Test(String)
 */
public Test(String str) {}
}
}