package javadoc.testBug51770;
/**
 * @see java.util.Vector
 */
public class X {
}
