package javadoc.test008;
public class Test {
/** 
 * @see #foo(Object[],String[][][])
 */
public void foo(Object[] o1,String[][][] s3) {}
/** 
 * @see #foo(java.util.Vector[],java.util.Vector[][][])
 */
public void foo(java.util.Vector[] v1,java.util.Vector[][][] v3) {}
/** 
 * @see #foo(int[],char[][][])
 */
public void foo(int[] a1,char[][][] a3) {}
}