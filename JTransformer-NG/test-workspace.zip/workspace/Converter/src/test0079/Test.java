package test0079;
import java.util.*;
public class Test {
	public void foo() {
		super.bar(4);
	}

}