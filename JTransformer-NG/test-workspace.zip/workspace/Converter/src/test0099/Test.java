package test0099;
import java.util.*;
public class Test {
	public void foo(int i ) {
		do {;
		} while(true);
	}

}