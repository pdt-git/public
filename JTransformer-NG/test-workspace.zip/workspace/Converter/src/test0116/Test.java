package test0116;
import java.util.*;
public class Test {
	public int foo(Exception e) {
		throw e   \u003B
	}

}