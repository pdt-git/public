package test0215;
import java.util.*;
/** JavaDoc Comment*/
public class Test {
  int i;
}/**/