package test0035;
import java.util.*;
public class Test {

	public static void main(String[] args) {
		double d = 1.0;
		short s = (short) d;
	}
}