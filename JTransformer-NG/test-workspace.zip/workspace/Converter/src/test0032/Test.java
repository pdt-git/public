package test0032;
import java.util.*;
public class Test {

	public static void main(String[] args) {
		double d = 1.0;
		int i = (int) d;
	}
}