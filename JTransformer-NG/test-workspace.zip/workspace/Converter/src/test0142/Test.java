package test0142;
import java.util.*;
public class Test {
	/* Multiple lines comment
	 */
  class B {}

}