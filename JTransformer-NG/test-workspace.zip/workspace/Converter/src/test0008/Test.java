package test0008;
import java.util.*;
public class Test {

	public static void main(String[] args) {
		System.out.println(new int[] {1, 2, 3, 4});
	}
}