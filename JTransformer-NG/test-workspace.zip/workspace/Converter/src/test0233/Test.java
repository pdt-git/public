package test0233;

public class Test {
	Toto t;
}