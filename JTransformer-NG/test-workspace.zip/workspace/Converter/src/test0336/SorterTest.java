package test0336;

import junit.runner.Sorter;
import java.util.Vector;

public class SorterTest  {
	static class Swapper implements Sorter.Swapper {
		public void swap(Vector values, int left, int right) {
		}
    }
}