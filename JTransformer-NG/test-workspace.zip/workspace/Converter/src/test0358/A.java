package test0358;

class A {
	public void mdd(int y){
	}
}