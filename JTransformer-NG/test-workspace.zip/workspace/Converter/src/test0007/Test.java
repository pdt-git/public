package test0007;
import java.util.*;
public class Test {

	public static void main(String[] args) {
		System.out.println(new Test().new D());
	}
	class D {
	}
}