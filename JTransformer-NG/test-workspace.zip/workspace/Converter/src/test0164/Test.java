package test0164;
import java.util.*;
public class Test {
	private class B {}
}