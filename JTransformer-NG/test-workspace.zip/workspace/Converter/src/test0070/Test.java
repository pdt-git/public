package test0070;
import java.util.*;
public class Test {
	public static void main(String[] args) {
		Object o = new Object();
		boolean b = o instanceof Integer;
	}

}