package test0141;
import java.util.*;
public class Test {
	/** JavaDoc Comment*/
  class B {}
}