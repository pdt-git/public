package p2;

public class A {
	public static void foo() {
	}
}
