package test0337;

public class Test {
 	String message= Test.m("s", new String[]{"g"});
 	
 	static String m(String g, String[] s){
 		return null;
 	}
}