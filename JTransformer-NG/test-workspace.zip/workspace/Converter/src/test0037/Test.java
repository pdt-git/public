package test0037;
import java.util.*;
public class Test {

	public static void main(String[] args) {
		int i = 1;
		char c = (char) i;
	}
}