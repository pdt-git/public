package test0361;

public class X {
	public void foo() {
		for (int i=0; i<10 ; i++) {
  			System.out.println("L");
	  	}
	}
}