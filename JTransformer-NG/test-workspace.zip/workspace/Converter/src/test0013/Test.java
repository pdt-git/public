package test0013;
import java.util.*;
public class Test {

	public static void main(String[] args) {
		int i;
	}
}