% Author: Sebastian Lorenz
% Date: 7.03.2006
% Last updated: 2.7.2006

/*
Vorbereitung auf die Tests:
  1. "peSingleFilesJava." aufrufen. (-> Macht Einzelauswertungen und speichert
     die Ergebnisse in peResults('/einzeltest')
  2. consult(consult_peTestFiles)
  
Problem bei diesen Tests:
  - Bei individualisierten Tests, die auf einer asserteten Menge von PEFs basieren,
    m�ssen diese PEFs zus�tzlich ins Modul "pe:" geladen werden. Die Pr�dikate
    "genTestPEFsAll" und "cleanAll" wurden dahingehend erweitert.
*/
%:- peOneFileJava.
%:- consult(home(consult_peTestFiles)).

vergleich2 :-
    /* ::: T E S T � B E R S I C H T :::
      #### Zugriffsebene ####
      ast_node_term/2
      ast_node_signature/3
      ast_node_argument/3
      get_ast_node_term/3
      get_ast_node_enclosing/3
      get_ast_node_parent/3
      get_ast_node_label/3
    */
    chk1(ast_node_term('Java',X),pe:ast_node_term('Java',X)),
    chk1(ast_node_signature('Java',X,Y),pe:ast_node_signature('Java',X,Y)),
    chk1(ast_node_signature('JavaAttributes',X,Y),pe:ast_node_signature('JavaAttributes',X,Y)),
    chk1(ast_node_argument('Java',Node,Name), pe:ast_node_argument('Java',Node,Name)),
    
    (genTestPEFsEnclPar,
     chk1(
           (idsToCheck(ID),get_ast_node_term('Java',ID,Term)),
           (idsToCheck(ID),pe:get_ast_node_term('Java',ID,Term))
         ),
         cleanAll),
         
    (genTestPEFsEnclPar,
     chk1(
           (idsToCheck(ID),get_ast_node_term('Java',ID,_)),
           (idsToCheck(ID),pe:get_ast_node_term('Java',ID,_))
         ),
         cleanAll),
    %enclosing(ID,Enclosing)     <-> get_ast_node_enclosing('Java',ID,Enclosing)
    (genTestPEFsEnclPar,
     chk1(
           (idsToCheck(ID),get_ast_node_enclosing('Java',ID,Encl)),
           (idsToCheck(ID),pe:get_ast_node_enclosing('Java',ID,Encl))
         ),
         cleanAll),

    %tree(ID,Parent)             <-> get_ast_node_parent('Java',ID,Parent)
    (genTestPEFsEnclPar,
     chk1(
           (idsToCheck(ID),get_ast_node_parent('Java',ID,Parent)),
           (idsToCheck(ID),pe:get_ast_node_parent('Java',ID,Parent))
         ),
         cleanAll),

    %tree(ID,_,Label)            <-> get_ast_node_label('Java',ID,Label)
    (genTestPEFsEnclPar,
     chk1(
           (idsToCheck(ID),get_ast_node_label('Java',ID,Label)),
           (idsToCheck(ID),pe:get_ast_node_label('Java',ID,Label))
         ),
         cleanAll).

    %tree_constraints(Functor,Constraints) <-> ast_node_def(Lang,Functor,ArgList), extractConstraints(ArgList,Constraints),
    %chk1(tree_constraints(Functor,Constraints),(ast_node_def('Java',Functor,ArgList), extractConstraints(ArgList,Constraints))).
    %Die tree_constraints unterscheiden sich!!

/* Einzeltests auf Korrektheit des Ergebnisses:
   aus "/engine/ast/languageIndependentSyntax.pl":
:- peTest(ast_node_signature('Java',NodeType,Arity)).
   -> o.k.
:- peTest(ast_node_term('Java',Head)).
   -> o.k.
:- peTest(ast_reference_type('Java',Label)).
   -> o.k.
:- peTest(ast_node_type('Java',Type)).
   -> o.k.
:- peTest(ast_node_subtype('Java',SubType,SuperType)).
   -> ? "Out of local Stack" liegt irgendwie am rekursiven Aufruf..

*/

%petofile([ast_node_signature('Java',NodeType,Arity),ast_node_term('Java',Head)],pe_results('/vorabtest/aggr.pl')).

