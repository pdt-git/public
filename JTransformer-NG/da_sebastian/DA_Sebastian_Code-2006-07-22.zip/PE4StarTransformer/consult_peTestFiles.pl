% Author: Sebastian Lorenz
% Date: 6/12/2006

%Modul f�r Auswertungsergebnisse definieren
:- module(pe,[]).

consultDir(Dir) :-
    absolute_file_name(Dir,AbsDir),
    concat(AbsDir,'/*',SD_WildCard),
    expand_file_name(SD_WildCard,L),
    flag(consult_counter,_,0),
    multiConsult(L),
    flag(consult_counter,N,N),
    write(N), write(' files have been consulted..').
    
multiConsult([]).
multiConsult([H|T]) :- consult(H), flag(consult_counter,N,N+1), multiConsult(T).

%Verzeichnis der Einzelauswertungen consulten..
:- consultDir(pe_results('/einzeltest')).


