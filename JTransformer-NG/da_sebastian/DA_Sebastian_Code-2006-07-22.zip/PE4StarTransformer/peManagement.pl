% Author: Sebastian Lorenz
% Date: 3/27/2006
% Last updated: 6/10/2006

/*
    In dieser Datei befinden sich alle f�r die Mehrfachauswertung ben�tigten
    Pr�dikate.
    
    #### Toplevel-Pr�dikate zur Versionsgenerierung
    -----------------------------------------------
    specialisePTS(+Language,+TargetDirectory)
      Generiert eine Version, spezialisiert auf "Language", im "TargetDirectory"
    specialisePredicate(+Language,+TargetDirectory,+Predicate)
      Wertet ein einzelnes Pr�dikat aus und integriert es in das spezialisierte
      PTS in "TargetDirectory".
      Damit k�nnen nachtr�glich einzelne Auswertungen vorgenommen werden, ohne
      da� das komplette, spezialisierte PTS neu generiert werden mu�.

    #### Einf�ge-Hilfen
    insConfigBase(+Language,+PEFile,+TargetDir)
      F�gt f�r "Language" ausgehend von den Direktiven in peConfigBase
      ausgewerteten Code aus der Datei "PEFile" in "TargetDir" ein.
    insEvalCode(+Pred,+PEFile,+Dir,+File,+Option)

    #### Dateibehandlung/-management
    --------------------------------
    copyFile(+File,+TargetDir)
      Kopiert Datei "File" nach "TargetDir"
    copyDir(+SourceDir,+TargetDir)
      Kopiert den Verzeichnisbaum "SourceDir" nach "TargetDir".
    removeDef(+File,+Pr�dikat/Arity)
      Entfernt die Pr�dikatdefininition aus der Datei "File".
    insertPositions(+SourceFile, +TargetFile)
      Inserts the code fragments defined by positions/2 from "SourceFile"
      in "TargetFile" at the position denoted by targetPosition/2.
    insertDef(+SourceFile, +TargetFile, +Position)
      F�gt den kompletten Code aus "SourceFile" zu "TargetFile" an "Position" hinzu.
    insertCode(+Code, +TargetFile, +Position)
      F�gt "Code" zur Datei "TargetFile" an "Position" hinzu.
    insertCodeAtStart(+TargetFile, +Code)
      F�gt "Code" an Anfang der Datei "TargetFile" ein.
    findSubPEPreds(+Pred,-L)
      Ermittelt alle Pr�dikate, die im K�rper von Sub aufgerufen werden und
      nicht built-in sind.
    getSubPredPositions(+PEFile,+Type,+SubPreds)
      Merkt die Positionen der Pr�dikate in Liste "SubPreds" vor, wenn
      sie f�r den Kopiervorgang in Frage kommen.
      
 */

 /* In "positions" ist jeweils die Start- und die Endposition gespeichert in
  * folgendem Format:
  *   positions('$stream_property'(CharacterCount,LineNumber,CharacterInLine),CharacterEnd)
 */
:- dynamic(positions/2).
:- dynamic(deletePositions/2).
:- dynamic(targetPosition/2).

%bindArgs/3 wird bei der Auswertung unverh�ltnism��ig gro�. Auswertung vorerst unterbunden..
:- assert(st_pred_expansion(bindArgs(_,_,_))).
:- assert(st_pred_expansion(java_fq(_))).


/* specialisePTS(+Language,+TargetDirectory)
 *   Toplevel-predicate for the generation of a specialised version of
 *   the program-transformation-system StarTransformer for "Language".
 *   The generated version is written to TargetDirectory.
 *     example: specialisePTS('Java','d:/ptetest/').
 */
specialisePTS(Language,TargetDirectory) :-
    %ST_Directory = 'g:/da/work/startransformer',
    absolute_file_name(st_dir(''),ST_Directory),
    absolute_file_name(TargetDirectory,AbsTargetDirectory),
    copyDir(ST_Directory,AbsTargetDirectory),                 %make a copy of StarTransformer
    concat(AbsTargetDirectory,'auswertungen.pl',PE_TempFile), %tempfile for pe results
    %find directives of peConfigBase/3
    findall(Pred,peConfigBase(Language,Pred,_),PEListSimple),
    %finde directives and input bindings of peConfigBase/4
    findall(Pred,peConfigBase(Language,Pred,Inputs,_),PEListWithInputs),
    findall(Inputs,peConfigBase(Language,Pred,Inputs,_),PEListInputs),
    %combine pe-directives
    append(PEListSimple,PEListWithInputs,PEList),
    %combine pe-input bindings
    append(PEListSimple,PEListInputs,PEInputs),
    peitofile(PEList,PEInputs,PE_TempFile),
    %Die Auswertungsdatei in Modul "pe" consulten
    insertCodeAtStart(PE_TempFile,':- module(pe,[]).\n\n'),
    consult(PE_TempFile),
    insConfigBase(Language,PE_TempFile,AbsTargetDirectory).

/* specialisePredicate(+Language,+TargetDirectory,+Predicate)
 *   Wertet ein einzelnes Pr�dikat aus und integriert es in das spezialisierte
 *   PTS in "TargetDirectory".
 *   Damit k�nnen nachtr�glich einzelne Auswertungen vorgenommen werden, ohne
 *   da� das komplette, spezialisierte PTS neu generiert werden mu�.
 *     example: specialisePredicate('Java','d:/ptetest020706/',ast_node_argument('Java',_,_)).
 */
specialisePredicate(Language,TargetDirectory,Predicate) :-
    absolute_file_name(TargetDirectory,AbsTargetDirectory),
    exists_directory(AbsTargetDirectory),
    functor(Predicate,Functor,_),
    concat(Functor,'_pe.pl',TempFile),
    concat(AbsTargetDirectory,TempFile,PE_TempFile),        %PE_TempFile = Pfad (c:/test/pe/) + Datei (ast_node_argument_pe.pl)
    peConfigBase(Language,Predicate,File),                  %Hole Zieldatei "File"
    petofile(Predicate,PE_TempFile),                        %Einzelauswertung f�r "Predicate"
    insertCodeAtStart(PE_TempFile,':- module(pe,[]).\n\n'),
    consult(PE_TempFile),                                   %Ausgewertete Datei in pe-Modul laden
    concat(AbsTargetDirectory,File,FileToInsert),
    exists_file(FileToInsert),
    insEvalCode(Predicate,PE_TempFile,AbsTargetDirectory,File,complete).

/*##############################################################################
Hilfspr�dikate f�r Testauswertungen
################################################################################*/

peSingleFilesJava :-
    peConfigBase('Java',Term,_),
    functor(Term,Functor,_),
    concat(Functor,'.pl',FuncPl),
    concat('/einzeltest/',FuncPl,Complete),
    absolute_file_name(pe_results(Complete),N),
    write(N),nl,
    petofile(Term,pe_results(Complete)),
    fail.
peSingleFilesJava.

peOneFileJava :-
    findall(Pred,peConfigBase('Java',Pred,_),PEListSimple),
    %finde directives and input bindings of peConfigBase/4
    findall(Pred,peConfigBase('Java',Pred,Inputs,_),PEListWithInputs),
    findall(Inputs,peConfigBase('Java',Pred,Inputs,_),PEListInputs),
    %combine pe-directives
    append(PEListSimple,PEListWithInputs,PEList),
    %combine pe-input bindings
    append(PEListSimple,PEListInputs,PEInputs),
    peitofile(PEList,PEInputs,pe_results('/einzeltest/auswertungen.pl')).


/*##############################################################################
Einf�ge-Hilfen
################################################################################*/

/* insConfigBase(+Language,+PEFile,+TargetDir)
 *   F�gt f�r "Language" ausgehend von den Direktiven in peConfigBase
 *   ausgewerteten Code aus der Datei "PEFile" in "TargetDir" ein.
 */
insConfigBase(Language,PEFile,TargetDir) :-
    peConfigBase(Language,Pred,TargetFile),
      %concat(TargetDir,TargetFile,Target),
      insEvalCode(Pred,PEFile,TargetDir,TargetFile,complete),
      write(Pred),write(' specialised for '),write(Language), write(' partially evaluated and inserted..'),nl,
    fail.
insConfigBase(_,_,_).

/* insEvalCode(+Pred,+File,+Option)
 *   F�gt den ausgewerteten Code von "Pred" in "File" ein.
 *   Option ist entweder complete oder peonly.
 *   Bei peonly wird das Weiterleitungspr�dikat nicht kopiert!
 */
insEvalCode(Pred,PEFile,TargetDir,TargetFile,Option) :-
    concat(TargetDir,TargetFile,File),
    absolute_file_name(File,AbsFile),
    exists_file(AbsFile),
    PETerm = (pe:Pred),                 %Name im Auswertungsmodul
    clause(PETerm,Body),                %Body ermitteln
    %Positionen f�r Pr�dikat und Auswertungspr�dikat ermitteln.
    retractall(positions(_,_)),
    (Option == complete ->
      getPositions(PEFile,Pred,positions);true
    ),
    getPositions(PEFile,Body,positions),
    BodyPE = (pe:Body),
    findSubPEPreds(BodyPE,SubPreds),
    getSubPredPositions(PEFile,positions,SubPreds),
    %listing(positions),
    %Zielposition ermitteln -> der Punkt, wo Pr�dikat zum ersten Mal auftaucht
    retractall(targetPosition(_,_)),
    getFirstPosition(AbsFile,Pred),
    %listing(targetPosition),
    %Ursprungsdatei ausfindig machen:
    pclause_consult(Pred,_,RemFile),
    absolute_file_name(st_dir(''),STDirectory),    %StarTransformer Directory holen
    concat(STDirectory,RemainingPath,RemFile),
    concat(TargetDir,RemainingPath,FileToRemPred), %Datei in ST-Kopie ausfindig machen
    %removeDef(AbsFile,Pred),
    removeDef(FileToRemPred,Pred),            %Urspr�ngliche Definition l�schen
    insertPositions(PEFile,AbsFile).          %Neue Definitionen einf�gen

/* getSubPredPositions(+PEFile,+Type,+SubPreds)
 *   Merkt die Positionen der Pr�dikate in Liste "SubPreds" vor, wenn
 *   sie f�r den Kopiervorgang in Frage kommen.
 */
getSubPredPositions(_,_,[]).
getSubPredPositions(PEFile,Type,[H|T]) :-
    %Voraussetzung: es gibt kein direktes, �quivalentes Auswertungspr�dikat
    findall(Body,
                (
                  peConfigBase(_,Pred,_),
                  PEPred = (pe:Pred),
                  clause(PEPred,Body)
                ),PredList),
   \+ member(H,PredList),
   !,
   getPositions(PEFile,H,Type),
   getSubPredPositions(PEFile,Type,T).
getSubPredPositions(PEFile,Type,[_|T]) :- getSubPredPositions(PEFile,Type,T).

/*##############################################################################
Dateimanagement
################################################################################*/


/* copyDir(+SourceDir,+TargetDir)
 *   Kopiert den Verzeichnisbaum mit Wurzel "SourceDir" komplett mit allen
 *   Dateien und Unterverzeichnissen nach "TargetDir".
 */
copyDir(SourceDir,TargetDir) :-
    make_directory(TargetDir),
    concat(SourceDir,'/*',SD_WildCard),
    expand_file_name(SD_WildCard,L),        %L = Liste der Elemente im Verzeichnis; Dateien und Verzeichnisse
    processFileList(L,TargetDir).


/* processFileList(+List,+TargetDirectory)
 *   Hilfspr�dikat f�r copyDir/2
 *   Bekommt eine Liste von Dateien und Unterverzeichnissen und initiiert
 *   die n�tige Behandlung dieser zwei Typen.
 */
 
processFileList([],_).
 
%Fall 1: Listenelement ist ein Verzeichnis -> rekursiv Verzeichnisbehandlung aufrufen
processFileList([H|T],TDir) :-
    exists_directory(H),
    !,
    file_base_name(H,DirBase),
    concat(TDir,'/',TDirSlash),
    concat(TDirSlash,DirBase,NewTDir),
    copyDir(H,NewTDir),
    processFileList(T,TDir).

%Fall 2: Sonst ist das Listenelement eine Datei -> Kopieraktion
processFileList([H|T],TDir) :-
    copyFile(H,TDir),
    processFileList(T,TDir).
    

/* copyFile(+File,+TargetDir)
 *   Copies "File" to "TargetDir".
 *   TODO: More sophisticated error handling
 */
copyFile(File,TargetDir) :-
    absolute_file_name(File, AbsFile),
    absolute_file_name(TargetDir,AbsTargetDir),
    exists_file(AbsFile),
    exists_directory(AbsTargetDir),
    file_base_name(AbsFile,FileWODir),
    concat(AbsTargetDir,'/',AbsTargetDir2),
    concat(AbsTargetDir2,FileWODir,CompleteTarget),
    open(AbsFile,read,SourceStream,[type(binary)]),
    open(CompleteTarget,write,TargetStream,[type(binary)]),
    copy_stream_data(SourceStream,TargetStream),
    close(TargetStream),
    close(SourceStream).
    

/*
 * removeDef(+File,+ToDelete)
 *   Entfernt die Pr�dikatdefininition von ToDelete aus der Datei File.
 *   ToDelete ist von der Form "Pr�dikatname/Arity"
 */
removeDef(File,ToDelete) :-
    nonvar(File),
    absolute_file_name(File,AbsFName),
    retractall(deletePositions(_,_)),
    getPositions(File,ToDelete,deletePositions),
    %listing(positions),
    %Schritt 2: Tats�chliches L�schen der ermittelten Positionen
    open(AbsFName,update,WriteStream,[type(binary)]),
    deletePosition(WriteStream),
    close(WriteStream).


/* insertDef(+SourceFile, +TargetFile, +Position)
 *   F�gt den kompletten Code aus "SourceFile" zur Datei "TargetFile" an Position
 *   "Position"hinzu
 */
insertDef(SourceFile,TargetFile,Position) :-
    nonvar(SourceFile),
    nonvar(TargetFile),
    nonvar(Position),
    absolute_file_name(SourceFile,SourceAbsFName),
    absolute_file_name(TargetFile,TargetAbsFName),
    concat(TargetAbsFNameohnepl,'.pl',TargetAbsFName),
    concat(TargetAbsFNameohnepl,'.tmp',TempFile),

    %--Alles ab der gew�hlten Position in tempor�re Datei sichern:
    open(TargetAbsFName,read,TargetStream,[type(binary)]),
    open(TempFile,write,TempStream,[type(binary)]),
    set_stream_position(TargetStream,Position),                %Position setzen
    copy_stream_data(TargetStream,TempStream),
    close(TempStream),
    close(TargetStream),

    %--Daten aus SourceFile ab Position nach TargetFile schreiben:
    open(SourceAbsFName,read,SourceStream,[type(binary)]),
    open(TargetAbsFName,update,TargetStream,[type(binary)]),
    set_stream_position(TargetStream,Position),
    copy_stream_data(SourceStream,TargetStream),
    stream_property(TargetStream,position(EndPos)),
    close(TargetStream),
    close(SourceStream),

    
    %--Daten ais TempFile an TargetFile anh�ngen
    open(TargetAbsFName,update,TargetStream,[type(binary)]),
    open(TempFile,read,TempStream,[type(binary)]),
    set_stream_position(TargetStream,EndPos),
    copy_stream_data(TempStream,TargetStream),
    close(TempStream),
    close(TargetStream),

    %--Clean-Up
    delete_file(TempFile).

/* insertPositions(+SourceFile, +TargetFile)
 *   Inserts the code fragments defined by positions/2 from "SourceFile"
 *   in "TargetFile" at the position denoted by targetPosition.
 *   Subpredicates:
 *     saveFromPoint/3
 *     restoreAtPoint/3
 */
 %case 1: delete old definition and insert at this point new evaluated data
insertPositions(SourceFile,TargetFile) :-
    nonvar(SourceFile),
    nonvar(TargetFile),
    absolute_file_name(SourceFile,SourceAbsFName),
    absolute_file_name(TargetFile,TargetAbsFName),
    concat(TargetAbsFNameohnepl,'.pl',TargetAbsFName),
    concat(TargetAbsFNameohnepl,'.tmp',TempFile),

    targetPosition(Position,_),
    saveFromPoint(TargetAbsFName,Position,TempFile),
    
    %--Daten aus SourceFile ab Position nach TargetFile schreiben:
    open(SourceAbsFName,read,PosSourceStream,[type(binary)]),
    open(TargetAbsFName,update,PosTargetStream,[type(binary)]),
    set_stream_position(PosTargetStream,Position),
    copyPositions(PosSourceStream,PosTargetStream),
    stream_property(PosTargetStream,position(EndPos)),
    close(PosTargetStream,[force(true)]),
    close(PosSourceStream,[force(true)]),

    %--Daten ais TempFile an TargetFile anh�ngen
    restoreAtPoint(TargetAbsFName,EndPos,TempFile),

    %--Clean-Up
    delete_file(TempFile),
    !.
    
    
%case 2: no definition in TargetFile -> append evaluated data at end of file
insertPositions(SourceFile,TargetFile) :-
    absolute_file_name(SourceFile,SourceAbsFName),
    absolute_file_name(TargetFile,TargetAbsFName),
    exists_file(SourceAbsFName),
    exists_file(TargetAbsFName),
    open(SourceAbsFName,read,PosSourceStream,[type(binary)]),
    open(TargetAbsFName,append,PosTargetStream,[type(binary)]),
    copyPositions(PosSourceStream,PosTargetStream),
    close(PosTargetStream,[force(true)]),
    close(PosSourceStream,[force(true)]).
    
    
/* saveFromPoint(+TargetFileName,+Position,+TempFileName)
 *   Saves the remaining content of "TargetFileName" from "Position" in
 *   a temporary file "TempFileName".
 */
saveFromPoint(TargetFileName,Position,TempFileName) :-
    %--Alles ab der gew�hlten Position in tempor�re Datei sichern:
    open(TargetFileName,read,TargetStream,[type(binary)]),
    set_stream_position(TargetStream,Position),                %Position setzen
    open(TempFileName,write,TempStream,[type(binary)]),
    copy_stream_data(TargetStream,TempStream),
    close(TempStream,[force(true)]),
    close(TargetStream,[force(true)]).
    
/* restoreAtPoint(+TargetFileName,+Position,+TempFileName)
 *   Copies the whole content of "TempFileName" to "TargetFileName"
 *   starting at "Position".
 */
restoreAtPoint(TargetFileName,Position,TempFileName) :-
    open(TargetFileName,update,TargetStream,[type(binary)]),
    set_stream_position(TargetStream,Position),
    open(TempFileName,read,TempStream,[type(binary)]),
    copy_stream_data(TempStream,TargetStream),
    close(TempStream,[force(true)]),
    close(TargetStream,[force(true)]).

copyPositions(SourceStream,TargetStream) :-
    positions(Position,EChar),
       Position = '$stream_position'(SChar,_,_,_),
       Len is (EChar - SChar),
       set_stream_position(SourceStream,Position),
       copy_stream_data(SourceStream,TargetStream,Len),
       string_to_list('. \n',CharList),       %"Code" in Liste von Character-Codes konvertieren
       writeCharsToFile(TargetStream,CharList), %Punkt am Ende wird nicht mitkopiert..
     fail.

copyPositions(_,_).

    
/* insertCode(+Code, +TargetFile, +Position)
 *   F�gt "Code" zur Datei "TargetFile" an Position
 *   "Position"hinzu
 */
insertCode(TargetFile,Position,Code) :-
    nonvar(Code),
    nonvar(TargetFile),
    nonvar(Position),

    absolute_file_name(TargetFile,TargetAbsFName),
    concat(TargetAbsFNameohnepl,'.pl',TargetAbsFName),
    concat(TargetAbsFNameohnepl,'.tmp',TempFile),

    %--Alles ab der gew�hlten Position in tempor�re Datei sichern:
    open(TargetAbsFName,read,TargetStream,[type(binary)]),
      stream_property(TargetStream,position(XPos)), write(XPos),
    open(TempFile,write,TempStream,[type(binary)]),
    set_stream_position(TargetStream,Position),                %Position setzen
    copy_stream_data(TargetStream,TempStream),
    close(TempStream),
    close(TargetStream/*,[force(true)]*/),

    %--Code ab Position nach TargetFile schreiben:
    open(TargetAbsFName,update,TargetStream,[type(binary)]),
    set_stream_position(TargetStream,Position),
    string_to_list(Code,CharList),       %"Code" in Liste von Character-Codes konvertieren
    writeCharsToFile(TargetStream,CharList),
    stream_property(TargetStream,position(EndPos)),
    close(TargetStream),

    %--Daten aus TempFile an TargetFile anh�ngen
    open(TargetAbsFName,update,TargetStream,[type(binary)]),
    open(TempFile,read,TempStream,[type(binary)]),
    set_stream_position(TargetStream,EndPos),
    copy_stream_data(TempStream,TargetStream),
    close(TempStream),
    close(TargetStream),

    %--Clean-Up
    delete_file(TempFile).

writeCharsToFile(Stream,[H|T]) :- put_code(Stream,H), writeCharsToFile(Stream,T).
writeCharsToFile(_,[]).

/* insertCodeAtStart(+TargetFile, +Code)
 *   F�gt "Code" an Anfang der Datei "TargetFile" ein.
 */
insertCodeAtStart(TargetFile, Code) :- insertCode(TargetFile,'$stream_position'(0, 1, 0, 0),Code).


/* deletePosition(+Stream)
 *   Deletes in "Stream" all positions that are listed in positions/2
 *   (- used in removeDef/2)
 */
deletePosition(Stream) :-
    getNextPosition(PosToDelete,CharactersToDelete,deletePositions),
      deletePart(Stream,PosToDelete,CharactersToDelete),
    fail.
    
deletePosition(_).


/* deletePart(+Stream,+PosToDelete,+CharactersToDelete)
 *   Deletes in "Stream" #CharactersToDelete Characters, starting from
 *   "PosToDelete"
 *   (- used in removeDef/2)
 */
deletePart(Stream, PosToDelete, CharactersToDelete) :-
    flag(counter,_,CharactersToDelete),
    set_stream_position(Stream,PosToDelete),
    repeat,
      put_char(Stream,' '),
      flag(counter,Co,Co-1),
    (Co == 0),
    !.
    
deletePart(_,_,_).


/* getNextPosition(-PosToDelete,-CharactersToDelete)
 *   Returns the next starting position and the number of Characters
 *   which should be deleted thenceforth.
 *   (- used in removeDef/2)
 */
getNextPosition(PosToDelete,CharactersToDelete,Func) :-
    PosPred =.. [Func,PosToDelete,EndCount],
    PosPred,
    %positions(PosToDelete,EndCount),
    PosToDelete = ('$stream_position'(BeginCount,_,_,_)),
    CharactersToDelete is (EndCount - BeginCount).


/* getPositions(+File,+Pred,+ErgFunc)
 *   Finds all occurences of "Pred" (=Predname/Arity or Predname(..args..)) in "File" and records
 *   the corresponding positions by assertings "positions/2"-facts
 *
 *   Subpredicate:
 *     findPositions(+Pred,+Term,+Pos,+SubPos)
 */
getPositions(File,Pred,ErgFunc) :-
    exists_file(File),
    Pred = (_ / _),
    absolute_file_name(File,AbsFName),
    open(AbsFName,read,InputStream,[type(binary)]),
    repeat,
      read_term(InputStream,Term,[term_position(Pos),subterm_positions(SubPos)]),
      findPositions(Pred,Term,Pos,SubPos,ErgFunc),
    Term == end_of_file,
    !,
    close(InputStream).

%create func/arity pair and try again..
getPositions(File,Pred,ErgFunc) :-
    functor(Pred,Func,Arity),
    Pair = (Func / Arity),
    getPositions(File,Pair,ErgFunc).

%case 1: rules
findPositions(Pred,Term,Pos,SubPos,ErgFunc) :-
    Term = (Head :- _),
    functor(Head,Func,Arity),
    Funcar = (Func / Arity),
    ((Pred == Funcar) ->
      (SubPos = term_position(_,EndPos,_,_,_),
      NewTerm =.. [ErgFunc,Pos,EndPos],
      assert(NewTerm),!
    );!
    ).

%case 2: facts
findPositions(Pred,Term,Pos,SubPos,ErgFunc) :-
    functor(Term,Func,Arity),
    Funcar = (Func / Arity),
    ((Pred == Funcar) ->
      (SubPos = term_position(_,EndPos,_,_,_),
      NewTerm =.. [ErgFunc,Pos,EndPos],
      assert(NewTerm),!
    );!
    ).

findPositions(_,_,_,_,_).

getFirstPosition(File,Pred) :-
    Pred = (_ / _),
    nonvar(File),
    absolute_file_name(File,AbsFName),
    open(AbsFName,read,InputStream,[type(binary)]),
    repeat,
      read_term(InputStream,Term,[term_position(Pos),subterm_positions(SubPos)]),
      %findPositions(Pred,Term,Pos,SubPos),
      (Term = (Head :- _); Head = Term),
      functor(Head,Func,Arity),
      Funcar = (Func / Arity),
    (Term == end_of_file; Pred == Funcar),
    !,
    ((Pred == Funcar) ->
          (
           SubPos = term_position(_,EndPos,_,_,_),
           assert(targetPosition(Pos,EndPos))
          );true
     ),
    close(InputStream).


%create func/arity pair and try again..
getFirstPosition(File,Pred) :-
    functor(Pred,Func,Arity),
    Pair = (Func / Arity),
    getFirstPosition(File,Pair).
    
/**
 *  conj2list(+Conjunction, ?List) or
 *  conj2list(?Conjunction, +List)
 *
 * Converts a conjunction to a list or vice-versa.
 * May not be called with all arguments free!
 */
conj2list(true,[]) :-            % true
   !.
conj2list((A,B), [A|List]) :-   % conjunction
   conj2list(B, List),
   !.
conj2list(One,[One]) .          % single literal different from "true"


/* findSubPEPreds(+Pred,-L)
 *   Ermittelt alle Pr�dikate, die im K�rper von Sub aufgerufen werden und
 *   nicht built-in sind.
 */
findSubPEPreds(Pred,L) :-
    findall(B,clause(Pred,B),Body),
    %conj2list(Body,BodyList),
    checkList(Body,NewList),
    list_to_set(NewList,L),
    !.
    
findSubPEPreds(_,[]).

checkList([],[]) :- !.
checkList([H1|T1],L) :-
  H1 = (\+ X),
  conj2list(X,XList),
  checkList(XList,L1),
  checkList(T1,L2),
  append(L1,L2,L),
  !.
checkList([H|T],L) :-
  H = (_,_),
  conj2list(H,HList),
  checkList(HList,L1),
  checkList(T,L2),
  append(L1,L2,L),
  !.
checkList([H|T],L) :-
  H = (H1;H2),
  conj2list(H1,H1List),
  conj2list(H2,H2List),
  checkList(H1List,L1),
  checkList(H2List,L2),
  append(L1,L2,LTemp),
  checkList(T,L3),
  append(L3,LTemp,L),
  !.
checkList([H1|T1],L) :-
  predicate_property(H1,built_in),
  %clause(H1,Body),write(Body),nl,
  checkList(T1,L),
  !.
checkList([H1|T1],[H1|T2]) :-
  functor(H1,Functor,Arity),
  \+ current_predicate((Functor / Arity)),   %wenn's ein spezielles pe:..-Pr�dikat ist
  checkList(T1,T2),!.                        %-> dann in Liste aufnehmen
checkList([_|T1],L) :-
  checkList(T1,L),!.





