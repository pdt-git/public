% Author: Sebastian Lorenz
% Date: 2/9/2006

/*************************************************************************
Load Mixtus
**************************************************************************/

:- consult(mixtus('anti_unify')).
:- consult(mixtus('bagof8c')).
:- consult(mixtus('breakout8')).
:- consult(mixtus('builtin2')).
:- consult(mixtus('can_fold8c')).
:- consult(mixtus('cl')).
:- consult(mixtus('cleanup_conj2')).
:- consult(mixtus('cyclic')).
:- consult(mixtus('delayoutput')).
:- consult(mixtus('erase8')).
:- consult(mixtus('evaluable8c')).
:- consult(mixtus('evaluableg8')).
:- consult(mixtus('executable')).
:- consult(mixtus('gs1')).
:- consult(mixtus('instance2')).
:- consult(mixtus('loop8a')).
:- consult(mixtus('may_cut9')).
:- consult(mixtus('new_literal')).
:- consult(mixtus('ok_determ')).
:- consult(mixtus('p8f')).
:- consult(mixtus('pclause3')).
:- consult(mixtus('pconsult4')).
:- consult(mixtus('propagate2')).
:- consult(mixtus('remove_last7')).
:- consult(mixtus('reset_all8a')).
:- consult(mixtus('residue')).
:- consult(mixtus('save8c')).
:- consult(mixtus('set')).
:- consult(mixtus('solsand2')).
:- consult(mixtus('state8c')).
:- consult(mixtus('to_disj4')).
:- consult(mixtus('transform8d')).
:- consult(mixtus('vars8')).
:- consult(mixtus('varstructs')).
:- consult(mixtus('write8c')).
:- consult(mixtus('isp')).

/*************************************************************************
MIXTUS SETTINGS
<settings.> lists all settings if Mixtus is loaded.
see http://www.sics.se/isl/mixtus.1.html
**************************************************************************/


:- set(maxnondeterm,100).   %If a predicate generated has more than maxnondeterm clauses, it will not be unfolded.

%Stoplisten definieren

/*************************************************************************
HELPER PREDICATES FOR MIXTUS
**************************************************************************/

/*
listAsserted/0
lists all interal dynamic predicates from Mixtus
*/
listAsserted :- listing(pclause_consult/3),   %pconsult4: 9 matches
                listing(pdynamic/2),          %pconsult4: 6 matches, write8c: 2 matches
                listing(p_op/4),              %pconsult4: 5 matches, write8c: 1 match
                listing(pmultifile/2),        %pconsult4: 4 matches
                listing(static_struct/1),     %pconsult4: 4 matches, loop8a: 1 match
                listing(pblock_consult/2),    %pconsult4: 7 matches
                listing(mixtus_term_expansion/3).      %pconsult4: 5 matches


/*
petofile(+Query,+Filename)
Die Anfrage "Query" wird mit Mixtus partiell ausgewertet und das Ergebnis in
"Filename" gespeichert. Dabei k�nnen in "Filename" auch Aliase verwendet werden
*/
petofile(Query,Filename) :-
            absolute_file_name(Filename,AbsFilename),
            pe(Query,AbsFilename).
            
peitofile(Query,Inputs,Filename) :-
            absolute_file_name(Filename,AbsFilename),
            pei(Query,Inputs,AbsFilename).
            
/*
getPredicates(+File,-PredList)
Listet auf der Basis von den in Mixtus geladenen Daten alle in der Datei
"File" enthaltenen Pr�dikate in "PredList" auf.
*/
getPredicates(File,PredList) :-
               absolute_file_name(File,AbsFileName),
               findall(A,pclause_consult(A,_,AbsFileName),PredList).


/* declare predicates which should not be used for expansion in higher
   layers of the transformation system
*/
lockEvaluation :-
    assert(st_pred_expansion(ast_node_signature('Java',_,_))),
    assert(st_pred_expansion(ast_node_signature('JavaAttributes',_,_))),
    assert(st_pred_expansion(ast_node_term('Java',_))),
    assert(st_pred_expansion(ast_node_argument('Java',_,_))),
    assert(st_pred_expansion(get_ast_node_term('Java',_,_))),
    assert(st_pred_expansion(get_ast_node_enclosing('Java', _, _))),
    assert(st_pred_expansion(get_ast_node_parent('Java', _, _))),
    assert(st_pred_expansion(get_ast_node_label('Java', _, _))),
    assert(st_pred_expansion(get_ast_sub_tree('Java',_,_))).
    
    


