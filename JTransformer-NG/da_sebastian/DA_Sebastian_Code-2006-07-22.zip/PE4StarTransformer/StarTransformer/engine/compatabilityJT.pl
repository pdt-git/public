% Author: Sebastian Lorenz
% Date: 7/6/2006

/* Compatibility file for the transition between JTransformer and StarTransformer.
 * Performs a mapping between old JT-Predicates and new generalised ST-Predicates
 */


%/engine/ast/java/javaAstOperations/tree_queries.pl
enclosing(A,B) :- get_ast_node_enclosing('Java',A,B).
getTerm(A,B)   :- get_ast_node_term('Java',A,B).

%/st.java/pl/org/cs3/java/astSpec/javaFactBase.pl
tree(A,B,C)          :- tree('Java',A,B,C).
tree(Lang,ID,PID,Functor) :-
    ast_node_argument_value(Lang, NodeTerm, Functor, id, ID),
    ast_node_argument_value(Lang, NodeTerm, Functor, parent, PID),
    NodeTerm.


treeSignature(A,B)   :- ast_node_signature('Java',A,B).
attribSignature(A,B) :- ast_node_signature('JavaAttributes',A,B).


%/engine/apply/garbage_collection.pl
deleteTree(A)                         :- delete_ast_node('Java',A).
retractTree(A)                        :- retract_ast_node('Java',A).
retractTrees(A)                       :- retract_ast_nodes('Java',A).
deepDeleteIfNotReferenced(A,B)        :- deepDeleteIfNotReferenced('Java',A,B).
deepDeleteIfParentCorrect('Java',A,B) :- deepDeleteIfParentCorrect('Java',A,B).
garbageCollection                     :- garbageCollection('Java').
deleteSubElements(A,B,C)              :- deleteSubElements('Java',A,B,C).

%/engine/ast/

%transaction.pl
markEnclAsDirty(A) :- markEnclAsDirty('Java',A).

%ct_apply.pl
add(A)     :- add('Java',A).
delete(A)  :- delete('Java',A).
replace(A) :- replace('Java',A).

%tree_modifications.pl
replaceId(A,B,C)         :- replaceId('Java',A,B,C).
deepDelete(A)            :- deepDelete('Java',A).
set_encl_method(A,B)     :- set_ast_node_enclosing(_Lang,A,B).
rec_set_encl_method(A,B) :- rec_set_ast_node_enclosing(_Lang,A,B).
rec_set_parent(A,B)      :- rec_set_ast_node_parent(_Lang,A,B).
set_parent(A,B)          :- set_ast_node_parent(_Lang,A,B).

%tree_queries.pl
tree_attributes(Lang,A,B,C) :- tree_attributes(Lang,A,B,C).

%tree_checks.pl
checkConstraints(A,B)       :- checkConstraints('Java',A,B).
checkConstraints(A,B,C,D,E) :- checkConstraints('Java',A,B,C,D,E).
checkConstraintList(A,B)    :- checkConstraintList('Java',A,B).
checkTreeLinks(A,B)         :- checkTreeLinks('Java',A,B).
checkTreeLinks(A,B,C,D)     :- checkTreeLinks('Java',A,B,C,D).
checkParentLink(A,B,C)      :- checkParentLink('Java',A,B,C).
checkTreeLinks              :- checkTreeLinks('Java').


%clone.pl
cloneTree(A,B)     :- cloneTree('Java',A,B).
cloneTree(A,B,C,D) :- cloneTree('Java',A,B,C,D).
clone(A,B,C,D )    :- clone('Java',A,B,C,D).


