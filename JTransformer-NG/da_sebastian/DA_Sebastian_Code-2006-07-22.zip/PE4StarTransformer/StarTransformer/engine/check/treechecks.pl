:- dynamic constraintErrorMsg/1.

/**
  * violatedContraints(+Id, -ErrorMsg)
  */
violatedContraints(Id, ErrorMsg):-
    retractall(constraintErrorMsg(_)),
    !,
    checkTreeLinks('Java',Id, assertErrorMsgs),
    constraintErrorMsg(ErrorMsg).

setUp(violatedContraints):-
    assert(classDefT(a,b,c,[d])).
test(violatedContraints):-
    assert_true(findall(M,violatedContraints(a,M),List)),
    assert_true(length(List,4)).     
tearDown(violatedContraints):-
    retractall(classDefT(a,b,c,[d])).

assertErrorMsgs(ErrorMsg):-
    assert(constraintErrorMsg(ErrorMsg)).
/*
    checkTreeLinks

    Testet alle trees auf korrekte Referenzierung durch den parent tree.
*/

checkTreeLinks(Lang) :- findall(_id, checkTreeLinks(Lang,_id,write), _l).

/*
    checkTreeLinks(+Id, +ErrorHandler)

    Tests the constraints of parent, encl and referencing trees of id.
    Provide an ErrorHandler predicate to handle the error message.
    E.g. checkTreeLinks(1001,write) will write out all error messages to the console.
*/

checkTreeLinks(Lang,_id,ErrorHandler) :-
    %tree(_id, _p, _ptype),
    get_ast_node_parent(Lang,_id,_p),
    get_ast_node_label(Lang,_id,_ptype),
    checkConstraints(Lang,_id,ErrorHandler),
    checkParentLink(Lang,_p,_id,ErrorHandler),
    %sub_trees(_id, _subs),
    get_ast_node_sub_trees(Lang,_id,_subs2),
    flatten(_subs2,_subs),
    vars_bound(_id,_subs,ErrorHandler),
    checkTreeLinks(Lang,_id, _ptype, _subs,ErrorHandler).

checkTreeLinks(_,_, _, [],_).
checkTreeLinks(Lang,_pid, _ptype, [_h|_t],ErrorHandler) :-
    %tree(_h, _p, _stype),
    get_ast_node_parent(Lang,_h,_p),
    get_ast_node_label(Lang,_h,_stype),
    !,
    subtreeError(_h, _stype, _p, _pid, _ptype,ErrorHandler),
    checkTreeLinks(Lang,_pid, _ptype, _t,ErrorHandler).

checkTreeLinks(Lang,_pid, _ptype, [_h|_t],ErrorHandler) :-
     sformat(Msg,'referenced subtree ~a from ~a ~a does not exist.~n',[_h, _ptype, _pid]),
         Term =.. [ErrorHandler,Msg], 
         call(Term),
     checkTreeLinks(Lang,_pid, _ptype, _t,ErrorHandler).


/* checkParentLink(+Lang, ParentId, Id, ErrorHandler)
 */
 
%Case1: Toplevel-Element, which has no parentID (e.g. packageT(ID,_))
checkParentLink(Lang,_,ID,_):-
    %packageT(ID,_),
    checkIfTopLevel(Lang,ID),
    !.

%Case2: Parent=null
checkParentLink(_,null,_,_):-
        !.
%Case3: java-specific..
checkParentLink(Lang,NODE, CHILD,_) :-
    %blockT(CHILD, _,_,_),
    %tryT(NODE, _,_,_,_, CHILD),
    ast_node_argument(Lang,Node,blockT,id,CHILD),
    Node,
    get_ast_node_argument(Lang,tryT,NODE,finalize,CHILD),
    !.
        
checkParentLink(Lang,Node,Child,_):-
    %sub_trees(Node,Subs),
    get_ast_node_sub_trees(Lang,Node,Subs),
    member(Child,Subs),
    !.

%Error
checkParentLink(_,Node,Child,ErrorHandler):-
    sformat(Msg,'node ~a is not a subtree of its parent ~a.~n',[Child,Node]),
         Term =.. [ErrorHandler,Msg], 
         call(Term).

vars_bound(_,[],_).
vars_bound(_id,[_sub|_subs],ErrorHandler):-
    nonvar(_sub),
    !,
    vars_bound(_id,_subs,ErrorHandler).
    
vars_bound(_id,[_sub|_],ErrorHandler):-
    sformat(Msg,'referenced id ~a from ~a is not bound.~n',[_sub, _id]),
         Term =.. [ErrorHandler,Msg], 
         call(Term),
    fail.

subtreeError(_id, _,   _pid, _pid, _,_) :- !.
% sonderfall, classen haben als parent packages statt toplevel, die sie eigentlich referenzieren
subtreeError(_id, classDefT,   _, _, toplevelT,_) :- !.
subtreeError(_id, _stype, _p, _pid, _ptype,ErrorHandler) :-
    sformat(Msg,'referenced ~a ~a has ~a as parent instead of ~a ~a.~n',[_stype, _id, _p, _ptype, _pid]),
         Term =.. [ErrorHandler,Msg], 
         call(Term).


/*
checkTree(_id):-
   getFieldT(_id,_pid,_encl,_expr,_v2,_v3), 
   printErrorIfNotMethodAndNotField(_encl),
   printErrorIfNotExpressionOrNull(_expr).

   
checkEncl(_id):-selectT(_id,_pid,_encl,_v1,_v2,_v3), printFailure(_id,_encl).
checkEncl(_id):-identT(_id,_pid,_encl,_v1,_v2), notMethodOrField(_encl),printFailure(_id,_encl).

checkEncl(_id):-methodDefT(_id,_pid,_v1,_v2,_v3,_v4,_v5), not(classDefT(_pid,_,_,_)),printFailure(_id,_pid).
checkEncl(_id):-fieldDefT(_id,_pid,_v1,_v2,_v3), not(classDefT(_pid,_,_,_)),printFailure(_id,_pid).

checkEncl(_id):-localDefT(_id,_pid,_encl,_v1,_v2,_v3), not(methodDefT(_encl,_,_,_,_,_,_)),printFailure(_id,_encl).
checkEncl(_id):-paramDefT(_id,_pid,_v1,_v2), not(methodDefT(_pid,_,_,_,_,_,_)),printFailure(_id,_pid).

checkEncl(_id):-classDefT(_id,_pid,_v1,_v2),not(packageT(_pid,_)),printFailure(_id,_pid).
checkEncl(_id):-packageT(_id,_v1),!.
checkEncl(_id):-toplevelT(_id,_pid,_v1,_v2),not(packageT(_pid,_)),printFailure(_id,_pid).

checkEncl(_id):-blockT(_id,_pid,_encl,_v1), notMethodOrField(_encl),printFailure(_id,_encl).

checkEncl(_id):-doLoopT(_id,_pid,_encl,_v1,_v2), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-whileLoopT(_id,_pid,_encl,_v1,_v2),notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-forLoopT(_id,_pid,_encl,_v1,_v2,_v3,_v4),notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-labelT(_id,_pid,_encl,_v1,_v2), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-switchT(_id,_pid,_encl,_v1,_v2), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-caseT(_id,_pid,_encl,_v1), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-synchronizedT(_id,_pid,_encl,_v1,_v2), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-tryT(_id,_pid,_encl,_v1,_v2,_v3),notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-catchT(_id,_pid,_encl,_v1,_v2),notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-ifT(_id,_pid,_encl,_v1,_v2,_v3), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-conditionalT(_id,_pid,_encl,_v1,_v2,_v3),notMethodOrField(_encl),printFailure(_id,_encl).
//format('rt:exec: ~a~n', [_id])
checkEncl(_id):-execT(_id,_pid,_encl,_v1), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-returnT(_id,_pid,_encl,_v1), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-breakT(_id,_pid,_encl,_v1,_v2),notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-continueT(_id,_pid,_encl,_v1,_v2), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-throwT(_id,_pid,_encl,_v1),notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-applyT(_id,_pid,_encl,_v1,_v2,_v3,_v4),notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-newClassT(_id,_pid,_encl,_v1,_v2,_v3,_v4,_v5), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-newArrayT(_id,_pid,_encl,_v1,_v2,_v3), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-assignT(_id,_pid,_encl,_v1,_v2), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-assignopT(_id,_pid,_encl,_v1,_v2,_v3), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-operationT(_id,_pid,_encl,_v1,_v2,_v3),notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-typeCastT(_id,_pid,_encl,_v1,_v2), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-typeTestT(_id,_pid,_encl,_v1,_v2), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-indexedT(_id,_pid,_encl,_v1,_v2),notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-literalT(_id,_pid,_encl,_v1,_v2),notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id):-assertT(_id,_pid,_encl,_v1,_v2),notMethodOrField(_encl),printFailure(_id,_encl).
%checkEncl(_id):-classMembersT(_id,_v1), notMethodOrField(_encl),printFailure(_id,_encl).
checkEncl(_id).

printFailure(_id,_encl):-
        format('encl elem of ~a is ~a but not a method or field (for method: class)~n',[_id,_encl]).
*/

printErrorIfNotMethodAndNotField(_encl):-
        %not(methodDefT(_encl,_,_,_,_,_,_)),
        %not(fieldDefT(_encl,_,_,_,_)),
        \+ get_ast_node_label('Java',_encl,methodDefT),
        \+ get_ast_node_label('Java',_encl,fieldDefT),
        printFailure(_id,_encl),
        !.
printErrorIfNotMethodAndNotField(_).

printErrorIfNotExpressionOrNull(_id):-
    not(isExpression(_id)),
    not(_id = 'null'),
    %tree(_id,_p,_type),
    get_ast_node_parent('Java',_id,_p),
    get_ast_node_label('Java',_id,_type),
    format('the id ~a should bei an expression or null, but it is an ~a~n',[_id,_type]).
printErrorIfNotExpressionOrNull(_).


/**
 * checkConstraints(Lang,ID,ErrorHandler)
 *
 * ErrorHandler is a predicate with arity 1
 * which is evaluated on the error message
 * generated on failure.
 */

checkConstraints(Lang,ID,ErrorHandler):-
    %hole Term
    get_ast_node_term(Lang,ID,Term),
    %Zerlege in Funktor und Argumente
    Term =.. [Functor|Args],
    %Hole Beschr�nkungen f�r die Argumente
    ast_node_def(Lang,Functor,ArgList),
    extractConstraints(ArgList,Constraints),
    %tree_constraints(Functor,Constraints),
    checkConstraints(Lang,Term,Constraints,Args,2,ErrorHandler).
    
%extractConstraints(+ArgumentList,-ExtractedConstraintList)
extractConstraints([],[]).
extractConstraints([ast_arg(_,_,_,Constraint)|T1],[Constraint|T2]) :-
    extractConstraints(T1,T2).

    
checkConstraints(_,_,_,[],_,_).
checkConstraints(Lang,Term,[Constraints | CRest],[Arg|ARest],Pos,ErrorHandler):-
    (
          (checkConstraintList(Lang,Constraints,Arg),!);                %�berpr�fe Constraint, wenn o.k. -> Cut
          printCheckError(Term,Constraints,Arg,Pos,ErrorHandler)   %sonst Fehlermeldung
        ),
        plus(Pos,1,Inc),
    checkConstraints(Lang,Term,CRest,ARest,Inc,ErrorHandler).           %�berpr�fe restliche Argumente


printCheckError(Term,Constraints,Arg,Pos,ErrorHandler):-
    term_to_atom(Term,TermAtom),
    term_to_atom(Constraints,ConstraintsAtom),
    term_to_atom(Arg,ArgAtom),
    sformat(Msg,'ERROR in term: ~a, argument ~a (\'~a\') does not fullfill constraints:~n  ~a~n',
          [TermAtom,Pos,ArgAtom,ConstraintsAtom]),
         MsgTerm =.. [ErrorHandler,Msg], 
         call(MsgTerm),
          
        flush_output.


%Behandlung f�r den Fall, da� das Argument aus einer Liste besteht
%-> verzweige weiter in Einzelbehandlungen..
checkConstraintList(_,_,[]):-!.
checkConstraintList(Lang,Constraints,[H|T]):-
        checkConstraintList(Lang,Constraints,H),
        checkConstraintList(Lang,Constraints,T).

        

/*
checkConstraintList(_,[],_):-!.
checkConstraintList(Constraints,[H|T],Pos):-
    (
          (
            checkConstraints(Constraints,H),
            !
          );
          (
            printCheckError('list',Constraints,H,Pos),
            fail
          )
        ),
        plus(Pos,1,Inc),
    checkConstraintList(Constraints,T,Inc).
*/



/**
 * checks if the type of arg is a member of the Constraint list:
 * e.g.: identT(Arg,...), checkConstraintList([identT],Arg)
 * (checks if functor is a member of the list Constraints )
 */
checkConstraintList(Lang,Constraints,Arg):-
    get_ast_node_label(Lang,Arg,PLASTFact),
    member(PLASTFact,Constraints),
    %tree(_,_,PLASTFact),
    %Wof�r soll dieser Aufruf von Tree gut sein? Durch get_ast_node_label werden sowieso nur g�ltige M�glichkeiten gegeben..
    !.

/**
 * checks if the type of arg is a member of the Constraints list:
 * e.g.: identT(Arg,...), checkConstraintList([expressionType],Arg)
 */
checkConstraintList(Lang,Constraints,Arg):-
    get_ast_node_label(Lang,Arg,PLASTFact),
    member(Constraint,Constraints),
    not(ast_node_signature(Lang,Constraint,_)),
    Predicate =.. [Constraint, Lang,PLASTFact],
    call(Predicate),
    !.

/**
 * checks if the type of arg is a member of the Constraints list:
 * e.g.: identT(Arg,...), checkConstraintList([atomType],'Name')
 */
checkConstraintList(Lang,Constraints,Arg):-
    member(Constraint,Constraints),              %Backtracking �ber einzelne Member
    not(ast_node_signature(Lang,Constraint,_)), %wenn kein g�ltiges AST-Node Label.. (z.B. expressionType)
    Predicate =.. [Constraint,Arg],             %..dann �berpr�fe den Typ
    call(Predicate),
    !.



/**
 * tree_constraints(treeType, [[kind_1,...],...])
 *
 * constraints for all tree elements 
 */

test('tree_constraints_ident'):-
    assert(identT(1,parentId,enclId,name,classId)),
    assert(identT(parentId,a,enclId,a,a)),
    assert(fieldDefT(enclId,a,a,a,a)),
    assert(classDefT(classId,a,a,a)),
    checkConstraints(1,write),
    retract(identT(1,parentId,enclId,name,classId)),
    retract(identT(parentId,a,enclId,a,a)),
    retract(fieldDefT(enclId,a,a,a,a)),
    retract(classDefT(classId,a,a,a)).
    




tree_constraints(applyT ,[[allType],[methodDefT,fieldDefT],[expressionType,nullType],[atomType],[expressionType],[methodDefT]]).
tree_constraints(assertT ,[[allType],[methodDefT],[expressionType]]).
tree_constraints(assignopT,[[allType],[methodDefT,fieldDefT],[getFieldT,identT,indexedT],[atomType],[expressionType]]).
tree_constraints(assignT,[[allType],[methodDefT,fieldDefT],[getFieldT,identT,indexedT],[expressionType]]).
tree_constraints(blockT, [[allType],[methodDefT],[statementType]]).
tree_constraints(breakT,[[allType],[methodDefT],[atomType],[statementType]]).
tree_constraints(caseT,[[allType],[methodDefT],[expressionType,nullType]]).
tree_constraints(catchT,[[allType],[methodDefT],[paramDefT],[blockT]]).
tree_constraints(classDefT ,[[execT,packageT,classDefT,newClassT,blockT,nullType],[atomType],[methodDefT,fieldDefT,classDefT]]).
tree_constraints(conditionalT,[[allType],[methodDefT,fieldDefT],[expressionType],[expressionType],[expressionType]]).
tree_constraints(continueT,[[allType],[methodDefT],[atomType],[statementType]]).
tree_constraints(doLoopT,[[allType],[methodDefT,fieldDefT],[expressionType],[statementType]]).
tree_constraints(execT,[[allType],[methodDefT],[expressionType,classDefT]]).
tree_constraints(extendsT,[[],[classDefT]]).
tree_constraints(externT,[[]]).
tree_constraints(fieldDefT ,[[classDefT],[typeTermType],[atomType],[expressionType,nullType]]).
tree_constraints(forLoopT,[[allType],[methodDefT],[expressionType,nullType,localDefT],[expressionType,nullType],[expressionType,nullType],[statementType]]).
tree_constraints(getFieldT, [[allType],[methodDefT,fieldDefT],[expressionType,nullType],[atomType], [fieldDefT,nullType]]). % if it is the length field of an array
tree_constraints(identT, [[allType], [methodDefT,fieldDefT], [atomType], [classDefT,localDefT,paramDefT,nullType,packageT]]).
tree_constraints(ifT,[[allType],[methodDefT],[expressionType],[blockT,statementType],[blockT,statementType,nullType]]).
tree_constraints(implementsT,[[],[classDefT]]).
tree_constraints(importT ,[[toplevelT],[packageT,classDefT]]).
tree_constraints(indexedT,[[allType],[methodDefT,fieldDefT],[expressionType],[expressionType]]).
tree_constraints(interfaceT ,[[]]).
tree_constraints(labelT,[[allType],[methodDefT,fieldDefT],[statementType],[atomType]]).
tree_constraints(literalT ,[[allType],[methodDefT,fieldDefT],[typeTermType],[atomType/* TODO: vorher auch typeTermType*/ ]]). 
tree_constraints(localDefT,[[allType],[methodDefT],[typeTermType],[atomType],[expressionType,nullType]]).
tree_constraints(methodDefT ,[[classDefT],[atomType],[paramDefT],[typeTermType,nullType],[classDefT],[blockT,nullType]]).
tree_constraints(modifierT,[[atomType]]).
tree_constraints(newArrayT, [[allType],[methodDefT,fieldDefT],[expressionType],[expressionType],[typeTermType]]).
tree_constraints(newClassT, [[allType],[methodDefT,fieldDefT],[methodDefT,nullType],[expressionType],[identT,selectT],[classDefT,nullType],[classDefT,nullType]]).
tree_constraints(nopT,[[allType],[methodDefT]]).
tree_constraints(operationT,[[allType],[methodDefT,fieldDefT],[expressionType],[atomType],[atomType]]).
tree_constraints(packageT ,[[atomType]]).
tree_constraints(paramDefT ,[[methodDefT,catchT],[typeTermType],[atomType]]).
tree_constraints(precedenceT,[[allType],[methodDefT,fieldDefT],[expressionType]]).
tree_constraints(returnT,[[allType],[methodDefT],[expressionType,nullType]]).
tree_constraints(selectT, [[allType], [methodDefT,fieldDefT], [atomType],[selectT,identT],[classDefT,packageT]]).
tree_constraints(switchT,[[allType],[methodDefT],[expressionType],[statementType]]).
tree_constraints(synchronizedT,[[allType],[methodDefT],[expressionType],[blockT]]).
tree_constraints(throwT,[[allType],[methodDefT],[expressionType]]).
tree_constraints(toplevelT, [[packageT,nullType],[atomType],[importT,classDefT]]).
tree_constraints(tryT,[[allType],[methodDefT],[blockT],[catchT],[blockT,nullType]]).
tree_constraints(typeCastT,[[allType],[methodDefT,fieldDefT],[typeTermType],[expressionType]]).
tree_constraints(typeTestT,[[allType],[methodDefT,fieldDefT],[typeTermType],[expressionType]]).
tree_constraints(whileLoopT,[[allType],[methodDefT],[expressionType],[statementType]]).

expressionType('Java',applyT).
expressionType('Java',assignT).
expressionType('Java',assignopT).
expressionType('Java',conditionalT).
expressionType('Java',getFieldT).
expressionType('Java',identT).
expressionType('Java',indexedT).
expressionType('Java',literalT).
expressionType('Java',newArrayT).
expressionType('Java',newClassT).
expressionType('Java',operationT).
expressionType('Java',precedenceT).
expressionType('Java',selectT).
expressionType('Java',typeCastT).
expressionType('Java',typeTestT).

expression('Java',Id) :- get_ast_node_label('Java',Id,Type), expressionType('Java',Type).

id('Java',ID):-
        %tree(ID,_,_).
        get_ast_node_term('Java',ID,_).

atomType('Java',Atom):-atom(Atom).
atomType('Java',Atom):-number(Atom).


typeTypes('Java',classDefT).

refType('Java',classDefT).
refType('Java',localDefT).
refType('Java',paramDefT).
refType('Java',fieldDefT).
refType('Java',methodDefT).

typeTermType('Java',type(_,_,_)).

nullType('Java','null').

statementType('Java',assertT).
statementType('Java',assignopT).
statementType('Java',assignT).
statementType('Java',blockT).
statementType('Java',breakT).
statementType('Java',caseT).
statementType('Java',catchT).
statementType('Java',continueT).
statementType('Java',doLoopT).
statementType('Java',execT).
statementType('Java',forLoopT).
statementType('Java',ifT).
statementType('Java',labelT).
statementType('Java',localDefT).
statementType('Java',nopT).
statementType('Java',returnT).
statementType('Java',switchT).
statementType('Java',synchronizedT).
statementType('Java',throwT).
statementType('Java',tryT).
statementType('Java',whileLoopT).

/*validReferenceType(_type, _pos, _validtypes) :-
    (_type == identT, 
        (_pos == 5, _validtypes == [classDefT, localDefT, paramDefT, fieldDefT]));
        (_type == getFieldT, 
            (_pos == #, _validtypes ==[];
             _pos == #, _validtypes ==[]))
    (_type == selectT, 
        (_pos == 5, _validtypes == [selectT, identT];
         _pos == 6, _validtypes == [classDefT, packageT])).
*/


    
/* usw. */
/* Statt mit pos k�nnte man auch den Parametern Namen verpassen. */
/* den Knoten mittels tree. */
    
invalidSelectReference(_id, _selectedfrom, _pos, _validtypes, _actualtype) :- 
   selectT(_id, _, _, _, _selectedfrom, _), 
   validReferenceType(selectT, 5, _validtypes), 
   %tree(_selectedfrom, _, _actualtype),
   get_ast_node_label('Java',_selectedfrom,_actualtype),
   not(member(_actualtype, _validtypes)).
   
   
    
