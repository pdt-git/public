% Author: G�nter, Sebastian
% Date: 7/4/2006

/*********************************************************************
Naming conventions:
    ast_node..       : Abstract AST-Information
    ast_node.._value : Concrete AST-Information
    get_ast_node..   : Concrete AST-Information accessible with ID
                       Two kinds of argument-data are required:
                       1. ID of Target-Fact
                       2. Information about desired argument

Layer 1: pure definition of AST-nodes and their properties
  ast_node_def/3
  ast_node_signature/3
  ast_node_sub_tree/3

Layer 2: 'abstract' term operations
  ast_node_data/6
  ast_node_argument/11  (/5)
    ast_node_edge/10
    ast_node_attribute/10

Layer 3: 'concrete' term operations (actual Term is called -> unification)
  ast_node_data_value/6
  ast_node_argument_value/11  (/10, /8)
    ast_node_edge_value/10
    ast_node_attribute_value/10

Layer 4: special case of Layer 3. Desired Node is indicated by Term/Functor/ID

  get_ast_node_argument/12     (/11, /7, /6, /5)
    get_ast_node_edge/11       (/10, /6, /5, /4)
      get_ast_node_parent/5    (/4, /3)
      get_ast_node_enclosing/5 (/4, /3)
      get_ast_node_label/3
      get_ast_node_term/4      (/3)
    get_ast_node_attribute/11  (/10, /6, /5, /4)
  get_ast_node_id/3

  set_ast_node_argument/9
    set_ast_node_parent/5      (/4, /3)
    set_ast_node_enclosing/5   (/4, /3)

**********************************************************************/

/*##############################################################################
From ast2graph.pl:
################################################################################*/

/**
 * tree_condition(?Node)
 *
 * Define the generic relation of AST nodes to atomic conditions for CTs.
 * A condition is either a term representing an AST node or a negation of
 * such a term.
 *
 * In the current implementation the fact 'Node' is used as a shorthand
 * for exists(Node). Such a fact is called a program element fact (PEF).
 */
tree_condition(Node) :-
   tree(Node).
tree_condition(\+(Node)) :-
   tree(Node).

/**
 * tree_action(?term)
 *
 * Define the generic relation of AST nodes to atomic actions for CTs.
 * An action is either empty or the addition, deletion or replacement of
 * an AST node.
 */
tree_action(add(_tree))             :- tree(_tree).
tree_action(delete(_tree))          :- tree(_tree).
tree_action(replace(_tree1,_tree2)) :- tree_action(delete(_tree1)),
                                       tree_action(add(_tree2)).
tree_action(empty). % <-- TODO: replace 'empty' by 'skip' (Abgleich mit CT intepreter).

/**
 * abstract_action(?term)
 *
 * A more generic form of the above, used in expand.pl::expandAction_/2
 * for identifying the actions that must be expanded. Tree actions are
 * atomic.
 */
abstract_action(add(_)).
abstract_action(delete(_)).
abstract_action(replace(_,_)).
abstract_action(empty).

/**
 * tree_id(+NodeOrMore, ?id)
 *
 * If Arg1 is a term representing an AST node, its negation, or an action
 * on an AST node then Arg2 is unified with the identity of the node.
 */
tree_id(\+(_tree),       _id) :- !, ast_node(_tree,_id), !.% ast_node(_,_tree,_).
tree_id(add(_tree),       _id) :- !, ast_node(_tree,_id), !.% ast_node(_,_tree,_).
tree_id(delete(_tree),    _id) :- !, ast_node(_tree,_id), !.% ast_node(_,_tree,_).
tree_id(replace(_tree,_), _id) :- !, ast_node(_tree,_id), !.% ast_node(_,_tree,_).
tree_id(replace(_,_tree), _id) :- !, ast_node(_tree,_id), !.% ast_node(_,_tree,_).
tree_id(_tree,            _id) :-    ast_node(_tree,_id), !.% ast_node(_,_tree,_).


/************************* nodes ***************************
 *  ast_node(?term, ?id)
 *     Arg1 is an AST node or the negation of an AST node.
 *     Arg2 is unified with its identity.
 *     NOTE: Upon success, arg2 may still be a free variable.
 *     If arg1 is a variable the predicate enumerates all legal
 *     AST nodes of any language known to JT.
 */
ast_node(Term, ID) :-
    ast_node_id(Term, ID).

ast_node_id(Term, ID) :-
    ast_node_term(_Lang, Term),  % Term must be a legal AST node
    Term =.. [_Functor,ID|_].

ast_node_id(Term, _val) :-
    nonvar(Term),                % Avoid infinite recursion
    Term = \+(_tree),
    !,
    ast_node_id(_tree, _val).

/************************* edges ***************************
 *  ast_node_edge(+term,?edgeId)
 *     Arg1 is an AST node or the negation of an AST node.
 *     Arg2 is an outgoing edge of arg1, that is the value of an
 *     argument of arg1 that is the id of another node.
 *     If arg1 has many edge-type arguments, they are all
 *     visited upon backtracking.
 */
ast_edge(Term, EdgeId):-
    ast_node_edge(Term, EdgeId).
    
ast_node_edge(Term, EdgeId):-
    ast_node_edge(Term, _, EdgeId).

/**
 * ast_node_edge(?Node,+EdgeType,?EdgeVal)
 *   Node = a term representing an AST node.
 *   EdgeType = an edge type as defined in ast_node_def/3.
 *   EdgeVal = the value of the node element whose type is EdgeType.
 */

ast_edge(Node,EdgeType,EdgeVal) :-
    ast_node_edge(Node,EdgeType,EdgeVal).
ast_node_edge(Node,EdgeType,EdgeVal) :-
    ast_node_argument(_, Node, EdgeType, id, EdgeVal).

/************************* attributes ***************************
 *  ast_node_attr(+term,?attr)
 *     Arg1 is an AST node or the negation of an AST node.
 *     Arg2 is an attribute of arg1.
 *     If arg1 has many attribute-type arguments, they are all
 *     visited upon backtracking.
 */
ast_attr(Term, AttrVal):-
   ast_node_attr(Term, AttrVal).
ast_node_attr(Term, AttrVal):-
    ast_node_attr(Term, _, AttrVal).
ast_attr(Term, AttrType, AttrVal):-
   ast_node_attr(Term, AttrType, AttrVal).
ast_node_attr(Term, AttrType, AttrVal):-
    ast_node_argument(_, Term, AttrType, attr, AttrVal).

/*##############################################################################
Combined access layer
################################################################################*/

%Compatibility with ast2graph.pl (from Condor):
tree(Node) :- ast_node_term(_,Node).

ast_node_term(Lang,Term) :-
    ast_node_data(Lang,Term,_,_,_,_).

/*********************************************************************
'Abstract' Term Operations
**********************************************************************/

/**
 * ast_node_data(?Lang, ?Node, ?NodeType, ?NodeArity, ?ArgSpecs, ?Subs) :-
 *   Arg1 is a term representing a language.
 *   Arg2 is a term representing an AST node.
 *   Arg3 is the functor of Arg2
 *   Arg4 is the arity of Arg2
 *   Arg5 is a list describing the argument syntax of Node
 *
 *   Bundles all information about the AST-Representation.
 */
ast_node_data(Lang, Node, NodeType, NodeArity, ArgSpecs,Subs) :-
    nonvar(Node),                 % Avoid infinite recursion
    Node = \+(Tree),
    !,
    ast_node_data(Lang, Tree, NodeType, NodeArity, ArgSpecs,Subs).

%checking variant
ast_node_data(Lang, Node, NodeType, NodeArity, ArgSpecs,Subs) :-
    nonvar(Node),
    !,
    functor(Node,NodeType,_),
    ast_node_signature(Lang,NodeType,NodeArity),
    ast_node_def(Lang,NodeType,ArgSpecs),
    ast_node_sub_tree(Lang,NodeType,Subs).

%generating variant
ast_node_data(Lang, Node, NodeType, NodeArity, ArgSpecs,Subs) :-
    var(Node),
    !,
    ast_node_def(Lang,NodeType,ArgSpecs),    % generate all via backtracking (if var(NodeType)..)
    ast_node_signature(Lang,NodeType,NodeArity),% use this to include above hack!
    ast_node_sub_tree(Lang,NodeType,Subs),
    functor(Node,NodeType,NodeArity).            % a prototypical instance of NodeType terms

/**
 * ast_node_argument(?Lang, ?Node, ?NodeType, ?ArgType, ?ArgKind, ?ArgValue)
 *    Arg1 is a term representing a language.
 *    Arg2 is a term representing an AST node.
 *    Arg3 is the functor of Arg2
 *    Arg3 is the name of an argument of Arg1.
 *    Arg4 is either 'attr' or 'id'. It indicates whether
 *    the current argument is an attribute ('attr')
 *    or a references to another node ('id').
 *    Arg5 is the value of the argument.
 *    If arg1 has many arguments, they are all
 *    visited upon backtracking.
 */
ast_node_argument(Lang, Node, NodeType, NodeArity, ArgSpecs, Subs, ArgType, ArgCard, ArgKind, ArgConstr, ArgVal) :-
    ast_node_data(Lang, Node, NodeType, NodeArity, ArgSpecs,Subs),
    Node =.. [_|Args],                       % Args = Arguments of Node (all distinct free variables)
    find_and_unify(ArgSpecs, Args, ArgType, ArgCard, ArgKind, ArgConstr, ArgVal).

ast_node_argument(Lang, Node, NodeType, ArgType, ArgKind, ArgVal) :-
    ast_node_argument(Lang, Node, NodeType, _, _,_, ArgType, _,ArgKind, _,ArgVal).
    
ast_node_argument(Lang, Node, NodeType, ArgType, ArgVal) :-
    ast_node_argument(Lang, Node, NodeType, ArgType, _, ArgVal).
    
/*
ast_node_argument(Lang, Node, ArgType, ArgKind, ArgVal) :-
    ast_node_argument(Lang, Node, _, _, _, ArgType, _,ArgKind, _,_,ArgVal).
*/

/**
 * find_and_unify(AST_arg_specs, ArgValues, ArgType, ArgKind, ArgVal)
 */
find_and_unify(AST_arg_specs, ArgValues, ArgType, ArgCard, ArgKind, ArgConstr, ArgVal) :-
    ArgSpec = ast_arg(ArgType, ArgCard, ArgKind, ArgConstr),
    find_and_unify(AST_arg_specs, ArgValues, ArgSpec, ArgVal).

find_and_unify([ArgSpec|_], [Arg|_], ArgSpec, ArgVal) :-
    %!,       %SL: necessary to backtrack through arguments.. improvement or not?
    ArgVal = Arg.
find_and_unify([_|ArgSpecs], [_|ArgVars], ArgSpec, ArgVal) :-
    find_and_unify(ArgSpecs, ArgVars, ArgSpec, ArgVal).

ast_node_edge(Lang, Node, NodeType, NodeArity, ArgSpecs, ArgType, ArgCard, ArgConstr, Subs,ArgVal) :-
    ast_node_argument(Lang, Node, NodeType, NodeArity, ArgSpecs, Subs, ArgType, ArgCard, id, ArgConstr, ArgVal).
    
ast_node_edge(Lang, Node, NodeType, ArgType, ArgVal) :-
    ast_node_argument(Lang, Node, NodeType, ArgType, id, ArgVal).

ast_node_attribute(Lang, Node, NodeType, NodeArity, ArgSpecs, ArgType, ArgCard, ArgConstr, Subs,ArgVal) :-
    ast_node_argument(Lang, Node, NodeType, NodeArity, ArgSpecs, Subs, ArgType, ArgCard, attr, ArgConstr, ArgVal).

ast_node_attribute(Lang, Node, NodeType, ArgType, ArgVal) :-
    ast_node_argument(Lang, Node, NodeType, ArgType, attr, ArgVal).


/*********************************************************************
'Concrete' Term Operations (with real values of asserted facts)
**********************************************************************/

ast_node_data_value(Lang, Node, NodeType, NodeArity, ArgSpecs,Subs) :-
    ast_node_data(Lang, Node, NodeType, NodeArity, ArgSpecs,Subs),
    Node.


/**
 * ast_node_argument_value(?Lang, ?Node, ?NodeType, ?NodeArity, ?ArgSpecs, ?ArgType, ?ArgCard, ?ArgKind, ?ArgConstr, ?ArgVal)
 *   Same arguments as "ast_node_argument_value".
 *   This time, the arguments of arg2 (?Node) are being set to their values.
 */
ast_node_argument_value(Lang, Node, NodeType, NodeArity, ArgSpecs, Subs, ArgType, ArgCard, ArgKind, ArgConstr, ArgVal) :-
    ast_node_argument(Lang, Node, NodeType, NodeArity, ArgSpecs, Subs, ArgType, ArgCard, ArgKind, ArgConstr, ArgVal),
    Node.
ast_node_argument_value(Lang, Node, NodeType, NodeArity, ArgSpecs, ArgType, ArgCard, ArgKind, ArgConstr, ArgVal) :-
    ast_node_argument_value(Lang, Node, NodeType, NodeArity, ArgSpecs, _, ArgType, ArgCard, ArgKind, ArgConstr, ArgVal).

    
ast_node_argument_value(Lang, Node, NodeType, NodeArity, ArgSpecs, ArgLabel, ArgKind, Value) :-
    ast_node_argument_value(Lang, Node, NodeType, NodeArity, ArgSpecs, ArgLabel, _, ArgKind, _, Value).
ast_node_argument_value(Lang, Node, NodeType, ArgLabel, Value) :-
    ast_node_argument_value(Lang, Node, NodeType, _, _, ArgLabel, _, Value).


ast_node_edge_value(Lang, Node, NodeType, NodeArity, ArgSpecs, Subs, ArgType, ArgCard, ArgConstr, ArgVal) :-
    ast_node_argument_value(Lang, Node, NodeType, NodeArity, ArgSpecs, Subs, ArgType, ArgCard, id, ArgConstr, ArgVal).

ast_node_attribute_value(Lang, Node, NodeType, NodeArity, ArgSpecs, Subs, ArgType, ArgCard, ArgConstr, ArgVal) :-
    ast_node_argument_value(Lang, Node, NodeType, NodeArity, ArgSpecs, Subs, ArgType, ArgCard, attr, ArgConstr, ArgVal).

ast_node_attribute_value(Lang, Node, NodeType, NodeArity, ArgSpecs, ArgType, ArgCard, ArgConstr, ArgVal) :-
    ast_node_argument_value(Lang, Node, NodeType, NodeArity, ArgSpecs, ArgType, ArgCard, attr, ArgConstr, ArgVal).


/****************************
"get" Operations
*****************************/

/**
 * get_ast_node_argument(?Lang, ?Node, ?NodeType, ?NodeArity, ?ID, ?ArgSpecs, ?ArgLabel, ?ArgKind, ?Value)
 * get_ast_node_argument(?Lang, ?Node, ?NodeType, ?ID, ?ArgLabel, ?ArgKind, ?Value)
 * get_ast_node_argument(?Lang, ?NodeType, ?ID, ?ArgLabel, ?ArgKind, ?Value)
 * get_ast_node_argument(?Lang, ?ID, ?ArgLabel, ?ArgKind, ?Value)
 *   Same arguments as "ast_node_argument_value".
 *   This time, the arguments of arg2 (?Node) are being set to their values.
 *   Offers the possibility to access the argument of an asserted fact, determined
 *   by its ID.
 */
%most general variant
get_ast_node_argument(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, Subs, ArgLabel, ArgCard, ArgKind, ArgConstr, Value) :-
    ast_node_edge(Lang, Node, NodeType, NodeArity, ArgSpecs, id, _, _, _,ID),
    ast_node_argument(Lang, Node, NodeType, NodeArity, ArgSpecs, Subs, ArgLabel, ArgCard, ArgKind, ArgConstr, Value),
    Node.
    
get_ast_node_argument(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, ArgLabel, ArgCard, ArgKind, ArgConstr, Value) :-
    get_ast_node_argument(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, _, ArgLabel, ArgCard, ArgKind, ArgConstr, Value).

get_ast_node_argument(Lang, Node, NodeType, ID, ArgLabel, ArgKind, Value) :-
    get_ast_node_argument(Lang, Node, NodeType, _, ID, _, ArgLabel, _, ArgKind, _, Value).
    %get_ast_node_argument(Lang, Node, NodeType, _, ID, _, ArgLabel, ArgKind, Value).

/*get_ast_node_argument(Lang, NodeType, ID, ArgLabel, ArgKind, Value) :-
    get_ast_node_argument(Lang, _, NodeType, ID, ArgLabel, ArgKind, Value).
*/
    %get_ast_node_argument(Lang, _, NodeType, _, ID, _, ArgLabel, ArgKind, Value).
get_ast_node_argument(Lang, NodeType,ID, ArgLabel, Value) :-
    get_ast_node_argument(Lang, _, NodeType, ID, ArgLabel, _, Value).
    %get_ast_node_argument(Lang, _, ID, ArgLabel, ArgKind, Value).
    %get_ast_node_argument(Lang, _, _, _, ID, _, ArgLabel, ArgKind, Value).
get_ast_node_argument(Lang, ID, ArgLabel, Value) :-
    get_ast_node_argument(Lang, _,ID, ArgLabel, Value).
    %get_ast_node_argument(Lang, ID, ArgLabel, _, Value).

/*
get_ast_node_argument(Lang, Node, NodeType, ID, ArgName, ArgVal) :-
    ast_node_argument(Lang, Node, NodeType, id, ID),
    ast_node_argument(Lang, Node, NodeType, ArgName, ArgVal),
    Node.
*/

/**
 * get_ast_node_edge(?Lang, ?Node, ?NodeType, ?ArgValue)
 */
 %most general:
get_ast_node_edge(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, Subs, EdgeLabel, ArgCard, ArgConstr, Value) :-
    get_ast_node_argument(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, Subs, EdgeLabel, ArgCard, id, ArgConstr, Value).
    
get_ast_node_edge(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, EdgeLabel, ArgCard, ArgConstr, Value) :-
    get_ast_node_edge(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, _, EdgeLabel, ArgCard, ArgConstr, Value).

%specialised:
get_ast_node_edge(Lang, Node, NodeType, ID, EdgeLabel, Value) :-
    get_ast_node_edge(Lang, Node, NodeType, _, ID, _, EdgeLabel, _, _, Value).
get_ast_node_edge(Lang, NodeType, ID, EdgeLabel, Value) :-
    get_ast_node_edge(Lang, _, NodeType, ID, EdgeLabel, Value).
get_ast_node_edge(Lang, ID, EdgeLabel, Value) :-
    get_ast_node_edge(Lang, _, ID, EdgeLabel, Value).


/**
 * get_node_attribute(?Lang, ?Node, ?NodeType, ?AttrLabel,?ArgValue)
 */
%most general:
get_ast_node_attribute(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, Subs, EdgeLabel, ArgCard, ArgConstr, Value) :-
    get_ast_node_argument(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, Subs, EdgeLabel, ArgCard, attr, ArgConstr, Value).

get_ast_node_attribute(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, AttributeLabel, ArgCard, ArgConstr, Value) :-
    get_ast_node_argument(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, AttributeLabel, ArgCard, attr, ArgConstr, Value).
%specialised:
get_ast_node_attribute(Lang, Node, NodeType, ID, AttributeLabel, Value) :-
    get_ast_node_attribute(Lang, Node, NodeType, _, ID, _, AttributeLabel, _, _, Value).
get_ast_node_attribute(Lang, NodeType, ID, AttributeLabel, Value) :-
    get_ast_node_attribute(Lang, _, NodeType, ID, AttributeLabel, Value).
get_ast_node_attribute(Lang, ID, AttributeLabel, Value) :-
    get_ast_node_attribute(Lang, _, ID, AttributeLabel, Value).



%More specialised access-predicates for frequently used tasks:

/**
 * get_ast_node_parent(?Lang,?NodeTerm,?NodeType,?ID,?Parent)
 * get_ast_node_parent(?Lang,?NodeType,?ID,?Parent)
 * get_ast_node_parent(?Lang,?ID,?Parent)
 */
get_ast_node_parent(Lang,NodeTerm,NodeType,ID,Parent) :-
    get_ast_node_edge(Lang,NodeTerm,NodeType,ID,parent,Parent).
get_ast_node_parent(Lang,NodeType,ID,Parent) :-
    get_ast_node_parent(Lang,_,NodeType,ID,Parent).
get_ast_node_parent(Lang,ID,Parent) :-
    get_ast_node_parent(Lang,_,ID,Parent).

/**
 * get_ast_node_enclosing(?Lang,?NodeTerm,?NodeType,?ID,?Encl)
 * get_ast_node_enclosing(?Lang,?NodeType,?ID,?Encl)
 * get_ast_node_enclosing(?Lang,?ID,?Encl)
 */
get_ast_node_enclosing(Lang,NodeTerm,NodeType,ID,Encl) :-
    get_ast_node_edge(Lang,NodeTerm,NodeType,ID,encl,Encl).
get_ast_node_enclosing(Lang,NodeType,ID,Encl) :-
    get_ast_node_edge(Lang,_,NodeType,ID,encl,Encl).
get_ast_node_enclosing(Lang,ID,Encl) :-
    get_ast_node_edge(Lang,_,_,ID,encl,Encl),!.

/**
 * get_ast_node_label(?Lang, ?ID,?Label)
 */
get_ast_node_label(Lang,ID,Label) :-
    get_ast_node_term(Lang,ID,Label,_).

/**
 * get_ast_node_term(?Lang,?ID,?NodeType,?Term)
 * get_ast_node_term(?Lang,?ID,?Term)
 */
get_ast_node_term(Lang,ID,NodeType,Term) :-
    %nonvar(ID),
    ast_node_argument_value(Lang, Term, NodeType, id, ID),
    !.
/*
get_ast_node_term(Lang,ID,NodeType,Term) :-
    var(ID),nonvar(Term),
    get_ast_node_id(Lang,Term,ID).
    %ast_node_argument_value(Lang, Term, NodeType, id, ID),
    !.
*/

get_ast_node_term(Lang,ID,Term) :-
    get_ast_node_term(Lang,ID,_,Term).

    

/**
 * get_ast_node_id(?Lang,?NodeTerm,?ID)
 */
get_ast_node_id(Lang,NodeTerm,ID) :-
    nonvar(NodeTerm),
    %ast_node_edge(Lang,NodeTerm,_,id,ID).
    ast_node_edge_value(Lang, NodeTerm, _, _, _, _, _, _, _,ID),
    !.

/****************************
"set" Operations
*****************************/

/**
 *  set_ast_node_argument(?Lang,?Term,?Functor,?ID,?ArgName, ?ArgCard, ?ArgKind, ?ArgConstr, +NewValue)
 *
 *  Sets the Value of an argument of "ArgType" regarding the PEF with "ID".
 *  WARNING: compatability issues with earlier versions are NOT considered
 *    Arg1 is a term representing a language.
 *    Arg2 is a term representing an AST node.
 *    Arg3 is the functor of Arg2
 *    Arg4 is the ID of Arg2
 *    Arg5 is the name of an argument of Arg2.
 *    Arg6 is the cardinality of an argument of Arg2
 *    Arg7 is either 'attr' or 'id'. It indicates whether
 *    Arg8 is a list of constraints for an argument of Arg2
 *    Arg9 is the new value for the specified argument
 */
%most general variant
set_ast_node_argument(Lang,Term,Functor,ID,ArgName, ArgCard, ArgKind, ArgConstr, NewValue) :-
    %ast_node_argument_value(Lang, Term, Functor, _, ArgSpecs, id, id, ID), %get values
    ast_node_edge_value(Lang, Term, Functor, _, ArgSpecs, _,id, _, _,  ID),
    Term =.. [_|ArgVals],                                               %isolate arguments
    setArgValue(ArgSpecs,ArgVals,ArgName, ArgCard, ArgKind, ArgConstr, NewValue,NewArgVals),
    NewTerm =.. [Functor|NewArgVals],              %create new term
    delete(Lang,Term),                             %delete old term
    add(Lang,NewTerm).                             %add new term with changed values

%specialised variants
set_ast_node_argument(Lang,Term,Functor,ID,ArgName,NewValue) :-
    set_ast_node_argument(Lang,Term,Functor,ID,ArgName, _, _, _, NewValue).
set_ast_node_argument(Lang,Functor,ID,ArgName,NewValue) :-
    set_ast_node_argument(Lang,_,Functor,ID,ArgName, _, _, _, NewValue).
set_ast_node_argument(Lang,ID,ArgName,NewValue) :-
    set_ast_node_argument(Lang,_,_,ID,ArgName, _, _, _, NewValue).

/**
 * setArgValue(ASTArgSpecs,ArgVals,ArgName,ArgCard,ArgKind,ArgConstr,NewValue,NewArgVals)
 *
 * Helper Predicate for set_ast_node_argument
 *   Arg1 is a list of argument specifications
 *   Arg2 is a list of argument values
 *   Arg3 is the name of the argument which should be changed
 *   Arg4 is the cardinality of the argument which should be changed
 *   Arg5 is the kind ("id" or "attr") of the argument which should be changed
 *   Arg6 is a list of constraints for the argument which should be changed
 *   Arg7 is the new value which is to be set
 *   Arg8 is a list of arguments which contain the modification
 */
%setArgValue/7
setArgValue(ASTArgSpecs,ArgVals,ArgName,ArgCard,ArgKind,ArgConstr,NewValue,NewArgVals) :-
    ArgSpec = ast_arg(ArgName, ArgCard, ArgKind, ArgConstr),
    setArgValue(ASTArgSpecs,ArgVals,ArgSpec,NewValue,NewArgVals).
%setArgValue/5
setArgValue(ASTArgSpecs,ArgVals,ArgName,ArgKind,NewValue,NewArgVals) :-
    ArgSpec = ast_arg(ArgName, _, ArgKind, _),
    setArgValue(ASTArgSpecs,ArgVals,ArgSpec,NewValue,NewArgVals).

setArgValue(_,[],_,_,[]).
%set new value
setArgValue([ASTArgSpecs|T1],[_|T2],ASTArgSpecs,NewValue,[NewValue|T3]) :-
    setArgValue(T1,T2,ASTArgSpecs,NewValue,T3),!.
%copy old values
setArgValue([_|T1],[H1|T2],ArgSpec,NewValue,[H1|T3]) :-
    setArgValue(T1,T2,ArgSpec,NewValue,T3).


/**
 * set_ast_node_parent(Lang,Term,Functor,ID,NewValue)
 *   set_ast_node_parent(Lang,Functor,ID,NewValue)
 *     set_ast_node_parent(Lang,ID,NewValue)
 *
 *    For most general variant:
 *    Arg1 is a term representing a language.
 *    Arg2 is a term representing an AST node term.
 *    Arg3 is the functor of Arg2
 *    Arg4 is the ID of Arg2
 *    Arg5 is the new parent value
 */
set_ast_node_parent(Lang,Term,Functor,ID,NewValue) :-
    set_ast_node_argument(Lang,Term,Functor,ID,parent,NewValue).
set_ast_node_parent(Lang,Functor,ID,NewValue) :-
    set_ast_node_argument(Lang,Functor,ID,parent,NewValue).
set_ast_node_parent(Lang,ID,NewValue) :-
    set_ast_node_argument(Lang,ID,parent,NewValue).


/**
 * set_ast_node_enclosing(Lang,Term,Functor,ID,NewValue)
 *   set_ast_node_enclosing(Lang,Functor,ID,NewValue)
 *     set_ast_node_enclosing(Lang,ID,NewValue)
 *
 *    For most general variant:
 *    Arg1 is a term representing a language.
 *    Arg2 is a term representing an AST node term.
 *    Arg3 is the functor of Arg2
 *    Arg4 is the ID of Arg2
 *    Arg5 is the new enclosing value
 */
set_ast_node_enclosing(Lang,Term,Functor,ID,NewValue) :-
    set_ast_node_argument(Lang,Term,Functor,ID,encl,NewValue).
set_ast_node_enclosing(Lang,Functor,ID,NewValue) :-
    set_ast_node_argument(Lang,Functor,ID,encl,NewValue).
set_ast_node_enclosing(Lang,ID,NewValue) :-
    set_ast_node_argument(Lang,ID,encl,NewValue).



/* checkIfTopLevel(+Lang,+ID)
 *   �berpr�ft, ob der AST-Knoten mit id "ID" ein Toplevel-Element ist.
 *   Ein Toplevel-Element ist hier so definiert, da� es KEINEN Parent hat,
 *   also die Wurzel des AST bildet.
 *   F�r Lang=Java ist packageT der Toplevel.
 */
checkIfTopLevel(Lang,ID) :-
     \+ get_ast_node_parent(Lang,ID,_),
     !.

/*##############################################################################
for compatibility during transition:
################################################################################*/
get_ast_node_enclosing('Java',_id, _id)  :- packageT(_id, _), !.
get_ast_node_enclosing('Java',_id, _Encl):- classDefT(_id, _Encl,_,_), !.
get_ast_node_enclosing('Java',_id, _Encl):- paramDefT(_id,_Encl,_,_), !.
get_ast_node_enclosing('Java',_id, _Encl):- fieldDefT(_id, _Encl, _, _, _),!.
get_ast_node_enclosing('Java',_id, _Encl):- methodDefT(_id, _Encl,_,_,_,_,_), !.
get_ast_node_enclosing('Java',_id, _Encl):- toplevelT(_id, _Encl,_,_), !.
get_ast_node_enclosing('Java',_id, _Encl):- importT(_id, _,_Encl), !.

get_ast_node_parent('Java',ID,null) :- packageT(ID,_).

set_ast_node_enclosing('Java',_id,_new_encl):-paramDefT(_id,_encl,_v1,_v2),!,delete('Java',paramDefT(_id,_encl,_v1,_v2)),add('Java',paramDefT(_id,_new_encl,_v1,_v2)).




%###############################################################################
/* get_ast_sub_tree(+Lang,+ID,-Subs)
     Liefert die Subtrees des AST-Knotens mit "ID" zur�ck. Basiert auf
     der minimalistischen Implementierung von "ast_sub_tree". Alle dort
     aufgelisteten Parameternamen werden auf die komplette AST-Definition
     bezogen.
     !!! ACHTUNG !!! Inkonsistent zu "sub_trees/2".
     Fehlerbeispiel: continueT-target
                     ast_sub_tree('Java',target)
                     in sub_trees/2 ist target aber KEIN Kind

     Bei Verwendung dieser Fassung m��ten die Namen von ast_sub_tree konventionalisiert
     werden, so da� sie NUR im richtigen Kontext verwendet werden d�rfen.
*/
/*
get_ast_sub_tree(Lang,ID,Subs) :-
    get_ast_node_term(Lang,ID,Term),
    Term =.. [_|InstArgList],
    functor(Term,Functor,_),
    ast_node_def(Lang,Functor,ArgList),
    extract_sub_trees(Lang,InstArgList,ArgList,SubList),
    flatten(SubList,Subs).

extract_sub_trees(_,_,[],[]).
extract_sub_trees(_,[],_,[]). %kann im Transitionszustand passieren..
extract_sub_trees(Lang,[H|T1],[ast_arg(Name,_,_,_)|T2],[H|T3]) :-
    ast_sub_tree(Lang,STName),
    Name == STName,
    extract_sub_trees(Lang,T1,T2,T3),
    !.
extract_sub_trees(Lang,[_|T1],[_|T2],T3) :-
    extract_sub_trees(Lang,T1,T2,T3),!.
*/
%------------------------------------------------------------------------------
%Variante 2:

%Compatability..----------------------------------------------|
get_ast_node_sub_trees('Java',_id, _subtrees) :-
    methodDefT(_id,_,_,_params,_,_,_body),
    !,
%    format('sub_trees:methodDef: ~a~a~n', [_id, _name]),
    listOrEmptyListIfNull(_body, _bodyList),
    append(_bodyList, _params, _subtrees).
get_ast_node_sub_trees('Java',_id, _subtrees) :-
    packageT(_id,_),
    !,
    findall(_sub,(classDefT(_sub, _id, _, _) ; toplevelT(_sub, _id, _,_)), _subtrees).
%-------------------------------------------------------------|


get_ast_node_sub_trees(Lang,Term,NodeType,ID,SubList) :-
    findall(Value,
                 (
                  get_ast_node_edge(Lang, Term, NodeType, _, ID, _, Subs, EdgeLabel, _, _, Value),
                  member(EdgeLabel,Subs)
                 ), SubList).
                 
get_ast_node_sub_trees(Lang,NodeType,ID,SubList) :-
    get_ast_node_sub_trees(Lang,_,NodeType,ID,SubList).
get_ast_node_sub_trees(Lang,ID,SubList) :-
    get_ast_node_sub_trees(Lang,_,ID,SubList).



%get_ast_sub_tree(Lang,Functor,ID,Subs)
/*
ID: denotes desired fact
Subs: list of edge values which point down in ast-hierarchy
*/
/*
get_ast_sub_tree(Lang,ID,Subs) :-
    get_ast_node_term(Lang,ID,Term),
    Term =.. [_|InstArgList],
    functor(Term,Functor,_),
    ast_node_def(Lang,Functor,ArgList),
    extract_sub_trees(Lang,Functor,InstArgList,ArgList,SubList),
    flatten(SubList,Subs).
    %(length(SubsFlat,1) -> SubsFlat = [Subs];SubsFlat = Subs).

%extract_sub_trees2(+Lang,+Functor,+InstArgList,+ArgList,-Subs)
extract_sub_trees(_,_,_,[],[]).
extract_sub_trees(_,_,[],_,[]). %kann im Transitionszustand passieren..
extract_sub_trees(Lang,Functor,[H|T1],[ast_arg(Name,_,_,_)|T2],[H|T3]) :-
    ast_node_sub_tree(Lang,Functor,STNames),
    member(Name,STNames),
    extract_sub_trees(Lang,Functor,T1,T2,T3),
    !.
extract_sub_trees(Lang,Functor,[_|T1],[_|T2],T3) :-
    extract_sub_trees(Lang,Functor,T1,T2,T3),!.
*/
/* ast_sub_tree2(Lang,Label,ArgNames)
     Alternative Darstellung von top->down Verkn�pfungen im AST.
     Der Vorteil liegt darin, da� die Angaben f�r jeden Knoten individuell
     definiert werden k�nnen.
     Arg2 ist der betroffene Knoten und Arg3 die Namen der Parameter, die
     als Subtrees betrachtet werden.
*/

:- multifile ast_node_sub_tree/3.

%###############################################################################
/* Test f�r Subtrees
     - Wie sollen Listen in den Parametern getestet werden?

   - Wie sehen die Implementierungen von
       * listOrEmptyListIfNull/2 und
       * emptyListIfNull/2 aus???
     Was sind die Unterschiede?
*/
listOrEmptyListIfNull(null,[]).
listOrEmptyListIfNull(L,[L]).
emptyListIfNull(null,[]).
emptyListIfNull(L,[L]).

membertest1 :- membertest2(a),membertest2(f).
membertest2(Y) :-
    X = [a,c,f],
    member(Y,X).
    
testme :- pe([ast_node_data('Java',_,_,_,_,_),ast_node_argument('Java',_,_,_,_,_,_,_,_,_,_)]).
testm2 :- pe([ast_node_data('Java',_,_,_,_,_),
              ast_node_argument('Java',_,_,_,_,_,_,_,_,_,_),
              ast_node_argument_value('Java',_,_,_,_,_,_,_,_,_,_)]).
