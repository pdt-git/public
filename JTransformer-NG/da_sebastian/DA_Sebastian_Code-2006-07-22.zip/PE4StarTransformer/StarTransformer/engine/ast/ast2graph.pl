 

%:- multifile ast_node/3.
%:- multifile ast_edge/3.
%:- multifile ast_attr/3. 
%:- multifile ast_node/2.  % Arity changed -- gk, Sept. 19 2005
%:- multifile ast_edge/2.  % Arity changed -- gk, Sept. 19 2005
%:- multifile ast_attr/2.  % Arity changed -- gk, Sept. 19 2005

/**
 * TODO:
 *  - Compare ast_edge/ to ast_edge_alternative/3 and ast_argument/4 
 *    and eliminate what is redundant, leaving only forwarding definition
 *    behind, for backward compatibility.
 *  - change ast_node_def(Lang, Functor, ArgList) 
 *    to     ast_node_def(Functor, Lang, ArgList)
 *    in order to take advantage of first argument indexing on functors
 *    which is more selective than first argument indexing on languages.
 *    Might not be required if Sebastian's partial evaluator works well.
  */
 
/*****************************************************************
 * Graph Sicht auf Programmelemente (unabh�ngig von Faktenbasis)
 *
 * tree_condition(?term)
 * tree_action(?term)
 * abstract_action(?term)
 * tree(+term)
 * tree_id(+term,?id)
 *
 * ast_node(+term, ?id)  Changed on Sept. 19 2005
 * ast_edge(+term, ?id)
 * ast_edge(+term, +edgeType, ?id)
 * ast_attr(+term, ?attr)
 *
 * %ast_node(?type, +term, ?id)
 * %ast_edge(?type, +term, ?id)
 * %ast_attr(?type, +term, ?attr)
 *****************************************************************/

/**
 * tree_condition(?Node)
 *
 * Define the generic relation of AST nodes to atomic conditions for CTs.
 * A condition is either a term representing an AST node or a negation of 
 * such a term. 
 *
 * In the current implementation the fact 'Node' is used as a shorthand 
 * for exists(Node). Such a fact is called a program element fact (PEF).
 */
tree_condition(Node) :- 
   tree(Node).   
tree_condition(not(Node)) :- 
   tree(Node).  




/**
 * tree_action(?term)
 *
 * Define the generic relation of AST nodes to atomic actions for CTs.
 * An action is either empty or the addition, deletion or replacement of 
 * an AST node. 
 */
tree_action(add(_tree))             :- tree(_tree).
tree_action(delete(_tree))          :- tree(_tree).
tree_action(replace(_tree1,_tree2)) :- tree_action(delete(_tree1)),
                                       tree_action(add(_tree2)).
tree_action(empty). % <-- TODO: replace 'empty' by 'skip' (Abgleich mit CT intepreter).


/**
 * abstract_action(?term)
 *
 * A more generic form of the above, used in expand.pl::expandAction_/2
 * for identifying the actions that must be expanded. Tree actions are
 * atomic. 
 */
abstract_action(add(_)).
abstract_action(delete(_)).
abstract_action(replace(_,_)).
abstract_action(empty).

    
/**
 * tree(+Node)
 *
 * The argument term represents a legal AST node. 
 */
tree(Node) :-                      % Checking variant
   nonvar(Node), !,
   functor(Node,Functor,Arity),
   ast_node_signature(_Lang, Functor, Arity). 
   
   % treeSignature(Functor, Arity). % <-- use this instead of 
% ast_node_term(_Lang, _tree)! This is a hack but necessary
% as long as the new and old syntax coexist. See definition
% of treeSignature/2 for further explanation.

tree(Node) :-                       % Generating variant
   var(Node), !,
   ast_node_signature(_Lang, Functor, Arity), 
   % treeSignature(Functor, Arity), 
   functor(Node,Functor,Arity). 
   

/**
 * tree_id(+NodeOrMore, ?id)
 *
 * If Arg1 is a term representing an AST node, its negation, or an action
 * on an AST node then Arg2 is unified with the identity of the node.
 */
tree_id(not(_tree),       _id) :- !, ast_node(_tree,_id), !.% ast_node(_,_tree,_).
tree_id(add(_tree),       _id) :- !, ast_node(_tree,_id), !.% ast_node(_,_tree,_). 
tree_id(delete(_tree),    _id) :- !, ast_node(_tree,_id), !.% ast_node(_,_tree,_).
tree_id(replace(_tree,_), _id) :- !, ast_node(_tree,_id), !.% ast_node(_,_tree,_).
tree_id(replace(_,_tree), _id) :- !, ast_node(_tree,_id), !.% ast_node(_,_tree,_).
tree_id(_tree,            _id) :-    ast_node(_tree,_id), !.% ast_node(_,_tree,_).


/************************* nodes ***************************
 *  ast_node(?term, ?id)
 *     Arg1 is an AST node or the negation of an AST node. 
 *     Arg2 is unified with its identity. 
 *     NOTE: Upon success, arg2 may still be a free variable.
 *     If arg1 is a variable the predicate enumerates all legal 
 *     AST nodes of any language known to JT. 
 */
ast_node(Term, ID) :-
    ast_node_id(Term, ID).
    
ast_node_id(Term, ID) :-
    ast_node_term(_Lang, Term),  % Term must be a legal AST node
    Term =.. [_Functor,ID|_].    

ast_node_id(Term, _val) :- 
    nonvar(Term),                % Avoid infinite recursion 
    Term = not(_tree),
    !,
    ast_node_id(_tree, _val).

/************************* edges ***************************
 *  ast_node_edge(+term,?edgeId)
 *     Arg1 is an AST node or the negation of an AST node.
 *     Arg2 is an outgoing edge of arg1, that is the value of an
 *     argument of arg1 that is the id of another node.
 *     If arg1 has many edge-type arguments, they are all 
 *     visited upon backtracking. 
 */
ast_edge(Term, EdgeId):-
    ast_node_edge(Term, EdgeId).

ast_node_edge(Term, EdgeId):-
        ast_node_edge(Term, _, EdgeId).

/**
 * ast_node_edge(?Node,+EdgeType,?EdgeVal)
 *   Node = a term representing an AST node.
 *   EdgeType = an edge type as defined in ast_node_def/3.
 *   EdgeVal = the value of the node element whose type is EdgeType.
 */
 
ast_edge(Node,EdgeType,EdgeVal) :-
    ast_node_edge(Node,EdgeType,EdgeVal).
    
ast_node_edge(Node,EdgeType,EdgeVal) :-
    ast_node_argument(_, Node, EdgeType, id, EdgeVal).
        
           
/************************* attributes ***************************
 *  ast_node_attr(+term,?attr)
 *     Arg1 is an AST node or the negation of an AST node.
 *     Arg2 is an attribute of arg1.
 *     If arg1 has many attribute-type arguments, they are all 
 *     visited upon backtracking. 
 */
ast_attr(Term, AttrVal):-
   ast_node_attr(Term, AttrVal).
   
ast_node_attr(Term, AttrVal):-
    ast_node_attr(Term, _, AttrVal).

ast_attr(Term, AttrType, AttrVal):-
   ast_node_attr(Term, AttrType, AttrVal).
   
ast_node_attr(Term, AttrType, AttrVal):-
    ast_node_argument(_, Term, AttrType, attr, AttrVal).


/*********************************************************************
Naming conventions:
    ast_node..       : Abstract AST-Information
    ast_node.._value : Concrete AST-Information
    get_ast_node..   : Concrete AST-Information accessible with ID
    
    
ast_node_def/3
ast_node_signature/3
ast_node_data/5
ast_node_argument/8
**********************************************************************/


/*********************************************************************
'Abstract' Term Operations
**********************************************************************/

/**
 * ast_node_data(?Lang, ?Node, ?NodeType, ?NodeArity, ?ArgSpecs) :-
 *   Arg1 is a term representing a language.
 *   Arg2 is a term representing an AST node.
 *   Arg3 is the functor of Arg2
 *   Arg4 is the arity of Arg2
 *   Arg5 is a list describing the argument syntax of Node
 *
 *   Bundles all information about the AST-Representation.
 *   !!! WARNING: Do not use the NodeArity-Argument until the
 *                arity-inconsistency is fixed.
 *                Use ast_node_signature/3 instead.
 */
ast_node_data(Lang, Node, NodeType, NodeArity, ArgSpecs) :-
    nonvar(Node),                 % Avoid infinite recursion
    Node = not(Tree),
    !,
    ast_node_data(Lang, Tree, NodeType, NodeArity, ArgSpecs).

%checking variant
ast_node_data(Lang, Node, NodeType, NodeArity, ArgSpecs) :-
    nonvar(Node),
    !,
    functor(Node,NodeType,NodeArity),
    ast_node_def(Lang,NodeType,ArgSpecs).

%generating variant
ast_node_data(Lang, Node, NodeType, NodeArity, ArgSpecs) :-
    var(Node),
    !,
    ast_node_def(Lang,NodeType,ArgSpecs),    % generate all via backtracking (if var(NodeType)..)
    ast_node_signature(Lang,NodeType,NodeArity),% use this to include above hack!
    functor(Node,NodeType,NodeArity).            % a prototypical instance of NodeType terms
    
/**
 * ast_node_argument(?Lang, ?Node, ?NodeType, ?ArgType, ?ArgKind, ?ArgValue)
 *    Arg1 is a term representing a language.
 *    Arg2 is a term representing an AST node.
 *    Arg3 is the functor of Arg2
 *    Arg3 is the name of an argument of Arg1.
 *    Arg4 is either 'attr' or 'id'. It indicates whether 
 *    the current argument is an attribute ('attr')
 *    or a references to another node ('id'). 
 *    Arg5 is the value of the argument.
 *    If arg1 has many arguments, they are all 
 *    visited upon backtracking.     
 */
ast_node_argument(Lang, Node, NodeType, NodeArity, ArgSpecs, ArgType, ArgKind, ArgVal) :-
    ast_node_data(Lang, Node, NodeType, NodeArity, ArgSpecs),
    Node =.. [_|Args],                       % Args = Arguments of Node (all distinct free variables)
    find_and_unify(ArgSpecs, Args, ArgType, ArgKind, ArgVal).

ast_node_argument(Lang, Node, ArgType, ArgKind, ArgVal) :-
    ast_node_argument(Lang, Node, NodeType, NodeArity, ArgSpecs, ArgType, ArgKind, ArgVal).
    

/**
 * find_and_unify(AST_arg_specs, ArgValues, ArgType, ArgKind, ArgVal)
 */      
find_and_unify(AST_arg_specs, ArgValues, ArgType, ArgKind, ArgVal) :-
    ArgSpec = ast_arg(ArgType, _ArgCard, ArgKind, _ArgConstr),
    find_and_unify(AST_arg_specs, ArgValues, ArgSpec, ArgVal).

find_and_unify([ArgSpec|_], [Arg|_], ArgSpec, ArgVal) :-
    !,
    ArgVal = Arg.
find_and_unify([_|ArgSpecs], [_|ArgVars], ArgSpec, ArgVal) :-
    find_and_unify(ArgSpecs, ArgVars, ArgSpec, ArgVal).


/*********************************************************************
'Concrete' Term Operations (with real values of asserted facts)
**********************************************************************/

ast_node_data_value(Lang, Node, NodeType, NodeArity, ArgSpecs) :-
    ast_node_data(Lang, Node, NodeType, NodeArity, ArgSpecs),
    Node.


/**
 * ast_node_argument_value(?Lang, ?Node, ?NodeType, ?ArgLabel, ?ArgKind, ?ArgValue)
 *   Same arguments as "ast_node_argument_value".
 *   This time, the arguments of arg2 (?Node) are being set to their values.
 */
ast_node_argument_value(Lang, Node, NodeType, NodeArity, ArgSpecs, ArgLabel, ArgKind, Value) :-
    ast_node_argument(Lang, Node, NodeType, NodeArity, ArgSpecs, ArgLabel, ArgKind, Value),
    Node.
 
 
/**
 * get_ast_node_argument(?Lang, ?Node, ?NodeType, ?NodeArity, ?ID, ?ArgSpecs, ?ArgLabel, ?ArgKind, ?Value)
 * get_ast_node_argument(?Lang, ?Node, ?NodeType, ?ID, ?ArgLabel, ?ArgKind, ?Value)
 * get_ast_node_argument(?Lang, ?NodeType, ?ID, ?ArgLabel, ?ArgKind, ?Value)
 * get_ast_node_argument(?Lang, ?ID, ?ArgLabel, ?ArgKind, ?Value)
 *   Same arguments as "ast_node_argument_value".
 *   This time, the arguments of arg2 (?Node) are being set to their values.
 */
%most general variant
get_ast_node_argument(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, ArgLabel, ArgKind, Value) :-
    ast_node_argument(Lang, Node, NodeType, NodeArity, ArgSpecs, id, id, ID),
    ast_node_argument(Lang, Node, NodeType, NodeArity, ArgSpecs, ArgLabel, ArgKind, Value),
    Node.
    
get_ast_node_argument(Lang, Node, NodeType, ID, ArgLabel, ArgKind, Value) :-
    get_ast_node_argument(Lang, Node, NodeType, _, ID, _, ArgLabel, ArgKind, Value).
get_ast_node_argument(Lang, NodeType, ID, ArgLabel, ArgKind, Value) :-
    get_ast_node_argument(Lang, _, NodeType, _, ID, _, ArgLabel, ArgKind, Value).
get_ast_node_argument(Lang, ID, ArgLabel, ArgKind, Value) :-
    get_ast_node_argument(Lang, _, _, _, ID, _, ArgLabel, ArgKind, Value).

    
/**
 * get_ast_node_edge(?Lang, ?Node, ?NodeType, ?ArgValue)
 */
%most general:
get_ast_node_edge(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, EdgeLabel, Value) :-
    get_ast_node_argument(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, EdgeLabel, id, Value).
%specialised:
get_ast_node_edge(Lang, Node, NodeType, ID, EdgeLabel, Value) :-
    get_ast_node_argument(Lang, Node, NodeType, ID, EdgeLabel, id, Value).
get_ast_node_edge(Lang, NodeType, ID, EdgeLabel, Value) :-
    get_ast_node_argument(Lang, NodeType, ID, EdgeLabel,id,Value).
get_ast_node_edge(Lang, ID, EdgeLabel, Value) :-
    get_ast_node_argument(Lang, ID, EdgeLabel,id,Value).

    
/**
 * get_node_attribute(?Lang, ?Node, ?NodeType, ?AttrLabel,?ArgValue)
 */
%most general:
get_ast_node_attribute(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, AttributeLabel, Value) :-
    get_ast_node_argument(Lang, Node, NodeType, NodeArity, ID, ArgSpecs, AttributeLabel, attr, Value).
%specialised:
get_ast_node_attribute(Lang, Node, NodeType, ID, AttributeLabel, Value) :-
    get_ast_node_argument(Lang, Node, NodeType, ID, AttributeLabel, attr, Value).
get_ast_node_attribute(Lang, NodeType, ID, AttributeLabel, Value) :-
    get_ast_node_argument(Lang, NodeType, ID, AttributeLabel,attr,Value).
get_ast_node_attribute(Lang, ID, AttributeLabel, Value) :-
    get_ast_node_argument(Lang, ID, AttributeLabel,attr,Value).

%More specialised access-predicates for frequently used tasks:

/**
 * get_ast_node_parent(?Lang,?NodeTerm,?NodeType,?ID,?Parent)
 * get_ast_node_parent(?Lang,?NodeType,?ID,?Parent)
 * get_ast_node_parent(?Lang,?ID,?Parent)
 */
get_ast_node_parent(Lang,NodeTerm,NodeType,ID,Parent) :-
    get_ast_node_edge(Lang,NodeTerm,NodeType,ID,parent,Parent).
get_ast_node_parent(Lang,NodeType,ID,Parent) :-
    get_ast_node_edge(Lang,_,NodeType,ID,parent,Parent).
get_ast_node_parent(Lang,ID,Parent) :-
    get_ast_node_edge(Lang,_,_,ID,parent,Parent).
    
/**
 * get_ast_node_enclosing(?Lang,?NodeTerm,?NodeType,?ID,?Encl)
 * get_ast_node_enclosing(?Lang,?NodeType,?ID,?Encl)
 * get_ast_node_enclosing(?Lang,?ID,?Encl)
 */
get_ast_node_enclosing(Lang,NodeTerm,NodeType,ID,Encl) :-
    get_ast_node_edge(Lang,NodeTerm,NodeType,ID,encl,Encl).
get_ast_node_enclosing(Lang,NodeType,ID,Encl) :-
    get_ast_node_edge(Lang,_,NodeType,ID,encl,Encl).
get_ast_node_enclosing(Lang,ID,Encl) :-
    get_ast_node_edge(Lang,_,_,ID,encl,Encl).

/**
 * get_ast_node_label(?Lang, ?ID,?Label)
 */
get_ast_node_label(Lang,ID,Label) :-
    get_ast_node_edge(Lang,_, Label, id, ID).

/**
 * get_ast_node_term(?Lang,?ID,?NodeType,?Term)
 * get_ast_node_term(?Lang,?ID,?Term)
 */
get_ast_node_term(Lang,ID,NodeType,Term) :-
    get_ast_node_edge(Lang,Term,NodeType,id,ID).
get_ast_node_term(Lang,ID,Term) :-
    get_ast_node_edge(Lang,Term,_,id,ID).

/**
 * get_ast_node_id(?Lang,?NodeTerm,?ID)
 */
get_ast_node_id(Lang,NodeTerm,ID) :-
    nonvar(NodeTerm),
    ast_node_edge(Lang,NodeTerm,_,id,ID).



/**
 *  set_ast_node_argument(?Lang,?Term,?Functor,?ID,?ArgName, ?ArgCard, ?ArgKind, ?ArgConstr, +NewValue)
 *
 *  Sets the Value of an argument of "ArgType" regarding the PEF with "ID".
 *  WARNING: compatability issues with earlier versions are NOT considered
 *    Arg1 is a term representing a language.
 *    Arg2 is a term representing an AST node.
 *    Arg3 is the functor of Arg2
 *    Arg4 is the ID of Arg2
 *    Arg5 is the name of an argument of Arg2.
 *    Arg6 is the cardinality of an argument of Arg2
 *    Arg7 is either 'attr' or 'id'. It indicates whether
 *    Arg8 is a list of constraints for an argument of Arg2
 *    Arg9 is the new value for the specified argument
 */
%most general variant
set_ast_node_argument(Lang,Term,Functor,ID,ArgName, ArgCard, ArgKind, ArgConstr, NewValue) :-
    ast_node_argument_value(Lang, Term, Functor, _, ArgSpecs, id, id, ID), %get values
    Term =.. [_|ArgVals],                                               %isolate arguments
    setArgValue(ArgSpecs,ArgVals,ArgName, ArgCard, ArgKind, ArgConstr, NewValue,NewArgVals),
    NewTerm =.. [Functor|NewArgVals],              %create new term
    delete(Lang,Term),                             %delete old term
    add(Lang,NewTerm).                             %add new term with changed values
    
%specialised variants
set_ast_node_argument(Lang,Term,Functor,ID,ArgName,NewValue) :-
    set_ast_node_argument(Lang,Term,Functor,ID,ArgName, _, _, _, NewValue).
set_ast_node_argument(Lang,Functor,ID,ArgName,NewValue) :-
    set_ast_node_argument(Lang,_,Functor,ID,ArgName, _, _, _, NewValue).
set_ast_node_argument(Lang,ID,ArgName,NewValue) :-
    set_ast_node_argument(Lang,_,_,ID,ArgName, _, _, _, NewValue).

/**
 * setArgValue(ASTArgSpecs,ArgVals,ArgName,ArgCard,ArgKind,ArgConstr,NewValue,NewArgVals)
 *
 * Helper Predicate for set_ast_node_argument
 *   Arg1 is a list of argument specifications
 *   Arg2 is a list of argument values
 *   Arg3 is the name of the argument which should be changed
 *   Arg4 is the cardinality of the argument which should be changed
 *   Arg5 is the kind ("id" or "attr") of the argument which should be changed
 *   Arg6 is a list of constraints for the argument which should be changed
 *   Arg7 is the new value which is to be set
 *   Arg8 is a list of arguments which contain the modification
 */
%setArgValue/7
setArgValue(ASTArgSpecs,ArgVals,ArgName,ArgCard,ArgKind,ArgConstr,NewValue,NewArgVals) :-
    ArgSpec = ast_arg(ArgName, ArgCard, ArgKind, ArgConstr),
    setArgValue(ASTArgSpecs,ArgVals,ArgSpec,NewValue,NewArgVals).
%setArgValue/5
setArgValue(ASTArgSpecs,ArgVals,ArgName,ArgKind,NewValue,NewArgVals) :-
    ArgSpec = ast_arg(ArgName, _, ArgKind, _),
    setArgValue(ASTArgSpecs,ArgVals,ArgSpec,NewValue,NewArgVals).

setArgValue(_,[],_,_,[]).
%set new value
setArgValue([ASTArgSpecs|T1],[_|T2],ASTArgSpecs,NewValue,[NewValue|T3]) :-
    setArgValue(T1,T2,ASTArgSpecs,NewValue,T3),!.
%copy old values
setArgValue([_|T1],[H1|T2],ArgSpec,NewValue,[H1|T3]) :-
    setArgValue(T1,T2,ArgSpec,NewValue,T3).
    

/**
 * set_ast_node_parent(Lang,Term,Functor,ID,NewValue)
 *   set_ast_node_parent(Lang,Functor,ID,NewValue)
 *     set_ast_node_parent(Lang,ID,NewValue)
 *
 *    For most general variant:
 *    Arg1 is a term representing a language.
 *    Arg2 is a term representing an AST node term.
 *    Arg3 is the functor of Arg2
 *    Arg4 is the ID of Arg2
 *    Arg5 is the new parent value
 */
set_ast_node_parent(Lang,Term,Functor,ID,NewValue) :-
    set_ast_node_argument(Lang,Term,Functor,ID,parent,NewValue).
set_ast_node_parent(Lang,Functor,ID,NewValue) :-
    set_ast_node_argument(Lang,Functor,ID,parent,NewValue).
set_ast_node_parent(Lang,ID,NewValue) :-
    set_ast_node_argument(Lang,ID,parent,NewValue).


/**
 * set_ast_node_enclosing(Lang,Term,Functor,ID,NewValue)
 *   set_ast_node_enclosing(Lang,Functor,ID,NewValue)
 *     set_ast_node_enclosing(Lang,ID,NewValue)
 *
 *    For most general variant:
 *    Arg1 is a term representing a language.
 *    Arg2 is a term representing an AST node term.
 *    Arg3 is the functor of Arg2
 *    Arg4 is the ID of Arg2
 *    Arg5 is the new enclosing value
 */
set_ast_node_enclosing(Lang,Term,Functor,ID,NewValue) :-
    set_ast_node_argument(Lang,Term,Functor,ID,encl,NewValue).
set_ast_node_enclosing(Lang,Functor,ID,NewValue) :-
    set_ast_node_argument(Lang,Functor,ID,encl,NewValue).
set_ast_node_enclosing(Lang,ID,NewValue) :-
    set_ast_node_argument(Lang,ID,encl,NewValue).



/* ========== Rest is unused, just for backup ================== */

/************************* nodes ***************************
 REPLACED BY ABOVE ast_node/2:
*
*  ast_node(?type, ?term, ?id)
*     Arg1 is the node type (functor) of arg2 and arg3 is its identity.
*     If arg1 is a variable the predicate enumerates all the nodes
*     including their negation (eg. 'a' and 'not(a)').
*     If no node exists the predicate THROWS AN EXCEPTION.
* 
* Pseudo Knoten: implementsT, extendsT, modifierT,
* 
*****************************************************************/
/*
ast_node(_type, Term, _id) :-    % check for negated terms first
    nonvar(Term),
    Term = not(_tree),
    !,
    ast_node(_type, _tree, _id).

ast_node(Functor, Term, ID) :-
    tree_kind(Functor,Len),
    functor(Term, Functor, Len),
    Term =.. [Functor,ID|_].
 */       

/*ast_node(Term, ID) :- 
    nonvar(Term),
    !,
    % functor(Term, Functor, Len), 
    % throw_exception_upon_failure(tree_kind(Functor,Len),'Wrong AST node! '),
    Term =.. [Functor,ID|_].     % the id of any AST node is its first argumnent
*/


