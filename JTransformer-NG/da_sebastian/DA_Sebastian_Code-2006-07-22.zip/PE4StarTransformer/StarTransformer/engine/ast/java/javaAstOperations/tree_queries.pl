/**
  enclMethod(?Id, ?MethodId)
  
  Unifies MethodId with the 
  enclosing method of the tree Id.
*/

enclMethod(_ID, _ID) :-
    %methodDefT(_ID, _, _, _, _, _, _),
    get_ast_node_label('Java',_ID,methodDefT),
    !.
enclMethod(_id, _Encl) :-
    Lang='Java',
    get_ast_node_enclosing('Java',_id, _encl),
    enclMethod(_encl, _Encl),
    !.
enclMethod(_id, 'null').
    
/**
  enclClass(?Id, ?ClassId)
  
  Unifies ClassId with the 
  enclosing class of the tree Id.
  Fails if Id is a package id.
*/

enclClass(Id, Id) :-
    %classDefT(Id, _, _, _),
    get_ast_node_label('Java',Id,classDefT),
    !.
enclClass(Id, Id) :-
    %packageT(Id, _),
    get_ast_node_label('Java',Id,packageT),
    !,
    fail.
    
enclClass(Id, Encl) :-
    get_ast_node_enclosing('Java',Id, EnclRec),
    enclClass(EnclRec, Encl),
    !.
enclClass(_, 'null').

/**
  enclosing(?Id, ?EnclId)
  
  Unifies EnclId with the enclosing class
  element (method, constructor, initializer or field)
  of the tree Id.
  
  TODO: reimplement as a meta-predicate

  see languageIndependentAccessLayer.pl!!!
*/



test(getTermT01) :-
    assert(methodDefT(testId,1,2,3,type(1,class, 0),5,6)),
    get_ast_node_term(testId, methodDefT(testId,1,2,3,type(1,class, 0),5,6)),
    retract(methodDefT(testId,1,2,3,type(1,class, 0),5,6)).

    

getToplevel(Id, _) :-
    %not(tree(Id,_,_)),
    \+ get_ast_node_term('Java',Id,_),
    !,
    fail.

getToplevel(Id, Tl) :-
    %class(Id,Pckg,_),
    %toplevelT(Tl, Pckg, _, Classes),
    get_ast_node_argument('Java',classDefT,Id,parent,Pckg),
    %get_ast_node_label('Java',T1,toplevelT),
    get_ast_node_argument('Java',toplevelT,T1,parent,Pckg),
    get_ast_node_argument('Java',toplevelT,T1,defs,Classes),
    member(Id, Classes),
    !.

getToplevel(Id, TL) :-
    %class(Id,Outer,_),
    %class(Outer,_,_),
    get_ast_node_argument('Java',classDefT,Id,parent,Outer),
    %get_ast_node_label('Java',Outer,classDefT),
    !,
    getToplevel(Outer, TL).

getToplevel(Id, TL) :-
    %class(Id,Parent,_),
    get_ast_node_argument('Java',classDefT,Id,parent,Parent),
    enclClass(Parent,Outer),
    !,
    getToplevel(Outer, TL).

getToplevel(Id, TL) :-
    %not(class(Id,_,_)),
    \+ get_ast_node_label('Java',Id,classDefT),
    enclClass(Id,Class),
    !,
    getToplevel(Class, TL).


can_modify(_id) :-
    enclClass(_id, _class),
    %not(externT(_class)).
    \+ get_ast_node_label('Java',_class,externT).
% TODO  forall(reference(_id, _ref), (enclClass(_ref, _c2), not(externT(_c2)))).

% todo TEUER : effizientere loesung
reference(_id, _Ref) :-
    % look at all facts
    clause(_c, true),
    % that describe tree's
    arg(1, _c, _Ref),
    get_ast_node_term('Java',_Ref,_),
    % and reference _id
    arg(_, _c, _id).
    
getPackage(_pckg,_pckg):-
    %packageT(_pckg, _),
    get_ast_node_label('Java',_pckg,packageT),
    !.

getPackage(Class,null):-
    %classDefT(Class, null,_,_),
    %get_ast_node_label('Java',Class,classDefT),
    get_ast_node_argument('Java',classDefT,Class,parent,null),
    !.

getPackage(_id,null):-
    get_ast_node_enclosing('Java',_id, null).

getPackage(_id,_pckg):-
    get_ast_node_enclosing('Java',_id, _encl),
    getPackage(_encl,_pckg).


/**
 * tree_attributes(ID, Functor, [AttributeVal1,...])
 *
 * e.g. for the class id 10001 (java.lang.Object):
 * 
 * tree_attributes(10001,  classDefT, ['Object']).
 */
    
tree_attributes(Lang,ID, Functor, Attributes) :-
    %tree(ID,_, Functor),
    get_ast_node_label(Lang,ID,Functor),
    get_ast_node_term(Lang,ID,Term),
    Term =.. [Functor|Args],
    ast_node_def(Lang, Functor,AttributeDescr),
    extract_attributes_(AttributeDescr,Args, Attributes).

extract_attributes_(_,[],[]).
extract_attributes_([ast_arg(_,_, attr, _)|Descrs],[Arg|Args],[Arg|Attribs]) :-
    !, extract_attributes_(Descrs,Args,Attribs).
         
extract_attributes_([_|Descrs],[_|Args],Attribs) :-
    !, extract_attributes_(Descrs,Args,Attribs).
    
test(tree_attributes) :-
    fullQualifiedName(ID,'java.lang.Object'),
    tree_attributes(ID, Kind, Attributes),
    assert_true(Kind = classDefT),
    assert_true(Attributes = ['Object']).

test(tree_attributes2) :-
    fullQualifiedName(ID,'java.lang.Object'),
    tree_attributes(MID,methodDefT,[wait, type(basic, void, 0)]),
    methodDefT(MID,ID,_,_,_,_,_).
    
    

% ld:
% contains_type tests wether a classDefT is declared 
% in the respective topLevelT,named file or definition list.
% 
% the test descents to reach  innner classes aswell.
%
% i am using this predicate to collect the fqns to be retracted from
% globalIds when a toplevel is deleted. (not changed!)
contains_type(_tl,_type):-
    %toplevelT(_tl,_,_,_defs),
    %get_ast_node_label('Java',_t1,toplevelT),
    get_ast_node_argument('Java',toplevelT,_t1,defs,_defs),
    !,
    contains_type(_defs,_type).

contains_type(_filename,_type):-    
    %toplevelT(_,_,_filename,_defs),
    %get_ast_node_label('Java',ID,toplevelT),
    ast_node_argument('Java', Node, toplevelT, file, _filename),
    ast_node_argument('Java', Node, toplevelT, defs, _defs),
    Node,
    !,
    contains_type(_defs,_type).
    
contains_type(_list,_type):-
    member(_type,_list),
    %classDefT(_type,_,_,_).
    get_ast_node_label('Java',_type,classDefT).
    
contains_type(_list,_type):-
    member(_node,_list),
    %classDefT(_node,_,_,_defs),
    get_ast_node_argument('Java',classDefT,_node,defs,_defs),
    contains_type(_defs,_type).
    
    

findId(_root, _id) :-
    %sub_trees(_root, _subs),
    get_ast_sub_tree('Java',_root,_subs),
    !,
    findId(_root, _subs, _id).
findId(_root, _id) :-
    format("Tree node for ~d does not exist!~n", [_root]).


findId(_, [], _).
findId(_root, [_h | _t], _h) :-
    get_ast_node_label('Java',_h,_type),
    !,
    format("~s(~d)~n", [_type, _root]),
    findId(_root, _t, _h).

findId(_root, [_h | _t], _h) :-
    writeln(_root),
    !,
    findId(_root, _t, _h).

findId(_root, [_h | _t], _id) :-
    !,
    findId(_h, _id),
    findId(_root, _t, _id).



new_ids_by_list([],[]).
new_ids_by_list([_ | _t],[_id | _T]) :-
    new_id(_id),
    new_ids_by_list(_t,_T).

/**
 * new_ids([-id1,-id2,...])
 * 
 * Binds the variables id1, ... to new Ids.
*/
 
new_ids([]).
new_ids([_H | _T]) :-
    new_id(_H),
    new_ids(_T).

/**
 * getSymbol(?id, ?symbol)
 *       
 * Binds ?symbol to the resolved class (member)
 * of a getFieldT, applyT, identT of selectT.
*/

getSymbol(_id, _Symbol) :- get_ast_node_argument('Java',_id,field,_Symbol). %getFieldT(_id, _, _, _, _, _Symbol).
getSymbol(_id, _Symbol) :- get_ast_node_argument('Java',_id,ref,_Symbol). %applyT(_id, _, _, _, _, _,_Symbol).
getSymbol(_id, _Symbol) :- get_ast_node_argument('Java',_id,ref,_Symbol). %selectT(_id, _, _, _, _, _Symbol).
getSymbol(_id, _Symbol) :- get_ast_node_argument('Java',_id,ref,_Symbol). %identT(_id, _, _, _, _Symbol).

/**
 *  getSymbolName(?id, ?name)
 *        
 *  Binds ?name to the name of the program element ?id.
 *  If the tree ?id has no name argument ?name will be bound
 *  to 'null'. 
 *  Following trees have a name attribute:
 *
 *  local variable (localDefT/6)
 *  field          (fieldDefT/5)
 *  parameter      (paramDefT/4)
 *  method         (methodDefT/7)
 *  class          (classDefT/4)
 *  package        (packageT/3)
 */
 
/*SL: Die obige Auflistung stimmt nicht mit ast_node_def/3 �berein.
      So k�nnten alle Elemente mit "name"-Argument abgefragt werden:
      
getSymbolName(_id,_name) :-
    get_ast_node_argument('Java',_id,name,_name),!.
getSymbolName(_,'null').
*/

getSymbolName(_id, _name) :-
    %localDefT(_id,_,_,_,_name, _),!.
    get_ast_node_argument('Java',localDefT,_id,name,_name),!.
getSymbolName(_id, _name) :-
    %fieldDefT(_id,_,_,_name, _),!.
    get_ast_node_argument('Java',fieldDefT,_id,name,_name),!.
getSymbolName(_id, _name) :-
    %methodDefT(_id, _, _name, _,_,_, _),!.
    get_ast_node_argument('Java',fieldDefT,_id,name,_name),!.
getSymbolName(_id, _name) :-
    %classDefT(_id,_, _name, _),!.
    get_ast_node_argument('Java',classDefT,_id,name,_name),!.
getSymbolName(_id, _name) :-
    %paramDefT(_id,_,_,_name),!.
    get_ast_node_argument('Java',paramDefT,_id,name,_name),!.
getSymbolName(_id, 'null').



beforeInBlock(_elem, _newElem, _EnclBlock, _NewList) :-
    enclBlockMember(_elem, _BlockMember),
    get_ast_node_parent('Java',_BlockMember,_EnclBlock),
    %blockT(_EnclBlock, _BlockParent, _, _List),
    ast_node_argument('Java', Node, blockT, id, _EnclBlock),
    ast_node_argument('Java', Node, blockT, parent, _BlockParent),
    ast_node_argument('Java', Node, blockT, stmts, _List),
    Node,
    insertBefore(_List, _BlockMember, _newElem, _NewList).



enclBlockMember(_tree, _tree) :-
    get_ast_node_parent('Java',blockT,_tree,_Parent).
    %blockT(_Parent, _, _, _).

enclBlockMember(_tree, _BlockMember) :-
    get_ast_node_parent('Java',_tree,_Parent),
    get_ast_node_label('Java',_Parent,_Factname),
    \+(equals(_Factname  , blockT)),
    \+(equals(_Factname, methodDefT)),
    \+(equals(_Factname, classDefT)),
    \+(equals(_Factname, packageT)),
    enclBlockMember(_Parent, _BlockMember).

enclBlock(_tree, _tree) :- get_ast_node_label('Java',_tree,blockT).
enclBlock(_tree, _Block) :-
   enclBlockMember(_tree, _BlockMember), 
   get_ast_node_parent('Java',_BlockMember,_Block).



getReceiver(_ident, 'null') :-     get_ast_node_label('Java',_ident,identT),!. %identT(_ident, _, _, _, _),!.
getReceiver(_select, _Receiver) :-
    get_ast_node_argument('Java',selectT,_select,selected,_Receiver).
    %selectT(_select, _, _, _, _Receiver, _).
getReceiver(_select, _Receiver) :-
    get_ast_node_argument('Java',getFieldT,_select,expr,_Receiver).
    %getFieldT(_select, _, _, _Receiver, _, _).
getReceiver(_select, _Receiver) :- setField(_select,_,_,_Receiver,_,_).
%SL: Wo ist setField definiert???
getReceiver(_select, _Receiver) :- methodCall(_select, _, _, _Receiver, _, _,_).
%SL: Wo ist methodCall definiert???


/*
    getType(localDefT | fieldDefT | paramDefT | methodDefT, _Type)

    gibt im Param2 den type type((class | basic tpyename), classID, ArrayCount)
    der *Def zur�ck

    Param1 type
        identT
            gibt im Param2 den type den umschlie�enden Klasse zur�ck
        selectT
            gibt im Param2 den return type zur�ck
            
    SL: gleiches Problem wie bei getSymbolName. Gro�e Inkonsistenzen zu
        ast_node_def/3, was Elemente mit "type"-Argumenten betrifft :(

*/

getType(type(_kind,_class,_dim),type(_kind,_class,_dim)) :-  !.

getType(Var,type(basic,null,0)) :- 
    nonvar(Var),
    Var = null.

getType(_varDef, _Type) :-
    %localDefT(_varDef, _,_, _Type, _,_).
    get_ast_node_argument('Java',localDefT,_varDef,type,_Type).
    
getType(_varDef, _Type) :-
    %fieldDefT(_varDef, _, _Type, _,_).
    get_ast_node_argument('Java',fieldDefT,_varDef,type,_Type).

getType(_varDef, _Type) :-
    %paramDefT(_varDef, _, _Type, _).
    get_ast_node_argument('Java',paramDefT,_varDef,type,_Type).

getType(_ident, _Type) :-
    %identT(_ident,_,_,_,_ref),
    get_ast_node_argument('Java',identT,_ident,ref,_ref),
    getType(_ref, _Type).

getType(_select, _Type) :-    
    %getFieldT(_select,_,_,_,_,_ref),
    get_ast_node_argument('Java',getFieldT,_select,field,_ref),
    getType(_ref, _Type).
 
% has setField a type? type(basic,void,0) ?     
getType(_select, _Type) :-
    setField(_select,_,_,_,_ref,_),
    getType(_ref, _Type).

getType(Apply, Type) :-
    %applyT(Apply,_,_,_,_,_,Meth),
    get_ast_node_argument('Java',applyT,Apply,ref,Meth),
    getType(Meth,Type).

getType(_methodDef, type(class,_class,0)) :-
    %methodDefT(_methodDef,_class, '<init>',_, _Type, _,_),
    ast_node_argument('Java', Node, methodDefT, id, _methodDefT),
    ast_node_argument('Java', Node, methodDefT, parent, _class),
    ast_node_argument('Java', Node, methodDefT, name, '<init>'),
    ast_node_argument('Java', Node, methodDefT, type, _Type),
    Node,
    !.

getType(_methodDef, _Type) :-
    %methodDefT(_methodDef,_, _,_, _Type, _,_).
    get_ast_node_argument('Java',methodDefT,_methodDef,type,_Type).

getType(_literal, _Type) :-
    %literalT(_literal,_,_,_Type,_).
    get_ast_node_argument('Java',literalT,_literal,type,_Type).
getType(_class, type(class, _class, 0)) :-
    %classDefT(_class,_,_,_).
    get_ast_node_label('Java',_class,classDefT).

getType(_class, _type) :-
    %newClassT(_class,_,_,_,_,_identSelect,_,_),
    get_ast_node_argument('Java',newClassT,_class,clident,_identSelect),
    getType(_identSelect,_type).


getType(Op, Type) :-
    %operationT(Op,_,_, [Expr|_], _,_),
    get_ast_node_argument('Java',operationT,Op,args,[Expr|_]),
    !,
    getType(Expr,Type).
    

getType(_select, _Type) :-
    %selectT(_select,_,_,_,_,_ref),
    get_ast_node_argument('Java',selectT,_select,ref,_ref),
    getType(_ref, _Type).

getType(Array, Type) :-
    %newArrayT(Array,_,_,_,_,Type).
    get_ast_node_argument('Java',newArrayT,Array,type,Type),


%TODO: weiter Expressions
getType(null, type(class,null,0)).

% optimiert fuer ident | selects
getRefType(_ident, _Type) :-
    %identT(_ident,_,_,_,_ref),
    get_ast_node_argument('Java',identT,_ident,ref,_ref),
    getType(_ref, _Type).

getRefType(_select, _Type) :-
    %selectT(_select,_,_,_,_,_ref),
    get_ast_node_argument('Java',selectT,_select,ref,_ref),
    getType(_ref, _Type).

/*
    Returns null if the id refers to an this ident,
    else it returns id
*/
nullIfThis(_this, 'null') :-
    %identT(_this, _, _, 'this', _),
    get_ast_node_argument('Java',identT,_this,name,'this'),
    !.
nullIfThis(_id, _id).

/*
        packagePath(+Pckgname,-PckgPath)
*/

packagePath(Pckgname,PckgPath) :-
    atom_concat(First,'.',RestName, Pckgname),
    !,
        packagePath(RestName,RestPath),
    atom_concat(First,'/',Rest1),
    atom_concat(Rest1, RestPath, PckgPath).
  

packagePath(Name,Name).
    
test(packagePath):-
    packagePath('pckg1.pckg2.Name','pckg1/pckg2/Name').

/**
 * types(?ExprOrDeclarationList, ?typeTermList)
 */
        
types([],[]).
types([Expr|Exprs], [Type|Types]):-   
    getType(Expr,Type),
    types(Exprs, Types).


/**
 * subtype(?Sub, ?Super)
 *
 * Binds Super to any direct or 
 * indirect super type of Sub.
 * 
 * Only for object types.
 */
   
subtype(_sub, _sub).
subtype(_sub, _super) :-
    %extendsT(_sub,_super).
    get_ast_node_argument('Java',extendsT,_sub,super,_super).
subtype(_sub, _super) :-
    %implementsT(_sub,_super).
    get_ast_node_argument('Java',implementsT,_sub,super,_super).
subtype(_sub, _super) :-
    %extendsT(_sub,_subsuper),
    get_ast_node_argument('Java',extendsT,_sub,super,_subsuper).
    subtype(_subsuper, _super).
subtype(_sub, _super) :-
    %implementsT(_sub,_subsuper),
    get_ast_node_argument('Java',implementsT,_sub,super,_subsuper),
    subtype(_subsuper, _super).
subtype(Var, _):-
    nonvar(Var),
    Var = null.

/**
 * stringType(StringTypeTerm)
 *
 * Binds StringTypeTerm to the term 
 * referencing java.lang.String.
 */

stringType(type(class, _id, 0)) :-
    stringClass(_id).

stringClass(_ID) :-
    %packageT(_syspid, 'java.lang'),
    %classDefT(_ID, _syspid, 'String', _).
    get_ast_node_argument('Java',packageT,_syspid,name,'java.lang'),
    ast_node_argument('Java', Node, classDefT, id, _ID),
    ast_node_argument('Java', Node, classDefT, parent, _syspid),
    ast_node_argument('Java', Node, classDefT, name, 'String'),
    Node.

    
