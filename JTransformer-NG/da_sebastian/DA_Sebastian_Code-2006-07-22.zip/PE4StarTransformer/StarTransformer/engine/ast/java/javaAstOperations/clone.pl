:- dynamic cloned/2.
/**
cloneTree(+Id,-NewId)

Creates a deep copy of the tree id and 
binds it to newId.
*/

cloneTree(Lang,_id, _newTree) :-
    %tree(_id, _parent, _),
    get_ast_node_parent(Lang,_id,_parent),
    %enclosing('Java',_id, _encl),
    get_ast_node_enclosing(Lang,_id, _encl),
    cloneTree(Lang,_id,_parent,_encl,_newTree),
    !.

/**
cloneTree(+Id,-NewId)

Creates a deep copy of the tree id, 
binds it to newId and sets the
new parent to Parent and the Enclosing
tree to Encl.
*/

cloneTree(Lang,_id, _parent, _encl, _newTree) :-
    createCloneIDs(_id,_newTree),
    clone(Lang,_id, _parent, _encl, _newTree),
    retractall(cloned(_, _)).

getCloneIfAvail(_id, _id) :-
    \+(cloned(_id, _)), !.

getCloneIfAvail(_id, _newId) :-
    cloned(_id, _newId),!.

getCloneIfAvail(type(class, _id, _count), type(class, _newId, _count)) :-
    cloned(_id, _newId), !.

getCloneIfAvail(type(_type, _id, _count), type(_type, _id, _count)).

cloneModifier(_id, _new) :-
    %findall(_mod, modifierT(_id, _mod), _list),
    findall(_mod,get_ast_node_attribute('JavaAttributes',modifierT,_id,modifier,_mod),_list),
    addModifier(_new, _list).

cloneExtends(Id,NewId) :-
    %extendsT(Id,Ext),
    get_ast_node_edge('JavaAttributes',extendsT,Id,super,Ext),
    getCloneIfAvail(Ext,NewExt),
    %add(extendsT(NewId,NewExt)),
    ast_node_edge('JavaAttributes',NewTerm,extendsT,id,NewId),
    ast_node_edge('JavaAttributes',NewTerm,extendsT,super,NewExt),
    add(NewTerm),
    !.
        
cloneExtends(_,_).      

cloneImplements(Id,NewId) :-
    findall(Impl,(
      %implementsT(Id,Impl),
      get_ast_node_edge('JavaAttributes',implementsT,Id,super,Impl),
      getCloneIfAvail(Impl,NewImpl),
        ast_node_edge('JavaAttributes',NewTerm,implementsT,id,NewId),
        ast_node_edge('JavaAttributes',NewTerm,implementsT,super,NewImpl),
        %add(implementsT(NewId,NewImpl)
        add(NewTerm)),_),
        !.      
cloneImplements(_,_).   


/**
addModifier(Id,ModList)

Adds the modifier(s) ModList to
the the tree Id.
Instead of a one-element list a 
just one element may be
given as an argument.
*/

addModifier(_, []) :- !.
addModifier(Id, [H | T]) :-
    !,
    %add(modifierT(Id, H)),
    ast_node_edge('JavaAttributes',NewTerm,modifierT,id,Id),
    ast_node_attribute('JavaAttributes',NewTerm,modifierT,modifier,H),
    add(NewTerm),
    addModifier(Id, T).
addModifier(Id, Mod) :-
    !,
    %add(modifierT(Id, Mod)).
    ast_node_edge('JavaAttributes',NewTerm,modifierT,id,Id),
    ast_node_attribute('JavaAttributes',NewTerm,modifierT,modifier,Mod),
    add(NewTerm).

/**
removeModifier(+Id,+ModList)

Removes the list of modifiers ModList 
from the tree id.
*/
removeModifier(_, []) :- !.
removeModifier(Id, [H | T]) :-
    !,
    %delete(modifierT(Id, H)),
    ast_node_edge('JavaAttributes',NewTerm,modifierT,id,Id),
    ast_node_attribute('JavaAttributes',NewTerm,modifierT,modifier,H),
    delete(NewTerm),
    removeModifier(Id,T).
    
removeModifier(Id, Mod) :-
    !,
    %delete(modifierT(Id, Mod)).
    ast_node_edge('JavaAttributes',NewTerm,modifierT,id,Id),
    ast_node_attribute('JavaAttributes',NewTerm,modifierT,modifier,Mod),
    delete(NewTerm).


/**
  createCloneIDs(+id)

Asserts a clone/2 fact for every subtree of
the tree id (including id). 
The first argument is id,
the second one a new unique id.

Auxiliary predicate for cloneTree.
*/
createCloneIDs('null') :- !.
createCloneIDs([_h | _t]) :-
    createCloneIDs(_h),
    createCloneIDs(_t).
createCloneIDs([]) :- !.
createCloneIDs(_id) :-
    new_id(_new),
    !,
    assert(cloned(_id,_new)),
    %sub_trees(_id, _subs),
    get_ast_node_sub_trees('Java',_id,_subs),
    createCloneIDs(_subs).

createCloneIDs(_id,_new) :-
    ( var(_new)->
       new_id(_new);true),
    !,
    assert(cloned(_id,_new)),
    %sub_trees(_id, _subs),
    get_ast_node_sub_trees('Java',_id,_subs),
    createCloneIDs(_subs).



%handleArgs(Lang,NewID,Encl,Functor,InstArgs,ArgInfo,NewArgs)
%Behandlung von Parameterlisten

handleArgs(_,_,_,_,_,[],_,[]) :- !.
%Fall1: id -> setze NewID
handleArgs(Lang,NewID,Parent,Encl,Functor,[ID|T1],[ast_arg(id,_,_,_)|T2],[NewID|T3]) :-
    cloned(ID,NewID),
    %((ast_node_argument(Lang, _, Functor, hasModif, attr, ArgVal), cloneModifier(ID,NewID));true),
    handleArgs(Lang,NewID,Parent,Encl,Functor,T1,T2,T3),
    !.

%Fall2: Attribut -> kopieren
handleArgs(Lang,NewID,Parent,Encl,Functor,[El|T1],[ast_arg(_,_,attr,_)|T2],[El|T3]) :-
    handleArgs(Lang,NewID,Parent,Encl,Functor,T1,T2,T3),                                  %copy attributes
    !.
%Fall3: Referenzen auf Kinder (Subtree) -> Klonen und Ergebnis kopieren..
handleArgs(Lang,NewID,Parent,Encl,Functor,[El|T1],[ast_arg(Name,_,id,_)|T2],[NewEl|T3]) :-
    ast_node_sub_tree(Lang,Functor,Subtypes),
    member(Name,Subtypes),        %ist es ein Subtype?
    clone(Lang,El,NewID,Encl,NewEl),
    handleArgs(Lang,NewID,Parent,Encl,Functor,T1,T2,T3),
    !.
%Fall4: Referenzen auf Geschwister
handleArgs(Lang,NewID,Parent,Encl,Functor,[El|T1],[ast_arg(Name,_,id,_)|T2],[NewEl|T3]) :-
    getCloneIfAvail(El,NewEl),
    handleArgs(Lang,NewID,Parent,Encl,Functor,T1,T2,T3).
/*
Neue Version von clone, die sich nach den Infos in ast_node_def/3 richtet:
  - Attribute werden kopiert
  - Referenzen auf parents und siblings kopieren
  - Referenzen auf children klonen
Unterschiede:
  - Es kommt in der alten Version vor, dass der Klon von Argumenten gesucht
    wird, die als Attribute gekennzeichnet sind. Wird hier als nicht sinnvoll
    erachtet und �bergangen.
    
Bei localDefT hasModif-Argument hinzugef�gt!!!
 */
 
 
clone(_,'null', _, _, 'null') :- !.
clone(_,[],_,_,[]) :- !.
clone(Lang,[H|T],NewID,Encl,[H2|T2]) :-
    clone(Lang,H,NewID,Encl,H2),
    clone(Lang,T,NewID,Encl,T2),
    !.
 
%---SPEZIALF�LLE-----------------------------------------------------------
clone('Java',_id, _parent, _encl, _new) :-
    packageT(_id,_name),
    !,
    findall(_sub, toplevelT(_sub, _id, _,_), _subtrees),
    cloned(_id, _new),
    add(package(_new, _name)),
    clone(_subtrees, _new, _new, _toplevels).

clone('Java',_id, _parent, _encl, _new) :-
    classDefT(_id,Package,_name,Subtrees),!,
    cloned(_id, _new),
    cloneModifier(_id, _new),
    cloneExtends(_id,_new),
    cloneImplements(_id,_new),
    !,
        (
                add_to_class(_parent, _new)      % member class
                ;
                true
        ),(
        toplevelT(Toplevel,Package,_,Members), % toplevel class
        member(_id, Members),
        addToToplevel(Toplevel, _new)
        ;
        true
    ),
    clone(Subtrees, _new, _new, NewSubtrees),
    add(classDefT(_new, _parent, _name, NewSubtrees)),
    add_to_class(_new, NewSubtrees).
clone('Java',_id, _parent, _encl, _new) :-
    methodDefT(_id,_,_name,_params,_ret,_thrown,_body),
    !,
    cloned(_id, _new),
    cloneModifier(_id, _new),
    !,
    clone(_params, _new, _new, _newParams),
    clone(_body, _new, _new, _newBody),
    (add_to_class(_parent, _new);true),
    add(methodDefT(_new, _parent, _name, _newParams, _ret, _thrown, _newBody)).

clone('Java',_id, _parent, _encl, _new) :-
    localDefT(_id,_,_,_type,_name,_init),
    !,
    cloned(_id, _new),
    cloneModifier(_id, _new),
    getCloneIfAvail(_type, _newType),
    clone(_init, _new, _encl, _newInit),
    add(localDefT(_new,_parent,_encl,_newType,_name,_newInit)).

clone('Java',_id, _parent, _encl, _new) :-
    fieldDefT(_id,_,_type,_name,_init),
    !,
    cloned(_id, _new),
    cloneModifier(_id, _new),
    getCloneIfAvail(_type, _newType),
    clone(_init, _new, _id, _newInit),
    (add_to_class(_parent, _new);true),
    add(fieldDefT(_new,_parent,_newType,_name,_newInit)).

clone('Java',_id, _parent, _encl, _new) :-
    paramDefT(_id,_,_type,_name),
    !,
    cloned(_id, _new),
    cloneModifier(_id, _new),
    getCloneIfAvail(_type, _newType),
    add(paramDefT(_new,_parent,_newType,_name)).

%--------------------------------------------------------------------------
 
clone(Lang,_id,_parent,_encl,_new) :-
    get_ast_node_term(Lang,_id,PEF),       %AST-Knoten von "_id" finden und Term holen
    !,
    PEF =.. [_|InstArgs],                   %Instanziierte Argumente isolieren
    functor(PEF,Functor,_),
    ast_node_def(Lang,Functor,ArgInfo),     %Argumentbeschreibung holen
    handleArgs(Lang,_new,_parent,_encl,Functor,InstArgs,ArgInfo,NewArgs),
    NewPEF =.. [Functor|NewArgs],
    add(NewPEF).

clone(Lang,_id, _, _, _) :-
    %tree(_id, _p, _name),
    get_ast_node_parent(Lang,_id,_p),
    get_ast_node_label(Lang,_id,_name),
    !,
    format('ERROR: clone: ~a, ~a, ~a~n', [_id, _p, _name]).

clone(Lang,_id, _, _, 'null') :-
    %not(tree(_id, _, _)),!.
    \+ get_ast_node_term(Lang,_id,_),!.



cloneParams(_newParent, _oldList, _newList) :-
    recCloneParams(_newParent, _oldList, _newList, 0).
recCloneParams(_, [], [], _).
recCloneParams(_newParent, [_varDef | _varDefs], [_Copy | _Copies], _counter) :-
    %paramDefT(_varDef, _, _retType, _),
    get_ast_node_attribute('Java',paramDefT,_varDef,type,_retType),
    new_id(_Copy),
    append_num('x', _counter, _name),
    %add(paramDefT(_Copy, _newParent,_retType, _name)),
      ast_node_edge('Java',NewTerm,paramDefT,id,_Copy),
      ast_node_edge('Java',NewTerm,paramDefT,parent,_newParent),
      ast_node_attribute('Java',NewTerm,paramDefT,type,_retType),
      ast_node_attribute('Java',NewTerm,paramDefT,name,_name),
      add(NewTerm),
    plus(_counter, 1, _next),
    recCloneParams(_newParent, _varDefs, _Copies, _next).
