/*
 * This module provides predicates for 
 * the traversal of the PEFs and general 
 * queries on the tree structure.
 * May be splitted in the future (traversal/general, or s.th.).
 */


/*
  remove_from_class(+Class,+Member)
  
  Removed a member from the class, if Member is
  an element of the class.
  Fails if Class or Member is not bound and if Class is not a
  of type classDefT.
*/
remove_from_class(_class, _) :- \+ (get_ast_node_label('Java',_class, classDefT)).
remove_from_class(_class, _id) :-
    %classDefT(_class, _p,_n,_members),
    ast_node_argument('Java',Term,classDefT,id,_class),
    ast_node_argument('Java',Term,classDefT,parent,_p),
    ast_node_argument('Java',Term,classDefT,name,_n),
    ast_node_argument('Java',Term,classDefT,defs,_members),
    Term,
    findall(_m, (member(_m, _members), _m \= _id ), _newMembers),
    %delete('Java',classDefT(_class, _p,_n,_members)),
    %add('Java',classDefT(_class, _p,_n,_newMembers)).
    set_ast_node_argument('Java',classDefT,_class,defs,_newMembers).


/*
  add_to_class(+Class,+Member|+MemberList)
  
  Adds Member(s) to the class, if the Member is not already in the 
  member list.
  Fails if Class or Member is not bound and if Class is not a
  of type classDefT.
*/

/*

%case1: element _id is already in class
add_to_class(_class, _id) :-
    nonvar(_class),
    nonvar(_id),
    get_ast_node_argument('Java',_class,defs,_members),
    member(_id, _members),
    !.
add_to_class(_class, _id) :-
    nonvar(_class),
    nonvar(_id),
    get_ast_node_argument('Java',_class,defs,_members),     %get old members
    append(_members, [_id], _newMembers),                   %append new member
    set_ast_node_argument('Java',_class,defs,_newMembers).  %set new argument value
*/

/**
        rec_set_ast_node_enclosing(+Id, +Encl)

        Set the enclosing element of the tree Id
        and all its sub trees to Encl. 
        The old facts will be retracted and
        new facts with Encl asserted.
        
        INFO: This predicate uses the add/1 and delete/1 
        predicates which track all changes to
        the factbase in the rollback functionality.
*/

rec_set_ast_node_enclosing(_,'null', _).
rec_set_ast_node_enclosing(_,[], _).
rec_set_ast_node_enclosing(Lang,[_H | _T], _encl) :-
    !,
    rec_set_ast_node_enclosing(Lang,_H, _encl),
    rec_set_ast_node_enclosing(Lang,_T, _encl).

rec_set_ast_node_enclosing(_,_id, _encl) :-
    %classDefT(_id,_,_,_).
    ast_node_argument('Java',Term,classDefT,id,_id),
    Term.
    
rec_set_ast_node_enclosing(Lang,_id, _encl) :-
    set_ast_node_enclosing(Lang,_id, _encl),
    get_ast_sub_tree(Lang,_id,_subs),
    rec_set_ast_node_enclosing(Lang,_subs, _encl).

/**
        set_ast_node_enclosing(+Id, +Encl)

        Set the enclosing element of the tree Id
        to Encl.
        The old fact will be retracted and
        a new fact with Encl asserted.
        
        INFO: This predicate uses the add/1 and delete/1 
        predicates which track all changes to
        the factbase in the rollback functionality.
*/

/* Notizen zur Verallgemeinerung:
   - 34 F�lle. Nicht alle PEFs haben ein enclosing.
   - Normalerweise steht das dritte Argument f�r "enclosing".
     Ausnahmen:
       - paramDefT (2.Arg)
*/

/*
set_ast_node_enclosing(Lang,_id,_new_encl) :-
    nonvar(_id),nonvar(_new_encl),
    get_ast_node_term(Lang,_id,TermWithEncl),
    ast_node_argument(Lang,TermWithEncl,encl),
    functor(TermWithEncl,Functor,Arity),
    functor(NewTerm,Functor,Arity),       %NewTerm f�r neues Enclosing
    arg(3,NewTerm,_new_encl),             %Enclosing setzen
    TermWithEncl =.. OldTermList,
    NewTerm      =.. NewTermList,
    unifyLists(OldTermList,NewTermList),
    NewTermInst =.. NewTermList,
    delete(Lang,TermWithEncl),
    add(Lang,NewTermInst).
set_ast_node_enclosing('Java',_id,_new_encl):-paramDefT(_id,_encl,_v1,_v2),!,delete('Java',paramDefT(_id,_encl,_v1,_v2)),add('Java',paramDefT(_id,_new_encl,_v1,_v2)).


unifyLists([],[]).
unifyLists([H|T1],[H|T2]) :- unifyLists(T1,T2),!.
unifyLists([_|T1],[_|T2]) :- unifyLists(T1,T2),!.
*/

/**
        rec_set_Parent(+Id, +Parent)

        Sets the parent of the tree Id or the list of 
        trees IdList to Parent.
        Then it recursive sets the parents of 
        the subtrees to their parent.
        
        INFO: This predicate uses the add/1 and delete/1 
        predicates which track all changes to
        the factbase in the rollback functionality.
*/

rec_set_ast_node_parent(Lang,'null', _).
rec_set_ast_node_parent(Lang,[], _).
rec_set_ast_node_parent(Lang,[_H | _T], _parent) :-
    !,
    rec_set_ast_node_parent(Lang,_H, _parent),
    rec_set_ast_node_parent(Lang,_T, _parent).
rec_set_ast_node_parent(Lang,_id, _parent) :-
    set_ast_node_parent(Lang,_id, _parent),
    %sub_trees(_id, _subs),
    get_ast_sub_tree(Lang,_ids,_subs),
    rec_set_ast_node_parent(Lang,_subs, _id).





/*
        set_parent(+Id | +IdList, +Parent)

        Sets the parent of the tree Id or the list of
        trees IdList to Parent.

        Es wird von der Konvention ausgegangen, da� der Parent immer an zweiter Stelle steht!
 */
/*
set_ast_node_parent(Lang,_id,_new_parent) :-
    nonvar(_id),nonvar(_new_parent),
    get_ast_node_term(Lang,_id,TermWithPar),
    ast_node_argument(Lang,TermWithPar,parent),
    functor(TermWithPar,Functor,Arity),
    functor(NewTerm,Functor,Arity),       %NewTerm f�r neuen Parent
    arg(2,NewTerm,_new_parent),             %Parent setzen
    TermWithPar =.. OldTermList,
    NewTerm      =.. NewTermList,
    unifyLists(OldTermList,NewTermList),
    NewTermInst =.. NewTermList,
    delete(Lang,TermWithPar),
    add(Lang,NewTermInst).
set_ast_node_parent('Java',_id,_newParent):-importT(_id,_pid,_v1),!,delete('Java',importT(_id,_pid,_v1)),add('Java',importT(_id,_newParent,_v1)).

set_ast_node_parent(_,[], _).
set_ast_node_parent(Lang,[_h| _t], _parent) :-
    set_ast_node_parent(Lang,_h,_parent),
    set_ast_node_parent(Lang,_t,_parent).
*/


% SL: Kann replaceID/4 durch set_ast_node_arg(Lang,ID,id,NewID) ersetzt werden?
/*
replaceId(Lang,_id,_oldId,_newId) :-
    get_ast_node_edge(Lang, _id, EdgeLabel, _oldId),    %get Name of Argument with value _oldId
    set_ast_node_argument(Lang,_id, EdgeLabel, _newId). %set new Value
*/
/**
 replaceId(+Term, +oldId, +newId)
 
 Replaces the
*/

replaceId(Lang,_id, _oldId, _newId) :-
    get_ast_node_term(Lang,_id, _oldTerm),
    replaceIdInTerm(_oldTerm, _newTerm, _oldId, _newId),
    delete(Lang,_oldTerm),
    add(Lang,_newTerm).

replaceIdInTerm(_term, _Translated,_oldId, _newId) :-
    _term =.. [_name | _args],
    replaceIdInList(_args, _translatedArgs,_oldId, _newId),
    _Translated =.. [_name | _translatedArgs].

replaceIdInList([], [],_,_) :- !.
replaceIdInList([_oldId | _t], [_newId | _rest], _oldId, _newId) :-
    replaceIdInList(_t, _rest, _oldId, _newId).

replaceIdInList([_term | _t], [_Term | _rest],_oldId, _newId) :-
    \+(atomic(_term)),
    !,
    replaceIdInTerm(_term,_Term,_oldId, _newId),
    replaceIdInList(_t, _rest, _oldId, _newId).

replaceIdInList([_term | _t], [_term | _rest],_oldId, _newId) :-
    replaceIdInList(_t, _rest, _oldId, _newId).


test(replaceIdInTermT01) :-
    replaceIdInTerm(methodDefT(1,2,3,4,type(1,a,0), 5,6), methodDefT(new_id,2,3,4,type(new_id,a,0), 5,6), 1, new_id).
    
createVarDefIdents(_, [], []).
createVarDefIdents(_newParent, _oldList, _newList) :-
    reccreateVarDefIdents(_newParent, _oldList, _newList).
reccreateVarDefIdents(_newParent, [], []).
reccreateVarDefIdents(_newParent, [_varDef | _varDefs], [_Ident | _Idents]) :-
    createIdentRefParam(_varDef,_newParent, _Ident),
    reccreateVarDefIdents(_newParent, _varDefs, _Idents).

/**
 * createIdentRefParam(+Param,+Parent, -Ident)
 */
createIdentRefParam(_param,_parent, _Ident) :-
    %paramDefT(_param, _encl, _, _name),
    ast_node_argument('Java',Term,paramDefT,id,_param),
    ast_node_argument('Java',Term,paramDefT,parent,_encl),
    ast_node_argument('Java',Term,paramDefT,name,_name),
    Term,
    new_id(_Ident),
    %add('Java',identT(_Ident, _parent, _encl, _name, _param)).
    ast_node_argument('Java',NewTerm,identT,id,_Ident),
    ast_node_argument('Java',NewTerm,identT,parent,_parent),
    ast_node_argument('Java',NEwTerm,identT,encl,_encl),
    ast_node_argument('Java',NEwTerm,identT,name,_name),
    ast_node_argument('Java',NEwTerm,identT,ref,_param),
    add('Java',NewTerm).

createThisIdent(_Ident,_parent, _encl, _class) :-
    new_id(_Ident),
%    debugme,
    ast_node_argument('Java',NewTerm,identT,id,_Ident),
    ast_node_argument('Java',NewTerm,identT,parent,_parent),
    ast_node_argument('Java',NEwTerm,identT,encl,_encl),
    ast_node_argument('Java',NEwTerm,identT,name,'this'),
    ast_node_argument('Java',NEwTerm,identT,ref,_class),
    add('Java',NewTerm).
    %add('Java',identT(_Ident, _parent, _encl, 'this', _class)).



addEdgeToPEF(Lang,PEFFunctor,ArgName,_id,_edgeID) :-
    nonvar(_id),
    nonvar(_edgeID).
addEdgeToPEF(Lang,PEFFunctor,ArgName,_id,_edgeID) :-
    \+ get_ast_node_label(Lang,_id,PEFFunctor), !.
addEdgeToPEF(Lang,PEFFunctor,ArgName,_id,_edgeID) :-
    get_ast_node_argument(Lang,_id,ArgName,EdgeList),
    member(_edgeID, EdgeList),    %check if edge is already set
    !.
addEdgeToPEF(Lang,PEFFunctor,ArgName,_id,_edgeID) :-
    get_ast_node_argument(Lang,_id,ArgName,EdgeList),
    append(EdgeList, [_edgeID], NewEdgeList),
    set_ast_node_argument(Lang,_id,ArgName,NewEdgeList).

add_to_class(_class, _id) :- addEdgeToPEF('Java',classDefT,defs,_class,_id).
add_to_class(_, []):- !.
add_to_class(Class, [Member|Rest]) :-
    add_to_class(Class,Member),
    add_to_class(Class,Rest).

addToToplevel(_tl, _id) :- addEdgeToPEF('Java',toplevelT,defs,_tl,_id).

addToMethodArgs(_method, _id) :- addEdgeToPEF('Java',methodDefT,params,_method,_id).

addToBlock(_block, _id) :- addEdgeToPEF('Java',blockT,stmts,_block,_id).
addToBlock(_block, []) :- !.
addToBlock(_block, [_H, _T]) :-
    addToBlock(_block, _H),
    !,
    addToBlock(_block, _T).
    
    

removeEdgeFromPEF(Lang,PEFFunctor,ArgName,ID, EdgeID) :-
    \+ get_ast_node_label(Lang,ID,PEFFunctor), !.
removeEdgeFromPEF(Lang,PEFFunctor,ArgName,ID, EdgeID) :-
    get_ast_node_argument(Lang,ID,ArgName,EdgeList),
    findall(_m, (member(_m, EdgeList), _m \= EdgeID ), NewEdgeList),
    set_ast_node_argument(Lang,ID,ArgName,NewEdgeList).
    
removeFromBlock(_block, _id)       :- removeEdgeFromPEF('Java',blockT,stmts,_block,_id).
removeFromMethodArgs(_method, _id) :- removeEdgeFromPEF('Java',methodDefT,params,_method,_id).

%Achtung! "action" nicht ber�cksichtigt
add_body(_elem, _body):-
    %methodDefT(_elem,_parent,_name,_parm,_type,_exc, _),
    %action(replace('Java',methodDefT(_elem,_parent,_name,_parm,_type,_exc, _body))).
    set_ast_node_argument('Java',methodDefT,_elem,body,_body).         %SL: neue action definieren?
    
add_body(_elem, _init):-
    %localDefT(_elem, _class, _class, _RetType, _name, _),
    %action(replace('Java',localDefT(_elem, _class, _class, _RetType, _name, _init))).
    set_ast_node_argument('Java',localDefT,_elem,expr,_init).

add_body(_elem, _init):-
    %fieldDefT(_elem, _class, _RetType, _name, _),
    %action(replace('Java',fieldDefT(_elem, _class, _RetType, _name, _init))).
    set_ast_node_argument('Java',fieldDefT,_elem,expr,_init).
/*
addToToplevel(_tl, _id) :- \+ get_ast_node_label('Java',_t1,toplevelT), !.
addToToplevel(_tl, _id) :-
    %toplevelT(_tl, _, _, _members),
    get_ast_node_argument('Java',_t1,defs,_members),
    member(_id, _members),
    !.
addToToplevel(_tl, _id) :-
    %toplevelT(_tl, _p,_n,_members),
    %delete('Java',toplevelT(_tl, _p,_n,_members)),
    %append(_members, [_id], _newMembers),
    %add('Java',toplevelT(_tl, _p, _n, _newMembers)).
    get_ast_node_argument('Java',_t1,defs,_members),     %get old members
    append(_members, [_id], _newMembers),                   %append new member
    set_ast_node_argument('Java',__tl,defs,_newMembers).  %set new argument value
*/

/*
removeFromBlock(_block, _id) :- \+ get_ast_node_label('Java',_block,blockT), !.
removeFromBlock(_block, _id) :-
    %blockT(_block, _p, _e, _members),
    get_ast_node_argument('Java',_block,stmts,_members),
    findall(_m, (member(_m, _members), _m \= _id ), _newMembers),
    %delete('Java',blockT(_block, _p, _e, _members)),
    %add('Java',blockT(_block, _p, _e, _newMembers)).
    set_ast_node_argument('Java',_block,stmts,_newMembers).
*/

/*
addToBlock(_block, _id) :- \+ get_ast_node_label('Java',_block,blockT), !.
addToBlock(_block, _id) :-
    %blockT(_block, _, _, _members),
    get_ast_node_argument('Java',_block,stmts,_members),
    member(_id, _members),
    !.
addToBlock(_block, _id) :-
    %blockT(_block, _p, _e, _members),
    get_ast_node_argument('Java',_block,stmts,_members),
    %delete('Java',blockT(_block, _p, _e, _members)),
    append(_members, [_id], _newMembers),
    %add('Java',blockT(_block, _p, _e, _newMembers)).
    set_ast_node_argument('Java',_block,stmts,_newMembers).
*/
/*
removeFromMethodArgs(_method, _id) :- \+ get_ast_node_label('Java',_method,methodDefT), !.
removeFromMethodArgs(_method, _id) :-
    %methodDefT(_method, _p, _n, _members, _r, _e, _b),
    get_ast_node_argument('Java',_method,params,_members),
    findall(_m, (member(_m, _members), _m \= _id ), _newMembers),
    %delete('Java',methodDefT(_method, _p, _n, _members, _r, _e, _b)),
    %add('Java',methodDefT(_method, _p, _n, _newMembers, _r, _e, _b)).
    set_ast_node_argument('Java',_method,params,_newMembers).
*/

/*
addToMethodArgs(_method, _id) :- \+ get_ast_node_label('Java',_method,methodDefT), !.
addToMethodArgs(_method, _id) :-
    %methodDefT(_method, _p, _n, _members, _r, _e, _b),
    get_ast_node_argument('Java',_method,params,_members),
    member(_id, _members),
    !.
addToMethodArgs(_method, _id) :-
    %methodDefT(_method, _p, _n, _members, _r, _e, _b),
    get_ast_node_argument('Java',_method,params,_members),
    %delete('Java',methodDefT(_method, _p, _n, _members, _r, _e, _b)),
    append(_members, [_id], _newMembers),
    %add('Java',methodDefT(_method, _p, _n, _newMembers, _r, _e, _b)).
    set_ast_node_argument('Java',_method,params,_newMembers).
*/
       
/** 
 * removeTags(DeletionKind, ID)
    Deletes recursively all sub trees of a tree, or of a list of trees.
    Exceptions are the targets of break and continue.

    Removes  (if they exist) the following 'tags' of a node:
        slT - the  Sourcelocation
        modifierT - all modifiers,
        extendsT - the reference to a super class (for classDefT),
        implementsT - all references to implemented interfaces (for classDefT),
        externT - set, if the class is extern
        interfaceT - exists if the PEF reprecents an interface 
*/

removeTags(DeletionKind, ID):-
    forall((ast_node_signature('JavaAttributes',Functor,Arity),
            functor(Term, Functor, Arity), Term =.. [Functor, ID|_]),
    removeTagKind(DeletionKind, Term)).
/*
    removeTagKind(DeletionKind, slT(ID,_start,_length)),
    removeTagKind(DeletionKind, modifierT(ID,_mod)),
    removeTagKind(DeletionKind, implementsT(ID,_iface)),
    removeTagKind(DeletionKind, extendsT(ID,_super)),
    removeTagKind(DeletionKind, externT(ID)),
    removeTagKind(DeletionKind, projectLocationT(ID,_,_)),
    removeTagKind(DeletionKind, sourceLocation(ID,_,_,_)),
    removeTagKind(DeletionKind, interfaceT(ID)).
*/    
removeTagKind(DeletionKind,Tag) :-
    forall(
                Tag,
                (
                   Call =.. [DeletionKind,Tag],
                   call(Call)
                )
        ).

deepDelete(_,[]).
deepDelete(Lang,[_head | _tail]) :-
    %sub_trees(_head, _subtrees),
    get_ast_sub_tree(Lang,_head,_subtrees),
    deepDelete(Lang,_subtrees),
    delete_ast_node(Lang,_head),
        removeTags(delete, _head),      
    deepDelete(Lang,_tail).

deepDelete(Lang,_id) :-
    get_ast_node_term(Lang,_id,_),
    !,
    deepDelete(Lang,[_id]).

deepRetract([]).
deepRetract([Tree | _]) :-
    %not(tree(Tree,_,_)),
    \+ get_ast_node_term('Java',Tree,_),
    sformat(S,'deepRetract: tree not found: ~w',[Tree]),
    throw(S).
    
deepRetract([_head | _tail]) :-
    %sub_trees(_head, _subtrees),
    get_ast_sub_tree('Java',_head,_subtrees),
    deepRetract(_subtrees),
    retract_ast_node('Java',_head),
        removeTags(retract, _head),     
    deepRetract(_tail).

deepRetract(_id) :-
    get_ast_node_term('Java',_id,_),
    !,
    deepRetract([_id]).
    
    

/**
 * discard_permanently(Toplevel)
 *
 * removes the toplevel permanently.
 * Also the contained types are removed form
 * the symtable (globalIds/2).
 *
 * Be sure you know what you are doing!
 */
 
discard_permanently(Id):-
    %toplevelT(Id,_,_,_),
    get_ast_node_label('Java',Id,toplevelT),
    !,
    forall(
        contains_type(Id,Type),
        (
                globalIds(FQN,Type),            
                retractall(globalIds(FQN,Type))
                %%format('i would retract ~a, but...~n',FQN)
        )
    ),
    deepDelete('Java',Id).

    
discard_permanently(_fileName):-
    %toplevelT(Id,_,_fileName,_),
    get_ast_node_label('Java',Id,toplevelT),
    get_ast_node_argument('Java',Id,file,_fileName),
    !,
    forall(
        contains_type(Id,Type),
        (
                globalIds(FQN,Type),
                retractall(globalIds(FQN,Type)) 
                %%format('i would retract ~a, but...~n',FQN)
        )
    ),
    deepDelete('Java',Id).
    

    /**
        uniqueArgumentList(+Arity,-Arguments)
*/
        
uniqueArgumentList(0,[]):-!.
    
uniqueArgumentList(Arity,[Argument| Arguments]):-
    atom_concat('A', Arity,Atom),
    atom_to_term(Atom,Argument,_),
    plus(Prec, 1, Arity),
    uniqueArgumentList(Prec, Arguments).
    
test(uniqueArgumentList) :-
    uniqueArgumentList(5,[_,_,_,_,_]).


/**
  * createReturnOrExec(+Parent, +Encl,+Type,+Expr,+ReturnOrExecStmt)
  * 
  * Creates a new execT/4 fact (with id ReturnOrExecStmt) around the expression Expr,
  * if Type is void. Otherwise a returnT/4 fact is generated.
  */

createReturnOrExec(_parent, _encl, type(basic, void, 0), _stat, _exec) :-
    !,
    add('Java',execT(_exec, _parent, _encl, _stat)).

createReturnOrExec(_parent, _encl, _type, _stat, _return) :-
    add('Java',returnT(_return, _parent, _encl, _stat)).

    
deleteToplevelOfClass(Id) :-
    modifierT(Id,public),
    getToplevel(Id, Tl),
    !,
    findall(Import,(importT(Import,Tl,ClassPckg),delete('Java',importT(Import,Tl,ClassPckg))),_),
%    findall(Class,(classDefT(Class,Package,Name,List),delete(classDefT(Class,Package,Name,List))),_),
    %toplevelT(Tl,TlPackage,Filename, Defs),
    ast_node_argument('Java',Term,toplevelT,id,Tl),
    ast_node_argument('Java',Term,toplevelT,parent,TlPackage),
    ast_node_argument('Java',Term,toplevelT,file,Filename),
    ast_node_argument('Java',Term,toplevelT,defs,Defs),
    Term,
    assert(deleted_file(Filename)),
    delete('Java',toplevelT(Tl,TlPackage,Filename, Defs)).

deleteToplevelOfClass(_).   
