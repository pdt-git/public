% Author: Tobias
% Date: 29.08.02

/*
    garbageCollection
    
    Deletes all trees that are not referenced by their parent node.
    On this trees 'deepDeleteIfParentCorrect' is called, which runs a  deep
    search and deletes every subtree which is correctly referenced by its parent.
*/

garbageCollection(Lang) :-
    findall(_id, (get_ast_node_parent(Lang,_id, _parent), deepDeleteIfNotReferenced(Lang,_id, _parent)), _alltrees).

deepDeleteIfNotReferenced(_,_id, 'null') :-
    !.
deepDeleteIfNotReferenced(Lang,_id, _parent) :-
    \+(get_ast_sub_tree(Lang,_parent, _subtrees)),
    !,
    format('gc: deleted ~a, _parent ~a has no subtrees~n', [_id, _parent]),
    deepDeleteIfParentCorrect(Lang,_id, _parent).

deepDeleteIfNotReferenced(Lang,_id, _parent) :-
    get_ast_sub_tree(Lang,_parent, _subtrees),
    equals(_subtrees, 'null'),
    !,
    get_ast_node_label(Lang,_id,_t),
    %tree(_id, _, _t),
    format('gc: deleted ~a, sub_trees of parent ~a is null~n', [_id, _parent]),
    deepDeleteIfParentCorrect(Lang,_id, _parent).
    
deepDeleteIfNotReferenced(Lang,_id, _parent) :-
    get_ast_sub_tree(Lang,_parent, _subtrees),
    \+(equals(_parent, 'null')),
    \+(equals(_subtrees, 'null')),
    \+(member(_id, _subtrees)),
    !,
    get_ast_node_label(Lang,_id,_t),
    format('gc: deleted ~a, not a member of the subtrees of parent ~a~n', [_id, _parent]),
    deepDeleteIfParentCorrect(Lang,_id, _parent).


/*
 * deleteSubElements
 * 
 * L�scht _num Subelemente von _parent
 * Die Subelemente werden durch den R�ckverweis parent in
 * den Subtrees bestimmt.
 * 
 * Diese Clause dient nur zu DEBUG Zwecken!
 * Die Auswahl der Element wird durch Prolog bestimmt.
 *
 */

deleteSubElements(Lang,_parent, _type, _num) :-
    counter(0),
    findall(_id, (%tree(_id, _parent, _type),
                  get_ast_node_parent(_id,_parent),
                  get_ast_node_label(_id,_type),
                  incCounter(_c), _c =< _num,
                  deepDelete(Lang,_id)),
            _list).

/*
 *  L�scht einen tree und alle seine subtrees wenn der �bergebene parent tree
 *  mit dem im tree gesetzten parent �bereinstimmt.
 *  Rekursive wird an die Methode immer der aktuelle tree und die liste der subtrees �bergeben.
 *  Die Funktion bricht jeweils in den trees ab, in denen die Bedingung nicht erf�llt ist.
 */
deepDeleteIfParentCorrect(_,[], _).
deepDeleteIfParentCorrect(Lang,[_head | _tail], _parent) :-
    get_ast_node_parent(Lang,_head,_parent),
    !,
    get_ast_sub_tree(Lang,_head, _subtrees),
    deepDeleteIfParentCorrect(Lang,_subtrees, _head),
    retract_ast_node(Lang,_head),
    deepDeleteIfParentCorrect(Lang,_tail, _parent).
deepDeleteIfParentCorrect(Lang,[_head | _tail], _parent) :-
    %tree(_head, _headparent, _),
    get_ast_node_parent(_head,_headparent),
    \+(equals(_headparent, _parent)),
    !.
deepDeleteIfParentCorrect(Lang,_id, _parent) :-
    %tree(_id, _,_),
    get_ast_node_term(Lang,_id,_),
    !,
    deepDeleteIfParentCorrect(Lang,[_id], _parent).
deepDeleteIfParentCorrect(Lang,[_head | _], _parent) :-
    \+(/*tree(_head, _parent, _)*/get_ast_node_parent(Lang,_head,_parent)),
    !.


/*
    delete_ast_node(+Lang,+ID)
    Verallgemeinerte Version von delete_ast_node/1
    Seb: 02.5.06
    Probleme: - Inkonsistenz bei Arity von paramDefT:
                ast_node_tern -> 5; altes delete_ast_node -> 4
              - externT/1 fehlt bei ast_node_term
    Aufrufe:
        /engine/ast/java/javaASTOperations/tree_modifications.pl:392
        /st.java/pl/org/cs3/java/ctSpec/high_level_api.pl:453,460
*/
delete_ast_node(Lang,_id) :-
    get_ast_node_term(Lang,_id,NodeTerm),
    delete(Lang,NodeTerm),
    !.
    
delete_ast_node(Lang,_id) :- nopT(_id,_pid,_encl),!,delete(Lang,nopT(_id,_pid,_encl)).

delete_ast_node(Lang,_id) :-
    %not(tree(_id, _,_)),
    \+ get_ast_node_term(Lang,_id,_),
    format('could not retract id: ~a~n', [_id]), !.


/*
    retract_ast_node(+Lang,+ID)
    Verallgemeinerte Version von retract_ast_node/1
    Seb: 02.5.06
    Probleme: - Inkonsistenz bei Arity von paramDefT:
                ast_node_term -> 5; altes retract_ast_node -> 4
              - externT/1 fehlt bei ast_node_term
    Aufrufe:
        /engine/apply/garbage_collect.pl:138
        /engine/ast/java/javaASTOperations/tree_modifications.pl:410
*/
retract_ast_node(Lang,_id) :-
    get_ast_node_term(Lang,_id,NodeTerm),
    retract(NodeTerm),
    !.

retract_ast_node(Lang,_id) :- nopT(_id,_pid,_encl),!,retract(nopT(_id,_pid,_encl)).

retract_ast_node(Lang,_id) :-
    %not(tree(_id, _,_)),
    \+ get_ast_node_term(Lang,_id,_),
    format('could not retract id: ~a~n', [_id]), !.


retract_ast_nodes(Lang,[]).
retract_ast_nodes(Lang,[_H, _T]) :-
    retract_ast_node(Lang,_H),
    retract_ast_nodes(Lang,_T).
    

    
