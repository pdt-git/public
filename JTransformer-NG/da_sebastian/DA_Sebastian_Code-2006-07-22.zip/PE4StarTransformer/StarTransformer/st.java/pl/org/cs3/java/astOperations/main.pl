:- ['ast_getter.pl'].
:- ['ast_setter.pl'].

