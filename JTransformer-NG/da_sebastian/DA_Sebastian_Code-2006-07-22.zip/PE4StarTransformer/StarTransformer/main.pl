:- style_check(-singleton).
:- style_check(-discontiguous).

:- ['engine/main'].
:- ['st.java/pl/main.stj'].
