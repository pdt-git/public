% Author: Sebastian Lorenz
% Date: 22.06.2006

%inferences: number of passes via the call and redo ports

:- dynamic timetstp/2.
:- assert(timetstp(1,2)).

change1 :- Y = timetstp(X,Y),
           retract(timetstp(X,Y)),
           assert(timetstp(Y,X)).
change2 :- timetstp(X,Y),
           setarg(1,timetstp(X,Y),Y),
           setarg(2,timetstp(X,Y),X).

asd2 :- enumeratingCalls(get_ast_node_parent('Java',_,P)), write(P),nl.

asd :-
    write('treeSignature..\n'),
    testEnumTime(treeSignature(_,_)),
    testEnumTime(ast_node_signature('Java',_,_)),
    testEnumTime(pe:ast_node_signature('Java',_,_)),
    write('attribSignature..\n'),
    testEnumTime(attribSignature(_,_)),
    testEnumTime(ast_node_signature('JavaAttributes',_,_)),
    testEnumTime(pe:ast_node_signature('JavaAttributes',_,_)),
    %write('ast_node_term..\n'),
    %testEnumTime(attribSignature(X,Y)),
    %testEnumTime(ast_node_term('Java',_)),
    %testEnumTime(pe:ast_node_term('Java',_)),
    %write('ast_node_argument..\n'),
    %testEnumTime(ast_node_argument('Java',_,_)),
    %testEnumTime(pe:ast_node_argument('Java',_,_)),
    write('get_ast_node_term..\n'),
    genTestPEFsAll,
    testEnumTime(getTerm(_,_)),
    testEnumTime(get_ast_node_term('Java',_,_)),
    testEnumTime(pe:get_ast_node_term('Java',_,_)),
    cleanAll,
    write('get_ast_node_enclosing..\n'),
    genTestPEFsAll,
    testEnumTime((idsToCheck(ID),enclosing(ID,_))),
    testEnumTime((idsToCheck(ID),get_ast_node_enclosing('Java',ID,_))),
    testEnumTime((idsToCheck(ID),pe:get_ast_node_enclosing('Java',ID,_))),
    cleanAll,
    write('get_ast_node_parent..\n'),
    genTestPEFsAll,
    testEnumTime(tree(_,_,_)),
    testEnumTime(get_ast_node_parent('Java',_,_)),
    testEnumTime(pe:get_ast_node_parent('Java',_,_)),
    cleanAll,
    write('get_ast_node_label..\n'),
    genTestPEFsAll,
    testEnumTime(tree(_,_,_)),
    testEnumTime(get_ast_node_label('Java',_,_)),
    testEnumTime(pe:get_ast_node_label('Java',_,_)),
    cleanAll.
  /*  write('retractTree..\n'),
    genTestPEFsAll,
    testEnumTimeX((idsToCheck(ID),retractTree(ID)),10),
    cleanAll, genTestPEFsAll,
    testEnumTimeX((idsToCheck(ID),retract_ast_node('Java',ID)),10),
    cleanAll, genTestPEFsAll,
    testEnumTimeX((idsToCheck(ID),pe:retract_ast_node('Java',ID)),10),
    cleanAll,
    write('deleteTree..\n'),
    testEnumTimeX((genTestPEFsAll,idsToCheck(ID),deleteTree(ID)),10),
    testEnumTimeX((genTestPEFsAll,idsToCheck(ID),delete_ast_node('Java',ID)),10),
    testEnumTimeX((genTestPEFsAll,idsToCheck(ID),pe:delete_ast_node('Java',ID)),10),
    cleanAll,
    write('retractTree..\n'),
    testEnumTimeX((genTestPEFsAll,idsToCheck(ID),retractTree(ID)),10),
    testEnumTimeX((genTestPEFsAll,idsToCheck(ID),retract_ast_node('Java',ID)),10),
    testEnumTimeX((genTestPEFsAll,idsToCheck(ID),pe:retract_ast_node('Java',ID)),10),
    cleanAll,*/
    /*write('set_ast_node_enclosing..\n'),
    genTestPEFsAll,
    testEnumTimeX((idsToCheck(ID),set_encl_method(ID,1)),10),
    cleanAll, genTestPEFsAll,
    testEnumTimeX((idsToCheck(ID),set_ast_node_enclosing('Java',ID,1)),10),
    cleanAll, genTestPEFsAll,
    testEnumTimeX((idsToCheck(ID),pe:set_ast_node_enclosing('Java',ID,1)),10),
    cleanAll,
    write('set_ast_node_parent..\n'),
    genTestPEFsAll,
    testEnumTimeX((idsToCheck(ID),set_parent(ID,1)),10),
    cleanAll, genTestPEFsAll,
    testEnumTimeX((idsToCheck(ID),set_ast_node_parent('Java',ID,1)),10),
    cleanAll, genTestPEFsAll,
    testEnumTimeX((idsToCheck(ID),pe:set_ast_node_parent('Java',ID,1)),10),
    cleanAll.
     */

/******************************************************************************
Hilfspr�dikate f�r die Zeitmessung
----------------------------------
  SWI-Prolog bietet grunds�tzlich folgende M�glichkeiten zur Messung:
    - time/1
    - profile/1 (-> Profiler mit detaillierten Angaben)
*******************************************************************************/

testEnumTime2(Pred) :-
  time(enumeratingCalls(Pred)).


testEnumTime(Pred) :- testEnumTimeX(Pred,1000).

testEnumTimeX(Pred,Number) :-
    integer(Number),
    flag(counter,_,0),
    time(
          (repeat,
             enumeratingCalls(Pred),
             flag(counter,N,N+1),
          ((N+1) >= Number))
         ).

/* enumeratingCalls(+Pred)
 *   Sorgt einfach per Backtracking f�r das Aufz�hlen aller L�sungen.
 */
enumeratingCalls(Pred) :-
    Pred,
    fail.
enumeratingCalls(_).
