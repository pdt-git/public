% Author:
% Date: 6/4/2006

/*############################################################################
  /st.java/pl/org/cs3/java/astSpec/javaFactbase.pl
 #############################################################################*/

/** So soll's sein: -----------------------------------------------------------
 * treeSignature(?Functor, ?Arity)
 *    Obsolete, use ast_node_signature/3 instead. See "ast/java_syntax.pl"
 */

% TODO: Does not consider exceptional cases e.g. classDefT, paramDefT. @gk: you wrote this code, didn't you? -- TR 31.10.2005
%treeSignature(Functor, Arity) :-
%   ast_node_signature('Java' /* <-- I had to put this in again, otherwise
%   non-existing predicate are referenced and clearTreeFactBase/0 fails. -- TR 31.10.2005*/
%
%   /*'Java' <-- not while we transitionally mix
%   old and new representation -- GK, 23.9.2005 */ , Functor, Arity).

/*
Test:
?- regressionTest( newTreeSignature(F, Arity), treeSignature(F, Arity) ).
*/

/* So war's bisher:---------------------------------------------------
Obsolete definition of tree signature. TODO for Sebastian:
Check whether partial evaluation of the above definition
yields the following one. -- GK, 17.6.2005
*/

:- multifile treeSignature/2.

%treeSignature(Functor,Arity) :- ast_node_signature('Java', Functor, Arity).
treeSignature(localDefT, 6).
treeSignature(paramDefT, 4).
treeSignature(fieldDefT, 5).
treeSignature(methodDefT, 7).
treeSignature(classDefT, 4).
treeSignature(packageT, 2).
treeSignature(identT,5).
treeSignature(literalT,5).
treeSignature(execT,4).
treeSignature(operationT,6).
treeSignature(applyT,7).
treeSignature(blockT,4).
treeSignature(selectT,6).
treeSignature(conditionalT,6).
treeSignature(ifT,6).
treeSignature(assignT,5).
treeSignature(importT,3).
treeSignature(newArrayT,6).
treeSignature(toplevelT,4).
treeSignature(newClassT,8).
treeSignature(returnT,4).
treeSignature(switchT,5).
treeSignature(typeCastT,5).
treeSignature(tryT,6).
treeSignature(whileLoopT,5).
treeSignature(continueT,5).
treeSignature(doLoopT,5).
treeSignature(indexedT,5).
treeSignature(throwT,4).
treeSignature(forLoopT,7).
treeSignature(synchronizedT,5).
treeSignature(labelT,5).
treeSignature(breakT,5).
treeSignature(typeTestT,5).
treeSignature(assignopT,6).
treeSignature(caseT,4).
treeSignature(catchT,5).
treeSignature(assertT,5).
treeSignature(getFieldT,6).
treeSignature(precedenceT,4).
treeSignature(nopT,3).
 % TODO: fehlte / inkonsistenz zu tree/3 -- GK 3.9.2004


/** So soll's sein: -----------------------------------------------------------
 * attribSignature(?Functor, ?Arity)
 *    Obsolete, use ast_node_signature/3 instead. See "ast/java_syntax.pl"
 *
 */
 /*
attribSignature(Functor, Arity) :-
   ast_node_signature('JavaAttributes', Functor, Arity).
*/

/*
Test:
?- regressionTest( attribSignatureNEW(F, Arity), attribSignature(F, Arity) ).
*/

:- multifile attribSignature/2.


attribSignature(extendsT,2).
attribSignature(implementsT,2).
attribSignature(modifierT,2).
attribSignature(externT,1).
attribSignature(interfaceT,1).
attribSignature(sourceLocation,4).   % :( nicht in ast_node_def :(
attribSignature(projectLocationT,3). % :( nicht in ast_node_def :(
attribSignature(slT,3).              % :( nicht in ast_node_def :(

/**
 * sub_trees(_id, _subtrees)
 * Binds all sub trees of the id to Subtrees
 */

sub_trees(_id, _subtrees) :-
    blockT(_id,_, _, _subtrees),!.
sub_trees(_id, _subtrees) :-
    packageT(_id,_),
    !,
    findall(_sub,(classDefT(_sub, _id, _, _) ; toplevelT(_sub, _id, _,_)), _subtrees).

sub_trees(_id, [Expr]) :-
    precedenceT(_id,_, _, Expr),!.

sub_trees(_id, _subtrees) :-
    toplevelT(_id,_,_,_subtrees),!.
sub_trees(_id, _subtrees) :-
    classDefT(_id,_,_,_subtrees),!.
%    format('sub_trees:classDef: ~a~a~n', [_id, _name]),
%    classMembersT(_id, _subtrees),!.

sub_trees(_id, _subtrees) :-
    methodDefT(_id,_,_name,_params,_,_,_body),
    !,
%    format('sub_trees:methodDef: ~a~a~n', [_id, _name]),
    listOrEmptyListIfNull(_body, _bodyList),
    append(_bodyList, _params, _subtrees).

sub_trees(_id, _subtrees) :-
    fieldDefT(_id,_,_,_name,_init),
    !,
    listOrEmptyListIfNull(_init, _subtrees).

sub_trees(_id, []) :-
    paramDefT(_id,_,_,_),
    !.

sub_trees(_id, _subtrees) :-
    localDefT(_id,_,_,_,_name,_init),
    !,
    listOrEmptyListIfNull(_init, _subtrees).


sub_trees(_id, [_cond ,_body]) :-
    doLoopT(_id,_,_,_cond,_body),!.

sub_trees(_id, [_cond ,_body]) :-
    whileLoopT(_id,_,_,_cond,_body),!.

% body (cond | []) (inits | []) (steps | [])
sub_trees(_id, [_body | _subtrees]) :-
    forLoopT(_id,_,_,_initList,_cond,_stepList,_body),
    !,
    listOrEmptyListIfNull(_cond, _condList),
    append(_initList, _stepList, _dummyList),
    append(_condList, _dummyList, _subtrees).

sub_trees(_id, [_body]) :-
    labelT(_id,_,_,_body,_),!.

sub_trees(_id, [_selector | _cases]):-
    switchT(_id,_,_,_selector,_cases),!.


sub_trees(_id, List) :-
    caseT(_id,_,_,_pat),
    !,
    listOrEmptyListIfNull(_pat,List).

sub_trees(_id, [_lock, _body]) :-
    synchronizedT(_id,_,_,_lock,_body),!.

sub_trees(_id, [_body | _catchfinal]) :-
    tryT(_id,_,_,_body,_catch,_final),
    !,
    emptyListIfNull(_catch, _catchNonNull),
    emptyListIfNull(_final, _finalNonNull),
    append(_catchNonNull, _finalNonNull, _catchfinal).

sub_trees(_id, [_param, _body]) :-
    catchT(_id,_,_,_param,_body),!.

sub_trees(_id, [_test, _msg]) :-
    assertT(_id,_,_,_test,_msg),!.

sub_trees(_id, [_cond |_thenelse]) :-
    ifT(_id,_,_,_cond,_then,_else),
    !,
    listOrEmptyListIfNull(_else, _elseList),
    append([_then], _elseList, _thenelse).


sub_trees(_id, [_cond,_then,_else]) :-
    conditionalT(_id,_,_,_cond,_then,_else),!.

sub_trees(_id, [_expr]) :-
    execT(_id,_,_,_expr),!.

sub_trees(_id, _list) :-
    returnT(_id,_,_,_expr), !,
    listOrEmptyListIfNull(_expr, _list).


sub_trees(_id, []) :-
       breakT(_id,_,_,_,_),!.

sub_trees(_id, []) :-
    continueT(_id,_,_,_,_),!.

sub_trees(_id, [_expr]) :-
    throwT(_id,_,_,_expr),!.

sub_trees(_id, SubTrees) :-
    applyT(_id,_,_,_recv,_,_args,_),!,
    listOrEmptyListIfNull(_recv,List),
    append(List,_args,SubTrees).

sub_trees(_id, [_clazz | _dummyList]) :-
    newClassT(_id,_,_,_,_args,_clazz,_def,_encl),
    !,
    listOrEmptyListIfNull(_encl, _enclList),
    listOrEmptyListIfNull(_def, _defList),
    append(_enclList,_defList,_dl1),
    append(_dl1,_args,_dummyList).
    %append(_enclList, _defList, _args, _dummyList).

sub_trees(_id, _subtrees) :-
    newArrayT(_id,_,_,_dims,_elems,_),
    !,
    emptyListIfNull(_dims, _dimsList),
    emptyListIfNull(_elems, _elemsList),
    append(_dimsList, _elemsList, _subtrees).

sub_trees(_id, [_lhs, _rhs]) :-
    assignT(_id,_,_,_lhs,_rhs),!.

sub_trees(_id, [_lhs, _rhs]) :-
    assignopT(_id,_,_,_lhs,_,_rhs),!.

sub_trees(_id, _args) :-
    operationT(_id,_,_,_args,_,_),!.

sub_trees(_id, [_expr]) :-
    typeCastT(_id,_,_,_,_expr),!.

sub_trees(_id, [_expr]) :-
    typeTestT(_id,_,_,_,_expr),!.

sub_trees(_id, [_index, _indexed]) :-
    indexedT(_id,_,_,_index, _indexed),!.

sub_trees(_id, [_selected]) :-
    selectT(_id,_,_,_,_selected,_),!.

sub_trees(_id, _subtrees) :-
    getFieldT(_id,_,_,Expr,_,_),
    !,
    (Expr == 'null' ->
        (_subtrees = []);
        (_subtrees = [Expr])
    ).

sub_trees(_id, []) :-
    importT(_id,_,_),!.
%    format('sub_trees:import: ~a, ~a~n', [_id, _imp]).

sub_trees(_id, []) :-
    literalT(_id,_,_,_,_),!.

sub_trees(_id, []) :-
    identT(_id,_,_,_,_),!.

sub_trees(_id, []) :-
    nopT(_id,_,_),
    !.

sub_trees(_id, []) :-
    tree(_id, _p, _name),
    !,
    format('ERROR: sub_trees: ~a, ~a, ~a~n', [_id, _p, _name]).

sub_trees(_id, 'null') :-
    not(tree(_id, _, _)),!.

