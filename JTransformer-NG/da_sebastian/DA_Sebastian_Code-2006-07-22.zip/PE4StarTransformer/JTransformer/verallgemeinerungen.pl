% Author:
% Date: 6/9/2006

/* Verallgemeinerung von markEnclAsDirty(Elem)
   Aufrufe:
     /engine/ast/ct_apply.pl:265 in add/1
                            :283 in delete/1
   Aufgabe:
     Als Input kommt ein PEF
     Wenn's nicht packageT ist, wird ein dirty_tree-fact asserted
 */


markEnclAsDirty(Lang,Elem):-
    getTerm(Lang,ID,Elem), %ermittle ID
    \+ checkIfTopLevel(Lang,ID),     %wenn es sich nicht um das Toplevel-Element handelt..
    (
        (
           enclosing(Lang,ID,Encl),    %hole Enclosing
           \+ (Encl = 'null'),           %Enclosing darf nicht null sein
           \+ checkIfTopLevel(Lang,Encl)         %Enclosing darf nicht die ID vom Toplevel sein
        );
        Encl = ID
    ),
    assert1T(dirty_tree(Lang,Encl)),     %wird IMMER ein dirty_tree-fact asserted? Wieso??
    !.

markEnclAsDirty(_).

/* getEnclPEFs(+Lang,?PEF)
 * Either checks if PEF contains an "enclosing"-argument or enumerates
 * all PEFs which have such an argument.
 *
 * Verallgemeinerung von set_encl_method2:
 * COMMENT: es w�re sch�ner, das encl-Argument mit member/2 oder nth1/3
 *          zu �berpr�fen. wird von Mixtus aber nicht unterst�tzt :(
 *          Au�erdem w�re die encl-�nderung am Ende am einfachsten mit dem
 *          Pr�dikat setarg(3,PEF,_new_encl) zu realisieren. Davon wird aber
 *          abgeraten.
 *          WICHTIG: Es wird von der Konvention ausgegangen, da� der encl-Parameter
 *                   immer an DRITTER! Stelle steht. Weitere Verallgemeinerung n�tig?
 */
getEnclPEFs(Lang,PEF) :-
    ast_node_def(Lang,PEF,Args),
    argsContainEncl(Args).

argsContainEncl([H|T]) :-
    H = ast_arg(encl,_,_,_) ;
    argsContainEncl(T).

set_encl_method(Lang, _id, _new_encl) :-
    getEnclPEFs(Lang,NodeTerm),
    ast_node_signature(Lang,NodeTerm,Arity),             %fetch arity
    functor(PEF,NodeTerm,Arity),
    functor(PEF2,NodeTerm,Arity),                        %PEF2 ist das Grundger�st f�r Knoten mit neuem Enclosing
    PEF2 =.. PEFList,                                    %Umwandlung in Liste
    arg(1,PEF,_id),
    PEFList = [_,_,_,_new_encl|_],                       %Enclosing wird gesetzt
    PEF,
    !,
    PEF =.. PEFListInst,                                 %alle Werte, die noch variabel sind, werden kopiert
    unifyLists(PEFListInst,PEFList),                     %R�ckumwandlung in Term
    NewPEF =.. PEFList,
    delete(PEF),
    %setarg(3,PEF,_new_encl),      %use of setarg/3 is not recommended, implement alternative version?
    add(NewPEF).

set_encl_method('Java',_id,_new_encl):-paramDefT(_id,_encl,_v1,_v2),!,delete(paramDefT(_id,_encl,_v1,_v2)),add(paramDefT(_id,_new_encl,_v1,_v2)).

getParentPEFs(Lang,PEF) :-
    ast_node_def(Lang,PEF,Args),
    argsContainParent(Args).

argsContainParent([H|T]) :-
    H = ast_arg(parent,_,_,_) ;
    argsContainParent(T).

/*
        set_parent(+Id | +IdList, +Parent)

        Sets the parent of the tree Id or the list of
        trees IdList to Parent.

        Es wird von der Konvention ausgegangen, da� der Parent immer an zweiter Stelle steht!
 */
set_parent(Lang, _id, _new_parent) :-
    getParentPEFs(Lang,NodeTerm),
    ast_node_signature(Lang,NodeTerm,Arity),             %fetch arity
    functor(PEF,NodeTerm,Arity),
    functor(PEF2,NodeTerm,Arity),                        %PEF2 ist das Grundger�st f�r Knoten mit neuem Enclosing
    PEF2 =.. PEFList,                                    %Umwandlung in Liste
    arg(1,PEF,_id),
    PEFList = [_,_,_new_parent|_],                       %Enclosing wird gesetzt
    PEF,
    !,
    PEF =.. PEFListInst,                                 %alle Werte, die noch variabel sind, werden kopiert
    unifyLists(PEFListInst,PEFList),                     %R�ckumwandlung in Term
    NewPEF =.. PEFList,
    delete(PEF),
    %setarg(3,PEF,_new_encl),      %use of setarg/3 is not recommended, implement alternative version?
    add(NewPEF).

set_parent('Java',_id,_newParent):-importT(_id,_pid,_v1),!,delete(importT(_id,_pid,_v1)),add(importT(_id,_newParent,_v1)).

/**
  enclosing(?Id, ?EnclId)

  Unifies EnclId with the enclosing class
  element (method, constructor, initializer or field)
  of the tree Id.

  TODO: reimplement as a meta-predicate
*/

%enclosing(?Lang,+_id,-_Encl)
enclosing(Lang,_id,_Encl) :-
    getEnclPEFs(Lang,Func),
    ast_node_signature(Lang,Func,Arity),
    functor(PEF,Func,Arity),
    arg(1,PEF,_id),
    arg(3,PEF,_Encl),
    PEF,
    !.
    
%getTerm(+Lang,+ID,-Term)
getTerm(Lang,ID,Term) :-
    ast_node_term(Lang,NodeTerm),
    arg(1,NodeTerm,ID),
    NodeTerm,
    Term = NodeTerm.
    
/*
    deleteTree(+Lang,+ID)
    Verallgemeinerte Version von deleteTree/1
    Seb: 02.5.06
    Probleme: - Inkonsistenz bei Arity von paramDefT:
                ast_node_tern -> 5; altes deleteTree -> 4
              - externT/1 fehlt bei ast_node_term
    Aufrufe:
        /engine/ast/java/javaASTOperations/tree_modifications.pl:392
        /st.java/pl/org/cs3/java/ctSpec/high_level_api.pl:453,460
*/
deleteTree(Lang,_id) :-
    ast_node_term(Lang,NodeTerm),
    arg(1,NodeTerm,_id),
    NodeTerm,
    !,
    delete(NodeTerm).

deleteTree(Lang,_id) :- nopT(_id,_pid,_encl),!,delete(nopT(_id,_pid,_encl)).

deleteTree(Lang,_id) :-
    not(tree(_id, _,_)),
    format('could not retract id: ~a~n', [_id]), !.


/*
    retractTree(+Lang,+ID)
    Verallgemeinerte Version von retractTree/1
    Seb: 02.5.06
    Probleme: - Inkonsistenz bei Arity von paramDefT:
                ast_node_term -> 5; altes retractTree -> 4
              - externT/1 fehlt bei ast_node_term
    Aufrufe:
        /engine/apply/garbage_collect.pl:138
        /engine/ast/java/javaASTOperations/tree_modifications.pl:410
*/
retractTree(Lang,_id) :-
    ast_node_term(Lang,NodeTerm),
    arg(1,NodeTerm,_id),
    NodeTerm,
    !,
    retract(NodeTerm).

retractTree(Lang,_id) :- nopT(_id,_pid,_encl),!,retract(nopT(_id,_pid,_encl)).

retractTree(Lang,_id) :-
    not(tree(_id, _,_)),
    format('could not retract id: ~a~n', [_id]), !.
    
/*##############################################################################
treechecks.pl
################################################################################*/

/**
 * checkConstraints(ID,ErrorHandler)
 *
 * ErrorHandler is a predicate with arity 1
 * which is evaluated on the error message
 * generated on failure.
 */

checkConstraints(Lang,ID,ErrorHandler):-
    %hole Term
    get_ast_node_term(Lang,ID,Term),
    %Zerlege in Funktor und Argumente
    Term =.. [Functor|[Args]],
    %Hole Beschr�nkungen f�r die Argumente
    ast_node_def(Lang,Functor,ArgList),
    extractConstraints(ArgList,Constraints),
    checkConstraints(Lang,Term,Constraints,Args,2,ErrorHandler).

%extractConstraints(+ArgumentList,-ExtractedConstraintList)
extractConstraints([],[]).
extractConstraints([ast_arg(_,_,_,Constraint)|T1],[Constraint|T2]) :-
    extractConstraints(T1,T2).


checkConstraints(_,_,[],[],_,_).
checkConstraints(Lang,Term,[Constraints | CRest],[Arg|ARest],Pos,ErrorHandler):-
    (
          (checkConstraintList(Lang,Constraints,Arg),!);                %�berpr�fe Constraint, wenn o.k. -> Cut
          printCheckError(Term,Constraints,Arg,Pos,ErrorHandler)   %sonst Fehlermeldung
        ),
        plus(Pos,1,Inc),
    checkConstraints(Lang,Term,CRest,ARest,Inc,ErrorHandler).           %�berpr�fe restliche Argumente


printCheckError(Term,Constraints,Arg,Pos,ErrorHandler):-
    term_to_atom(Term,TermAtom),
    term_to_atom(Constraints,ConstraintsAtom),
    term_to_atom(Arg,ArgAtom),
    sformat(Msg,'ERROR in term: ~a, argument ~a (\'~a\') does not fullfill constraints:~n  ~a~n',
          [TermAtom,Pos,ArgAtom,ConstraintsAtom]),
         MsgTerm =.. [ErrorHandler,Msg],
         call(MsgTerm),
        flush_output.


%Behandlung f�r den Fall, da� das Argument aus einer Liste besteht
%-> verzweige weiter in Einzelbehandlungen..
checkConstraintList(_,_,[]):-!.
checkConstraintList(Lang,Constraints,[H|T]):-
        checkConstraintList(Lang,Constraints,H),
        checkConstraintList(Lang,Constraints,T).

/**
 * checks if the type of arg is a member of the Constraints list:
 * e.g.: identT(Arg,...), checkConstraintList([identT],Arg)
 * (checks if functor is a member of the list Constraints )
 */
checkConstraintList(Lang,Constraints,Arg):-
    get_ast_node_label(Lang,Arg,PLASTFact),
    member(PLASTFact,Constraints),
    !.

/**
 * checks if the type of arg is a member of the Constraints list:
 * e.g.: identT(Arg,...), checkConstraintList([expressionType],Arg)
 */
checkConstraintList(Lang,Constraints,Arg):-
    get_ast_node_label(Lang,Arg,PLASTFact),
    member(Constraint,Constraints),
    not(ast_node_signature(Lang,Constraint,_)),
    Predicate =.. [Constraint, PLASTFact],
    call(Predicate),
    !.

/**
 * checks if the type of arg is a member of the Constraints list:
 * e.g.: identT(Arg,...), checkConstraintList([atomType],'Name')
 */
checkConstraintList(Lang,Constraints,Arg):-
    member(Constraint,Constraints),              %Backtracking �ber einzelne Member
    not(ast_node_signature(Lang,Constraint,_)), %wenn kein g�ltiges AST-Node Label.. (z.B. expressionType)
    Predicate =.. [Constraint|Arg],             %..dann �berpr�fe den Typ
    call(Predicate),
    !.

