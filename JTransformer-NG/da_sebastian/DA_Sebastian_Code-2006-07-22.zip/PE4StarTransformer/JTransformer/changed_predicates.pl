% Author:
% Date: 5/30/2006

/*##############################################################################
ct_apply.pl
################################################################################*/

add(java_fq(Elem)):-
    !,
    java_fq_to_pef(Elem,PEF),
    add(PEF).

add(Elem) :-
    nonvar(Elem),
        call(Elem),
        !,
        format('~nWARNING: element: already exists: ~w~n.',[Elem]).

add(_elem) :-
    nonvar(_elem),
    assert(_elem),
    asserta(rollback(retract(_elem))),
    markEnclAsDirty(_elem).

delete(java_fq(Elem)):-
    !,
    java_fq_to_pef(Elem,PEF),
    delete(PEF).

delete(_elem) :-
        nonvar(_elem),
        retract(_elem),
        markEnclAsDirty(_elem),
        asserta(rollback(assert(_elem))).

replace(java_fq(Elem1),java_fq(Elem2)):-
    !,
    java_fq_to_pef(Elem1,PEF1),
    java_fq_to_pef(Elem2,PEF2),
    replace(PEF1,PEF2).

replace(_elem1, _elem2) :- delete(_elem1), add(_elem2).

replace(Elem) :-
    Elem =.. [_|[ID|_]],
    getTerm(ID,ElemOld),
%    term_to_atom(ElemOld,A),
%    print(A),
    flush_output,
        delete(ElemOld),
        add(Elem).


/*##############################################################################
transaction.pl
################################################################################*/
:- dynamic dirty_tree/1.

markEnclAsDirty(Elem):-
    getTerm(ID,Elem),
    not(packageT(ID,_)),
    (
        (enclosing(ID,Encl), not(Encl = 'null'),not(packageT(Encl,_)));
        Encl = ID
    ),
    assert1T(dirty_tree(Encl)),
    !.

markEnclAsDirty(_).

/*##############################################################################
  aus /engine/apply/garbage_collect.pl
  ##############################################################################*/

/*
        deleteTree(+#pef)
        retract #pef and protcolls this for rollback.
        Uses delete/1 to retract the tree.
*/

deleteTree(_id):-getFieldT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(getFieldT(_id,_pid,_encl,_v1,_v2,_v3)).
deleteTree(_id):-selectT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(selectT(_id,_pid,_encl,_v1,_v2,_v3)).
deleteTree(_id):-identT(_id,_pid,_encl,_v1,_v2),!,delete(identT(_id,_pid,_encl,_v1,_v2)).
deleteTree(_id):-methodDefT(_id,_pid,_v1,_v2,_v3,_v4,_v5),!,delete(methodDefT(_id,_pid,_v1,_v2,_v3,_v4,_v5)).
deleteTree(_id):-localDefT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(localDefT(_id,_pid,_encl,_v1,_v2,_v3)).
deleteTree(_id):-fieldDefT(_id,_pid,_v1,_v2,_v3),!,delete(fieldDefT(_id,_pid,_v1,_v2,_v3)).
deleteTree(_id):-paramDefT(_id,_pid,_v1,_v2),!,delete(paramDefT(_id,_pid,_v1,_v2)).
deleteTree(_id):-classDefT(_id,_pid,_v1,_v2),!,delete(classDefT(_id,_pid,_v1,_v2)).
deleteTree(_id):-packageT(_id,_v1),!,delete(packageT(_id,_v1)).
deleteTree(_id):-toplevelT(_id,_pid,_v1,_v2),!,delete(toplevelT(_id,_pid,_v1,_v2)).
deleteTree(_id):-blockT(_id,_pid,_encl,_v1),!,delete(blockT(_id,_pid,_encl,_v1)).
deleteTree(_id):-doLoopT(_id,_pid,_encl,_v1,_v2),!,delete(doLoopT(_id,_pid,_encl,_v1,_v2)).
deleteTree(_id):-whileLoopT(_id,_pid,_encl,_v1,_v2),!,delete(whileLoopT(_id,_pid,_encl,_v1,_v2)).
deleteTree(_id):-forLoopT(_id,_pid,_encl,_v1,_v2,_v3,_v4),!,delete(forLoopT(_id,_pid,_encl,_v1,_v2,_v3,_v4)).
deleteTree(_id):-labelT(_id,_pid,_encl,_v1,_v2),!,delete(labelT(_id,_pid,_encl,_v1,_v2)).
deleteTree(_id):-switchT(_id,_pid,_encl,_v1,_v2),!,delete(switchT(_id,_pid,_encl,_v1,_v2)).
deleteTree(_id):-caseT(_id,_pid,_encl,_v1),!,delete(caseT(_id,_pid,_encl,_v1)).
deleteTree(_id):-synchronizedT(_id,_pid,_encl,_v1,_v2),!,delete(synchronizedT(_id,_pid,_encl,_v1,_v2)).
deleteTree(_id):-tryT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(tryT(_id,_pid,_encl,_v1,_v2,_v3)).
deleteTree(_id):-catchT(_id,_pid,_encl,_v1,_v2),!,delete(catchT(_id,_pid,_encl,_v1,_v2)).
deleteTree(_id):-ifT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(ifT(_id,_pid,_encl,_v1,_v2,_v3)).
deleteTree(_id):-conditionalT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(conditionalT(_id,_pid,_encl,_v1,_v2,_v3)).
/*format('rt:exec: ~a~n', [_id]),*/
deleteTree(_id):-execT(_id,_pid,_encl,_v1),!,delete(execT(_id,_pid,_encl,_v1)).
deleteTree(_id):-returnT(_id,_pid,_encl,_v1),!,delete(returnT(_id,_pid,_encl,_v1)).
deleteTree(_id):-breakT(_id,_pid,_encl,_v1,_v2),!,delete(breakT(_id,_pid,_encl,_v1,_v2)).
deleteTree(_id):-continueT(_id,_pid,_encl,_v1,_v2),!,delete(continueT(_id,_pid,_encl,_v1,_v2)).
deleteTree(_id):-throwT(_id,_pid,_encl,_v1),!,delete(throwT(_id,_pid,_encl,_v1)).
deleteTree(_id):-applyT(_id,_pid,_encl,_v1,_v2,_v3,_v4),!,delete(applyT(_id,_pid,_encl,_v1,_v2,_v3,_v4)).
deleteTree(_id):-newClassT(_id,_pid,_encl,_v1,_v2,_v3,_v4,_v5),!,delete(newClassT(_id,_pid,_encl,_v1,_v2,_v3,_v4,_v5)).
deleteTree(_id):-newArrayT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(newArrayT(_id,_pid,_encl,_v1,_v2,_v3)).
deleteTree(_id):-assignT(_id,_pid,_encl,_v1,_v2),!,delete(assignT(_id,_pid,_encl,_v1,_v2)).
deleteTree(_id):-assignopT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(assignopT(_id,_pid,_encl,_v1,_v2,_v3)).
deleteTree(_id):-operationT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(operationT(_id,_pid,_encl,_v1,_v2,_v3)).
deleteTree(_id):-typeCastT(_id,_pid,_encl,_v1,_v2),!,delete(typeCastT(_id,_pid,_encl,_v1,_v2)).
deleteTree(_id):-typeTestT(_id,_pid,_encl,_v1,_v2),!,delete(typeTestT(_id,_pid,_encl,_v1,_v2)).
deleteTree(_id):-indexedT(_id,_pid,_encl,_v1,_v2),!,delete(indexedT(_id,_pid,_encl,_v1,_v2)).
deleteTree(_id):-literalT(_id,_pid,_encl,_v1,_v2),!,delete(literalT(_id,_pid,_encl,_v1,_v2)).
deleteTree(_id):-assertT(_id,_pid,_encl,_v1,_v2),!,delete(assertT(_id,_pid,_encl,_v1,_v2)).
%deleteTree(_id):-classMembersT(_id,_v1),!,delete(classMembersT(_id,_v1)).
deleteTree(_id):-externT(_id),!,delete(externT(_id)).
deleteTree(_id):-importT(_id,_pid,_v1),!,delete(importT(_id,_pid,_v1)).
deleteTree(_id):-nopT(_id,_pid,_encl),!,delete(nopT(_id,_pid,_encl)).
deleteTree(_id):-precedenceT(_id,_pid,_encl,_v1),!,delete(precedenceT(_id,_pid,_encl,_v1)).
deleteTree(_id) :-
    not(tree(_id, _,_)),
    format('could not retract id: ~a~n', [_id]), !.


/*
    L�scht eine tree definiert durch seine id.
*/

retractTree(_id):-getFieldT(_id,_pid,_encl,_v1,_v2,_v3),!,retract(getFieldT(_id,_pid,_encl,_v1,_v2,_v3)).
retractTree(_id):-selectT(_id,_pid,_encl,_v1,_v2,_v3),!,retract(selectT(_id,_pid,_encl,_v1,_v2,_v3)).
retractTree(_id):-identT(_id,_pid,_encl,_v1,_v2),!,retract(identT(_id,_pid,_encl,_v1,_v2)).
retractTree(_id):-methodDefT(_id,_pid,_v1,_v2,_v3,_v4,_v5),!,retract(methodDefT(_id,_pid,_v1,_v2,_v3,_v4,_v5)).
retractTree(_id):-localDefT(_id,_pid,_encl,_v1,_v2,_v3),!,retract(localDefT(_id,_pid,_encl,_v1,_v2,_v3)).
retractTree(_id):-fieldDefT(_id,_pid,_v1,_v2,_v3),!,retract(fieldDefT(_id,_pid,_v1,_v2,_v3)).
retractTree(_id):-paramDefT(_id,_pid,_v1,_v2),!,retract(paramDefT(_id,_pid,_v1,_v2)).
retractTree(_id):-classDefT(_id,_pid,_v1,_v2),!,retract(classDefT(_id,_pid,_v1,_v2)).
retractTree(_id):-packageT(_id,_v1),!,retract(packageT(_id,_v1)).
retractTree(_id):-toplevelT(_id,_pid,_v1,_v2),!,retract(toplevelT(_id,_pid,_v1,_v2)).
retractTree(_id):-blockT(_id,_pid,_encl,_v1),!,retract(blockT(_id,_pid,_encl,_v1)).
retractTree(_id):-doLoopT(_id,_pid,_encl,_v1,_v2),!,retract(doLoopT(_id,_pid,_encl,_v1,_v2)).
retractTree(_id):-whileLoopT(_id,_pid,_encl,_v1,_v2),!,retract(whileLoopT(_id,_pid,_encl,_v1,_v2)).
retractTree(_id):-forLoopT(_id,_pid,_encl,_v1,_v2,_v3,_v4),!,retract(forLoopT(_id,_pid,_encl,_v1,_v2,_v3,_v4)).
retractTree(_id):-labelT(_id,_pid,_encl,_v1,_v2),!,retract(labelT(_id,_pid,_encl,_v1,_v2)).
retractTree(_id):-switchT(_id,_pid,_encl,_v1,_v2),!,retract(switchT(_id,_pid,_encl,_v1,_v2)).
retractTree(_id):-caseT(_id,_pid,_encl,_v1),!,retract(caseT(_id,_pid,_encl,_v1)).
retractTree(_id):-synchronizedT(_id,_pid,_encl,_v1,_v2),!,retract(synchronizedT(_id,_pid,_encl,_v1,_v2)).
retractTree(_id):-tryT(_id,_pid,_encl,_v1,_v2,_v3),!,retract(tryT(_id,_pid,_encl,_v1,_v2,_v3)).
retractTree(_id):-catchT(_id,_pid,_encl,_v1,_v2),!,retract(catchT(_id,_pid,_encl,_v1,_v2)).
retractTree(_id):-ifT(_id,_pid,_encl,_v1,_v2,_v3),!,retract(ifT(_id,_pid,_encl,_v1,_v2,_v3)).
retractTree(_id):-conditionalT(_id,_pid,_encl,_v1,_v2,_v3),!,retract(conditionalT(_id,_pid,_encl,_v1,_v2,_v3)).
/*format('rt:exec: ~a~n', [_id]),*/
retractTree(_id):-execT(_id,_pid,_encl,_v1),!,retract(execT(_id,_pid,_encl,_v1)).
retractTree(_id):-returnT(_id,_pid,_encl,_v1),!,retract(returnT(_id,_pid,_encl,_v1)).
retractTree(_id):-breakT(_id,_pid,_encl,_v1,_v2),!,retract(breakT(_id,_pid,_encl,_v1,_v2)).
retractTree(_id):-continueT(_id,_pid,_encl,_v1,_v2),!,retract(continueT(_id,_pid,_encl,_v1,_v2)).
retractTree(_id):-throwT(_id,_pid,_encl,_v1),!,retract(throwT(_id,_pid,_encl,_v1)).
retractTree(_id):-applyT(_id,_pid,_encl,_v1,_v2,_v3,_v4),!,retract(applyT(_id,_pid,_encl,_v1,_v2,_v3,_v4)).
retractTree(_id):-newClassT(_id,_pid,_encl,_v1,_v2,_v3,_v4,_v5),!,retract(newClassT(_id,_pid,_encl,_v1,_v2,_v3,_v4,_v5)).
retractTree(_id):-newArrayT(_id,_pid,_encl,_v1,_v2,_v3),!,retract(newArrayT(_id,_pid,_encl,_v1,_v2,_v3)).
retractTree(_id):-assignT(_id,_pid,_encl,_v1,_v2),!,retract(assignT(_id,_pid,_encl,_v1,_v2)).
retractTree(_id):-assignopT(_id,_pid,_encl,_v1,_v2,_v3),!,retract(assignopT(_id,_pid,_encl,_v1,_v2,_v3)).
retractTree(_id):-operationT(_id,_pid,_encl,_v1,_v2,_v3),!,retract(operationT(_id,_pid,_encl,_v1,_v2,_v3)).
retractTree(_id):-typeCastT(_id,_pid,_encl,_v1,_v2),!,retract(typeCastT(_id,_pid,_encl,_v1,_v2)).
retractTree(_id):-typeTestT(_id,_pid,_encl,_v1,_v2),!,retract(typeTestT(_id,_pid,_encl,_v1,_v2)).
retractTree(_id):-indexedT(_id,_pid,_encl,_v1,_v2),!,retract(indexedT(_id,_pid,_encl,_v1,_v2)).
retractTree(_id):-literalT(_id,_pid,_encl,_v1,_v2),!,retract(literalT(_id,_pid,_encl,_v1,_v2)).
retractTree(_id):-assertT(_id,_pid,_encl,_v1,_v2),!,retract(assertT(_id,_pid,_encl,_v1,_v2)).
%retractTree(_id):-classMembersT(_id,_v1),!,retract(classMembersT(_id,_v1)).
retractTree(_id):-externT(_id),!,retract(externT(_id)).
retractTree(_id):-importT(_id,_pid,_v1),!,retract(importT(_id,_pid,_v1)).
retractTree(_id):-nopT(_id,_pid,_encl),!,retract(nopT(_id,_pid,_encl)).
retractTree(_id):-precedenceT(_id,_pid,_encl,_v1),!,retract(precedenceT(_id,_pid,_encl,_v1)).
retractTree(_id) :-
    not(tree(_id, _,_)),
    format('could not retract id: ~a~n', [_id]), !.



/*##############################################################################
aus /engine/ast/java/javaASTOperations/tree_modifications.pl
 ###############################################################################*/

set_encl_method(_id,_new_encl):-applyT(_id,_pid,_encl,_v1,_v2,_v3,_v4),!,delete(applyT(_id,_pid,_encl,_v1,_v2,_v3,_v4)),add(applyT(_id,_pid,_new_encl,_v1,_v2,_v3,_v4)).
set_encl_method(_id,_new_encl):-assertT(_id,_pid,_encl,_v1,_v2),!,delete(assertT(_id,_pid,_encl,_v1,_v2)),add(assertT(_id,_pid,_new_encl,_v1,_v2)).
set_encl_method(_id,_new_encl):-assignT(_id,_pid,_encl,_v1,_v2),!,delete(assignT(_id,_pid,_encl,_v1,_v2)),add(assignT(_id,_pid,_new_encl,_v1,_v2)).
set_encl_method(_id,_new_encl):-assignopT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(assignopT(_id,_pid,_encl,_v1,_v2,_v3)),add(assignopT(_id,_pid,_new_encl,_v1,_v2,_v3)).
set_encl_method(_id,_new_encl):-blockT(_id,_pid,_encl,_v1),!,delete(blockT(_id,_pid,_encl,_v1)),add(blockT(_id,_pid,_new_encl,_v1)).
set_encl_method(_id,_new_encl):-breakT(_id,_pid,_encl,_v1,_v2),!,delete(breakT(_id,_pid,_encl,_v1,_v2)),add(breakT(_id,_pid,_new_encl,_v1,_v2)).
set_encl_method(_id,_new_encl):-caseT(_id,_pid,_encl,_v1),!,delete(caseT(_id,_pid,_encl,_v1)),add(caseT(_id,_pid,_new_encl,_v1)).
set_encl_method(_id,_new_encl):-catchT(_id,_pid,_encl,_v1,_v2),!,delete(catchT(_id,_pid,_encl,_v1,_v2)),add(catchT(_id,_pid,_new_encl,_v1,_v2)).
set_encl_method(_id,_new_encl):-conditionalT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(conditionalT(_id,_pid,_encl,_v1,_v2,_v3)),add(conditionalT(_id,_pid,_new_encl,_v1,_v2,_v3)).
set_encl_method(_id,_new_encl):-continueT(_id,_pid,_encl,_v1,_v2),!,delete(continueT(_id,_pid,_encl,_v1,_v2)),add(continueT(_id,_pid,_new_encl,_v1,_v2)).
set_encl_method(_id,_new_encl):-doLoopT(_id,_pid,_encl,_v1,_v2),!,delete(doLoopT(_id,_pid,_encl,_v1,_v2)),add(doLoopT(_id,_pid,_new_encl,_v1,_v2)).
set_encl_method(_id,_new_encl):-execT(_id,_pid,_encl,_v1),!,delete(execT(_id,_pid,_encl,_v1)),add(execT(_id,_pid,_new_encl,_v1)).
set_encl_method(_id,_new_encl):-forLoopT(_id,_pid,_encl,_v1,_v2,_v3,_v4),!,delete(forLoopT(_id,_pid,_encl,_v1,_v2,_v3,_v4)),add(forLoopT(_id,_pid,_new_encl,_v1,_v2,_v3,_v4)).
set_encl_method(_id,_new_encl):-getFieldT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(getFieldT(_id,_pid,_encl,_v1,_v2,_v3)),add(getFieldT(_id,_pid,_new_encl,_v1,_v2,_v3)).
set_encl_method(_id,_new_encl):-identT(_id,_pid,_encl,_v1,_v2),!,delete(identT(_id,_pid,_encl,_v1,_v2)),add(identT(_id,_pid,_new_encl,_v1,_v2)).
set_encl_method(_id,_new_encl):-ifT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(ifT(_id,_pid,_encl,_v1,_v2,_v3)),add(ifT(_id,_pid,_new_encl,_v1,_v2,_v3)).
set_encl_method(_id,_new_encl):-indexedT(_id,_pid,_encl,_v1,_v2),!,delete(indexedT(_id,_pid,_encl,_v1,_v2)),add(indexedT(_id,_pid,_new_encl,_v1,_v2)).
set_encl_method(_id,_new_encl):-labelT(_id,_pid,_encl,_v1,_v2),!,delete(labelT(_id,_pid,_encl,_v1,_v2)),add(labelT(_id,_pid,_new_encl,_v1,_v2)).
set_encl_method(_id,_new_encl):-literalT(_id,_pid,_encl,_v1,_v2),!,delete(literalT(_id,_pid,_encl,_v1,_v2)),add(literalT(_id,_pid,_new_encl,_v1,_v2)).
set_encl_method(_id,_new_encl):-localDefT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(localDefT(_id,_pid,_encl,_v1,_v2,_v3)),add(localDefT(_id,_pid,_new_encl,_v1,_v2,_v3)).
set_encl_method(_id,_new_encl):-newArrayT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(newArrayT(_id,_pid,_encl,_v1,_v2,_v3)),add(newArrayT(_id,_pid,_new_encl,_v1,_v2,_v3)).
set_encl_method(_id,_new_encl):-newClassT(_id,_pid,_encl,_v1,_v2,_v3,_v4,_v5),!,delete(newClassT(_id,_pid,_encl,_v1,_v2,_v3,_v4,_v5)),add(newClassT(_id,_pid,_new_encl,_v1,_v2,_v3,_v4,_v5)).
set_encl_method(_id,_new_encl):-nopT(_id,_pid,_encl),!,delete(nopT(_id,_pid,_encl)),add(nopT(_id,_pid,_new_encl)).
set_encl_method(_id,_new_encl):-operationT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(operationT(_id,_pid,_encl,_v1,_v2,_v3)),add(operationT(_id,_pid,_new_encl,_v1,_v2,_v3)).
set_encl_method(_id,_new_encl):-paramDefT(_id,_encl,_v1,_v2),!,delete(paramDefT(_id,_encl,_v1,_v2)),add(paramDefT(_id,_new_encl,_v1,_v2)).
set_encl_method(_id,_new_encl):-precedenceT(_id,_pid,_encl,_v1),!,delete(precedenceT(_id,_pid,_encl,_v1)),add(precedenceT(_id,_pid,_new_encl,_v1)).
set_encl_method(_id,_new_encl):-returnT(_id,_pid,_encl,_v1),!,delete(returnT(_id,_pid,_encl,_v1)),add(returnT(_id,_pid,_new_encl,_v1)).
set_encl_method(_id,_new_encl):-selectT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(selectT(_id,_pid,_encl,_v1,_v2,_v3)),add(selectT(_id,_pid,_new_encl,_v1,_v2,_v3)).
set_encl_method(_id,_new_encl):-switchT(_id,_pid,_encl,_v1,_v2),!,delete(switchT(_id,_pid,_encl,_v1,_v2)),add(switchT(_id,_pid,_new_encl,_v1,_v2)).
set_encl_method(_id,_new_encl):-synchronizedT(_id,_pid,_encl,_v1,_v2),!,delete(synchronizedT(_id,_pid,_encl,_v1,_v2)),add(synchronizedT(_id,_pid,_new_encl,_v1,_v2)).
set_encl_method(_id,_new_encl):-throwT(_id,_pid,_encl,_v1),!,delete(throwT(_id,_pid,_encl,_v1)),add(throwT(_id,_pid,_new_encl,_v1)).
set_encl_method(_id,_new_encl):-tryT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(tryT(_id,_pid,_encl,_v1,_v2,_v3)),add(tryT(_id,_pid,_new_encl,_v1,_v2,_v3)).
set_encl_method(_id,_new_encl):-typeCastT(_id,_pid,_encl,_v1,_v2),!,delete(typeCastT(_id,_pid,_encl,_v1,_v2)),add(typeCastT(_id,_pid,_new_encl,_v1,_v2)).
set_encl_method(_id,_new_encl):-typeTestT(_id,_pid,_encl,_v1,_v2),!,delete(typeTestT(_id,_pid,_encl,_v1,_v2)),add(typeTestT(_id,_pid,_new_encl,_v1,_v2)).
set_encl_method(_id,_new_encl):-whileLoopT(_id,_pid,_encl,_v1,_v2),!,delete(whileLoopT(_id,_pid,_encl,_v1,_v2)),add(whileLoopT(_id,_pid,_new_encl,_v1,_v2)).

/*S.L.
set_encl_method(_id,_):-
    atom_concat('set_encl_method: ', _id, _out),
    throw(_out).
*/


set_parent([], _).
set_parent([_h| _t], _parent) :-
    set_parent(_h,_parent),
    set_parent(_t,_parent).

set_parent(_id,_newParent):-getFieldT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(getFieldT(_id,_pid,_encl,_v1,_v2,_v3)),add(getFieldT(_id,_newParent,_encl,_v1,_v2,_v3)).
set_parent(_id,_newParent):-selectT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(selectT(_id,_pid,_encl,_v1,_v2,_v3)),add(selectT(_id,_newParent,_encl,_v1,_v2,_v3)).
set_parent(_id,_newParent):-identT(_id,_pid,_encl,_v1,_v2),!,delete(identT(_id,_pid,_encl,_v1,_v2)),add(identT(_id,_newParent,_encl,_v1,_v2)).
set_parent(_id,_newParent):-methodDefT(_id,_pid,_v1,_v2,_v3,_v4,_v5),!,delete(methodDefT(_id,_pid,_v1,_v2,_v3,_v4,_v5)),add(methodDefT(_id,_newParent,_v1,_v2,_v3,_v4,_v5)).
set_parent(_id,_newParent):-localDefT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(localDefT(_id,_pid,_encl,_v1,_v2,_v3)),add(localDefT(_id,_newParent,_encl,_v1,_v2,_v3)).
set_parent(_id,_newParent):-fieldDefT(_id,_pid,_v1,_v2,_v3),!,delete(fieldDefT(_id,_pid,_v1,_v2,_v3)),add(fieldDefT(_id,_newParent,_v1,_v2,_v3)).
set_parent(_id,_newParent):-paramDefT(_id,_pid,_v1,_v2),!,delete(paramDefT(_id,_pid,_v1,_v2)),add(paramDefT(_id,_newParent,_v1,_v2)).
set_parent(_id,_newParent):-blockT(_id,_pid,_encl,_v1),!,delete(blockT(_id,_pid,_encl,_v1)),add(blockT(_id,_newParent,_encl,_v1)).
set_parent(_id,_newParent):-doLoopT(_id,_pid,_encl,_v1,_v2),!,delete(doLoopT(_id,_pid,_encl,_v1,_v2)),add(doLoopT(_id,_newParent,_encl,_v1,_v2)).
set_parent(_id,_newParent):-whileLoopT(_id,_pid,_encl,_v1,_v2),!,delete(whileLoopT(_id,_pid,_encl,_v1,_v2)),add(whileLoopT(_id,_newParent,_encl,_v1,_v2)).
set_parent(_id,_newParent):-forLoopT(_id,_pid,_encl,_v1,_v2,_v3,_v4),!,delete(forLoopT(_id,_pid,_encl,_v1,_v2,_v3,_v4)),add(forLoopT(_id,_newParent,_encl,_v1,_v2,_v3,_v4)).
set_parent(_id,_newParent):-labelT(_id,_pid,_encl,_v1,_v2),!,delete(labelT(_id,_pid,_encl,_v1,_v2)),add(labelT(_id,_newParent,_encl,_v1,_v2)).
set_parent(_id,_newParent):-switchT(_id,_pid,_encl,_v1,_v2),!,delete(switchT(_id,_pid,_encl,_v1,_v2)),add(switchT(_id,_newParent,_encl,_v1,_v2)).
set_parent(_id,_newParent):-caseT(_id,_pid,_encl,_v1),!,delete(caseT(_id,_pid,_encl,_v1)),add(caseT(_id,_newParent,_encl,_v1)).
set_parent(_id,_newParent):-synchronizedT(_id,_pid,_encl,_v1,_v2),!,delete(synchronizedT(_id,_pid,_encl,_v1,_v2)),add(synchronizedT(_id,_newParent,_encl,_v1,_v2)).
set_parent(_id,_newParent):-tryT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(tryT(_id,_pid,_encl,_v1,_v2,_v3)),add(tryT(_id,_newParent,_encl,_v1,_v2,_v3)).
set_parent(_id,_newParent):-catchT(_id,_pid,_encl,_v1,_v2),!,delete(catchT(_id,_pid,_encl,_v1,_v2)),add(catchT(_id,_newParent,_encl,_v1,_v2)).
set_parent(_id,_newParent):-ifT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(ifT(_id,_pid,_encl,_v1,_v2,_v3)),add(ifT(_id,_newParent,_encl,_v1,_v2,_v3)).
set_parent(_id,_newParent):-conditionalT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(conditionalT(_id,_pid,_encl,_v1,_v2,_v3)),add(conditionalT(_id,_newParent,_encl,_v1,_v2,_v3)).
set_parent(_id,_newParent):-execT(_id,_pid,_encl,_v1),!,delete(execT(_id,_pid,_encl,_v1)),add(execT(_id,_newParent,_encl,_v1)).
set_parent(_id,_newParent):-returnT(_id,_pid,_encl,_v1),!,delete(returnT(_id,_pid,_encl,_v1)),add(returnT(_id,_newParent,_encl,_v1)).
set_parent(_id,_newParent):-breakT(_id,_pid,_encl,_v1,_v2),!,delete(breakT(_id,_pid,_encl,_v1,_v2)),add(breakT(_id,_newParent,_encl,_v1,_v2)).
set_parent(_id,_newParent):-continueT(_id,_pid,_encl,_v1,_v2),!,delete(continueT(_id,_pid,_encl,_v1,_v2)),add(continueT(_id,_newParent,_encl,_v1,_v2)).
set_parent(_id,_newParent):-throwT(_id,_pid,_encl,_v1),!,delete(throwT(_id,_pid,_encl,_v1)),add(throwT(_id,_newParent,_encl,_v1)).
set_parent(_id,_newParent):-applyT(_id,_pid,_encl,_v1,_v2,_v3,_v4),!,delete(applyT(_id,_pid,_encl,_v1,_v2,_v3,_v4)),add(applyT(_id,_newParent,_encl,_v1,_v2,_v3,_v4)).
set_parent(_id,_newParent):-newClassT(_id,_pid,_encl,_v1,_v2,_v3,_v4,_v5),!,delete(newClassT(_id,_pid,_encl,_v1,_v2,_v3,_v4,_v5)),add(newClassT(_id,_newParent,_encl,_v1,_v2,_v3,_v4,_v5)).
set_parent(_id,_newParent):-newArrayT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(newArrayT(_id,_pid,_encl,_v1,_v2,_v3)),add(newArrayT(_id,_newParent,_encl,_v1,_v2,_v3)).
set_parent(_id,_newParent):-assignT(_id,_pid,_encl,_v1,_v2),!,delete(assignT(_id,_pid,_encl,_v1,_v2)),add(assignT(_id,_newParent,_encl,_v1,_v2)).
set_parent(_id,_newParent):-classDefT(_id,_pid,_v1,_v2),!,delete(classDefT(_id,_pid,_v1,_v2)),add(classDefT(_id,_newParent,_v1,_v2)).
set_parent(_id,_newParent):-toplevelT(_id,_pid,_v1,_v2),!,delete(toplevelT(_id,_pid,_v1,_v2)),add(toplevelT(_id,_newParent,_v1,_v2)).
set_parent(_id,_newParent):-assignopT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(assignopT(_id,_pid,_encl,_v1,_v2,_v3)),add(assignopT(_id,_newParent,_encl,_v1,_v2,_v3)).
set_parent(_id,_newParent):-operationT(_id,_pid,_encl,_v1,_v2,_v3),!,delete(operationT(_id,_pid,_encl,_v1,_v2,_v3)),add(operationT(_id,_newParent,_encl,_v1,_v2,_v3)).
set_parent(_id,_newParent):-typeCastT(_id,_pid,_encl,_v1,_v2),!,delete(typeCastT(_id,_pid,_encl,_v1,_v2)),add(typeCastT(_id,_newParent,_encl,_v1,_v2)).
set_parent(_id,_newParent):-typeTestT(_id,_pid,_encl,_v1,_v2),!,delete(typeTestT(_id,_pid,_encl,_v1,_v2)),add(typeTestT(_id,_newParent,_encl,_v1,_v2)).
set_parent(_id,_newParent):-indexedT(_id,_pid,_encl,_v1,_v2),!,delete(indexedT(_id,_pid,_encl,_v1,_v2)),add(indexedT(_id,_newParent,_encl,_v1,_v2)).
set_parent(_id,_newParent):-literalT(_id,_pid,_encl,_v1,_v2),!,delete(literalT(_id,_pid,_encl,_v1,_v2)),add(literalT(_id,_newParent,_encl,_v1,_v2)).
set_parent(_id,_newParent):-assertT(_id,_pid,_encl,_v1,_v2),!,delete(assertT(_id,_pid,_encl,_v1,_v2)),add(assertT(_id,_newParent,_encl,_v1,_v2)).
set_parent(_id,_newParent):-importT(_id,_pid,_v1),!,delete(importT(_id,_pid,_v1)),add(importT(_id,_newParent,_v1)).
set_parent(_id,_newParent):-precedenceT(_id,_pid,_encl,_v1),!,delete(precedenceT(_id,_pid,_encl,_v1)),add(precedenceT(_id,_newParent,_encl,_v1)).
set_parent(_id,_newParent):-nopT(_id,_pid,_encl),!,delete(nopT(_id,_pid,_encl)),add(nopT(_id,_newParent,_encl)).

set_parent([],_).
set_parent([_H | _T],_newParent) :-
    set_parent(_H, _newParent),
    set_parent(_T, _newParent).
    
/**
 replaceId(+Term, +oldId, +newId)

 Replaces the
*/
/*
replaceId(_id, _oldId, _newId) :-
    getTerm(_id, _oldTerm),
    replaceIdInTerm(_oldTerm, _newTerm, _oldId, _newId),
    delete(_oldTerm),
    add(_newTerm).


replaceIdInTerm(_term, _Translated,_oldId, _newId) :-
    _term =.. [_name | _args],
    replaceIdInList(_args, _translatedArgs,_oldId, _newId),
    _Translated =.. [_name | _translatedArgs].

replaceIdInList([], [],_,_) :- !.
replaceIdInList([_oldId | _t], [_newId | _rest], _oldId, _newId) :-
    replaceIdInList(_t, _rest, _oldId, _newId).

replaceIdInList([_term | _t], [_Term | _rest],_oldId, _newId) :-
    not(atomic(_term)),
    !,
    replaceIdInTerm(_term,_Term,_oldId, _newId),
    replaceIdInList(_t, _rest, _oldId, _newId).

replaceIdInList([_term | _t], [_term | _rest],_oldId, _newId) :-
    replaceIdInList(_t, _rest, _oldId, _newId).
*/
/*##############################################################################
aus /engine/ast/java/javaASTOperations/tree_queries.pl
 ###############################################################################*/
    
enclosing(_id, _Encl):- fieldDefT(_id, _Encl, _, _, _),!.
enclosing(_id, _Encl):-identT(_id, _,_Encl,_,_), !.
enclosing(_id, _Encl):-getFieldT(_id, _,_Encl,_,_,_), !.
enclosing(_id, _Encl):-selectT(_id, _,_Encl,_,_,_), !.
enclosing(_id, _Encl):-localDefT(_id, _,_Encl,_,_,_), !.
enclosing(_id, _Encl):-paramDefT(_id,_Encl,_,_), !.
enclosing(_id, _Encl):-applyT(_id, _,_Encl,_,_,_,_), !.
enclosing(_id, _Encl):-methodDefT(_id, _Encl,_,_,_,_,_), !.
enclosing(_id, _Encl):-execT(_id, _,_Encl,_), !.
enclosing(_id, _Encl):-operationT(_id, _,_Encl,_,_,_), !.
enclosing(_id, _Encl):-literalT(_id, _,_Encl,_,_), !.
enclosing(_id, _Encl):-blockT(_id, _,_Encl,_), !.
enclosing(_id, _Encl):-assignT(_id, _,_Encl,_,_), !.
enclosing(_id, _Encl):-conditionalT(_id, _,_Encl,_,_,_), !.
enclosing(_id, _Encl):-returnT(_id, _,_Encl,_), !.
enclosing(_id, _Encl):-ifT(_id, _,_Encl,_,_,_), !.
enclosing(_id, _Encl):-caseT(_id, _,_Encl,_), !.
enclosing(_id, _Encl):-indexedT(_id, _,_Encl,_,_), !.
enclosing(_id, _Encl):-typeCastT(_id, _,_Encl,_,_), !.
enclosing(_id, _Encl):-newClassT(_id, _,_Encl,_,_,_,_,_), !.
enclosing(_id, _Encl):-classDefT(_id, _Encl,_,_), !.
enclosing(_id, _id)  :- packageT(_id, _), !.
enclosing(_id, _Encl):-forLoopT(_id, _,_Encl,_,_,_,_), !.
enclosing(_id, _Encl):-breakT(_id, _,_Encl,_,_), !.
enclosing(_id, _Encl):-importT(_id, _,_Encl), !.
enclosing(_id, _Encl):-whileLoopT(_id, _,_Encl,_,_), !.
enclosing(_id, _Encl):-newArrayT(_id, _,_Encl,_,_,_), !.
enclosing(_id, _Encl):-throwT(_id, _,_Encl,_), !.
enclosing(_id, _Encl):-switchT(_id, _,_Encl,_,_), !.
enclosing(_id, _Encl):-toplevelT(_id, _Encl,_,_), !.
enclosing(_id, _Encl):-assignopT(_id, _,_Encl,_,_,_), !.
enclosing(_id, _Encl):-catchT(_id, _,_Encl,_,_), !.
enclosing(_id, _Encl):-tryT(_id, _,_Encl,_,_,_), !.
enclosing(_id, _Encl):-typeTestT(_id, _,_Encl,_,_), !.
enclosing(_id, _Encl):-doLoopT(_id, _,_Encl,_,_), !.
enclosing(_id, _Encl):-labelT(_id, _,_Encl,_,_), !.
enclosing(_id, _Encl):-continueT(_id, _,_Encl,_,_), !.
enclosing(_id, _Encl):-synchronizedT(_id, _,_Encl,_,_), !.
enclosing(_id, _Encl):-assertT(_id, _,_Encl,_,_), !.
enclosing(_id, _Encl):-precedenceT(_id, _,_Encl,_), !.
enclosing(_id, _Encl):-nopT(_id, _,_Encl), !.

getTerm(_id,packageT(_id,_name)) :-                           packageT(_id,_name).
getTerm(_id,getFieldT(_id,_pid,_encl,_v1,_v2,_v3)) :-         getFieldT(_id,_pid,_encl,_v1,_v2,_v3).
getTerm(_id,selectT(_id,_pid,_encl,_v1,_v2,_v3)) :-           selectT(_id,_pid,_encl,_v1,_v2,_v3).
getTerm(_id,identT(_id,_pid,_encl,_v1,_v2)) :-                identT(_id,_pid,_encl,_v1,_v2).
getTerm(_id,methodDefT(_id,_pid,_v1,_v2,_v3,_v4,_v5)) :-      methodDefT(_id,_pid,_v1,_v2,_v3,_v4,_v5).
getTerm(_id,localDefT(_id,_pid,_encl,_v1,_v2,_v3)) :-         localDefT(_id,_pid,_encl,_v1,_v2,_v3).
getTerm(_id,fieldDefT(_id,_pid,_v1,_v2,_v3)) :-                   fieldDefT(_id,_pid,_v1,_v2,_v3).
getTerm(_id,paramDefT(_id,_pid,_v1,_v2)) :-                   paramDefT(_id,_pid,_v1,_v2).
getTerm(_id,classDefT(_id,_pid,_v1,_v2)) :-                   classDefT(_id,_pid,_v1,_v2).
getTerm(_id,toplevelT(_id,_pid,_v1,_v2)) :-                   toplevelT(_id,_pid,_v1,_v2).
getTerm(_id,blockT(_id,_pid,_encl,_v1)) :-                    blockT(_id,_pid,_encl,_v1).
getTerm(_id,doLoopT(_id,_pid,_encl,_v1,_v2)) :-               doLoopT(_id,_pid,_encl,_v1,_v2).
getTerm(_id,whileLoopT(_id,_pid,_encl,_v1,_v2)) :-            whileLoopT(_id,_pid,_encl,_v1,_v2).
getTerm(_id,forLoopT(_id,_pid,_encl,_v1,_v2,_v3,_v4)) :-      forLoopT(_id,_pid,_encl,_v1,_v2,_v3,_v4).
getTerm(_id,labelT(_id,_pid,_encl,_v1,_v2)) :-             labelT(_id,_pid,_encl,_v1,_v2).
getTerm(_id,switchT(_id,_pid,_encl,_v1,_v2)) :-               switchT(_id,_pid,_encl,_v1,_v2).
getTerm(_id,caseT(_id,_pid,_encl,_v1)) :-                     caseT(_id,_pid,_encl,_v1).
getTerm(_id,synchronizedT(_id,_pid,_encl,_v1,_v2)) :-         synchronizedT(_id,_pid,_encl,_v1,_v2).
getTerm(_id,tryT(_id,_pid,_encl,_v1,_v2,_v3)) :-              tryT(_id,_pid,_encl,_v1,_v2,_v3).
getTerm(_id,catchT(_id,_pid,_encl,_v1,_v2)) :-                catchT(_id,_pid,_encl,_v1,_v2).
getTerm(_id,ifT(_id,_pid,_encl,_v1,_v2,_v3)) :-               ifT(_id,_pid,_encl,_v1,_v2,_v3).
getTerm(_id,conditionalT(_id,_pid,_encl,_v1,_v2,_v3)) :-      conditionalT(_id,_pid,_encl,_v1,_v2,_v3).
getTerm(_id,execT(_id,_pid,_encl,_v1)) :-                     execT(_id,_pid,_encl,_v1).
getTerm(_id,returnT(_id,_pid,_encl,_v1)) :-                   returnT(_id,_pid,_encl,_v1).
getTerm(_id,breakT(_id,_pid,_encl,_v1,_v2)) :-                breakT(_id,_pid,_encl,_v1,_v2).
getTerm(_id,continueT(_id,_pid,_encl,_v1,_v2)) :-             continueT(_id,_pid,_encl,_v1,_v2).
getTerm(_id,throwT(_id,_pid,_encl,_v1)) :-                    throwT(_id,_pid,_encl,_v1).
getTerm(_id,applyT(_id,_pid,_encl,_v1,_v2,_v3,_v4)) :-        applyT(_id,_pid,_encl,_v1,_v2,_v3,_v4).
getTerm(_id,newClassT(_id,_pid,_encl,_v1,_v2,_v3,_v4,_v5)) :- newClassT(_id,_pid,_encl,_v1,_v2,_v3,_v4,_v5).
getTerm(_id,newArrayT(_id,_pid,_encl,_v1,_v2,_v3)) :-         newArrayT(_id,_pid,_encl,_v1,_v2,_v3).
getTerm(_id,assignT(_id,_pid,_encl,_v1,_v2)) :-               assignT(_id,_pid,_encl,_v1,_v2).
getTerm(_id,assignopT(_id,_pid,_encl,_v1,_v2,_v3)) :-         assignopT(_id,_pid,_encl,_v1,_v2,_v3).
getTerm(_id,operationT(_id,_pid,_encl,_v1,_v2,_v3)) :-        operationT(_id,_pid,_encl,_v1,_v2,_v3).
getTerm(_id,typeCastT(_id,_pid,_encl,_v1,_v2)) :-             typeCastT(_id,_pid,_encl,_v1,_v2).
getTerm(_id,typeTestT(_id,_pid,_encl,_v1,_v2)) :-             typeTestT(_id,_pid,_encl,_v1,_v2).
getTerm(_id,indexedT(_id,_pid,_encl,_v1,_v2)) :-              indexedT(_id,_pid,_encl,_v1,_v2).
getTerm(_id,literalT(_id,_pid,_encl,_v1,_v2)) :-              literalT(_id,_pid,_encl,_v1,_v2).
getTerm(_id,assertT(_id,_pid,_encl,_v1,_v2)) :-               assertT(_id,_pid,_encl,_v1,_v2).
getTerm(_id,importT(_id,_pid,_v1)) :-                         importT(_id,_pid,_v1).
getTerm(_id,precedenceT(_id,_pid,_encl,_v1)) :-               precedenceT(_id,_pid,_encl,_v1).
getTerm(_id,nopT(_id,_pid,_encl)) :-                          nopT(_id,_pid,_encl).

/*##############################################################################
aus /st.java/pl/org/cs3/Java/astSpec/javaFactbase.pl
################################################################################*/

%temporary hack: -- TR 03.11.2005

tree(_id, null, packageT):-packageT(_id,_).
tree(_id, _pid, localDefT):-localDefT(_id, _pid,_,_,_,_).
tree(_id, _pid, paramDefT):-paramDefT(_id, _pid,_,_).
tree(_id, _pid, fieldDefT):-fieldDefT(_id, _pid,_,_,_).
tree(_id, _pid, methodDefT):-methodDefT(_id, _pid,_,_,_,_,_).
tree(_id, _pid, classDefT):-classDefT(_id, _pid,_,_).
tree(_id, _pid, getFieldT):-getFieldT(_id, _pid,_,_,_,_).
tree(_id, _pid, identT):-identT(_id, _pid,_,_,_).
tree(_id, _pid, literalT):-literalT(_id, _pid,_,_,_).
tree(_id, _pid, execT):-execT(_id, _pid,_,_).
tree(_id, _pid, operationT):- operationT(_id, _pid,_,_,_,_).
tree(_id, _pid, applyT):-applyT(_id, _pid,_,_,_,_,_).
tree(_id, _pid, blockT):-blockT(_id, _pid,_,_).
tree(_id, _pid, selectT):-selectT(_id, _pid,_,_,_,_).
tree(_id, _pid, conditionalT):-conditionalT(_id, _pid,_,_,_,_).
tree(_id, _pid, ifT):-ifT(_id, _pid,_,_,_,_).
tree(_id, _pid, assignT):-assignT(_id, _pid,_,_,_).
tree(_id, _pid, importT):-importT(_id, _pid,_).
tree(_id, _pid, newArrayT):-newArrayT(_id, _pid,_,_,_,_).
tree(_id, _pid, toplevelT):-toplevelT(_id, _pid,_,_).
tree(_id, _pid, newClassT):-newClassT(_id, _pid,_,_,_,_,_,_).
tree(_id, _pid, returnT):-returnT(_id, _pid,_,_).
tree(_id, _pid, switchT):-switchT(_id, _pid,_,_,_).
tree(_id, _pid, typeCastT):-typeCastT(_id, _pid,_,_,_).
tree(_id, _pid, tryT):-tryT(_id, _pid,_,_,_,_).
tree(_id, _pid, whileLoopT):-whileLoopT(_id, _pid,_,_,_).
tree(_id, _pid, continueT):-continueT(_id, _pid,_,_,_).
tree(_id, _pid, doLoopT):-doLoopT(_id, _pid,_,_,_).
tree(_id, _pid, indexedT):-indexedT(_id, _pid,_,_,_).
tree(_id, _pid, throwT):-throwT(_id, _pid,_,_).
tree(_id, _pid, forLoopT):-forLoopT(_id, _pid,_,_,_,_,_).
tree(_id, _pid, synchronizedT):-synchronizedT(_id, _pid,_,_,_).
tree(_id, _pid, labelT):-labelT(_id, _pid,_,_,_).
tree(_id, _pid, breakT):-breakT(_id, _pid,_,_,_).
tree(_id, _pid, typeTestT):-typeTestT(_id, _pid,_,_,_).
tree(_id, _pid, assignopT):-assignopT(_id, _pid,_,_,_,_).
tree(_id, _pid, caseT):-caseT(_id, _pid,_,_).
tree(_id, _pid, catchT):-catchT(_id, _pid,_,_,_).
tree(_id, _pid, assertT):-assertT(_id, _pid,_,_,_).
tree(_id, _pid, precedenceT):-precedenceT(_id, _pid,_,_).
tree(_id, _pid, nopT):-nopT(_id, _pid,_).

/*##############################################################################
  treechecks.pl
  ##############################################################################*/

checkConstraints(ID,ErrorHandler):-
    getTerm('Java',ID,Term),
    Term =.. [Functor|[ID|Args]],
    tree_constraints(Functor,Constraints),
    checkConstraints(Term,Constraints,Args,2,ErrorHandler).

checkConstraints(_,[],[],_,_).
checkConstraints(Term,[Constraints | CRest],[Arg|ARest],Pos,ErrorHandler):-
    (
          (checkConstraintList(Constraints,Arg),!);                %�berpr�fe Constraint, wenn o.k. -> Cut
          printCheckError(Term,Constraints,Arg,Pos,ErrorHandler)   %sonst Fehlermeldung
        ),
        plus(Pos,1,Inc),
    checkConstraints(Term,CRest,ARest,Inc,ErrorHandler).           %�berpr�fe restliche Argumente


printCheckError(Term,Constraints,Arg,Pos,ErrorHandler):-
    term_to_atom(Term,TermAtom),
    term_to_atom(Constraints,ConstraintsAtom),
    term_to_atom(Arg,ArgAtom),
    sformat(Msg,'ERROR in term: ~a, argument ~a (\'~a\') does not fullfill constraints:~n  ~a~n',
          [TermAtom,Pos,ArgAtom,ConstraintsAtom]),
         MsgTerm =.. [ErrorHandler,Msg],
         call(MsgTerm),
         flush_output.


%Nun folgen viele Definitionen f�r checkConstraintList..

%Behandlung f�r den Fall, da� das Argument aus einer Liste besteht
%-> verzweige weiter in Einzelbehandlungen..
checkConstraintList(_,[]):-!.
checkConstraintList(Constraints,[H|T]):-
        checkConstraintList(Constraints,H),
        checkConstraintList(Constraints,T).



/**
 * checks if the type of arg is a member of the Constraints list:
 * e.g.: identT(Arg,...), checkConstraintList([identT],Arg)
 * (checks if functor is a member of the list Constraints )
 */
checkConstraintList(Constraints,Arg):-
    getTerm('Java',Arg, Term),
    functor(Term,PLASTFact, _),
    member(PLASTFact,Constraints),
    tree(_,_,PLASTFact),
    !.

/**
 * checks if the type of arg is a member of the Constraints list:
 * e.g.: identT(Arg,...), checkConstraintList([expressionType],Arg)
 */
checkConstraintList(Constraints,Arg):-
    getTerm('Java',Arg, Term),
    functor(Term,PLASTFact, _),
    member(Constraint,Constraints),
    not(ast_node_signature('Java',Constraint,_)/*treeSignature(Constraint,_)*/),
%    term_to_atom(Arg,Atom),
%    format('check2: ~a,~a~n',[Constraint,Atom]),
    Predicate =.. [Constraint, PLASTFact],
    call(Predicate),
    !.

/**
 * checks if the type of arg is a member of the Constraints list:
 * e.g.: identT(Arg,...), checkConstraintList([atomType],'Name')
 */
checkConstraintList(Constraints,Arg):-
    member(Constraint,Constraints),
    not(ast_node_signature('Java',Constraint,_)/*treeSignature(Constraint,_)*/),
%    term_to_atom(Arg,Atom),
%    format('check3: ~a,~a~n',[Constraint,Atom]),
    Predicate =.. [Constraint, Arg],
    call(Predicate),
    !.
    
/*##############################################################################
clone.pl
################################################################################*/

cloneTree(_id, _newTree) :-
    tree(_id, _parent, _),
    enclosing(_id, _encl),
    cloneTree(_id,_parent,_encl,_newTree).

cloneTree(_id, _parent, _encl, _newTree) :-
    createCloneIDs(_id,_newTree),
    clone(_id, _parent, _encl, _newTree),
    retractall(cloned(_, _)).
    
/**
  clone(+id, +parent,+encl,-newId)

Creates a deep copy of the tree id and
binds it to newId.


Auxiliary predicate for cloneTree.
*/
clone('null', _, _, 'null').
clone([], _, _, []).

clone([_h | _t], _parent, _encl, [_H | _T]) :-
    clone(_h, _parent, _encl, _H),
    clone(_t, _parent, _encl, _T).

clone(_id, _parent, _encl, _new) :-
    getFieldT(_id,_,_,_selected,_name,_sym),!,
    cloned(_id, _new),
    getCloneIfAvail(_sym, _newSym),
    clone(_selected, _new, _encl, _newSelected),
    add(getFieldT(_new,_parent,_encl,_newSelected,_name,_newSym)).

clone(_id, _parent, _encl, _new) :-
    selectT(_id,_,_,_name,_selected,_sym),!,
    cloned(_id, _new),
    getCloneIfAvail(_sym, _newSym),
    clone(_selected, _new, _encl, _newSelected),
    add(selectT(_new,_parent,_encl,_name,_newSelected,_newSym)).


clone(_id, _parent, _encl, _new) :-
    identT(_id,_,_,_name,_sym),!,
    cloned(_id, _new),
    getCloneIfAvail(_sym, _newSym),
    add(identT(_new,_parent,_encl,_name,_newSym)).

clone(_id, _parent, _encl, _new) :-
    literalT(_id,_,_,_type, _value),!,
    cloned(_id, _new),
    getCloneIfAvail(_type, _newType),
    add(literalT(_new, _parent, _encl, _newType, _value)).

clone(_id, _parent, _encl, _new) :-
    assertT(_id,_,_,_test, _msg),!,
    cloned(_id, _new),
    clone(_test, _new, _encl, _newTest),
    clone(_msg, _new, _encl, _newMsg),
    add(assertT(_new, _parent, _encl, _newTest, _newMsg)).

clone(_id, _parent, _encl, _new) :-
    blockT(_id, _, _, _subtrees),
    !,
    cloned(_id, _new),
    clone(_subtrees, _new, _encl, _newSubtrees),
    add(blockT(_new, _parent, _encl, _newSubtrees)).

clone(_id, _parent, _encl, _new) :-
    methodDefT(_id,_,_name,_params,_ret,_thrown,_body),
    !,
    cloned(_id, _new),
    cloneModifier(_id, _new),
    !,
    clone(_params, _new, _new, _newParams),
    clone(_body, _new, _new, _newBody),
    (add_to_class(_parent, _new);true),
    add(methodDefT(_new, _parent, _name, _newParams, _ret, _thrown, _newBody)).

clone(_id, _parent, _encl, _new) :-
    execT(_id,_,_,_expr),!,
    cloned(_id, _new),
    clone(_expr, _new, _encl, _newExpr),
    add(execT(_new,_parent,_encl,_newExpr)).

clone(_id, _parent, _encl, _new) :-
    localDefT(_id,_,_,_type,_name,_init),
    !,
    cloned(_id, _new),
    cloneModifier(_id, _new),
    getCloneIfAvail(_type, _newType),
    clone(_init, _new, _encl, _newInit),
    add(localDefT(_new,_parent,_encl,_newType,_name,_newInit)).

clone(_id, _parent, _encl, _new) :-
    fieldDefT(_id,_,_type,_name,_init),
    !,
    cloned(_id, _new),
    cloneModifier(_id, _new),
    getCloneIfAvail(_type, _newType),
    clone(_init, _new, _id, _newInit),
    (add_to_class(_parent, _new);true),
    add(fieldDefT(_new,_parent,_newType,_name,_newInit)).

clone(_id, _parent, _encl, _new) :-
    paramDefT(_id,_,_type,_name),
    !,
    cloned(_id, _new),
    cloneModifier(_id, _new),
    getCloneIfAvail(_type, _newType),
    add(paramDefT(_new,_parent,_newType,_name)).

clone(_id, _parent, _encl, _new) :-
    doLoopT(_id,_,_,_cond,_body),!,
    cloned(_id, _new),
    clone(_cond, _new, _encl, _newCond),
    clone(_body, _new, _encl, _newBody),
    add(doLoopT(_new,_parent,_encl,_newCond,_newBody)).

clone(_id, _parent, _encl, _new) :-
    whileLoopT(_id,_,_,_cond,_body),!,
    cloned(_id, _new),
    clone(_cond, _new, _encl, _newCond),
    clone(_body, _new, _encl, _newBody),
    add(whileLoopT(_new,_parent,_encl,_newCond,_newBody)).

% body (cond | []) (inits | []) (steps | [])
clone(_id, _parent, _encl, _new) :-
    forLoopT(_id,_,_,_initList,_cond,_stepList,_body),!,
    cloned(_id, _new),
    clone(_initList, _new, _encl, _newInitList),
    clone(_stepList, _new, _encl, _newStepList),
    clone(_cond, _new, _encl, _newCond),

    clone(_body, _new, _encl, _newBody),
    add(forLoopT(_new,_parent,_encl,_newInitList,_newCond,_newStepList,_newBody)).

clone(_id, _parent, _encl, _new) :-
    labelT(_id,_,_,_body,_label),!,
    cloned(_id, _new),
    clone(_body, _new, _encl, _newBoy),
    add(labelT(_new,_parent,_encl,_newBody,_label)).

clone(_id, _parent, _encl, _new) :-
    switchT(_id,_,_,_selector,_cases),!,
    cloned(_id, _new),
    clone(_selector, _new, _encl, _newSelector),
    clone(_cases, _new, _encl, _newCases),
    add(switchT(_new,_parent,_encl,_newSelector,_newCases)).

clone(_id, _parent, _encl, _new) :-
    caseT(_id,_,_,_pat),!,
    cloned(_id, _new),
    clone(_pat, _new, _encl, _newPat),
    add(caseT(_new,_parent,_encl,_newPat)).

clone(_id, _parent, _encl, _new) :-
    synchronizedT(_id,_,_,_lock,_body),!,
    cloned(_id, _new),
    clone(_lock, _new, _encl, _newLock),
    clone(_body, _new, _encl, _newBody),
    add(synchronizedT(_new,_parent,_encl,_newLock, _newBody)).

clone(_id, _parent, _encl, _new) :-
    tryT(_id,_,_,_body,_catch,_final),
    !,
    cloned(_id, _new),
    clone(_body, _new, _encl, _newBody),
    clone(_catch, _new, _encl, _newCatch),
    clone(_final, _new, _encl, _newFinal),
    add(tryT(_new,_parent,_encl,_newBody, _newCatch, _newFinal)).

clone(_id, _parent, _encl, _new) :-
    catchT(_id,_,_,_param,_body),!,
    cloned(_id, _new),
    clone(_body, _new, _encl, _newBody),
    clone(_param, _new, _encl, _newParam),
    add(catchT(_new,_parent,_encl, _newParam, _newBody)).

clone(_id, _parent, _encl, _new) :-
    ifT(_id,_,_,_cond,_then,_else),
    !,
    cloned(_id, _new),
    clone(_cond, _new, _encl, _newBody),
    clone(_then, _new, _encl, _newThen),
    clone(_else, _new, _encl, _newElse),
    add(ifT(_new,_parent,_encl,_newBody,_newThen,_newElse)).

clone(_id, _parent, _encl, _new) :-
    conditionalT(_id,_,_,_cond,_then,_else),!,
    cloned(_id, _new),
    clone(_cond, _new, _encl, _newBody),
    clone(_then, _new, _encl, _newThen),
    clone(_else, _new, _encl, _newElse),
    add(conditionalT(_new,_parent,_encl,_newBody,_newThen,_newElse)).


clone(_id, _parent, _encl, _new) :-
    returnT(_id,_,_,_expr),!,
    cloned(_id, _new),
    clone(_expr, _new, _encl, _newExpr),
    add(returnT(_new,_parent,_encl,_newExpr)).

clone(_id, _parent, _encl, _new) :-
    breakT(_id,_,_,_label,_target),!,
    cloned(_id, _new),
    getCloneIfAvail(_target, _newTarget),
    add(breakT(_new,_parent,_encl,_label, _newTarget)).

clone(_id, _parent, _encl, _new) :-
    continueT(_id,_,_,_target,_),!,
    cloned(_id, _new),
    getCloneIfAvail(_target,_newTarget),
    add(continueT(_new,_parent,_encl,_label, _newTarget)).

clone(_id, _parent, _encl, _new) :-
    throwT(_id,_,_,_expr),!,
    cloned(_id, _new),
    clone(_expr, _new, _encl, _newExpr),
    add(throwT(_new,_parent,_encl,_newExpr)).

clone(_id, _parent, _encl, _new) :-
    applyT(_id,_,_,_recv,_name,_args,_method),!,
    cloned(_id, _new),
    clone(_recv, _new, _encl, _newRecv),
    clone(_args, _new, _encl, _newArgs),
    getCloneIfAvail(_method,_newMethod),
    add(applyT(_new,_parent,_encl,_newRecv,_name,_newArgs,_newMethod)).


clone(_id, _parent, _encl, _new) :-
    newClassT(_id,_,_,_constr,_args,_clazz,_def,_enclClazz),
    !,
    cloned(_id, _new),
    clone(_args, _new, _encl, _newArgs),
%    getCloneIfAvail(_clazz, _newClazz),
    getCloneIfAvail(_constr,_newConstr),
    clone(_def, _new, _encl, _newDef),
    clone(_clazz, _new, _encl, _newClazz),
    clone(_enclClazz, _new, _encl, _newEnclClazz),
%    getClonedIfAvail(_enclClazz, _newEnclClazz),
    add(newClassT(_new,_parent,_encl,_newConstr, _newArgs,_newClazz, _newDef, _newEnclClazz)). %FIXME

clone(_id, _parent, _encl, _new) :-
    newArrayT(_id,_,_,_dims,_elems,_type),
    !,
    cloned(_id, _new),
    getCloneIfAvail(_type, _newType),
    clone(_dims, _new, _encl, _newDims),
    clone(_elems, _new, _encl, _newElems),
    add(newArrayT(_new,_parent,_encl,_newDims,_newElems, _newType)).

clone(_id, _parent, _encl, _new) :-
    assignT(_id,_,_,_lhs,_rhs),!,
    cloned(_id, _new),
    clone(_lhs, _new, _encl, _newLhs),
    clone(_rhs, _new, _encl, _newRhs),
    add(assignT(_new,_parent,_encl,_newLhs,_newRhs)).

clone(_id, _parent, _encl, _new) :-
    assignopT(_id,_,_,_lhs,_opname,_rhs),!,
    cloned(_id, _new),
    clone(_lhs, _new, _encl, _newLhs),
    clone(_rhs, _new, _encl, _newRhs),
    add(assignopT(_new,_parent,_encl,_newLhs,_opname,_newRhs)).

clone(_id, _parent, _encl, _new) :-
    operationT(_id,_,_,_args,_opname,_pos),!,
    cloned(_id, _new),
    clone(_args, _new, _encl, _newArgs),
    add(operationT(_new,_parent,_encl,_newArgs,_opname,_pos)).

clone(_id, _parent, _encl, _new) :-
    typeCastT(_id,_,_,_clazz,_expr),!,
    cloned(_id, _new),
    clone(_expr, _new, _encl, _newExpr),
    getCloneIfAvail(_clazz, _newClazz),
    add(typeCastT(_new,_parent,_encl,_newClazz, _newExpr)).

clone(_id, _parent, _encl, _new) :-
    typeTestT(_id,_,_,_,_expr),!,
    cloned(_id, _new),
    clone(_expr, _new, _encl, _newExpr),
    getCloneIfAvail(_clazz, _newClazz),
    add(typeTestT(_new,_parent,_encl,_newClazz, _newExpr)).

clone(_id, _parent, _encl, _new) :-
    indexedT(_id,_,_,_index, _indexed),!,
    cloned(_id, _new),
    clone(_index, _new, _encl, _newIndex),
    clone(_indexed, _new, _encl, _newIndexed),
    add(indexedT(_new,_parent,_encl,_newIndex, _newIndexed)).


clone(_id, _parent, _encl, _new) :-
    importT(_id,_,_name),!,
    cloned(_id, _new),
    add(importT(_new,_parent,_name)).

clone(_id, _parent, _encl, _new) :-
    packageT(_id,_name),
    !,
    findall(_sub, toplevelT(_sub, _id, _,_), _subtrees),
    cloned(_id, _new),
    add(package(_new, _name)),
    clone(_subtrees, _new, _new, _toplevels).

clone(_id, _parent, _encl, _new) :-
    toplevelT(_id,_,_filename,_subtrees),
    cloned(_id, _new),
    clone(_subtrees, _new, _encl, _newSubtrees),
    add(toplevelT(_id, _parent, _filename, _newSubtrees)).

clone(_id, _parent, _encl, _new) :-
    classDefT(_id,Package,_name,Subtrees),!,
    cloned(_id, _new),
    cloneModifier(_id, _new),
    cloneExtends(_id,_new),
    cloneImplements(_id,_new),
    !,
        (
                add_to_class(_parent, _new)      % member class
                ;
                true
        ),(
        toplevelT(Toplevel,Package,_,Members), % toplevel class
        member(_id, Members),
        addToToplevel(Toplevel, _new)
        ;
        true
    ),
    clone(Subtrees, _new, _new, NewSubtrees),
    add(classDefT(_new, _parent, _name, NewSubtrees)),
    add_to_class(_new, NewSubtrees).

clone(_id, _parent, _encl, _new) :-
    nopT(_id,_,_),!,
    cloned(_id, _new),
    clone(_expr, _new, _encl, _new),
    add(nopT(_new,_parent,_encl)).

clone(_id, _parent, _encl, _new) :-
    precedenceT(_id,_,_,_expr),!,
    cloned(_id, _new),
    clone(_expr, _new, _encl, _newExpr),
    add(precedenceT(_new,_parent,_encl,_newExpr)).

clone(_id, _, _, _) :-
    tree(_id, _p, _name),
    !,
    format('ERROR: clone: ~a, ~a, ~a~n', [_id, _p, _name]).

clone(_id, _, _, 'null') :-
    not(tree(_id, _, _)),!.
