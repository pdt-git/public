%TODO: remove after refactoring library path (and modules)
:- ['org/cs3/java/writer/main.pl'].
:- ['org/cs3/java/astSpec/main.pl'].
:- ['org/cs3/java/ctSpec/main.pl'].
