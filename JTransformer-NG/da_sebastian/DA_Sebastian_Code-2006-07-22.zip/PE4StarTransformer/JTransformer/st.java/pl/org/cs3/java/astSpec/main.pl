:- ['javaFactbase.pl'].
:- ['javaSyntax.pl'].

