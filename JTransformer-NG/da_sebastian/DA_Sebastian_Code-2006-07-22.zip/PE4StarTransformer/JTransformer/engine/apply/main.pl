:- ['garbage_collect'].
:- ['transaction'].
:- ['ct_apply'].
