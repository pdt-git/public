% Author: Sebastian
% Date: 06.03.2006

/*
Umbauvorgehensweise:
1. Welches Pr�dikat soll umgebaut werden? Verallgemeinerung.
2. Funktionstest1: Gibt das ver�nderte Pr�dikat in "StarTransformer" das gleiche
   Resultat wie die entsprechende Version in "JTransformer"?
3. Auswertung des verallgemeinerten Pr�dikats
4. Funktionstest2: Gibt die ausgewertete Version das gleiche Ergebnis wie die
   allgemeine Version?
*/

/*
Zu Funktionstest1:
  Wie kann ein Vergleich statuiert werden, der zu 100% verl��lich ist?
  Es gibt in Hinblick auf das Ergebnis verschiedene Pr�dikats-Typen:
      - Pr�dikate, bei denen man alle L�sungen aufz�hlen kann
      - Pr�dikate, bei denen man alle L�sungen NICHT aufz�hlen kann,
        weil sie etwas betimmtes tun.
  Wof�r kann regressionTest verwendet werden?

  Repr�sentatives Beispiel:
    tree_modifications.pl:set_encl_method/3
    - ver�ndert von einem durch die ID ausgew�hlten AST-Knoten das enclosing-Argument
    - es lassen sich keine Ergebnisse aufz�hlen. Vielmehr handelt es sich um eine
      die Datenbasis modifizierende Funktionalit�t.
    L�sungsidee zum Test:
      - f�r jedes AST-Element mit enclosing k�nnte das entsprechende Argument ge�ndert werden
        -> also m��te die Funktionalit�t f�r alle AST-Elemente mit encl-Argument getestet werden
        
    1. Test-AST-Fakten generieren
    2. urspr�ngliches Pr�dikat darauf ansetzen; f�r jede ID

*/

/* Test der Zugriffsschicht
   ------------------------
   
   Gegen�berstellung der Pr�dikate:
     - treeSignature(Func,Arity)   <-> ast_node_signature('Java',Func,Arity)
     - attribSignature(Func,Arity) <-> ast_node_signature('JavaAttributes',Func,Arity)
     - getTerm(ID,Term)            <-> get_ast_node_term('Java', ID, Term)
     - enclosing(ID,Encl)          <-> get_ast_node_enclosing('Java', ID, Encl)
     - tree(ID,ParentID,_)         <-> get_ast_node_parent('Java',ID,ParentID)
     - tree(ID,_,Label)            <-> get_ast_node_label('Java',ID,Label)
                                       
 */
 

vergleich1 :-
    %treeSignature
    chk1(treeSignature(X,Y),ast_node_signature('Java',X,Y)),
    %attribSignature
    chk1(attribSignature(X,Y),ast_node_signature('JavaAttributes',X,Y)),
    %getTerm
    (genTestPEFsEnclPar,chk1((idsToCheck(ID),getTerm(ID,Term)),(idsToCheck(ID),get_ast_node_term('Java',ID,Term))),cleanAll),
    %tree(+,_,_)
    (genTestPEFsEnclPar,chk1((idsToCheck(ID),tree(ID,_,_)),(idsToCheck(ID),get_ast_node_term('Java',ID,_))),cleanAll),
    %enclosing(ID,Enclosing)     <-> get_ast_node_enclosing('Java',ID,Enclosing)
    (genTestPEFsEnclPar,chk1((idsToCheck(ID),enclosing(ID,Encl)),(idsToCheck(ID),get_ast_node_enclosing('Java',ID,Encl))),cleanAll),
    %tree(ID,Parent,_)           <-> get_ast_node_parent('Java',ID,Parent)
    (genTestPEFsEnclPar,chk1((idsToCheck(ID),tree(ID,Parent,_)),(idsToCheck(ID),get_ast_node_parent('Java',ID,Parent))),cleanAll),
    %tree(ID,_,Label)            <-> get_ast_node_label('Java',ID,Label)
    (genTestPEFsEnclPar,chk1((idsToCheck(ID),tree(ID,_,Label)),(idsToCheck(ID),get_ast_node_label('Java',ID,Label))),cleanAll),
     compare('set_encl_method'),
     compare('set_parent'),
     test('addToMethodArgs'),
     test('test_addToToplevel'),
     test('addToBlock'),
     test('add_to_class'),
     test('removeFromMethodArgs'),
     test('removeFromBlock').

    %tree_constraints(Functor,Constraints) <-> ast_node_def(Lang,Functor,ArgList), extractConstraints(ArgList,Constraints),
    %chk1(tree_constraints(Functor,Constraints),(ast_node_def('Java',Functor,ArgList), extractConstraints(ArgList,Constraints))).
    %Die tree_constraints unterscheiden sich!!

/*************************************************************************
HILFSPR�DIKATE ZUM VERGLEICH ZWEIER L�SUNGEN
**************************************************************************/

/* von G�nter:
 * Quick comparison of two versions of a predicate
 * that are supposed to give the same result. Call
 * regressionTest/2 and look for ' --  fail ' strings in
 * the output in order to detect mismatches of the results.
 *
 * Assumption: Defensive programming, that is creation of a
 * new version of a predicate instead of overwriting the old
 * version. You can still overwrite the old version after
 * successful run of your regression test.
 *
 * Example:
 * regressionTest( newTreeSignature(F, Arity), treeSignature(F, Arity) ).
 */

regressionTest(Old,New) :- equiv( Old, New ).
regressionTest(_ld,_ew) :- nl, fail.
regressionTest(Old,New) :- equiv( New, Old ).
regressionTest(_ld,_ew) :- nl.

equiv(P,Q) :-
   call(P),
   ( (write(P), write(' -- '))
   ; (write(' fail '), nl, fail)
   ),
   call(Q),
   write(Q),
   fail.

regressionTest2(Old,New) :- flag(errorCount,0,0),equiv2( Old, New ).
regressionTest2(_ld,_ew) :- nl, fail.
regressionTest2(Old,New) :- equiv2( New, Old ).
regressionTest2(_ld,_ew) :- nl, flag(errorCount,N,0), write('Fehleranzahl: '), write(N).

equiv2(P,Q) :-
   call(P),
   ( (write(P), write(' -- '))
   ; (flag(errorCount,N,N+1),write(' fail '), nl, fail)
   ),
   call(Q),
   write(Q),
   fail.

/*
 * solNumber(+Pred,-Num)
 * Ermittelt die Anzahl der L�sungen, die das Pr�dikat "Pred" liefert.
 */
solNumber(Pred,Num) :-
    findall(_,Pred,L),
    length(L,Num).

runSolNum(Pred,Num) :-
    flag(lanzahl,_,0),      %initialize flag
    solNum(Pred),
    flag(lanzahl,Num,0).

solNum(Pred) :-
    call(Pred),
    flag(lanzahl,Old,Old+1),
    fail.
solNum(Pred).



/*
 * writeSolNum(+Pred)
 * Gibt die Anzahl der L�sungen des Pr�dikats "Pred" auf dem Bildschirm aus
 */
writeSolNum(Pred) :-
    solNumber(Pred,Num),
    write('Anzahl der L�sungen f�r Pr�dikat '),
    write(Pred),write(': '),write(Num),nl.


chk1(P1,P2) :-
    write('Testpr�dikate: '),write(P1),write(' -- '),write(P2),nl,
    %format('~nTestpr�dikate: ~a -- ~a',[P1,P2]),
    chk(P1,P2),
    chk(P2,P1).
%es m�ssen zum Test die gleichen Variablen benutzt werden!
chk(P1,P2) :-
    flag(p1count,0,0),
    flag(p2count,0,0),
    call(P1),
    flag(p1count,N,N+1),
    call(P2),
    flag(p2count,M,M+1),
    fail.
chk(_,_) :-
    flag(p1count,N,0),
    %write(N),nl,
    flag(p2count,M,0),
    %write(M),nl,
    B is N - M,
    %write('\tFehlschl�ge: '),write(B),nl.
    format('#Differenzen: ~d~n',B).


test_zgs :-
    regressionTest(treeSignature(X,Y),ast_node_signature('Java',X,Y)).


/*##############################################################################
PEF-related stuff for testing purposes
################################################################################*/

:- dynamic(idsToCheck/1). %ids, which have been created for testing
:- dynamic(testData/2).

/* listpefs/0
     lists all asserted pefs..
*/
listpefs :-
    ast_node_term('Java',Pef),
    Pef,
    write(Pef),nl,
    fail.
listpefs :-
    ast_node_term('JavaAttributes',JFunc),
    JFunc,
    write(JFunc),nl,
    fail.
listpefs.

/* cleanAll/0
     retracts PEF-data and internal dynamic test-predicates
*/
cleanAll :-
    findall(X,idsToCheck(X),L),
    reccheckTrees(L),
    retractall(idsToCheck(_)),
    retractall(lastID(_)),
    assert(lastID(10000)).


/* genTestPEFs/0
 *   generates testdata for 'Java'.
 *   Every possible Ast-Node-Term is asserted with well-defined id. All
 *   remaining arguments are set to 0.
 *   example: methodDefT(10003, 0, 0, 0, 0, 0, 0)
 */
genTestPEFs :-
    cleanAll,
    ast_node_term('Java',PEF),
    new_id(NewID),                              %generiere neue ID
    arg(1,PEF,NewID),                           %Setze ID von PEF
    PEF =.. PEFList,
    dummyArgs(PEFList),                         %Alle uninstanziierten Argumente werden auf 0 gesetzt
    PEFwithArgs =.. PEFList,
    assert(PEFwithArgs),
    assert(idsToCheck(NewID)),
    fail.

genTestPEFs.

/* genTestPEFsEnclPar/0
 *   generates testdata for 'Java'.
 *   Every possible Ast-Node-Term is asserted with well-defined id. Parent
 *   and enclosing are set to be unique. All remaining arguments are set to 0.
 *   example: whileLoopT(10041, whileLoopTparent, whileLoopTencl, 0, 0)
 */
genTestPEFsEnclPar :-
    cleanAll,
    ast_node_term('Java',PEF),
    new_id(NewID),                              %generiere neue ID
    arg(1,PEF,NewID),                           %Setze ID von PEF
    PEF =.. [Functor|ArgList],
    ast_node_def('Java',Functor,ArgDesc),
    dummyArgsEnclPar(Functor,ArgList,ArgDesc),         %Alle uninstanziierten Argumente werden auf 0 gesetzt
    PEFwithArgs =.. [Functor|ArgList],
    assert(PEFwithArgs),
    assert(idsToCheck(NewID)),
    fail.

genTestPEFsEnclPar.

genTestPEFsAll :-
    cleanAll,
    ast_node_term('Java',PEF),
    new_id(NewID),                              %generiere neue ID
    arg(1,PEF,NewID),                           %Setze ID von PEF
    PEF =.. [Functor|ArgList],
    ast_node_def('Java',Functor,ArgDesc),
    dummyArgsAll(Functor,ArgList,ArgDesc),         %Alle uninstanziierten Argumente werden auf 0 gesetzt
    PEFwithArgs =.. [Functor|ArgList],
    assert(PEFwithArgs),
    assert(pe:PEFwithArgs),
    assert(idsToCheck(NewID)),
    fail.

genTestPEFsAll.


%fill uninstantiated arguments with '0'
dummyArgs([]).
dummyArgs([H|T]) :-
    nonvar(H),
    dummyArgs(T), !.
dummyArgs([H|T]) :-
    var(H),
    H = 0,
    dummyArgs(T), !.
    
%dummyArgsEnclPar(Functor,ArgList,ArgDescribtion,NewArgList)
dummyArgsEnclPar(_,[],_).
dummyArgsEnclPar(Functor,[A|T1],[_|T2]) :-
    nonvar(A),
    dummyArgsEnclPar(Functor,T1,T2),!.
dummyArgsEnclPar(Functor,[A|T1],[ast_arg(parent,_,_,_)|T2]) :-
    var(A),
    concat(Functor,'parent',A),
    dummyArgsEnclPar(Functor,T1,T2),!.
dummyArgsEnclPar(Functor,[A|T1],[ast_arg(encl,_,_,_)|T2]) :-
    var(A),
    concat(Functor,'encl',A),
    dummyArgsEnclPar(Functor,T1,T2),!.
dummyArgsEnclPar(Functor,[A|T1],[_|T2]) :-
    var(A), A=0,
    dummyArgsEnclPar(Functor,T1,T2),!.
    
%dummyArgsEnclPar(Functor,ArgList,ArgDescribtion,NewArgList)
dummyArgsAll(_,[],_).
dummyArgsAll(Functor,[A|T1],[_|T2]) :-
    nonvar(A),
    dummyArgsAll(Functor,T1,T2),!.
dummyArgsAll(Functor,[A|T1],[ast_arg(Name,_,_,_)|T2]) :-
    var(A),
    concat(Functor,Name,A),
    dummyArgsAll(Functor,T1,T2),!.


/*##############################################################################
################################################################################*/


    


reccheckTrees([]).
reccheckTrees([H|T]) :-
    retractTree2(H),
    reccheckTrees(T).
    
retractTree2(_id) :-
    %ast_node_term(Lang,NodeTerm),
    %arg(1,NodeTerm,_id),
    %NodeTerm,
    %!,
    get_ast_node_term('Java',_id,NodeTerm),
    retract(NodeTerm),
    retract(pe:NodeTerm).
retractTree2(_).



/* testPred(+Pred,+ArgNr)
 *   Wendet das Pr�dikat Pred an. Speziell f�r Pr�dikate, die VER�NDERUNGEN an
 *   der AST-Datenbasis vornehmen. Die Ergebnisse werden in testData protokolliert
 *   und k�nnen anschlie�end miteinander verglichen werden.
 *   ArgNr gibt an, an welcher Stelle die ID stehen mu�
 */
testPred(Pred,ArgNr) :-
    idsToCheck(ID),
      arg(ArgNr,Pred,ID),
      Pred,
    fail.
    
testPred(Pred,_) :-
    idsToCheck(ID),
      ast_node_term('Java',PEF),
      arg(1,PEF,ID),
      PEF,
    assert(testData(Pred,PEF)),
    fail.
    
testPred(_,_).

/* set_enclosing TEST
   ACHTUNG!!!
     - paramDefT wird von der neuen Version nicht erfasst, weil kein encl-Argument vorhanden ist ?!
       hard-coded paramDefT/4, aber in JavaSyntax.pl:paramDefT/5
       kein Hack in ast_node_signature (-> hinzugef�gt)
     - Exception-Handling mu� zum Test deaktiviert werden
   TODO 26.5.05: 1. Den Test so erweitern, da� auch Fehlschl�ge erlaubt sind und
                    in testData/2 eingetragen werden
                 2. Altes durch neues Pr�dikat ersetzen. Test mit jt-Modul
*/

/*##############################################################################
 T E S T S
 ###############################################################################*/

test('addToMethodArgs') :-
    assert(methodDefT(9999,2,3,[4],5,6,7)),
    addToMethodArgs(9999,88),
    retract(methodDefT(9999,2,3,[4,88],5,6,7)).
test('test_addToToplevel') :-
    assert(toplevelT(9999,2,3,[4])),
    addToToplevel(9999, 55),
    retract(toplevelT(9999,2,3,[4,55])).
test('addToBlock') :-
    assert(blockT(9999,2,3,[4])),
    addToBlock(9999, 55),
    retract(blockT(9999,2,3,[4,55])).
test('add_to_class') :-
    assert(classDefT(9999,2,3,[4])),
    add_to_class(9999, 55),
    retract(classDefT(9999,2,3,[4,55])).
test('removeFromMethodArgs') :-
    assert(methodDefT(9999,2,3,[4,88],5,6,7)),
    removeFromMethodArgs(9999,88),
    retract(methodDefT(9999,2,3,[4],5,6,7)).
test('removeFromBlock') :-
    assert(blockT(9999,2,3,[4,88])),
    removeFromBlock(9999,88),
    retract(blockT(9999,2,3,[4])).




/* getTerm(+Lang, +ID, -Term)
     Semantik:
       Ermittelt den Term einer bestimmten ID.
     Testidee:
       Wird der gleiche Term f�r alle IDs zur�ckgegeben?
       Test-PEFs assertenm getTerm anwenden und vergleichen
       Am besten w�re es, wenn jedes Argument einen unterschiedlichen Wert h�tte..
     Aufrufe:
       /engine/apply/ct_apply.pl:294
       /engine/apply/transaction.pl:17
       /engine/ast/java/fq_api_type_term.pl:44,77
       /engine/ast/java/fq_api.pl:44,77
       /engine/ast/java/javaASTOperations/tree_modifications.pl:236
       /engine/ast/java/javaASTOperations/tree_queries.pl:153
       /engine/check/treechecks.pl:185,244,255
       /engine/debug/tree_spy.pl:23,32,112
       /engine/linker/java_fact_file_linking.pl:53
       
 */
/*
compare_getTerm :-
    retractall(testData(_,_)),
    genTestPEFs,
    testPred(getTerm('Java',_,_),2),
    genTestPEFs,
    testPred(getTerm(_,_),1),
    listing(testData),
    regressionTest(testData(getTerm('Java',_,_),X),testData(getTerm(_,_),X)).
*/

/* enclosing(+Lang, +ID, -Encl)
     Semantik:
       Ermittelt das Enclosing einer eindeutigen ID
                 (Mit CUT: und/oder alle IDs mit bestimmtem Enclosing)
     Testidee:
       Um den Fall [+ID,-Encl] zu testen, initialisiere TestPEFs, setze Encl-Argument
       auf distinguirbaren Wert.
       Die Faktenbasis wird nicht ver�ndert, sondern nur abgefragt.
     Aufrufe:
       /engine/apply/transaction.pl:20
       /engine/ast/java/javaASTOperations/clone.pl:11
       /engine/ast/java/javaASTOperations/tree_queries.pl:12,34,174,177
       /st.java/pl/org/cs3/java/writer/type_name.pl:149,160
 */
/*
compare('enclosing') :-
    genTestPEFsEnclPar,
    chk1(
          (idsToCheck(ID),enclosing(ID,Encl)),
          (idsToCheck(ID),get_ast_node_enclosing('Java',ID,Encl))
         ),
     cleanAll.
*/

/* set_encl_method/3
     Semantik:
       Das Enclosing des PEFs mit einer bestimmten ID wird ge�ndert.
     Testidee:
       Teste diese �nderung f�r alle m�glichen PEFs.
 */
 
%set_encl_method <-> set_ast_node_enclosing
compare('set_encl_method') :-
    retractall(testData(_,_)),
    genTestPEFs,                                      %generiere PEFs
    testPred(set_ast_node_enclosing('Java',_,99),2),  %Ver�nderung 1
    genTestPEFs,                                      %generiere erneut PEFs
    testPred(set_encl_method(_,99),1),                %Ver�nderung 2
    chk1(testData(set_ast_node_enclosing('Java',_,99),X),testData(set_encl_method(_,99),X)).


/* set_parent TEST
   - importT wird von der verallgemeinerten Version nicht erfasst, da der "Parent"
     "toplevel" hei�t..
 */

%set_parent <-> set_ast_node_parent/3
compare('set_parent') :-
    retractall(testData(_,_)),
    genTestPEFs,
    testPred(set_ast_node_parent('Java',_,99),2),
    genTestPEFs,
    testPred(set_parent(_,99),1),
    chk1(testData(set_ast_node_parent('Java',_,99),X),testData(set_parent(_,99),X)).

test_subtrees :-
    genTestPEFsAll,
    !,
    regressionTest((idsToCheck(ID),get_ast_node_sub_trees('Java',ID,Subs)),(idsToCheck(ID),sub_trees(ID,Subs))),
    cleanAll.
    %write(Subs),nl,
    %fail.
%test_subtrees.

/***** Ver�ndertes Pr�dikat: treeSignature/2 (st.java/pl/org/cs3/java/astSpec/javaFactbase.pl:1159)

:- regressionTest( jt:treeSignature(F, Arity), treeSignature(F, Arity) ).

   Inkonsistenz:
                - treeSignature(paramDefT, 5)
                - jt:treeSignature(paramDefT, 4)
*****/

/***** Ver�ndertes Pr�dikat: attribSignature/2 (st.java/pl/org/cs3/java/astSpec/javaFactbase.pl:1159)

:- regressionTest( jt:attribSignature(F, Arity), attribSignature(F, Arity) ).

   Inkonsistenz:
                jt:attribSignature(sourceLocation, 4) --  fail
                jt:attribSignature(projectLocationT, 3) --  fail
                jt:attribSignature(slT, 3) --  fail
*****/


%peTest(basicType('Java',X)).


