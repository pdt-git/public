retractTree('Java', A) :-
	retractTreeJava1(A).

% retractTreeJava1('$VAR'(0)):-retractTree('Java', '$VAR'(0))
retractTreeJava1(A) :-
	packageT(A, B), !,
	retract(packageT(A, B)).
retractTreeJava1(A) :-
	classDefT(A, B, C, D), !,
	retract(classDefT(A, B, C, D)).
retractTreeJava1(A) :-
	methodDefT(A, B, C, D, E, F, G), !,
	retract(methodDefT(A, B, C, D, E, F, G)).
retractTreeJava1(A) :-
	fieldDefT(A, B, C, D, E), !,
	retract(fieldDefT(A, B, C, D, E)).
retractTreeJava1(A) :-
	paramDefT(A, B, C, D), !,
	retract(paramDefT(A, B, C, D)).
retractTreeJava1(A) :-
	applyT(A, B, C, D, E, F, G), !,
	retract(applyT(A, B, C, D, E, F, G)).
retractTreeJava1(A) :-
	assertT(A, B, C, D, E), !,
	retract(assertT(A, B, C, D, E)).
retractTreeJava1(A) :-
	assignT(A, B, C, D, E), !,
	retract(assignT(A, B, C, D, E)).
retractTreeJava1(A) :-
	assignopT(A, B, C, D, E, F), !,
	retract(assignopT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	blockT(A, B, C, D), !,
	retract(blockT(A, B, C, D)).
retractTreeJava1(A) :-
	breakT(A, B, C, D, E), !,
	retract(breakT(A, B, C, D, E)).
retractTreeJava1(A) :-
	caseT(A, B, C, D), !,
	retract(caseT(A, B, C, D)).
retractTreeJava1(A) :-
	conditionalT(A, B, C, D, E, F), !,
	retract(conditionalT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	continueT(A, B, C, D, E), !,
	retract(continueT(A, B, C, D, E)).
retractTreeJava1(A) :-
	doLoopT(A, B, C, D, E), !,
	retract(doLoopT(A, B, C, D, E)).
retractTreeJava1(A) :-
	execT(A, B, C, D), !,
	retract(execT(A, B, C, D)).
retractTreeJava1(A) :-
	catchT(A, B, C, D, E), !,
	retract(catchT(A, B, C, D, E)).
retractTreeJava1(A) :-
	forLoopT(A, B, C, D, E, F, G), !,
	retract(forLoopT(A, B, C, D, E, F, G)).
retractTreeJava1(A) :-
	getFieldT(A, B, C, D, E, F), !,
	retract(getFieldT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	ifT(A, B, C, D, E, F), !,
	retract(ifT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	importT(A, B, C), !,
	retract(importT(A, B, C)).
retractTreeJava1(A) :-
	indexedT(A, B, C, D, E), !,
	retract(indexedT(A, B, C, D, E)).
retractTreeJava1(A) :-
	labelT(A, B, C, D, E), !,
	retract(labelT(A, B, C, D, E)).
retractTreeJava1(A) :-
	literalT(A, B, C, D, E), !,
	retract(literalT(A, B, C, D, E)).
retractTreeJava1(A) :-
	localDefT(A, B, C, D, E, F), !,
	retract(localDefT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	newArrayT(A, B, C, D, E, F), !,
	retract(newArrayT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	newClassT(A, B, C, D, E, F, G, H), !,
	retract(newClassT(A, B, C, D, E, F, G, H)).
retractTreeJava1(A) :-
	nopT(A, B, C), !,
	retract(nopT(A, B, C)).
retractTreeJava1(A) :-
	operationT(A, B, C, D, E, F), !,
	retract(operationT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	precedenceT(A, B, C, D), !,
	retract(precedenceT(A, B, C, D)).
retractTreeJava1(A) :-
	returnT(A, B, C, D), !,
	retract(returnT(A, B, C, D)).
retractTreeJava1(A) :-
	selectT(A, B, C, D, E, F), !,
	retract(selectT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	identT(A, B, C, D, E), !,
	retract(identT(A, B, C, D, E)).
retractTreeJava1(A) :-
	switchT(A, B, C, D, E), !,
	retract(switchT(A, B, C, D, E)).
retractTreeJava1(A) :-
	synchronizedT(A, B, C, D, E), !,
	retract(synchronizedT(A, B, C, D, E)).
retractTreeJava1(A) :-
	throwT(A, B, C, D), !,
	retract(throwT(A, B, C, D)).
retractTreeJava1(A) :-
	toplevelT(A, B, C, D), !,
	retract(toplevelT(A, B, C, D)).
retractTreeJava1(A) :-
	tryT(A, B, C, D, E, F), !,
	retract(tryT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	typeCastT(A, B, C, D, E), !,
	retract(typeCastT(A, B, C, D, E)).
retractTreeJava1(A) :-
	typeTestT(A, B, C, D, E), !,
	retract(typeTestT(A, B, C, D, E)).
retractTreeJava1(A) :-
	whileLoopT(A, B, C, D, E), !,
	retract(whileLoopT(A, B, C, D, E)).
retractTreeJava1(A) :-
	nopT(A, B, C), !,
	retract(nopT(A, B, C)).
retractTreeJava1(A) :-
	not(tree(A, _, _)),
	format('could not retract id: ~a~n', [A]), !.

% original definition
:- dynamic packageT/2.
packageT(null, '').

% original definition
:- dynamic classDefT/4.

% original definition
:- dynamic methodDefT/7.

% original definition
:- dynamic fieldDefT/5.

% original definition
:- dynamic paramDefT/4.

% original definition
:- dynamic applyT/7.

% original definition
:- dynamic assertT/5.

% original definition
:- dynamic assignT/5.

% original definition
:- dynamic assignopT/6.

% original definition
:- dynamic blockT/4.

% original definition
:- dynamic breakT/5.

% original definition
:- dynamic caseT/4.

% original definition
:- dynamic conditionalT/6.

% original definition
:- dynamic continueT/5.

% original definition
:- dynamic doLoopT/5.

% original definition
:- dynamic execT/4.

% original definition
:- dynamic catchT/5.

% original definition
:- dynamic forLoopT/7.

% original definition
:- dynamic getFieldT/6.

% original definition
:- dynamic ifT/6.

% original definition
:- dynamic importT/3.

% original definition
:- dynamic indexedT/5.

% original definition
:- dynamic labelT/5.

% original definition
:- dynamic literalT/5.

% original definition
:- dynamic localDefT/6.

% original definition
:- dynamic newArrayT/6.

% original definition
:- dynamic newClassT/8.

% original definition
:- dynamic nopT/3.

% original definition
:- dynamic operationT/6.

% original definition
:- dynamic precedenceT/4.

% original definition
:- dynamic returnT/4.

% original definition
:- dynamic selectT/6.

% original definition
:- dynamic identT/5.

% original definition
:- dynamic switchT/5.

% original definition
:- dynamic synchronizedT/5.

% original definition
:- dynamic throwT/4.

% original definition
:- dynamic toplevelT/4.

% original definition
:- dynamic tryT/6.

% original definition
:- dynamic typeCastT/5.

% original definition
:- dynamic typeTestT/5.

% original definition
:- dynamic whileLoopT/5.
