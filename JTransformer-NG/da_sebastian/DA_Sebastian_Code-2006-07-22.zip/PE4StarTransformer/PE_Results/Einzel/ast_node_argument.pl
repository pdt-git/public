ast_node_argument('Java', A, B) :-
	ast_node_argumentJava1(A, B).

% ast_node_argumentJava1('$VAR'(0), '$VAR'(1)):-ast_node_argument('Java', '$VAR'(0), '$VAR'(1))
ast_node_argumentJava1(A, E) :-
	nonvar(A), !,
	functor(A, B, C),
	(   B=packageT,
	    C=2,
	    functor(A, D, _),
	    (   D=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   D=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   D=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   D=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   D=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   D=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   D=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   D=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   D=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   D=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   D=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   D=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   D=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   D=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   D=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   D=execT,
		'checkArgs.ast_argid16'(E)
	    ;   D=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   D=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   D=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   D=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   D=importT,
		'checkArgs.ast_argid21'(E)
	    ;   D=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   D=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   D=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   D=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   D=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   D=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   D=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   D=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   D=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   D=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   D=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   D=identT,
		'checkArgs.ast_argid32'(E)
	    ;   D=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   D=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   D=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   D=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   D=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   D=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   D=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   D=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=classDefT,
	    hackTreeSignatureclassDefT1(C),
	    functor(A, F, _),
	    (   F=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   F=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   F=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   F=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   F=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   F=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   F=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   F=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   F=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   F=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   F=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   F=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   F=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   F=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   F=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   F=execT,
		'checkArgs.ast_argid16'(E)
	    ;   F=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   F=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   F=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   F=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   F=importT,
		'checkArgs.ast_argid21'(E)
	    ;   F=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   F=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   F=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   F=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   F=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   F=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   F=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   F=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   F=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   F=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   F=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   F=identT,
		'checkArgs.ast_argid32'(E)
	    ;   F=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   F=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   F=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   F=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   F=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   F=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   F=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   F=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=methodDefT,
	    hackTreeSignaturemethodDefT1(C),
	    functor(A, G, _),
	    (   G=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   G=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   G=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   G=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   G=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   G=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   G=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   G=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   G=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   G=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   G=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   G=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   G=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   G=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   G=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   G=execT,
		'checkArgs.ast_argid16'(E)
	    ;   G=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   G=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   G=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   G=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   G=importT,
		'checkArgs.ast_argid21'(E)
	    ;   G=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   G=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   G=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   G=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   G=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   G=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   G=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   G=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   G=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   G=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   G=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   G=identT,
		'checkArgs.ast_argid32'(E)
	    ;   G=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   G=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   G=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   G=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   G=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   G=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   G=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   G=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=fieldDefT,
	    hackTreeSignaturefieldDefT1(C),
	    functor(A, H, _),
	    (   H=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   H=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   H=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   H=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   H=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   H=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   H=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   H=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   H=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   H=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   H=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   H=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   H=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   H=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   H=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   H=execT,
		'checkArgs.ast_argid16'(E)
	    ;   H=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   H=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   H=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   H=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   H=importT,
		'checkArgs.ast_argid21'(E)
	    ;   H=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   H=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   H=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   H=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   H=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   H=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   H=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   H=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   H=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   H=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   H=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   H=identT,
		'checkArgs.ast_argid32'(E)
	    ;   H=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   H=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   H=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   H=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   H=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   H=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   H=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   H=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=paramDefT,
	    hackTreeSignatureparamDefT1(C),
	    functor(A, I, _),
	    (   I=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   I=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   I=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   I=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   I=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   I=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   I=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   I=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   I=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   I=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   I=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   I=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   I=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   I=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   I=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   I=execT,
		'checkArgs.ast_argid16'(E)
	    ;   I=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   I=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   I=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   I=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   I=importT,
		'checkArgs.ast_argid21'(E)
	    ;   I=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   I=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   I=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   I=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   I=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   I=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   I=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   I=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   I=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   I=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   I=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   I=identT,
		'checkArgs.ast_argid32'(E)
	    ;   I=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   I=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   I=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   I=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   I=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   I=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   I=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   I=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=applyT,
	    C=7,
	    functor(A, J, _),
	    (   J=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   J=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   J=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   J=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   J=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   J=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   J=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   J=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   J=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   J=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   J=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   J=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   J=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   J=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   J=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   J=execT,
		'checkArgs.ast_argid16'(E)
	    ;   J=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   J=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   J=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   J=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   J=importT,
		'checkArgs.ast_argid21'(E)
	    ;   J=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   J=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   J=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   J=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   J=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   J=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   J=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   J=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   J=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   J=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   J=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   J=identT,
		'checkArgs.ast_argid32'(E)
	    ;   J=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   J=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   J=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   J=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   J=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   J=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   J=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   J=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=assertT,
	    C=5,
	    functor(A, K, _),
	    (   K=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   K=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   K=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   K=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   K=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   K=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   K=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   K=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   K=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   K=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   K=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   K=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   K=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   K=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   K=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   K=execT,
		'checkArgs.ast_argid16'(E)
	    ;   K=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   K=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   K=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   K=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   K=importT,
		'checkArgs.ast_argid21'(E)
	    ;   K=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   K=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   K=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   K=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   K=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   K=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   K=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   K=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   K=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   K=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   K=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   K=identT,
		'checkArgs.ast_argid32'(E)
	    ;   K=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   K=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   K=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   K=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   K=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   K=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   K=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   K=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=assignT,
	    C=5,
	    functor(A, L, _),
	    (   L=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   L=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   L=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   L=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   L=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   L=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   L=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   L=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   L=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   L=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   L=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   L=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   L=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   L=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   L=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   L=execT,
		'checkArgs.ast_argid16'(E)
	    ;   L=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   L=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   L=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   L=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   L=importT,
		'checkArgs.ast_argid21'(E)
	    ;   L=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   L=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   L=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   L=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   L=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   L=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   L=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   L=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   L=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   L=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   L=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   L=identT,
		'checkArgs.ast_argid32'(E)
	    ;   L=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   L=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   L=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   L=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   L=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   L=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   L=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   L=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=assignopT,
	    C=6,
	    functor(A, M, _),
	    (   M=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   M=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   M=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   M=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   M=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   M=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   M=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   M=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   M=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   M=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   M=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   M=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   M=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   M=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   M=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   M=execT,
		'checkArgs.ast_argid16'(E)
	    ;   M=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   M=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   M=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   M=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   M=importT,
		'checkArgs.ast_argid21'(E)
	    ;   M=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   M=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   M=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   M=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   M=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   M=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   M=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   M=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   M=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   M=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   M=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   M=identT,
		'checkArgs.ast_argid32'(E)
	    ;   M=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   M=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   M=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   M=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   M=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   M=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   M=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   M=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=blockT,
	    C=4,
	    functor(A, N, _),
	    (   N=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   N=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   N=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   N=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   N=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   N=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   N=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   N=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   N=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   N=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   N=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   N=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   N=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   N=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   N=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   N=execT,
		'checkArgs.ast_argid16'(E)
	    ;   N=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   N=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   N=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   N=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   N=importT,
		'checkArgs.ast_argid21'(E)
	    ;   N=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   N=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   N=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   N=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   N=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   N=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   N=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   N=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   N=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   N=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   N=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   N=identT,
		'checkArgs.ast_argid32'(E)
	    ;   N=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   N=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   N=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   N=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   N=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   N=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   N=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   N=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=breakT,
	    C=5,
	    functor(A, O, _),
	    (   O=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   O=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   O=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   O=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   O=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   O=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   O=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   O=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   O=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   O=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   O=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   O=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   O=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   O=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   O=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   O=execT,
		'checkArgs.ast_argid16'(E)
	    ;   O=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   O=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   O=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   O=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   O=importT,
		'checkArgs.ast_argid21'(E)
	    ;   O=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   O=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   O=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   O=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   O=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   O=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   O=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   O=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   O=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   O=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   O=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   O=identT,
		'checkArgs.ast_argid32'(E)
	    ;   O=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   O=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   O=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   O=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   O=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   O=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   O=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   O=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=caseT,
	    C=4,
	    functor(A, P, _),
	    (   P=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   P=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   P=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   P=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   P=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   P=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   P=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   P=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   P=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   P=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   P=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   P=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   P=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   P=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   P=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   P=execT,
		'checkArgs.ast_argid16'(E)
	    ;   P=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   P=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   P=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   P=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   P=importT,
		'checkArgs.ast_argid21'(E)
	    ;   P=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   P=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   P=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   P=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   P=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   P=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   P=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   P=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   P=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   P=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   P=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   P=identT,
		'checkArgs.ast_argid32'(E)
	    ;   P=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   P=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   P=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   P=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   P=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   P=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   P=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   P=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=conditionalT,
	    C=6,
	    functor(A, Q, _),
	    (   Q=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   Q=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   Q=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   Q=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   Q=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   Q=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   Q=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   Q=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   Q=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   Q=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   Q=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   Q=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   Q=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   Q=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   Q=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   Q=execT,
		'checkArgs.ast_argid16'(E)
	    ;   Q=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   Q=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   Q=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   Q=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   Q=importT,
		'checkArgs.ast_argid21'(E)
	    ;   Q=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   Q=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   Q=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   Q=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   Q=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   Q=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   Q=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   Q=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   Q=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   Q=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   Q=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   Q=identT,
		'checkArgs.ast_argid32'(E)
	    ;   Q=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   Q=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   Q=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   Q=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   Q=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   Q=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   Q=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   Q=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=continueT,
	    C=5,
	    functor(A, R, _),
	    (   R=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   R=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   R=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   R=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   R=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   R=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   R=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   R=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   R=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   R=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   R=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   R=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   R=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   R=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   R=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   R=execT,
		'checkArgs.ast_argid16'(E)
	    ;   R=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   R=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   R=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   R=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   R=importT,
		'checkArgs.ast_argid21'(E)
	    ;   R=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   R=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   R=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   R=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   R=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   R=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   R=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   R=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   R=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   R=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   R=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   R=identT,
		'checkArgs.ast_argid32'(E)
	    ;   R=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   R=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   R=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   R=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   R=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   R=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   R=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   R=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=doLoopT,
	    C=5,
	    functor(A, S, _),
	    (   S=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   S=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   S=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   S=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   S=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   S=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   S=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   S=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   S=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   S=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   S=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   S=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   S=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   S=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   S=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   S=execT,
		'checkArgs.ast_argid16'(E)
	    ;   S=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   S=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   S=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   S=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   S=importT,
		'checkArgs.ast_argid21'(E)
	    ;   S=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   S=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   S=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   S=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   S=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   S=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   S=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   S=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   S=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   S=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   S=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   S=identT,
		'checkArgs.ast_argid32'(E)
	    ;   S=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   S=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   S=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   S=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   S=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   S=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   S=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   S=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=execT,
	    C=4,
	    functor(A, T, _),
	    (   T=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   T=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   T=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   T=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   T=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   T=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   T=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   T=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   T=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   T=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   T=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   T=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   T=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   T=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   T=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   T=execT,
		'checkArgs.ast_argid16'(E)
	    ;   T=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   T=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   T=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   T=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   T=importT,
		'checkArgs.ast_argid21'(E)
	    ;   T=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   T=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   T=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   T=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   T=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   T=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   T=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   T=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   T=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   T=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   T=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   T=identT,
		'checkArgs.ast_argid32'(E)
	    ;   T=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   T=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   T=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   T=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   T=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   T=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   T=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   T=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=catchT,
	    C=5,
	    functor(A, U, _),
	    (   U=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   U=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   U=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   U=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   U=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   U=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   U=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   U=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   U=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   U=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   U=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   U=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   U=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   U=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   U=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   U=execT,
		'checkArgs.ast_argid16'(E)
	    ;   U=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   U=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   U=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   U=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   U=importT,
		'checkArgs.ast_argid21'(E)
	    ;   U=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   U=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   U=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   U=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   U=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   U=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   U=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   U=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   U=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   U=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   U=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   U=identT,
		'checkArgs.ast_argid32'(E)
	    ;   U=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   U=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   U=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   U=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   U=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   U=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   U=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   U=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=forLoopT,
	    C=7,
	    functor(A, V, _),
	    (   V=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   V=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   V=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   V=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   V=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   V=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   V=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   V=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   V=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   V=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   V=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   V=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   V=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   V=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   V=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   V=execT,
		'checkArgs.ast_argid16'(E)
	    ;   V=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   V=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   V=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   V=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   V=importT,
		'checkArgs.ast_argid21'(E)
	    ;   V=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   V=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   V=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   V=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   V=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   V=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   V=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   V=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   V=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   V=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   V=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   V=identT,
		'checkArgs.ast_argid32'(E)
	    ;   V=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   V=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   V=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   V=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   V=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   V=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   V=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   V=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=getFieldT,
	    C=6,
	    functor(A, W, _),
	    (   W=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   W=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   W=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   W=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   W=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   W=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   W=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   W=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   W=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   W=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   W=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   W=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   W=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   W=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   W=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   W=execT,
		'checkArgs.ast_argid16'(E)
	    ;   W=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   W=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   W=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   W=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   W=importT,
		'checkArgs.ast_argid21'(E)
	    ;   W=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   W=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   W=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   W=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   W=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   W=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   W=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   W=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   W=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   W=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   W=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   W=identT,
		'checkArgs.ast_argid32'(E)
	    ;   W=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   W=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   W=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   W=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   W=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   W=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   W=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   W=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=ifT,
	    C=6,
	    functor(A, X, _),
	    (   X=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   X=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   X=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   X=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   X=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   X=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   X=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   X=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   X=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   X=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   X=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   X=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   X=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   X=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   X=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   X=execT,
		'checkArgs.ast_argid16'(E)
	    ;   X=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   X=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   X=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   X=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   X=importT,
		'checkArgs.ast_argid21'(E)
	    ;   X=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   X=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   X=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   X=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   X=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   X=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   X=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   X=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   X=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   X=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   X=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   X=identT,
		'checkArgs.ast_argid32'(E)
	    ;   X=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   X=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   X=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   X=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   X=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   X=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   X=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   X=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=importT,
	    C=3,
	    functor(A, Y, _),
	    (   Y=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   Y=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   Y=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   Y=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   Y=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   Y=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   Y=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   Y=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   Y=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   Y=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   Y=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   Y=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   Y=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   Y=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   Y=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   Y=execT,
		'checkArgs.ast_argid16'(E)
	    ;   Y=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   Y=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   Y=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   Y=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   Y=importT,
		'checkArgs.ast_argid21'(E)
	    ;   Y=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   Y=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   Y=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   Y=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   Y=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   Y=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   Y=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   Y=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   Y=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   Y=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   Y=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   Y=identT,
		'checkArgs.ast_argid32'(E)
	    ;   Y=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   Y=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   Y=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   Y=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   Y=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   Y=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   Y=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   Y=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=indexedT,
	    C=5,
	    functor(A, Z, _),
	    (   Z=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   Z=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   Z=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   Z=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   Z=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   Z=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   Z=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   Z=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   Z=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   Z=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   Z=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   Z=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   Z=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   Z=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   Z=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   Z=execT,
		'checkArgs.ast_argid16'(E)
	    ;   Z=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   Z=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   Z=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   Z=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   Z=importT,
		'checkArgs.ast_argid21'(E)
	    ;   Z=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   Z=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   Z=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   Z=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   Z=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   Z=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   Z=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   Z=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   Z=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   Z=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   Z=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   Z=identT,
		'checkArgs.ast_argid32'(E)
	    ;   Z=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   Z=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   Z=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   Z=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   Z=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   Z=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   Z=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   Z=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=labelT,
	    C=5,
	    functor(A, A1, _),
	    (   A1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   A1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   A1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   A1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   A1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   A1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   A1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   A1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   A1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   A1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   A1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   A1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   A1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   A1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   A1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   A1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   A1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   A1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   A1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   A1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   A1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   A1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   A1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   A1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   A1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   A1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   A1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   A1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   A1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   A1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   A1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   A1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   A1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   A1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   A1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   A1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   A1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   A1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   A1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   A1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   A1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=literalT,
	    C=5,
	    functor(A, B1, _),
	    (   B1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   B1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   B1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   B1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   B1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   B1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   B1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   B1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   B1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   B1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   B1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   B1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   B1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   B1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   B1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   B1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   B1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   B1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   B1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   B1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   B1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   B1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   B1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   B1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   B1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   B1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   B1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   B1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   B1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   B1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   B1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   B1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   B1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   B1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   B1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   B1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   B1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   B1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   B1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   B1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   B1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=localDefT,
	    C=6,
	    functor(A, C1, _),
	    (   C1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   C1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   C1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   C1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   C1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   C1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   C1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   C1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   C1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   C1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   C1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   C1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   C1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   C1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   C1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   C1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   C1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   C1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   C1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   C1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   C1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   C1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   C1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   C1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   C1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   C1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   C1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   C1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   C1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   C1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   C1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   C1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   C1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   C1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   C1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   C1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   C1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   C1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   C1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   C1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   C1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=newArrayT,
	    C=6,
	    functor(A, D1, _),
	    (   D1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   D1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   D1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   D1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   D1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   D1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   D1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   D1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   D1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   D1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   D1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   D1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   D1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   D1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   D1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   D1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   D1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   D1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   D1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   D1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   D1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   D1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   D1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   D1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   D1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   D1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   D1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   D1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   D1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   D1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   D1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   D1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   D1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   D1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   D1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   D1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   D1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   D1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   D1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   D1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   D1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=newClassT,
	    C=8,
	    functor(A, E1, _),
	    (   E1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   E1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   E1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   E1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   E1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   E1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   E1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   E1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   E1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   E1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   E1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   E1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   E1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   E1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   E1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   E1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   E1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   E1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   E1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   E1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   E1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   E1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   E1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   E1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   E1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   E1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   E1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   E1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   E1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   E1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   E1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   E1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   E1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   E1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   E1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   E1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   E1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   E1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   E1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   E1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   E1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=nopT,
	    C=3,
	    functor(A, F1, _),
	    (   F1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   F1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   F1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   F1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   F1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   F1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   F1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   F1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   F1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   F1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   F1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   F1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   F1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   F1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   F1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   F1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   F1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   F1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   F1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   F1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   F1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   F1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   F1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   F1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   F1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   F1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   F1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   F1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   F1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   F1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   F1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   F1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   F1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   F1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   F1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   F1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   F1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   F1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   F1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   F1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   F1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=operationT,
	    C=6,
	    functor(A, G1, _),
	    (   G1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   G1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   G1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   G1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   G1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   G1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   G1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   G1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   G1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   G1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   G1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   G1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   G1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   G1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   G1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   G1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   G1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   G1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   G1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   G1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   G1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   G1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   G1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   G1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   G1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   G1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   G1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   G1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   G1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   G1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   G1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   G1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   G1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   G1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   G1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   G1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   G1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   G1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   G1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   G1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   G1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=precedenceT,
	    C=4,
	    functor(A, H1, _),
	    (   H1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   H1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   H1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   H1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   H1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   H1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   H1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   H1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   H1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   H1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   H1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   H1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   H1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   H1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   H1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   H1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   H1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   H1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   H1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   H1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   H1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   H1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   H1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   H1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   H1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   H1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   H1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   H1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   H1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   H1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   H1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   H1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   H1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   H1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   H1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   H1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   H1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   H1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   H1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   H1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   H1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=returnT,
	    C=4,
	    functor(A, I1, _),
	    (   I1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   I1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   I1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   I1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   I1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   I1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   I1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   I1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   I1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   I1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   I1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   I1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   I1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   I1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   I1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   I1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   I1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   I1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   I1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   I1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   I1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   I1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   I1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   I1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   I1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   I1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   I1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   I1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   I1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   I1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   I1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   I1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   I1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   I1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   I1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   I1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   I1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   I1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   I1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   I1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   I1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=selectT,
	    C=6,
	    functor(A, J1, _),
	    (   J1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   J1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   J1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   J1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   J1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   J1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   J1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   J1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   J1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   J1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   J1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   J1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   J1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   J1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   J1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   J1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   J1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   J1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   J1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   J1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   J1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   J1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   J1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   J1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   J1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   J1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   J1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   J1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   J1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   J1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   J1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   J1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   J1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   J1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   J1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   J1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   J1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   J1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   J1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   J1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   J1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=identT,
	    C=5,
	    functor(A, K1, _),
	    (   K1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   K1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   K1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   K1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   K1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   K1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   K1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   K1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   K1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   K1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   K1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   K1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   K1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   K1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   K1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   K1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   K1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   K1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   K1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   K1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   K1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   K1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   K1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   K1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   K1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   K1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   K1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   K1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   K1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   K1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   K1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   K1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   K1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   K1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   K1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   K1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   K1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   K1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   K1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   K1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   K1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=switchT,
	    C=5,
	    functor(A, L1, _),
	    (   L1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   L1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   L1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   L1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   L1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   L1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   L1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   L1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   L1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   L1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   L1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   L1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   L1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   L1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   L1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   L1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   L1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   L1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   L1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   L1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   L1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   L1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   L1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   L1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   L1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   L1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   L1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   L1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   L1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   L1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   L1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   L1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   L1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   L1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   L1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   L1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   L1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   L1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   L1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   L1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   L1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=synchronizedT,
	    C=5,
	    functor(A, M1, _),
	    (   M1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   M1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   M1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   M1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   M1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   M1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   M1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   M1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   M1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   M1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   M1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   M1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   M1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   M1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   M1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   M1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   M1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   M1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   M1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   M1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   M1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   M1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   M1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   M1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   M1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   M1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   M1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   M1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   M1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   M1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   M1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   M1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   M1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   M1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   M1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   M1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   M1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   M1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   M1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   M1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   M1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=throwT,
	    C=4,
	    functor(A, N1, _),
	    (   N1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   N1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   N1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   N1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   N1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   N1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   N1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   N1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   N1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   N1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   N1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   N1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   N1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   N1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   N1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   N1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   N1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   N1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   N1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   N1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   N1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   N1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   N1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   N1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   N1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   N1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   N1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   N1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   N1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   N1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   N1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   N1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   N1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   N1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   N1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   N1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   N1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   N1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   N1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   N1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   N1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=toplevelT,
	    C=4,
	    functor(A, O1, _),
	    (   O1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   O1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   O1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   O1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   O1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   O1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   O1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   O1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   O1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   O1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   O1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   O1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   O1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   O1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   O1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   O1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   O1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   O1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   O1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   O1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   O1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   O1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   O1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   O1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   O1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   O1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   O1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   O1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   O1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   O1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   O1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   O1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   O1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   O1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   O1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   O1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   O1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   O1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   O1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   O1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   O1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=tryT,
	    C=6,
	    functor(A, P1, _),
	    (   P1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   P1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   P1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   P1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   P1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   P1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   P1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   P1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   P1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   P1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   P1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   P1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   P1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   P1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   P1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   P1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   P1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   P1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   P1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   P1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   P1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   P1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   P1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   P1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   P1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   P1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   P1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   P1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   P1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   P1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   P1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   P1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   P1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   P1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   P1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   P1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   P1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   P1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   P1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   P1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   P1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=typeCastT,
	    C=5,
	    functor(A, Q1, _),
	    (   Q1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   Q1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   Q1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   Q1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   Q1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   Q1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   Q1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   Q1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   Q1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   Q1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   Q1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   Q1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   Q1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   Q1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   Q1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   Q1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   Q1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   Q1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   Q1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   Q1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   Q1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   Q1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   Q1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   Q1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   Q1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   Q1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   Q1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   Q1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   Q1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   Q1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   Q1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   Q1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   Q1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   Q1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   Q1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   Q1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   Q1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   Q1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   Q1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   Q1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   Q1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=typeTestT,
	    C=5,
	    functor(A, R1, _),
	    (   R1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   R1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   R1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   R1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   R1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   R1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   R1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   R1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   R1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   R1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   R1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   R1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   R1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   R1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   R1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   R1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   R1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   R1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   R1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   R1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   R1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   R1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   R1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   R1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   R1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   R1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   R1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   R1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   R1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   R1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   R1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   R1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   R1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   R1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   R1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   R1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   R1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   R1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   R1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   R1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   R1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	;   B=whileLoopT,
	    C=5,
	    functor(A, S1, _),
	    (   S1=packageT,
		'checkArgs.ast_argid1'(E)
	    ;   S1=classDefT,
		'checkArgs.ast_argid2'(E)
	    ;   S1=methodDefT,
		'checkArgs.ast_argid3'(E)
	    ;   S1=fieldDefT,
		'checkArgs.ast_argid4'(E)
	    ;   S1=paramDefT,
		'checkArgs.ast_argid5'(E)
	    ;   S1=applyT,
		'checkArgs.ast_argid6'(E)
	    ;   S1=assertT,
		'checkArgs.ast_argid7'(E)
	    ;   S1=assignT,
		'checkArgs.ast_argid8'(E)
	    ;   S1=assignopT,
		'checkArgs.ast_argid9'(E)
	    ;   S1=blockT,
		'checkArgs.ast_argid10'(E)
	    ;   S1=breakT,
		'checkArgs.ast_argid11'(E)
	    ;   S1=caseT,
		'checkArgs.ast_argid12'(E)
	    ;   S1=conditionalT,
		'checkArgs.ast_argid13'(E)
	    ;   S1=continueT,
		'checkArgs.ast_argid14'(E)
	    ;   S1=doLoopT,
		'checkArgs.ast_argid15'(E)
	    ;   S1=execT,
		'checkArgs.ast_argid16'(E)
	    ;   S1=catchT,
		'checkArgs.ast_argid17'(E)
	    ;   S1=forLoopT,
		'checkArgs.ast_argid18'(E)
	    ;   S1=getFieldT,
		'checkArgs.ast_argid19'(E)
	    ;   S1=ifT,
		'checkArgs.ast_argid20'(E)
	    ;   S1=importT,
		'checkArgs.ast_argid21'(E)
	    ;   S1=indexedT,
		'checkArgs.ast_argid22'(E)
	    ;   S1=labelT,
		'checkArgs.ast_argid23'(E)
	    ;   S1=literalT,
		'checkArgs.ast_argid24'(E)
	    ;   S1=localDefT,
		'checkArgs.ast_argid25'(E)
	    ;   S1=newArrayT,
		'checkArgs.ast_argid26'(E)
	    ;   S1=newClassT,
		'checkArgs.ast_argid27'(E)
	    ;   S1=nopT,
		'checkArgs.ast_argid28'(E)
	    ;   S1=operationT,
		'checkArgs.ast_argid29'(E)
	    ;   S1=precedenceT,
		'checkArgs.ast_argid30'(E)
	    ;   S1=returnT,
		'checkArgs.ast_argid16'(E)
	    ;   S1=selectT,
		'checkArgs.ast_argid31'(E)
	    ;   S1=identT,
		'checkArgs.ast_argid32'(E)
	    ;   S1=switchT,
		'checkArgs.ast_argid33'(E)
	    ;   S1=synchronizedT,
		'checkArgs.ast_argid34'(E)
	    ;   S1=throwT,
		'checkArgs.ast_argid35'(E)
	    ;   S1=toplevelT,
		'checkArgs.ast_argid36'(E)
	    ;   S1=tryT,
		'checkArgs.ast_argid37'(E)
	    ;   S1=typeCastT,
		'checkArgs.ast_argid38'(E)
	    ;   S1=typeTestT,
		'checkArgs.ast_argid39'(E)
	    ;   S1=whileLoopT,
		'checkArgs.ast_argid40'(E)
	    )
	).
ast_node_argumentJava1(A, B) :-
	var(A),
	(   A=packageT(_, _),
	    'checkArgs.ast_argid1'(B)
	;   A=classDefT(_, _, _, _),
	    'checkArgs.ast_argid2'(B)
	;   A=methodDefT(_, _, _, _, _, _, _),
	    'checkArgs.ast_argid3'(B)
	;   A=fieldDefT(_, _, _, _, _),
	    'checkArgs.ast_argid4'(B)
	;   A=paramDefT(_, _, _, _),
	    'checkArgs.ast_argid5'(B)
	;   A=applyT(_, _, _, _, _, _, _),
	    'checkArgs.ast_argid6'(B)
	;   A=assertT(_, _, _, _, _),
	    'checkArgs.ast_argid7'(B)
	;   A=assignT(_, _, _, _, _),
	    'checkArgs.ast_argid8'(B)
	;   A=assignopT(_, _, _, _, _, _),
	    'checkArgs.ast_argid9'(B)
	;   A=blockT(_, _, _, _),
	    'checkArgs.ast_argid10'(B)
	;   A=breakT(_, _, _, _, _),
	    'checkArgs.ast_argid11'(B)
	;   A=caseT(_, _, _, _),
	    'checkArgs.ast_argid12'(B)
	;   A=conditionalT(_, _, _, _, _, _),
	    'checkArgs.ast_argid13'(B)
	;   A=continueT(_, _, _, _, _),
	    'checkArgs.ast_argid14'(B)
	;   A=doLoopT(_, _, _, _, _),
	    'checkArgs.ast_argid15'(B)
	;   A=execT(_, _, _, _),
	    'checkArgs.ast_argid16'(B)
	;   A=catchT(_, _, _, _, _),
	    'checkArgs.ast_argid17'(B)
	;   A=forLoopT(_, _, _, _, _, _, _),
	    'checkArgs.ast_argid18'(B)
	;   A=getFieldT(_, _, _, _, _, _),
	    'checkArgs.ast_argid19'(B)
	;   A=ifT(_, _, _, _, _, _),
	    'checkArgs.ast_argid20'(B)
	;   A=importT(_, _, _),
	    'checkArgs.ast_argid21'(B)
	;   A=indexedT(_, _, _, _, _),
	    'checkArgs.ast_argid22'(B)
	;   A=labelT(_, _, _, _, _),
	    'checkArgs.ast_argid23'(B)
	;   A=literalT(_, _, _, _, _),
	    'checkArgs.ast_argid24'(B)
	;   A=localDefT(_, _, _, _, _, _),
	    'checkArgs.ast_argid25'(B)
	;   A=newArrayT(_, _, _, _, _, _),
	    'checkArgs.ast_argid26'(B)
	;   A=newClassT(_, _, _, _, _, _, _, _),
	    'checkArgs.ast_argid27'(B)
	;   A=nopT(_, _, _),
	    'checkArgs.ast_argid28'(B)
	;   A=operationT(_, _, _, _, _, _),
	    'checkArgs.ast_argid29'(B)
	;   A=precedenceT(_, _, _, _),
	    'checkArgs.ast_argid30'(B)
	;   A=returnT(_, _, _, _),
	    'checkArgs.ast_argid16'(B)
	;   A=selectT(_, _, _, _, _, _),
	    'checkArgs.ast_argid31'(B)
	;   A=identT(_, _, _, _, _),
	    'checkArgs.ast_argid32'(B)
	;   A=switchT(_, _, _, _, _),
	    'checkArgs.ast_argid33'(B)
	;   A=synchronizedT(_, _, _, _, _),
	    'checkArgs.ast_argid34'(B)
	;   A=throwT(_, _, _, _),
	    'checkArgs.ast_argid35'(B)
	;   A=toplevelT(_, _, _, _),
	    'checkArgs.ast_argid36'(B)
	;   A=tryT(_, _, _, _, _, _),
	    'checkArgs.ast_argid37'(B)
	;   A=typeCastT(_, _, _, _, _),
	    'checkArgs.ast_argid38'(B)
	;   A=typeTestT(_, _, _, _, _),
	    'checkArgs.ast_argid39'(B)
	;   A=whileLoopT(_, _, _, _, _),
	    'checkArgs.ast_argid40'(B)
	).

% 'checkArgs.ast_argid1'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [id]), ast_arg(name, mult(1, 1, no), attr, [atom])], '$VAR'(0))
'checkArgs.ast_argid1'(id) :- !.
'checkArgs.ast_argid1'(name).

% 'checkArgs.ast_argid2'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [classDefT]), ast_arg(parent, mult(1, 1, no), id, [execT, packageT, classDefT, newClassT, blockT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(0))
'checkArgs.ast_argid2'(id) :- !.
'checkArgs.ast_argid2'(parent) :- !.
'checkArgs.ast_argid2'(name) :- !.
'checkArgs.ast_argid2'(defs) :- !.
'checkArgs.ast_argid2'(extends) :- !.
'checkArgs.ast_argid2'(implems) :- !.
'checkArgs.ast_argid2'(hasModif) :- !.
'checkArgs.ast_argid2'(isInterf) :- !.
'checkArgs.ast_argid2'(isExtern).

% 'checkArgs.ast_argid3'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [methodDefT]), ast_arg(parent, mult(1, 1, no), id, [classDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0))
'checkArgs.ast_argid3'(id) :- !.
'checkArgs.ast_argid3'(parent) :- !.
'checkArgs.ast_argid3'(name) :- !.
'checkArgs.ast_argid3'(params) :- !.
'checkArgs.ast_argid3'(type) :- !.
'checkArgs.ast_argid3'(excepts) :- !.
'checkArgs.ast_argid3'(body) :- !.
'checkArgs.ast_argid3'(hasModif).

% 'checkArgs.ast_argid4'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [fieldDefT]), ast_arg(parent, mult(1, 1, no), id, [classDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0))
'checkArgs.ast_argid4'(id) :- !.
'checkArgs.ast_argid4'(parent) :- !.
'checkArgs.ast_argid4'(type) :- !.
'checkArgs.ast_argid4'(name) :- !.
'checkArgs.ast_argid4'(expr) :- !.
'checkArgs.ast_argid4'(hasModif).

% 'checkArgs.ast_argid5'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [paramDefT]), ast_arg(parent, mult(1, 1, no), id, [methodDefT, catchT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0))
'checkArgs.ast_argid5'(id) :- !.
'checkArgs.ast_argid5'(parent) :- !.
'checkArgs.ast_argid5'(type) :- !.
'checkArgs.ast_argid5'(name) :- !.
'checkArgs.ast_argid5'(hasModif).

% 'checkArgs.ast_argid6'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [applyT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(0))
'checkArgs.ast_argid6'(id) :- !.
'checkArgs.ast_argid6'(parent) :- !.
'checkArgs.ast_argid6'(encl) :- !.
'checkArgs.ast_argid6'(expr) :- !.
'checkArgs.ast_argid6'(name) :- !.
'checkArgs.ast_argid6'(args) :- !.
'checkArgs.ast_argid6'(ref).

% 'checkArgs.ast_argid7'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [assertT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(msg, mult(0, 1, no), id, [expressionType])], '$VAR'(0))
'checkArgs.ast_argid7'(id) :- !.
'checkArgs.ast_argid7'(parent) :- !.
'checkArgs.ast_argid7'(encl) :- !.
'checkArgs.ast_argid7'(expr) :- !.
'checkArgs.ast_argid7'(msg).

% 'checkArgs.ast_argid8'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [assignT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0))
'checkArgs.ast_argid8'(id) :- !.
'checkArgs.ast_argid8'(parent) :- !.
'checkArgs.ast_argid8'(encl) :- !.
'checkArgs.ast_argid8'(lhs) :- !.
'checkArgs.ast_argid8'(expr).

% 'checkArgs.ast_argid9'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [assignopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0))
'checkArgs.ast_argid9'(id) :- !.
'checkArgs.ast_argid9'(parent) :- !.
'checkArgs.ast_argid9'(encl) :- !.
'checkArgs.ast_argid9'(lhs) :- !.
'checkArgs.ast_argid9'(operator) :- !.
'checkArgs.ast_argid9'(expr).

% 'checkArgs.ast_argid10'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [blockT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(stmts, mult(0, *, ord), id, [statementType])], '$VAR'(0))
'checkArgs.ast_argid10'(id) :- !.
'checkArgs.ast_argid10'(parent) :- !.
'checkArgs.ast_argid10'(encl) :- !.
'checkArgs.ast_argid10'(stmts).

% 'checkArgs.ast_argid11'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [breakT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])], '$VAR'(0))
'checkArgs.ast_argid11'(id) :- !.
'checkArgs.ast_argid11'(parent) :- !.
'checkArgs.ast_argid11'(encl) :- !.
'checkArgs.ast_argid11'(label) :- !.
'checkArgs.ast_argid11'(target).

% 'checkArgs.ast_argid12'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [caseT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(0))
'checkArgs.ast_argid12'(id) :- !.
'checkArgs.ast_argid12'(parent) :- !.
'checkArgs.ast_argid12'(encl) :- !.
'checkArgs.ast_argid12'(expr).

% 'checkArgs.ast_argid13'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [conditionalT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])], '$VAR'(0))
'checkArgs.ast_argid13'(id) :- !.
'checkArgs.ast_argid13'(parent) :- !.
'checkArgs.ast_argid13'(encl) :- !.
'checkArgs.ast_argid13'(cond) :- !.
'checkArgs.ast_argid13'(thenexpr) :- !.
'checkArgs.ast_argid13'(elseexpr).

% 'checkArgs.ast_argid14'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [continueT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])], '$VAR'(0))
'checkArgs.ast_argid14'(id) :- !.
'checkArgs.ast_argid14'(parent) :- !.
'checkArgs.ast_argid14'(encl) :- !.
'checkArgs.ast_argid14'(label) :- !.
'checkArgs.ast_argid14'(target).

% 'checkArgs.ast_argid15'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [doLoopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(0))
'checkArgs.ast_argid15'(id) :- !.
'checkArgs.ast_argid15'(parent) :- !.
'checkArgs.ast_argid15'(encl) :- !.
'checkArgs.ast_argid15'(cond) :- !.
'checkArgs.ast_argid15'(body).

% 'checkArgs.ast_argid16'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [execT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0))
'checkArgs.ast_argid16'(id) :- !.
'checkArgs.ast_argid16'(parent) :- !.
'checkArgs.ast_argid16'(encl) :- !.
'checkArgs.ast_argid16'(expr).

% 'checkArgs.ast_argid17'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [catchT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(param, mult(1, 1, no), id, [paramDefT]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(0))
'checkArgs.ast_argid17'(id) :- !.
'checkArgs.ast_argid17'(parent) :- !.
'checkArgs.ast_argid17'(encl) :- !.
'checkArgs.ast_argid17'(param) :- !.
'checkArgs.ast_argid17'(body).

% 'checkArgs.ast_argid18'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [forLoopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(inits, mult(0, *, ord), id, [[expressionType, localDefT]]), ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(0))
'checkArgs.ast_argid18'(id) :- !.
'checkArgs.ast_argid18'(parent) :- !.
'checkArgs.ast_argid18'(encl) :- !.
'checkArgs.ast_argid18'(inits) :- !.
'checkArgs.ast_argid18'(cond) :- !.
'checkArgs.ast_argid18'(updaters) :- !.
'checkArgs.ast_argid18'(body).

% 'checkArgs.ast_argid19'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [getFieldT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])], '$VAR'(0))
'checkArgs.ast_argid19'(id) :- !.
'checkArgs.ast_argid19'(parent) :- !.
'checkArgs.ast_argid19'(encl) :- !.
'checkArgs.ast_argid19'(expr) :- !.
'checkArgs.ast_argid19'(name) :- !.
'checkArgs.ast_argid19'(field).

% 'checkArgs.ast_argid20'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [ifT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])], '$VAR'(0))
'checkArgs.ast_argid20'(id) :- !.
'checkArgs.ast_argid20'(parent) :- !.
'checkArgs.ast_argid20'(encl) :- !.
'checkArgs.ast_argid20'(cond) :- !.
'checkArgs.ast_argid20'(then) :- !.
'checkArgs.ast_argid20'(else).

% 'checkArgs.ast_argid21'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [importT]), ast_arg(parent, mult(1, 1, no), id, [toplevelT]), ast_arg(import, mult(1, 1, no), id, [packageT, classDefT])], '$VAR'(0))
'checkArgs.ast_argid21'(id) :- !.
'checkArgs.ast_argid21'(parent) :- !.
'checkArgs.ast_argid21'(import).

% 'checkArgs.ast_argid22'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [indexedT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(index, mult(1, 1, no), id, [expressionType]), ast_arg(indexed, mult(1, 1, no), id, [expressionType])], '$VAR'(0))
'checkArgs.ast_argid22'(id) :- !.
'checkArgs.ast_argid22'(parent) :- !.
'checkArgs.ast_argid22'(encl) :- !.
'checkArgs.ast_argid22'(index) :- !.
'checkArgs.ast_argid22'(indexed).

% 'checkArgs.ast_argid23'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [labelT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(body, mult(1, 1, no), id, [statementType]), ast_arg(label, mult(1, 1, no), attr, [atom])], '$VAR'(0))
'checkArgs.ast_argid23'(id) :- !.
'checkArgs.ast_argid23'(parent) :- !.
'checkArgs.ast_argid23'(encl) :- !.
'checkArgs.ast_argid23'(body) :- !.
'checkArgs.ast_argid23'(label).

% 'checkArgs.ast_argid24'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [literalT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(value, mult(1, 1, no), attr, [atom])], '$VAR'(0))
'checkArgs.ast_argid24'(id) :- !.
'checkArgs.ast_argid24'(parent) :- !.
'checkArgs.ast_argid24'(encl) :- !.
'checkArgs.ast_argid24'(type) :- !.
'checkArgs.ast_argid24'(value).

% 'checkArgs.ast_argid25'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [localDefT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(0))
'checkArgs.ast_argid25'(id) :- !.
'checkArgs.ast_argid25'(parent) :- !.
'checkArgs.ast_argid25'(encl) :- !.
'checkArgs.ast_argid25'(type) :- !.
'checkArgs.ast_argid25'(name) :- !.
'checkArgs.ast_argid25'(expr).

% 'checkArgs.ast_argid26'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [newArrayT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(dims, mult(1, *, ord), id, [expressionType]), ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])], '$VAR'(0))
'checkArgs.ast_argid26'(id) :- !.
'checkArgs.ast_argid26'(parent) :- !.
'checkArgs.ast_argid26'(encl) :- !.
'checkArgs.ast_argid26'(dims) :- !.
'checkArgs.ast_argid26'(elems) :- !.
'checkArgs.ast_argid26'(type).

% 'checkArgs.ast_argid27'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [newClassT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(constr, mult(0, 1, no), id, [methodDefT]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(0))
'checkArgs.ast_argid27'(id) :- !.
'checkArgs.ast_argid27'(parent) :- !.
'checkArgs.ast_argid27'(encl) :- !.
'checkArgs.ast_argid27'(constr) :- !.
'checkArgs.ast_argid27'(args) :- !.
'checkArgs.ast_argid27'(clident) :- !.
'checkArgs.ast_argid27'(def) :- !.
'checkArgs.ast_argid27'(encltype).

% 'checkArgs.ast_argid28'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [nopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT])], '$VAR'(0))
'checkArgs.ast_argid28'(id) :- !.
'checkArgs.ast_argid28'(parent) :- !.
'checkArgs.ast_argid28'(encl).

% 'checkArgs.ast_argid29'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [operationT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(args, mult(1, 1, ord), id, [expressionType]), ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])], '$VAR'(0))
'checkArgs.ast_argid29'(id) :- !.
'checkArgs.ast_argid29'(parent) :- !.
'checkArgs.ast_argid29'(encl) :- !.
'checkArgs.ast_argid29'(args) :- !.
'checkArgs.ast_argid29'(op) :- !.
'checkArgs.ast_argid29'(pos).

% 'checkArgs.ast_argid30'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [precedenceT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0))
'checkArgs.ast_argid30'(id) :- !.
'checkArgs.ast_argid30'(parent) :- !.
'checkArgs.ast_argid30'(encl) :- !.
'checkArgs.ast_argid30'(expr).

% 'checkArgs.ast_argid31'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [selectT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], '$VAR'(0))
'checkArgs.ast_argid31'(id) :- !.
'checkArgs.ast_argid31'(parent) :- !.
'checkArgs.ast_argid31'(encl) :- !.
'checkArgs.ast_argid31'(name) :- !.
'checkArgs.ast_argid31'(selected) :- !.
'checkArgs.ast_argid31'(ref).

% 'checkArgs.ast_argid32'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [identT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT, localDefT])], '$VAR'(0))
'checkArgs.ast_argid32'(id) :- !.
'checkArgs.ast_argid32'(parent) :- !.
'checkArgs.ast_argid32'(encl) :- !.
'checkArgs.ast_argid32'(name) :- !.
'checkArgs.ast_argid32'(ref).

% 'checkArgs.ast_argid33'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [switchT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(stmts, mult(1, 1, no), id, [statementType])], '$VAR'(0))
'checkArgs.ast_argid33'(id) :- !.
'checkArgs.ast_argid33'(parent) :- !.
'checkArgs.ast_argid33'(encl) :- !.
'checkArgs.ast_argid33'(cond) :- !.
'checkArgs.ast_argid33'(stmts).

% 'checkArgs.ast_argid34'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [synchronizedT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(lock, mult(1, 1, no), id, [expressionType]), ast_arg(block, mult(1, 1, no), id, [blockT])], '$VAR'(0))
'checkArgs.ast_argid34'(id) :- !.
'checkArgs.ast_argid34'(parent) :- !.
'checkArgs.ast_argid34'(encl) :- !.
'checkArgs.ast_argid34'(lock) :- !.
'checkArgs.ast_argid34'(block).

% 'checkArgs.ast_argid35'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [throwT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0))
'checkArgs.ast_argid35'(id) :- !.
'checkArgs.ast_argid35'(parent) :- !.
'checkArgs.ast_argid35'(encl) :- !.
'checkArgs.ast_argid35'(expr).

% 'checkArgs.ast_argid36'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [toplevelT]), ast_arg(parent, mult(0, 1, no), id, [packageT]), ast_arg(file, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])], '$VAR'(0))
'checkArgs.ast_argid36'(id) :- !.
'checkArgs.ast_argid36'(parent) :- !.
'checkArgs.ast_argid36'(file) :- !.
'checkArgs.ast_argid36'(defs).

% 'checkArgs.ast_argid37'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [tryT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(block, mult(1, 1, no), id, [blockT]), ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])], '$VAR'(0))
'checkArgs.ast_argid37'(id) :- !.
'checkArgs.ast_argid37'(parent) :- !.
'checkArgs.ast_argid37'(encl) :- !.
'checkArgs.ast_argid37'(block) :- !.
'checkArgs.ast_argid37'(catchers) :- !.
'checkArgs.ast_argid37'(finalize).

% 'checkArgs.ast_argid38'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [typeCastT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0))
'checkArgs.ast_argid38'(id) :- !.
'checkArgs.ast_argid38'(parent) :- !.
'checkArgs.ast_argid38'(encl) :- !.
'checkArgs.ast_argid38'(type) :- !.
'checkArgs.ast_argid38'(expr).

% 'checkArgs.ast_argid39'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [typeTestT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0))
'checkArgs.ast_argid39'(id) :- !.
'checkArgs.ast_argid39'(parent) :- !.
'checkArgs.ast_argid39'(encl) :- !.
'checkArgs.ast_argid39'(type) :- !.
'checkArgs.ast_argid39'(expr).

% 'checkArgs.ast_argid40'('$VAR'(0)):-checkArgs([ast_arg(id, mult(1, 1, no), id, [whileLoopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(0))
'checkArgs.ast_argid40'(id) :- !.
'checkArgs.ast_argid40'(parent) :- !.
'checkArgs.ast_argid40'(encl) :- !.
'checkArgs.ast_argid40'(cond) :- !.
'checkArgs.ast_argid40'(body).

% hackTreeSignatureclassDefT1('$VAR'(0)):-hackTreeSignature(classDefT, 9, '$VAR'(0))
hackTreeSignatureclassDefT1(4) :- !.
hackTreeSignatureclassDefT1(9).

% hackTreeSignaturemethodDefT1('$VAR'(0)):-hackTreeSignature(methodDefT, 8, '$VAR'(0))
hackTreeSignaturemethodDefT1(7) :- !.
hackTreeSignaturemethodDefT1(8).

% hackTreeSignaturefieldDefT1('$VAR'(0)):-hackTreeSignature(fieldDefT, 6, '$VAR'(0))
hackTreeSignaturefieldDefT1(5) :- !.
hackTreeSignaturefieldDefT1(6).

% hackTreeSignatureparamDefT1('$VAR'(0)):-hackTreeSignature(paramDefT, 5, '$VAR'(0))
hackTreeSignatureparamDefT1(4) :- !.
hackTreeSignatureparamDefT1(5).
