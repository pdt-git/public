markEnclAsDirty('Java', A) :-
	markEnclAsDirtyJava1(A).

% markEnclAsDirtyJava1('$VAR'(0)):-markEnclAsDirty('Java', '$VAR'(0))
markEnclAsDirtyJava1(A) :-
	get_ast_node_termJava1(A, B),
	'\\+checkIfTopLevelJava1'(B),
	(   get_ast_node_enclosingJava1(B, C),
	    '\\+=1'(C),
	    '\\+checkIfTopLevelJava1'(C),
	    assert1T(dirty_tree('Java', C)), !
	;   assert1T(dirty_tree('Java', B)), !
	).
markEnclAsDirtyJava1(_).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_term('Java', '$VAR'(1), '$VAR'(0))
get_ast_node_termJava1(B, A) :-
	packageT(A, C), !,
	B=packageT(A, C).
get_ast_node_termJava1(B, A) :-
	classDefT(A, C, D, E), !,
	B=classDefT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	methodDefT(A, C, D, E, F, G, H), !,
	B=methodDefT(A, C, D, E, F, G, H).
get_ast_node_termJava1(B, A) :-
	fieldDefT(A, C, D, E, F), !,
	B=fieldDefT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	paramDefT(A, C, D, E), !,
	B=paramDefT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	applyT(A, C, D, E, F, G, H), !,
	B=applyT(A, C, D, E, F, G, H).
get_ast_node_termJava1(B, A) :-
	assertT(A, C, D, E, F), !,
	B=assertT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	assignT(A, C, D, E, F), !,
	B=assignT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	assignopT(A, C, D, E, F, G), !,
	B=assignopT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	blockT(A, C, D, E), !,
	B=blockT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	breakT(A, C, D, E, F), !,
	B=breakT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	caseT(A, C, D, E), !,
	B=caseT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	conditionalT(A, C, D, E, F, G), !,
	B=conditionalT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	continueT(A, C, D, E, F), !,
	B=continueT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	doLoopT(A, C, D, E, F), !,
	B=doLoopT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	execT(A, C, D, E), !,
	B=execT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	catchT(A, C, D, E, F), !,
	B=catchT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	forLoopT(A, C, D, E, F, G, H), !,
	B=forLoopT(A, C, D, E, F, G, H).
get_ast_node_termJava1(B, A) :-
	getFieldT(A, C, D, E, F, G), !,
	B=getFieldT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	ifT(A, C, D, E, F, G), !,
	B=ifT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	importT(A, C, D), !,
	B=importT(A, C, D).
get_ast_node_termJava1(B, A) :-
	indexedT(A, C, D, E, F), !,
	B=indexedT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	labelT(A, C, D, E, F), !,
	B=labelT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	literalT(A, C, D, E, F), !,
	B=literalT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	localDefT(A, C, D, E, F, G), !,
	B=localDefT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	newArrayT(A, C, D, E, F, G), !,
	B=newArrayT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	newClassT(A, C, D, E, F, G, H, I), !,
	B=newClassT(A, C, D, E, F, G, H, I).
get_ast_node_termJava1(B, A) :-
	nopT(A, C, D), !,
	B=nopT(A, C, D).
get_ast_node_termJava1(B, A) :-
	operationT(A, C, D, E, F, G), !,
	B=operationT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	precedenceT(A, C, D, E), !,
	B=precedenceT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	returnT(A, C, D, E), !,
	B=returnT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	selectT(A, C, D, E, F, G), !,
	B=selectT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	identT(A, C, D, E, F), !,
	B=identT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	switchT(A, C, D, E, F), !,
	B=switchT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	synchronizedT(A, C, D, E, F), !,
	B=synchronizedT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	throwT(A, C, D, E), !,
	B=throwT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	toplevelT(A, C, D, E), !,
	B=toplevelT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	tryT(A, C, D, E, F, G), !,
	B=tryT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	typeCastT(A, C, D, E, F), !,
	B=typeCastT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	typeTestT(A, C, D, E, F), !,
	B=typeTestT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	whileLoopT(A, C, D, E, F), !,
	B=whileLoopT(A, C, D, E, F).

% original definition
:- dynamic packageT/2.
packageT(null, '').

% original definition
:- dynamic classDefT/4.

% original definition
:- dynamic methodDefT/7.

% original definition
:- dynamic fieldDefT/5.

% original definition
:- dynamic paramDefT/4.

% original definition
:- dynamic applyT/7.

% original definition
:- dynamic assertT/5.

% original definition
:- dynamic assignT/5.

% original definition
:- dynamic assignopT/6.

% original definition
:- dynamic blockT/4.

% original definition
:- dynamic breakT/5.

% original definition
:- dynamic caseT/4.

% original definition
:- dynamic conditionalT/6.

% original definition
:- dynamic continueT/5.

% original definition
:- dynamic doLoopT/5.

% original definition
:- dynamic execT/4.

% original definition
:- dynamic catchT/5.

% original definition
:- dynamic forLoopT/7.

% original definition
:- dynamic getFieldT/6.

% original definition
:- dynamic ifT/6.

% original definition
:- dynamic importT/3.

% original definition
:- dynamic indexedT/5.

% original definition
:- dynamic labelT/5.

% original definition
:- dynamic literalT/5.

% original definition
:- dynamic localDefT/6.

% original definition
:- dynamic newArrayT/6.

% original definition
:- dynamic newClassT/8.

% original definition
:- dynamic nopT/3.

% original definition
:- dynamic operationT/6.

% original definition
:- dynamic precedenceT/4.

% original definition
:- dynamic returnT/4.

% original definition
:- dynamic selectT/6.

% original definition
:- dynamic identT/5.

% original definition
:- dynamic switchT/5.

% original definition
:- dynamic synchronizedT/5.

% original definition
:- dynamic throwT/4.

% original definition
:- dynamic toplevelT/4.

% original definition
:- dynamic tryT/6.

% original definition
:- dynamic typeCastT/5.

% original definition
:- dynamic typeTestT/5.

% original definition
:- dynamic whileLoopT/5.

% '\\+checkIfTopLevelJava1'('$VAR'(0)):- \+checkIfTopLevel('Java', '$VAR'(0))
'\\+checkIfTopLevelJava1'(A) :-
	checkIfTopLevelJava1(A), !,
	fail.
'\\+checkIfTopLevelJava1'(_).

% checkIfTopLevelJava1('$VAR'(0)):-checkIfTopLevel('Java', '$VAR'(0))
checkIfTopLevelJava1(A) :-
	classDefT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	paramDefT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assertT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assignT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	blockT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	breakT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	caseT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	continueT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	execT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	catchT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	importT(A, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	indexedT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	labelT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	literalT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	nopT(A, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	precedenceT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	returnT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	identT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	switchT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	throwT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	toplevelT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	packageT(A, _), !,
	fail.
checkIfTopLevelJava1(_).

% get_ast_node_enclosingJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_enclosing('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_enclosingJava1(A, B) :-
	applyT(A, _, B, _, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	assertT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	assignT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	assignopT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	blockT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	breakT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	caseT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	conditionalT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	continueT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	doLoopT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	execT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	catchT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	forLoopT(A, _, B, _, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	getFieldT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	ifT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	indexedT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	labelT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	literalT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	localDefT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	newArrayT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	newClassT(A, _, B, _, _, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	nopT(A, _, B).
get_ast_node_enclosingJava1(A, B) :-
	operationT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	precedenceT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	returnT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	selectT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	identT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	switchT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	synchronizedT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	throwT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	tryT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	typeCastT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	typeTestT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	whileLoopT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, A) :-
	packageT(A, _), !.
get_ast_node_enclosingJava1(A, B) :-
	classDefT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	paramDefT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	fieldDefT(A, B, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	methodDefT(A, B, _, _, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	toplevelT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	importT(A, _, B), !.

% '\\+=1'('$VAR'(0)):- \+'$VAR'(0)=null
'\\+=1'(null) :- !,
	fail.
'\\+=1'(_).
