get_ast_node_term('Java', A, B) :-
	get_ast_node_termJava1(A, B).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_term('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_termJava1(A, B) :-
	packageT(A, C), !,
	B=packageT(A, C).
get_ast_node_termJava1(A, B) :-
	classDefT(A, C, D, E), !,
	B=classDefT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	methodDefT(A, C, D, E, F, G, H), !,
	B=methodDefT(A, C, D, E, F, G, H).
get_ast_node_termJava1(A, B) :-
	fieldDefT(A, C, D, E, F), !,
	B=fieldDefT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	paramDefT(A, C, D, E), !,
	B=paramDefT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	applyT(A, C, D, E, F, G, H), !,
	B=applyT(A, C, D, E, F, G, H).
get_ast_node_termJava1(A, B) :-
	assertT(A, C, D, E, F), !,
	B=assertT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	assignT(A, C, D, E, F), !,
	B=assignT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	assignopT(A, C, D, E, F, G), !,
	B=assignopT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	blockT(A, C, D, E), !,
	B=blockT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	breakT(A, C, D, E, F), !,
	B=breakT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	caseT(A, C, D, E), !,
	B=caseT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	conditionalT(A, C, D, E, F, G), !,
	B=conditionalT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	continueT(A, C, D, E, F), !,
	B=continueT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	doLoopT(A, C, D, E, F), !,
	B=doLoopT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	execT(A, C, D, E), !,
	B=execT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	catchT(A, C, D, E, F), !,
	B=catchT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	forLoopT(A, C, D, E, F, G, H), !,
	B=forLoopT(A, C, D, E, F, G, H).
get_ast_node_termJava1(A, B) :-
	getFieldT(A, C, D, E, F, G), !,
	B=getFieldT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	ifT(A, C, D, E, F, G), !,
	B=ifT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	importT(A, C, D), !,
	B=importT(A, C, D).
get_ast_node_termJava1(A, B) :-
	indexedT(A, C, D, E, F), !,
	B=indexedT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	labelT(A, C, D, E, F), !,
	B=labelT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	literalT(A, C, D, E, F), !,
	B=literalT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	localDefT(A, C, D, E, F, G), !,
	B=localDefT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	newArrayT(A, C, D, E, F, G), !,
	B=newArrayT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	newClassT(A, C, D, E, F, G, H, I), !,
	B=newClassT(A, C, D, E, F, G, H, I).
get_ast_node_termJava1(A, B) :-
	nopT(A, C, D), !,
	B=nopT(A, C, D).
get_ast_node_termJava1(A, B) :-
	operationT(A, C, D, E, F, G), !,
	B=operationT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	precedenceT(A, C, D, E), !,
	B=precedenceT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	returnT(A, C, D, E), !,
	B=returnT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	selectT(A, C, D, E, F, G), !,
	B=selectT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	identT(A, C, D, E, F), !,
	B=identT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	switchT(A, C, D, E, F), !,
	B=switchT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	synchronizedT(A, C, D, E, F), !,
	B=synchronizedT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	throwT(A, C, D, E), !,
	B=throwT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	toplevelT(A, C, D, E), !,
	B=toplevelT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	tryT(A, C, D, E, F, G), !,
	B=tryT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	typeCastT(A, C, D, E, F), !,
	B=typeCastT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	typeTestT(A, C, D, E, F), !,
	B=typeTestT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	whileLoopT(A, C, D, E, F), !,
	B=whileLoopT(A, C, D, E, F).

% original definition
:- dynamic packageT/2.
packageT(null, '').

% original definition
:- dynamic classDefT/4.

% original definition
:- dynamic methodDefT/7.

% original definition
:- dynamic fieldDefT/5.

% original definition
:- dynamic paramDefT/4.

% original definition
:- dynamic applyT/7.

% original definition
:- dynamic assertT/5.

% original definition
:- dynamic assignT/5.

% original definition
:- dynamic assignopT/6.

% original definition
:- dynamic blockT/4.

% original definition
:- dynamic breakT/5.

% original definition
:- dynamic caseT/4.

% original definition
:- dynamic conditionalT/6.

% original definition
:- dynamic continueT/5.

% original definition
:- dynamic doLoopT/5.

% original definition
:- dynamic execT/4.

% original definition
:- dynamic catchT/5.

% original definition
:- dynamic forLoopT/7.

% original definition
:- dynamic getFieldT/6.

% original definition
:- dynamic ifT/6.

% original definition
:- dynamic importT/3.

% original definition
:- dynamic indexedT/5.

% original definition
:- dynamic labelT/5.

% original definition
:- dynamic literalT/5.

% original definition
:- dynamic localDefT/6.

% original definition
:- dynamic newArrayT/6.

% original definition
:- dynamic newClassT/8.

% original definition
:- dynamic nopT/3.

% original definition
:- dynamic operationT/6.

% original definition
:- dynamic precedenceT/4.

% original definition
:- dynamic returnT/4.

% original definition
:- dynamic selectT/6.

% original definition
:- dynamic identT/5.

% original definition
:- dynamic switchT/5.

% original definition
:- dynamic synchronizedT/5.

% original definition
:- dynamic throwT/4.

% original definition
:- dynamic toplevelT/4.

% original definition
:- dynamic tryT/6.

% original definition
:- dynamic typeCastT/5.

% original definition
:- dynamic typeTestT/5.

% original definition
:- dynamic whileLoopT/5.
