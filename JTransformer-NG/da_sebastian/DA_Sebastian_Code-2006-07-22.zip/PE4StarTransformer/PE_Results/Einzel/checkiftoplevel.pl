checkIfTopLevel('Java', A) :-
	checkIfTopLevelJava1(A).

% checkIfTopLevelJava1('$VAR'(0)):-checkIfTopLevel('Java', '$VAR'(0))
checkIfTopLevelJava1(A) :-
	classDefT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	paramDefT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assertT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assignT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	blockT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	breakT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	caseT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	continueT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	execT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	catchT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	importT(A, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	indexedT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	labelT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	literalT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	nopT(A, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	precedenceT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	returnT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	identT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	switchT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	throwT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	toplevelT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	packageT(A, _), !,
	fail.
checkIfTopLevelJava1(_).

% original definition
:- dynamic classDefT/4.

% original definition
:- dynamic methodDefT/7.

% original definition
:- dynamic fieldDefT/5.

% original definition
:- dynamic paramDefT/4.

% original definition
:- dynamic applyT/7.

% original definition
:- dynamic assertT/5.

% original definition
:- dynamic assignT/5.

% original definition
:- dynamic assignopT/6.

% original definition
:- dynamic blockT/4.

% original definition
:- dynamic breakT/5.

% original definition
:- dynamic caseT/4.

% original definition
:- dynamic conditionalT/6.

% original definition
:- dynamic continueT/5.

% original definition
:- dynamic doLoopT/5.

% original definition
:- dynamic execT/4.

% original definition
:- dynamic catchT/5.

% original definition
:- dynamic forLoopT/7.

% original definition
:- dynamic getFieldT/6.

% original definition
:- dynamic ifT/6.

% original definition
:- dynamic importT/3.

% original definition
:- dynamic indexedT/5.

% original definition
:- dynamic labelT/5.

% original definition
:- dynamic literalT/5.

% original definition
:- dynamic localDefT/6.

% original definition
:- dynamic newArrayT/6.

% original definition
:- dynamic newClassT/8.

% original definition
:- dynamic nopT/3.

% original definition
:- dynamic operationT/6.

% original definition
:- dynamic precedenceT/4.

% original definition
:- dynamic returnT/4.

% original definition
:- dynamic selectT/6.

% original definition
:- dynamic identT/5.

% original definition
:- dynamic switchT/5.

% original definition
:- dynamic synchronizedT/5.

% original definition
:- dynamic throwT/4.

% original definition
:- dynamic toplevelT/4.

% original definition
:- dynamic tryT/6.

% original definition
:- dynamic typeCastT/5.

% original definition
:- dynamic typeTestT/5.

% original definition
:- dynamic whileLoopT/5.

% original definition
:- dynamic packageT/2.
packageT(null, '').
