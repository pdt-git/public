set_parent('Java', A, B) :-
	set_parentJava1(A, B).

% set_parentJava1('$VAR'(0), '$VAR'(1)):-set_parent('Java', '$VAR'(0), '$VAR'(1))
set_parentJava1(A, E) :-
	classDefT(A, B, C, D), !,
	'unifyLists.1'(B, C, D, E, F, G),
	retract(classDefT(A, B, C, D)),
	markEnclAsDirtyJava1(A, B, C, D),
	asserta(rollback(assert(classDefT(A, B, C, D)))),
	addJava1(A, E, F, G).
set_parentJava1(A, H) :-
	methodDefT(A, B, C, D, E, F, G), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I, J, K, L, M),
	retract(methodDefT(A, B, C, D, E, F, G)),
	markEnclAsDirtyJava1(A, B, C, D, E, F, G),
	asserta(rollback(assert(methodDefT(A, B, C, D, E, F, G)))),
	addJava1(A, H, I, J, K, L, M).
set_parentJava1(A, F) :-
	fieldDefT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(fieldDefT(A, B, C, D, E)),
	markEnclAsDirtyJava1(A, B, C, D, E),
	asserta(rollback(assert(fieldDefT(A, B, C, D, E)))),
	addJava1(A, F, G, H, I).
set_parentJava1(A, E) :-
	paramDefT(A, B, C, D), !,
	'unifyLists.1'(B, C, D, E, F, G),
	retract(paramDefT(A, B, C, D)),
	markEnclAsDirtyJava2(A, B, C, D),
	asserta(rollback(assert(paramDefT(A, B, C, D)))),
	addJava2(A, E, F, G).
set_parentJava1(A, H) :-
	applyT(A, B, C, D, E, F, G), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I, J, K, L, M),
	retract(applyT(A, B, C, D, E, F, G)),
	markEnclAsDirtyJava2(A, B, C, D, E, F, G),
	asserta(rollback(assert(applyT(A, B, C, D, E, F, G)))),
	addJava2(A, H, I, J, K, L, M).
set_parentJava1(A, F) :-
	assertT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(assertT(A, B, C, D, E)),
	markEnclAsDirtyJava2(A, B, C, D, E),
	asserta(rollback(assert(assertT(A, B, C, D, E)))),
	addJava2(A, F, G, H, I).
set_parentJava1(A, F) :-
	assignT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(assignT(A, B, C, D, E)),
	markEnclAsDirtyJava3(A, B, C, D, E),
	asserta(rollback(assert(assignT(A, B, C, D, E)))),
	addJava3(A, F, G, H, I).
set_parentJava1(A, G) :-
	assignopT(A, B, C, D, E, F), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I, J, K),
	retract(assignopT(A, B, C, D, E, F)),
	markEnclAsDirtyJava1(A, B, C, D, E, F),
	asserta(rollback(assert(assignopT(A, B, C, D, E, F)))),
	addJava1(A, G, H, I, J, K).
set_parentJava1(A, E) :-
	blockT(A, B, C, D), !,
	'unifyLists.1'(B, C, D, E, F, G),
	retract(blockT(A, B, C, D)),
	markEnclAsDirtyJava3(A, B, C, D),
	asserta(rollback(assert(blockT(A, B, C, D)))),
	addJava3(A, E, F, G).
set_parentJava1(A, F) :-
	breakT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(breakT(A, B, C, D, E)),
	markEnclAsDirtyJava4(A, B, C, D, E),
	asserta(rollback(assert(breakT(A, B, C, D, E)))),
	addJava4(A, F, G, H, I).
set_parentJava1(A, E) :-
	caseT(A, B, C, D), !,
	'unifyLists.1'(B, C, D, E, F, G),
	retract(caseT(A, B, C, D)),
	markEnclAsDirtyJava4(A, B, C, D),
	asserta(rollback(assert(caseT(A, B, C, D)))),
	addJava4(A, E, F, G).
set_parentJava1(A, G) :-
	conditionalT(A, B, C, D, E, F), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I, J, K),
	retract(conditionalT(A, B, C, D, E, F)),
	markEnclAsDirtyJava2(A, B, C, D, E, F),
	asserta(rollback(assert(conditionalT(A, B, C, D, E, F)))),
	addJava2(A, G, H, I, J, K).
set_parentJava1(A, F) :-
	continueT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(continueT(A, B, C, D, E)),
	markEnclAsDirtyJava5(A, B, C, D, E),
	asserta(rollback(assert(continueT(A, B, C, D, E)))),
	addJava5(A, F, G, H, I).
set_parentJava1(A, F) :-
	doLoopT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(doLoopT(A, B, C, D, E)),
	markEnclAsDirtyJava6(A, B, C, D, E),
	asserta(rollback(assert(doLoopT(A, B, C, D, E)))),
	addJava6(A, F, G, H, I).
set_parentJava1(A, E) :-
	execT(A, B, C, D), !,
	'unifyLists.1'(B, C, D, E, F, G),
	retract(execT(A, B, C, D)),
	markEnclAsDirtyJava5(A, B, C, D),
	asserta(rollback(assert(execT(A, B, C, D)))),
	addJava5(A, E, F, G).
set_parentJava1(A, F) :-
	catchT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(catchT(A, B, C, D, E)),
	markEnclAsDirtyJava7(A, B, C, D, E),
	asserta(rollback(assert(catchT(A, B, C, D, E)))),
	addJava7(A, F, G, H, I).
set_parentJava1(A, H) :-
	forLoopT(A, B, C, D, E, F, G), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I, J, K, L, M),
	retract(forLoopT(A, B, C, D, E, F, G)),
	markEnclAsDirtyJava3(A, B, C, D, E, F, G),
	asserta(rollback(assert(forLoopT(A, B, C, D, E, F, G)))),
	addJava3(A, H, I, J, K, L, M).
set_parentJava1(A, G) :-
	getFieldT(A, B, C, D, E, F), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I, J, K),
	retract(getFieldT(A, B, C, D, E, F)),
	markEnclAsDirtyJava3(A, B, C, D, E, F),
	asserta(rollback(assert(getFieldT(A, B, C, D, E, F)))),
	addJava3(A, G, H, I, J, K).
set_parentJava1(A, G) :-
	ifT(A, B, C, D, E, F), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I, J, K),
	retract(ifT(A, B, C, D, E, F)),
	markEnclAsDirtyJava4(A, B, C, D, E, F),
	asserta(rollback(assert(ifT(A, B, C, D, E, F)))),
	addJava4(A, G, H, I, J, K).
set_parentJava1(A, D) :-
	importT(A, B, C), !,
	'unifyLists.1'(B, C, D, E),
	retract(importT(A, B, C)),
	markEnclAsDirtyJava1(A, B, C),
	asserta(rollback(assert(importT(A, B, C)))),
	addJava1(A, D, E).
set_parentJava1(A, F) :-
	indexedT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(indexedT(A, B, C, D, E)),
	markEnclAsDirtyJava8(A, B, C, D, E),
	asserta(rollback(assert(indexedT(A, B, C, D, E)))),
	addJava8(A, F, G, H, I).
set_parentJava1(A, F) :-
	labelT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(labelT(A, B, C, D, E)),
	markEnclAsDirtyJava9(A, B, C, D, E),
	asserta(rollback(assert(labelT(A, B, C, D, E)))),
	addJava9(A, F, G, H, I).
set_parentJava1(A, F) :-
	literalT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(literalT(A, B, C, D, E)),
	markEnclAsDirtyJava10(A, B, C, D, E),
	asserta(rollback(assert(literalT(A, B, C, D, E)))),
	addJava10(A, F, G, H, I).
set_parentJava1(A, G) :-
	localDefT(A, B, C, D, E, F), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I, J, K),
	retract(localDefT(A, B, C, D, E, F)),
	markEnclAsDirtyJava5(A, B, C, D, E, F),
	asserta(rollback(assert(localDefT(A, B, C, D, E, F)))),
	addJava5(A, G, H, I, J, K).
set_parentJava1(A, G) :-
	newArrayT(A, B, C, D, E, F), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I, J, K),
	retract(newArrayT(A, B, C, D, E, F)),
	markEnclAsDirtyJava6(A, B, C, D, E, F),
	asserta(rollback(assert(newArrayT(A, B, C, D, E, F)))),
	addJava6(A, G, H, I, J, K).
set_parentJava1(A, I) :-
	newClassT(A, B, C, D, E, F, G, H), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I, J, K, L, M, N, O),
	retract(newClassT(A, B, C, D, E, F, G, H)),
	markEnclAsDirtyJava1(A, B, C, D, E, F, G, H),
	asserta(rollback(assert(newClassT(A, B, C, D, E, F, G, H)))),
	addJava1(A, I, J, K, L, M, N, O).
set_parentJava1(A, D) :-
	nopT(A, B, C), !,
	'unifyLists.1'(B, C, D, E),
	retract(nopT(A, B, C)),
	markEnclAsDirtyJava2(A, B, C),
	asserta(rollback(assert(nopT(A, B, C)))),
	addJava2(A, D, E).
set_parentJava1(A, G) :-
	operationT(A, B, C, D, E, F), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I, J, K),
	retract(operationT(A, B, C, D, E, F)),
	markEnclAsDirtyJava7(A, B, C, D, E, F),
	asserta(rollback(assert(operationT(A, B, C, D, E, F)))),
	addJava7(A, G, H, I, J, K).
set_parentJava1(A, E) :-
	precedenceT(A, B, C, D), !,
	'unifyLists.1'(B, C, D, E, F, G),
	retract(precedenceT(A, B, C, D)),
	markEnclAsDirtyJava6(A, B, C, D),
	asserta(rollback(assert(precedenceT(A, B, C, D)))),
	addJava6(A, E, F, G).
set_parentJava1(A, E) :-
	returnT(A, B, C, D), !,
	'unifyLists.1'(B, C, D, E, F, G),
	retract(returnT(A, B, C, D)),
	markEnclAsDirtyJava7(A, B, C, D),
	asserta(rollback(assert(returnT(A, B, C, D)))),
	addJava7(A, E, F, G).
set_parentJava1(A, G) :-
	selectT(A, B, C, D, E, F), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I, J, K),
	retract(selectT(A, B, C, D, E, F)),
	markEnclAsDirtyJava8(A, B, C, D, E, F),
	asserta(rollback(assert(selectT(A, B, C, D, E, F)))),
	addJava8(A, G, H, I, J, K).
set_parentJava1(A, F) :-
	identT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(identT(A, B, C, D, E)),
	markEnclAsDirtyJava11(A, B, C, D, E),
	asserta(rollback(assert(identT(A, B, C, D, E)))),
	addJava11(A, F, G, H, I).
set_parentJava1(A, F) :-
	switchT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(switchT(A, B, C, D, E)),
	markEnclAsDirtyJava12(A, B, C, D, E),
	asserta(rollback(assert(switchT(A, B, C, D, E)))),
	addJava12(A, F, G, H, I).
set_parentJava1(A, F) :-
	synchronizedT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(synchronizedT(A, B, C, D, E)),
	markEnclAsDirtyJava13(A, B, C, D, E),
	asserta(rollback(assert(synchronizedT(A, B, C, D, E)))),
	addJava13(A, F, G, H, I).
set_parentJava1(A, E) :-
	throwT(A, B, C, D), !,
	'unifyLists.1'(B, C, D, E, F, G),
	retract(throwT(A, B, C, D)),
	markEnclAsDirtyJava8(A, B, C, D),
	asserta(rollback(assert(throwT(A, B, C, D)))),
	addJava8(A, E, F, G).
set_parentJava1(A, E) :-
	toplevelT(A, B, C, D), !,
	'unifyLists.1'(B, C, D, E, F, G),
	retract(toplevelT(A, B, C, D)),
	markEnclAsDirtyJava9(A, B, C, D),
	asserta(rollback(assert(toplevelT(A, B, C, D)))),
	addJava9(A, E, F, G).
set_parentJava1(A, G) :-
	tryT(A, B, C, D, E, F), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I, J, K),
	retract(tryT(A, B, C, D, E, F)),
	markEnclAsDirtyJava9(A, B, C, D, E, F),
	asserta(rollback(assert(tryT(A, B, C, D, E, F)))),
	addJava9(A, G, H, I, J, K).
set_parentJava1(A, F) :-
	typeCastT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(typeCastT(A, B, C, D, E)),
	markEnclAsDirtyJava14(A, B, C, D, E),
	asserta(rollback(assert(typeCastT(A, B, C, D, E)))),
	addJava14(A, F, G, H, I).
set_parentJava1(A, F) :-
	typeTestT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(typeTestT(A, B, C, D, E)),
	markEnclAsDirtyJava15(A, B, C, D, E),
	asserta(rollback(assert(typeTestT(A, B, C, D, E)))),
	addJava15(A, F, G, H, I).
set_parentJava1(A, F) :-
	whileLoopT(A, B, C, D, E), !,
	'unifyLists.1'(B, C, D, E, F, G, H, I),
	retract(whileLoopT(A, B, C, D, E)),
	markEnclAsDirtyJava16(A, B, C, D, E),
	asserta(rollback(assert(whileLoopT(A, B, C, D, E)))),
	addJava16(A, F, G, H, I).
set_parentJava1(A, D) :-
	importT(A, B, C), !,
	retract(importT(A, B, C)),
	markEnclAsDirtyJava1(A, B, C),
	asserta(rollback(assert(importT(A, B, C)))),
	addJava1(A, D, C).
set_parentJava1([], _).
set_parentJava1([A|C], B) :-
	set_parentJava1(A, B),
	set_parentJava1(C, B).

% original definition
:- dynamic classDefT/4.

% 'unifyLists.1'('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-unifyLists(['$VAR'(0), '$VAR'(1), '$VAR'(2)], ['$VAR'(3), '$VAR'(4), '$VAR'(5)])
'unifyLists.1'(A, B, C, A, B, C) :- !.
'unifyLists.1'(_, A, B, _, A, B).

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', classDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava1(A, B, C, D) :-
	get_ast_node_termJava1(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava1(_, _, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), classDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava1(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(B, D, F, H, A) :-
	classDefT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava1(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% original definition
:- dynamic packageT/2.
packageT(null, '').

% original definition
:- dynamic methodDefT/7.

% original definition
:- dynamic fieldDefT/5.

% original definition
:- dynamic paramDefT/4.

% original definition
:- dynamic applyT/7.

% original definition
:- dynamic assertT/5.

% original definition
:- dynamic assignT/5.

% original definition
:- dynamic assignopT/6.

% original definition
:- dynamic blockT/4.

% original definition
:- dynamic breakT/5.

% original definition
:- dynamic caseT/4.

% original definition
:- dynamic conditionalT/6.

% original definition
:- dynamic continueT/5.

% original definition
:- dynamic doLoopT/5.

% original definition
:- dynamic execT/4.

% original definition
:- dynamic catchT/5.

% original definition
:- dynamic forLoopT/7.

% original definition
:- dynamic getFieldT/6.

% original definition
:- dynamic ifT/6.

% original definition
:- dynamic importT/3.

% original definition
:- dynamic indexedT/5.

% original definition
:- dynamic labelT/5.

% original definition
:- dynamic literalT/5.

% original definition
:- dynamic localDefT/6.

% original definition
:- dynamic newArrayT/6.

% original definition
:- dynamic newClassT/8.

% original definition
:- dynamic nopT/3.

% original definition
:- dynamic operationT/6.

% original definition
:- dynamic precedenceT/4.

% original definition
:- dynamic returnT/4.

% original definition
:- dynamic selectT/6.

% original definition
:- dynamic identT/5.

% original definition
:- dynamic switchT/5.

% original definition
:- dynamic synchronizedT/5.

% original definition
:- dynamic throwT/4.

% original definition
:- dynamic toplevelT/4.

% original definition
:- dynamic tryT/6.

% original definition
:- dynamic typeCastT/5.

% original definition
:- dynamic typeTestT/5.

% original definition
:- dynamic whileLoopT/5.

% '\\+checkIfTopLevelJava1'('$VAR'(0)):- \+checkIfTopLevel('Java', '$VAR'(0))
'\\+checkIfTopLevelJava1'(A) :-
	checkIfTopLevelJava1(A), !,
	fail.
'\\+checkIfTopLevelJava1'(_).

% checkIfTopLevelJava1('$VAR'(0)):-checkIfTopLevel('Java', '$VAR'(0))
checkIfTopLevelJava1(A) :-
	classDefT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	paramDefT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assertT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assignT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	blockT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	breakT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	caseT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	continueT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	execT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	catchT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	importT(A, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	indexedT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	labelT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	literalT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	nopT(A, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	precedenceT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	returnT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	identT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	switchT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	throwT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	toplevelT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	packageT(A, _), !,
	fail.
checkIfTopLevelJava1(_).

% get_ast_node_enclosingJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_enclosing('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_enclosingJava1(A, B) :-
	applyT(A, _, B, _, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	assertT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	assignT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	assignopT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	blockT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	breakT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	caseT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	conditionalT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	continueT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	doLoopT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	execT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	catchT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	forLoopT(A, _, B, _, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	getFieldT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	ifT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	indexedT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	labelT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	literalT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	localDefT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	newArrayT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	newClassT(A, _, B, _, _, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	nopT(A, _, B).
get_ast_node_enclosingJava1(A, B) :-
	operationT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	precedenceT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	returnT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	selectT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	identT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	switchT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	synchronizedT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	throwT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	tryT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	typeCastT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	typeTestT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	whileLoopT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, A) :-
	packageT(A, _), !.
get_ast_node_enclosingJava1(A, B) :-
	classDefT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	paramDefT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	fieldDefT(A, B, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	methodDefT(A, B, _, _, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	toplevelT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	importT(A, _, B), !.

% '\\+=1'('$VAR'(0)):- \+'$VAR'(0)=null
'\\+=1'(null) :- !,
	fail.
'\\+=1'(_).

% addJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', classDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava1(A, B, C, D) :-
	classDefT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [classDefT(A, B, C, D)]).
addJava1(A, B, C, D) :-
	assert(classDefT(A, B, C, D)),
	asserta(rollback(retract(classDefT(A, B, C, D)))),
	markEnclAsDirtyJava1(A, B, C, D).

% 'unifyLists.1'('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7), '$VAR'(8), '$VAR'(9), '$VAR'(10), '$VAR'(11)):-unifyLists(['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)], ['$VAR'(6), '$VAR'(7), '$VAR'(8), '$VAR'(9), '$VAR'(10), '$VAR'(11)])
'unifyLists.1'(A, B, C, D, E, F, A, B, C, D, E, F) :- !.
'unifyLists.1'(_, A, B, C, D, E, _, A, B, C, D, E).

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-markEnclAsDirty('Java', methodDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
markEnclAsDirtyJava1(A, B, C, D, E, F, G) :-
	get_ast_node_termJava1(A, B, C, D, E, F, G, H),
	'\\+checkIfTopLevelJava1'(H),
	(   get_ast_node_enclosingJava1(H, I),
	    '\\+=1'(I),
	    '\\+checkIfTopLevelJava1'(I),
	    assert1T(dirty_tree('Java', I)), !
	;   assert1T(dirty_tree('Java', H)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-get_ast_node_term('Java', '$VAR'(7), methodDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(B, D, F, H, J, L, N, A) :-
	methodDefT(A, C, E, G, I, K, M), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L,
	M=N.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-add('Java', methodDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
addJava1(A, B, C, D, E, F, G) :-
	methodDefT(A, B, C, D, E, F, G), !,
	format('~nWARNING: element: already exists: ~w~n.', [methodDefT(A, B, C, D, E, F, G)]).
addJava1(A, B, C, D, E, F, G) :-
	assert(methodDefT(A, B, C, D, E, F, G)),
	asserta(rollback(retract(methodDefT(A, B, C, D, E, F, G)))),
	markEnclAsDirtyJava1(A, B, C, D, E, F, G).

% 'unifyLists.1'('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-unifyLists(['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], ['$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)])
'unifyLists.1'(A, B, C, D, A, B, C, D) :- !.
'unifyLists.1'(_, A, B, C, _, A, B, C).

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', fieldDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava1(A, B, C, D, E) :-
	get_ast_node_termJava1(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), fieldDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava1(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(B, D, F, H, J, A) :-
	fieldDefT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', fieldDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava1(A, B, C, D, E) :-
	fieldDefT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [fieldDefT(A, B, C, D, E)]).
addJava1(A, B, C, D, E) :-
	assert(fieldDefT(A, B, C, D, E)),
	asserta(rollback(retract(fieldDefT(A, B, C, D, E)))),
	markEnclAsDirtyJava1(A, B, C, D, E).

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', paramDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava2(A, B, C, D) :-
	get_ast_node_termJava2(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava2(_, _, _, _).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), paramDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava2(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(B, D, F, H, A) :-
	paramDefT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava2(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', paramDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava2(A, B, C, D) :-
	paramDefT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [paramDefT(A, B, C, D)]).
addJava2(A, B, C, D) :-
	assert(paramDefT(A, B, C, D)),
	asserta(rollback(retract(paramDefT(A, B, C, D)))),
	markEnclAsDirtyJava2(A, B, C, D).

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-markEnclAsDirty('Java', applyT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
markEnclAsDirtyJava2(A, B, C, D, E, F, G) :-
	get_ast_node_termJava2(A, B, C, D, E, F, G, H),
	'\\+checkIfTopLevelJava1'(H),
	(   get_ast_node_enclosingJava1(H, I),
	    '\\+=1'(I),
	    '\\+checkIfTopLevelJava1'(I),
	    assert1T(dirty_tree('Java', I)), !
	;   assert1T(dirty_tree('Java', H)), !
	).
markEnclAsDirtyJava2(_, _, _, _, _, _, _).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-get_ast_node_term('Java', '$VAR'(7), applyT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(B, D, F, H, J, L, N, A) :-
	applyT(A, C, E, G, I, K, M), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L,
	M=N.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-add('Java', applyT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
addJava2(A, B, C, D, E, F, G) :-
	applyT(A, B, C, D, E, F, G), !,
	format('~nWARNING: element: already exists: ~w~n.', [applyT(A, B, C, D, E, F, G)]).
addJava2(A, B, C, D, E, F, G) :-
	assert(applyT(A, B, C, D, E, F, G)),
	asserta(rollback(retract(applyT(A, B, C, D, E, F, G)))),
	markEnclAsDirtyJava2(A, B, C, D, E, F, G).

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', assertT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava2(A, B, C, D, E) :-
	get_ast_node_termJava2(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava2(_, _, _, _, _).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), assertT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava2(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(B, D, F, H, J, A) :-
	assertT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', assertT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava2(A, B, C, D, E) :-
	assertT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [assertT(A, B, C, D, E)]).
addJava2(A, B, C, D, E) :-
	assert(assertT(A, B, C, D, E)),
	asserta(rollback(retract(assertT(A, B, C, D, E)))),
	markEnclAsDirtyJava2(A, B, C, D, E).

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', assignT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava3(A, B, C, D, E) :-
	get_ast_node_termJava3(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava3(_, _, _, _, _).

% get_ast_node_termJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), assignT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava3(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(B, D, F, H, J, A) :-
	assignT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', assignT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava3(A, B, C, D, E) :-
	assignT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [assignT(A, B, C, D, E)]).
addJava3(A, B, C, D, E) :-
	assert(assignT(A, B, C, D, E)),
	asserta(rollback(retract(assignT(A, B, C, D, E)))),
	markEnclAsDirtyJava3(A, B, C, D, E).

% 'unifyLists.1'('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7), '$VAR'(8), '$VAR'(9)):-unifyLists(['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], ['$VAR'(5), '$VAR'(6), '$VAR'(7), '$VAR'(8), '$VAR'(9)])
'unifyLists.1'(A, B, C, D, E, A, B, C, D, E) :- !.
'unifyLists.1'(_, A, B, C, D, _, A, B, C, D).

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', assignopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava1(A, B, C, D, E, F) :-
	get_ast_node_termJava1(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), assignopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(B, D, F, H, J, L, A) :-
	assignopT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', assignopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava1(A, B, C, D, E, F) :-
	assignopT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [assignopT(A, B, C, D, E, F)]).
addJava1(A, B, C, D, E, F) :-
	assert(assignopT(A, B, C, D, E, F)),
	asserta(rollback(retract(assignopT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava1(A, B, C, D, E, F).

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', blockT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava3(A, B, C, D) :-
	get_ast_node_termJava3(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava3(_, _, _, _).

% get_ast_node_termJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), blockT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava3(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(B, D, F, H, A) :-
	blockT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava3(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', blockT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava3(A, B, C, D) :-
	blockT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [blockT(A, B, C, D)]).
addJava3(A, B, C, D) :-
	assert(blockT(A, B, C, D)),
	asserta(rollback(retract(blockT(A, B, C, D)))),
	markEnclAsDirtyJava3(A, B, C, D).

% markEnclAsDirtyJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', breakT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava4(A, B, C, D, E) :-
	get_ast_node_termJava4(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava4(_, _, _, _, _).

% get_ast_node_termJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), breakT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava4(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(B, D, F, H, J, A) :-
	breakT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', breakT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava4(A, B, C, D, E) :-
	breakT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [breakT(A, B, C, D, E)]).
addJava4(A, B, C, D, E) :-
	assert(breakT(A, B, C, D, E)),
	asserta(rollback(retract(breakT(A, B, C, D, E)))),
	markEnclAsDirtyJava4(A, B, C, D, E).

% markEnclAsDirtyJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', caseT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava4(A, B, C, D) :-
	get_ast_node_termJava4(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava4(_, _, _, _).

% get_ast_node_termJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), caseT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava4(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(B, D, F, H, A) :-
	caseT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava4(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', caseT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava4(A, B, C, D) :-
	caseT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [caseT(A, B, C, D)]).
addJava4(A, B, C, D) :-
	assert(caseT(A, B, C, D)),
	asserta(rollback(retract(caseT(A, B, C, D)))),
	markEnclAsDirtyJava4(A, B, C, D).

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', conditionalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava2(A, B, C, D, E, F) :-
	get_ast_node_termJava2(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava2(_, _, _, _, _, _).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), conditionalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(B, D, F, H, J, L, A) :-
	conditionalT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', conditionalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava2(A, B, C, D, E, F) :-
	conditionalT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [conditionalT(A, B, C, D, E, F)]).
addJava2(A, B, C, D, E, F) :-
	assert(conditionalT(A, B, C, D, E, F)),
	asserta(rollback(retract(conditionalT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava2(A, B, C, D, E, F).

% markEnclAsDirtyJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', continueT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava5(A, B, C, D, E) :-
	get_ast_node_termJava5(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava5(_, _, _, _, _).

% get_ast_node_termJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), continueT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava5(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(B, D, F, H, J, A) :-
	continueT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', continueT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava5(A, B, C, D, E) :-
	continueT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [continueT(A, B, C, D, E)]).
addJava5(A, B, C, D, E) :-
	assert(continueT(A, B, C, D, E)),
	asserta(rollback(retract(continueT(A, B, C, D, E)))),
	markEnclAsDirtyJava5(A, B, C, D, E).

% markEnclAsDirtyJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', doLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava6(A, B, C, D, E) :-
	get_ast_node_termJava6(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava6(_, _, _, _, _).

% get_ast_node_termJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), doLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava6(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(B, D, F, H, J, A) :-
	doLoopT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', doLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava6(A, B, C, D, E) :-
	doLoopT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [doLoopT(A, B, C, D, E)]).
addJava6(A, B, C, D, E) :-
	assert(doLoopT(A, B, C, D, E)),
	asserta(rollback(retract(doLoopT(A, B, C, D, E)))),
	markEnclAsDirtyJava6(A, B, C, D, E).

% markEnclAsDirtyJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', execT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava5(A, B, C, D) :-
	get_ast_node_termJava5(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava5(_, _, _, _).

% get_ast_node_termJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), execT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava5(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(B, D, F, H, A) :-
	execT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava5(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', execT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava5(A, B, C, D) :-
	execT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [execT(A, B, C, D)]).
addJava5(A, B, C, D) :-
	assert(execT(A, B, C, D)),
	asserta(rollback(retract(execT(A, B, C, D)))),
	markEnclAsDirtyJava5(A, B, C, D).

% markEnclAsDirtyJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', catchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava7(A, B, C, D, E) :-
	get_ast_node_termJava7(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava7(_, _, _, _, _).

% get_ast_node_termJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), catchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava7(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(B, D, F, H, J, A) :-
	catchT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', catchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava7(A, B, C, D, E) :-
	catchT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [catchT(A, B, C, D, E)]).
addJava7(A, B, C, D, E) :-
	assert(catchT(A, B, C, D, E)),
	asserta(rollback(retract(catchT(A, B, C, D, E)))),
	markEnclAsDirtyJava7(A, B, C, D, E).

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-markEnclAsDirty('Java', forLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
markEnclAsDirtyJava3(A, B, C, D, E, F, G) :-
	get_ast_node_termJava3(A, B, C, D, E, F, G, H),
	'\\+checkIfTopLevelJava1'(H),
	(   get_ast_node_enclosingJava1(H, I),
	    '\\+=1'(I),
	    '\\+checkIfTopLevelJava1'(I),
	    assert1T(dirty_tree('Java', I)), !
	;   assert1T(dirty_tree('Java', H)), !
	).
markEnclAsDirtyJava3(_, _, _, _, _, _, _).

% get_ast_node_termJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-get_ast_node_term('Java', '$VAR'(7), forLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(B, D, F, H, J, L, N, A) :-
	forLoopT(A, C, E, G, I, K, M), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L,
	M=N.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-add('Java', forLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
addJava3(A, B, C, D, E, F, G) :-
	forLoopT(A, B, C, D, E, F, G), !,
	format('~nWARNING: element: already exists: ~w~n.', [forLoopT(A, B, C, D, E, F, G)]).
addJava3(A, B, C, D, E, F, G) :-
	assert(forLoopT(A, B, C, D, E, F, G)),
	asserta(rollback(retract(forLoopT(A, B, C, D, E, F, G)))),
	markEnclAsDirtyJava3(A, B, C, D, E, F, G).

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', getFieldT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava3(A, B, C, D, E, F) :-
	get_ast_node_termJava3(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava3(_, _, _, _, _, _).

% get_ast_node_termJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), getFieldT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(B, D, F, H, J, L, A) :-
	getFieldT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', getFieldT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava3(A, B, C, D, E, F) :-
	getFieldT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [getFieldT(A, B, C, D, E, F)]).
addJava3(A, B, C, D, E, F) :-
	assert(getFieldT(A, B, C, D, E, F)),
	asserta(rollback(retract(getFieldT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava3(A, B, C, D, E, F).

% markEnclAsDirtyJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', ifT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava4(A, B, C, D, E, F) :-
	get_ast_node_termJava4(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava4(_, _, _, _, _, _).

% get_ast_node_termJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), ifT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(B, D, F, H, J, L, A) :-
	ifT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', ifT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava4(A, B, C, D, E, F) :-
	ifT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [ifT(A, B, C, D, E, F)]).
addJava4(A, B, C, D, E, F) :-
	assert(ifT(A, B, C, D, E, F)),
	asserta(rollback(retract(ifT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava4(A, B, C, D, E, F).

% 'unifyLists.1'('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-unifyLists(['$VAR'(0), '$VAR'(1)], ['$VAR'(2), '$VAR'(3)])
'unifyLists.1'(A, B, A, B) :- !.
'unifyLists.1'(_, A, _, A).

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-markEnclAsDirty('Java', importT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
markEnclAsDirtyJava1(A, B, C) :-
	get_ast_node_termJava1(A, B, C, D),
	'\\+checkIfTopLevelJava1'(D),
	(   get_ast_node_enclosingJava1(D, E),
	    '\\+=1'(E),
	    '\\+checkIfTopLevelJava1'(E),
	    assert1T(dirty_tree('Java', E)), !
	;   assert1T(dirty_tree('Java', D)), !
	).
markEnclAsDirtyJava1(_, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-get_ast_node_term('Java', '$VAR'(3), importT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
get_ast_node_termJava1(_, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(B, D, F, A) :-
	importT(A, C, E), !,
	A=B,
	C=D,
	E=F.
get_ast_node_termJava1(_, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-add('Java', importT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
addJava1(A, B, C) :-
	importT(A, B, C), !,
	format('~nWARNING: element: already exists: ~w~n.', [importT(A, B, C)]).
addJava1(A, B, C) :-
	assert(importT(A, B, C)),
	asserta(rollback(retract(importT(A, B, C)))),
	markEnclAsDirtyJava1(A, B, C).

% markEnclAsDirtyJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', indexedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava8(A, B, C, D, E) :-
	get_ast_node_termJava8(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava8(_, _, _, _, _).

% get_ast_node_termJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), indexedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava8(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava8(B, D, F, H, J, A) :-
	indexedT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', indexedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava8(A, B, C, D, E) :-
	indexedT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [indexedT(A, B, C, D, E)]).
addJava8(A, B, C, D, E) :-
	assert(indexedT(A, B, C, D, E)),
	asserta(rollback(retract(indexedT(A, B, C, D, E)))),
	markEnclAsDirtyJava8(A, B, C, D, E).

% markEnclAsDirtyJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', labelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava9(A, B, C, D, E) :-
	get_ast_node_termJava9(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava9(_, _, _, _, _).

% get_ast_node_termJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), labelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava9(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(B, D, F, H, J, A) :-
	labelT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', labelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava9(A, B, C, D, E) :-
	labelT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [labelT(A, B, C, D, E)]).
addJava9(A, B, C, D, E) :-
	assert(labelT(A, B, C, D, E)),
	asserta(rollback(retract(labelT(A, B, C, D, E)))),
	markEnclAsDirtyJava9(A, B, C, D, E).

% markEnclAsDirtyJava10('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', literalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava10(A, B, C, D, E) :-
	get_ast_node_termJava10(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava10(_, _, _, _, _).

% get_ast_node_termJava10('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), literalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava10(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(B, D, F, H, J, A) :-
	literalT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava10('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', literalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava10(A, B, C, D, E) :-
	literalT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [literalT(A, B, C, D, E)]).
addJava10(A, B, C, D, E) :-
	assert(literalT(A, B, C, D, E)),
	asserta(rollback(retract(literalT(A, B, C, D, E)))),
	markEnclAsDirtyJava10(A, B, C, D, E).

% markEnclAsDirtyJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', localDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava5(A, B, C, D, E, F) :-
	get_ast_node_termJava5(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava5(_, _, _, _, _, _).

% get_ast_node_termJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), localDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(B, D, F, H, J, L, A) :-
	localDefT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', localDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava5(A, B, C, D, E, F) :-
	localDefT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [localDefT(A, B, C, D, E, F)]).
addJava5(A, B, C, D, E, F) :-
	assert(localDefT(A, B, C, D, E, F)),
	asserta(rollback(retract(localDefT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava5(A, B, C, D, E, F).

% markEnclAsDirtyJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', newArrayT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava6(A, B, C, D, E, F) :-
	get_ast_node_termJava6(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava6(_, _, _, _, _, _).

% get_ast_node_termJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), newArrayT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(B, D, F, H, J, L, A) :-
	newArrayT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', newArrayT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava6(A, B, C, D, E, F) :-
	newArrayT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [newArrayT(A, B, C, D, E, F)]).
addJava6(A, B, C, D, E, F) :-
	assert(newArrayT(A, B, C, D, E, F)),
	asserta(rollback(retract(newArrayT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava6(A, B, C, D, E, F).

% 'unifyLists.1'('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7), '$VAR'(8), '$VAR'(9), '$VAR'(10), '$VAR'(11), '$VAR'(12), '$VAR'(13)):-unifyLists(['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)], ['$VAR'(7), '$VAR'(8), '$VAR'(9), '$VAR'(10), '$VAR'(11), '$VAR'(12), '$VAR'(13)])
'unifyLists.1'(A, B, C, D, E, F, G, A, B, C, D, E, F, G) :- !.
'unifyLists.1'(_, A, B, C, D, E, F, _, A, B, C, D, E, F).

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-markEnclAsDirty('Java', newClassT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)))
markEnclAsDirtyJava1(A, B, C, D, E, F, G, H) :-
	get_ast_node_termJava1(A, B, C, D, E, F, G, H, I),
	'\\+checkIfTopLevelJava1'(I),
	(   get_ast_node_enclosingJava1(I, J),
	    '\\+=1'(J),
	    '\\+checkIfTopLevelJava1'(J),
	    assert1T(dirty_tree('Java', J)), !
	;   assert1T(dirty_tree('Java', I)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _, _, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7), '$VAR'(8)):-get_ast_node_term('Java', '$VAR'(8), newClassT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)))
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(B, D, F, H, J, L, N, P, A) :-
	newClassT(A, C, E, G, I, K, M, O), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L,
	M=N,
	O=P.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-add('Java', newClassT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)))
addJava1(A, B, C, D, E, F, G, H) :-
	newClassT(A, B, C, D, E, F, G, H), !,
	format('~nWARNING: element: already exists: ~w~n.', [newClassT(A, B, C, D, E, F, G, H)]).
addJava1(A, B, C, D, E, F, G, H) :-
	assert(newClassT(A, B, C, D, E, F, G, H)),
	asserta(rollback(retract(newClassT(A, B, C, D, E, F, G, H)))),
	markEnclAsDirtyJava1(A, B, C, D, E, F, G, H).

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2)):-markEnclAsDirty('Java', nopT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
markEnclAsDirtyJava2(A, B, C) :-
	get_ast_node_termJava2(A, B, C, D),
	'\\+checkIfTopLevelJava1'(D),
	(   get_ast_node_enclosingJava1(D, E),
	    '\\+=1'(E),
	    '\\+checkIfTopLevelJava1'(E),
	    assert1T(dirty_tree('Java', E)), !
	;   assert1T(dirty_tree('Java', D)), !
	).
markEnclAsDirtyJava2(_, _, _).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-get_ast_node_term('Java', '$VAR'(3), nopT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
get_ast_node_termJava2(_, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(B, D, F, A) :-
	nopT(A, C, E), !,
	A=B,
	C=D,
	E=F.
get_ast_node_termJava2(_, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava2('$VAR'(0), '$VAR'(1), '$VAR'(2)):-add('Java', nopT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
addJava2(A, B, C) :-
	nopT(A, B, C), !,
	format('~nWARNING: element: already exists: ~w~n.', [nopT(A, B, C)]).
addJava2(A, B, C) :-
	assert(nopT(A, B, C)),
	asserta(rollback(retract(nopT(A, B, C)))),
	markEnclAsDirtyJava2(A, B, C).

% markEnclAsDirtyJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', operationT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava7(A, B, C, D, E, F) :-
	get_ast_node_termJava7(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava7(_, _, _, _, _, _).

% get_ast_node_termJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), operationT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava7(B, D, F, H, J, L, A) :-
	operationT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', operationT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava7(A, B, C, D, E, F) :-
	operationT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [operationT(A, B, C, D, E, F)]).
addJava7(A, B, C, D, E, F) :-
	assert(operationT(A, B, C, D, E, F)),
	asserta(rollback(retract(operationT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava7(A, B, C, D, E, F).

% markEnclAsDirtyJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', precedenceT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava6(A, B, C, D) :-
	get_ast_node_termJava6(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava6(_, _, _, _).

% get_ast_node_termJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), precedenceT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava6(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(B, D, F, H, A) :-
	precedenceT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava6(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', precedenceT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava6(A, B, C, D) :-
	precedenceT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [precedenceT(A, B, C, D)]).
addJava6(A, B, C, D) :-
	assert(precedenceT(A, B, C, D)),
	asserta(rollback(retract(precedenceT(A, B, C, D)))),
	markEnclAsDirtyJava6(A, B, C, D).

% markEnclAsDirtyJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', returnT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava7(A, B, C, D) :-
	get_ast_node_termJava7(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava7(_, _, _, _).

% get_ast_node_termJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), returnT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava7(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(B, D, F, H, A) :-
	returnT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava7(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', returnT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava7(A, B, C, D) :-
	returnT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [returnT(A, B, C, D)]).
addJava7(A, B, C, D) :-
	assert(returnT(A, B, C, D)),
	asserta(rollback(retract(returnT(A, B, C, D)))),
	markEnclAsDirtyJava7(A, B, C, D).

% markEnclAsDirtyJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', selectT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava8(A, B, C, D, E, F) :-
	get_ast_node_termJava8(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava8(_, _, _, _, _, _).

% get_ast_node_termJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), selectT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(B, D, F, H, J, L, A) :-
	selectT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', selectT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava8(A, B, C, D, E, F) :-
	selectT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [selectT(A, B, C, D, E, F)]).
addJava8(A, B, C, D, E, F) :-
	assert(selectT(A, B, C, D, E, F)),
	asserta(rollback(retract(selectT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava8(A, B, C, D, E, F).

% markEnclAsDirtyJava11('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', identT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava11(A, B, C, D, E) :-
	get_ast_node_termJava11(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava11(_, _, _, _, _).

% get_ast_node_termJava11('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), identT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava11(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(B, D, F, H, J, A) :-
	identT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava11('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', identT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava11(A, B, C, D, E) :-
	identT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [identT(A, B, C, D, E)]).
addJava11(A, B, C, D, E) :-
	assert(identT(A, B, C, D, E)),
	asserta(rollback(retract(identT(A, B, C, D, E)))),
	markEnclAsDirtyJava11(A, B, C, D, E).

% markEnclAsDirtyJava12('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', switchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava12(A, B, C, D, E) :-
	get_ast_node_termJava12(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava12(_, _, _, _, _).

% get_ast_node_termJava12('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), switchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava12(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(B, D, F, H, J, A) :-
	switchT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava12('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', switchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava12(A, B, C, D, E) :-
	switchT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [switchT(A, B, C, D, E)]).
addJava12(A, B, C, D, E) :-
	assert(switchT(A, B, C, D, E)),
	asserta(rollback(retract(switchT(A, B, C, D, E)))),
	markEnclAsDirtyJava12(A, B, C, D, E).

% markEnclAsDirtyJava13('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', synchronizedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava13(A, B, C, D, E) :-
	get_ast_node_termJava13(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava13(_, _, _, _, _).

% get_ast_node_termJava13('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), synchronizedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava13(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(B, D, F, H, J, A) :-
	synchronizedT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava13('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', synchronizedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava13(A, B, C, D, E) :-
	synchronizedT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [synchronizedT(A, B, C, D, E)]).
addJava13(A, B, C, D, E) :-
	assert(synchronizedT(A, B, C, D, E)),
	asserta(rollback(retract(synchronizedT(A, B, C, D, E)))),
	markEnclAsDirtyJava13(A, B, C, D, E).

% markEnclAsDirtyJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', throwT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava8(A, B, C, D) :-
	get_ast_node_termJava8(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava8(_, _, _, _).

% get_ast_node_termJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), throwT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava8(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(B, D, F, H, A) :-
	throwT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava8(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', throwT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava8(A, B, C, D) :-
	throwT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [throwT(A, B, C, D)]).
addJava8(A, B, C, D) :-
	assert(throwT(A, B, C, D)),
	asserta(rollback(retract(throwT(A, B, C, D)))),
	markEnclAsDirtyJava8(A, B, C, D).

% markEnclAsDirtyJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', toplevelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava9(A, B, C, D) :-
	get_ast_node_termJava9(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava9(_, _, _, _).

% get_ast_node_termJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), toplevelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava9(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(B, D, F, H, A) :-
	toplevelT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava9(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', toplevelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava9(A, B, C, D) :-
	toplevelT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [toplevelT(A, B, C, D)]).
addJava9(A, B, C, D) :-
	assert(toplevelT(A, B, C, D)),
	asserta(rollback(retract(toplevelT(A, B, C, D)))),
	markEnclAsDirtyJava9(A, B, C, D).

% markEnclAsDirtyJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', tryT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava9(A, B, C, D, E, F) :-
	get_ast_node_termJava9(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava9(_, _, _, _, _, _).

% get_ast_node_termJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), tryT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(B, D, F, H, J, L, A) :-
	tryT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', tryT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava9(A, B, C, D, E, F) :-
	tryT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [tryT(A, B, C, D, E, F)]).
addJava9(A, B, C, D, E, F) :-
	assert(tryT(A, B, C, D, E, F)),
	asserta(rollback(retract(tryT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava9(A, B, C, D, E, F).

% markEnclAsDirtyJava14('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', typeCastT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava14(A, B, C, D, E) :-
	get_ast_node_termJava14(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava14(_, _, _, _, _).

% get_ast_node_termJava14('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), typeCastT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava14(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(B, D, F, H, J, A) :-
	typeCastT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava14('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', typeCastT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava14(A, B, C, D, E) :-
	typeCastT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [typeCastT(A, B, C, D, E)]).
addJava14(A, B, C, D, E) :-
	assert(typeCastT(A, B, C, D, E)),
	asserta(rollback(retract(typeCastT(A, B, C, D, E)))),
	markEnclAsDirtyJava14(A, B, C, D, E).

% markEnclAsDirtyJava15('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', typeTestT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava15(A, B, C, D, E) :-
	get_ast_node_termJava15(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava15(_, _, _, _, _).

% get_ast_node_termJava15('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), typeTestT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava15(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(B, D, F, H, J, A) :-
	typeTestT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% addJava15('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', typeTestT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava15(A, B, C, D, E) :-
	typeTestT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [typeTestT(A, B, C, D, E)]).
addJava15(A, B, C, D, E) :-
	assert(typeTestT(A, B, C, D, E)),
	asserta(rollback(retract(typeTestT(A, B, C, D, E)))),
	markEnclAsDirtyJava15(A, B, C, D, E).

% markEnclAsDirtyJava16('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', whileLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava16(A, B, C, D, E) :-
	get_ast_node_termJava16(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava16(_, _, _, _, _).

% get_ast_node_termJava16('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), whileLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava16(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(B, D, F, H, J, A) :-
	whileLoopT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.

% addJava16('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', whileLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava16(A, B, C, D, E) :-
	whileLoopT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [whileLoopT(A, B, C, D, E)]).
addJava16(A, B, C, D, E) :-
	assert(whileLoopT(A, B, C, D, E)),
	asserta(rollback(retract(whileLoopT(A, B, C, D, E)))),
	markEnclAsDirtyJava16(A, B, C, D, E).
