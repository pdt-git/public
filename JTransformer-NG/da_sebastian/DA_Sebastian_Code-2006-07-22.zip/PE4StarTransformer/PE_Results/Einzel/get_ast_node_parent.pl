get_ast_node_parent('Java', A, B) :-
	get_ast_node_parentJava1(A, B).

% get_ast_node_parentJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_parent('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_parentJava1(A, B) :-
	classDefT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	methodDefT(A, B, _, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	fieldDefT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	paramDefT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	applyT(A, B, _, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	assertT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	assignT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	assignopT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	blockT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	breakT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	caseT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	conditionalT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	continueT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	doLoopT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	execT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	catchT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	forLoopT(A, B, _, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	getFieldT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	ifT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	importT(A, B, _).
get_ast_node_parentJava1(A, B) :-
	indexedT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	labelT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	literalT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	localDefT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	newArrayT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	newClassT(A, B, _, _, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	nopT(A, B, _).
get_ast_node_parentJava1(A, B) :-
	operationT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	precedenceT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	returnT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	selectT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	identT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	switchT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	synchronizedT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	throwT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	toplevelT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	tryT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	typeCastT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	typeTestT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	whileLoopT(A, B, _, _, _).
get_ast_node_parentJava1(A, null) :-
	packageT(A, _).

% original definition
:- dynamic classDefT/4.

% original definition
:- dynamic methodDefT/7.

% original definition
:- dynamic fieldDefT/5.

% original definition
:- dynamic paramDefT/4.

% original definition
:- dynamic applyT/7.

% original definition
:- dynamic assertT/5.

% original definition
:- dynamic assignT/5.

% original definition
:- dynamic assignopT/6.

% original definition
:- dynamic blockT/4.

% original definition
:- dynamic breakT/5.

% original definition
:- dynamic caseT/4.

% original definition
:- dynamic conditionalT/6.

% original definition
:- dynamic continueT/5.

% original definition
:- dynamic doLoopT/5.

% original definition
:- dynamic execT/4.

% original definition
:- dynamic catchT/5.

% original definition
:- dynamic forLoopT/7.

% original definition
:- dynamic getFieldT/6.

% original definition
:- dynamic ifT/6.

% original definition
:- dynamic importT/3.

% original definition
:- dynamic indexedT/5.

% original definition
:- dynamic labelT/5.

% original definition
:- dynamic literalT/5.

% original definition
:- dynamic localDefT/6.

% original definition
:- dynamic newArrayT/6.

% original definition
:- dynamic newClassT/8.

% original definition
:- dynamic nopT/3.

% original definition
:- dynamic operationT/6.

% original definition
:- dynamic precedenceT/4.

% original definition
:- dynamic returnT/4.

% original definition
:- dynamic selectT/6.

% original definition
:- dynamic identT/5.

% original definition
:- dynamic switchT/5.

% original definition
:- dynamic synchronizedT/5.

% original definition
:- dynamic throwT/4.

% original definition
:- dynamic toplevelT/4.

% original definition
:- dynamic tryT/6.

% original definition
:- dynamic typeCastT/5.

% original definition
:- dynamic typeTestT/5.

% original definition
:- dynamic whileLoopT/5.

% original definition
:- dynamic packageT/2.
packageT(null, '').
