tree_attributes('Java', A, B, C) :-
	tree_attributesJava1(A, B, C).

% tree_attributesJava1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-tree_attributes('Java', '$VAR'(0), '$VAR'(1), '$VAR'(2))
tree_attributesJava1(A, B, E) :-
	packageT(A, _),
	B=packageT,
	get_ast_node_termJava1(A, C),
	C=..[packageT|D],
	(   D=[],
	    E=[]
	;   D=[_|F],
	    'extract_attributes_.ast_argname1'(F, E)
	).
tree_attributesJava1(A, B, E) :-
	classDefT(A, _, _, _),
	B=classDefT,
	get_ast_node_termJava1(A, C),
	C=..[classDefT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _|F],
	    'extract_attributes_.ast_argname2'(F, E)
	).
tree_attributesJava1(A, B, E) :-
	methodDefT(A, _, _, _, _, _, _),
	B=methodDefT,
	get_ast_node_termJava1(A, C),
	C=..[methodDefT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _|F],
	    'extract_attributes_.ast_argname3'(F, E)
	).
tree_attributesJava1(A, B, E) :-
	fieldDefT(A, _, _, _, _),
	B=fieldDefT,
	get_ast_node_termJava1(A, C),
	C=..[fieldDefT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _|F],
	    'extract_attributes_.ast_argtype2'(F, E)
	).
tree_attributesJava1(A, B, E) :-
	paramDefT(A, _, _, _),
	B=paramDefT,
	get_ast_node_termJava1(A, C),
	C=..[paramDefT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _|F],
	    'extract_attributes_.ast_argtype3'(F, E)
	).
tree_attributesJava1(A, B, E) :-
	applyT(A, _, _, _, _, _, _),
	B=applyT,
	get_ast_node_termJava1(A, C),
	C=..[applyT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _],
	    E=[]
	;   D=[_, _, _],
	    E=[]
	;   D=[_, _, _, _|F],
	    'extract_attributes_.ast_argname6'(F, E)
	).
tree_attributesJava1(A, B, C) :-
	assertT(A, _, _, _, _),
	B=assertT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[assertT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	;   E=[_, _, _, _, _]
	).
tree_attributesJava1(A, B, C) :-
	assignT(A, _, _, _, _),
	B=assignT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[assignT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	;   E=[_, _, _, _, _]
	).
tree_attributesJava1(A, B, E) :-
	assignopT(A, _, _, _, _, _),
	B=assignopT,
	get_ast_node_termJava1(A, C),
	C=..[assignopT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _],
	    E=[]
	;   D=[_, _, _],
	    E=[]
	;   D=[_, _, _, _|F],
	    'extract_attributes_.ast_argoperator1'(F, E)
	).
tree_attributesJava1(A, B, C) :-
	blockT(A, _, _, _),
	B=blockT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[blockT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	).
tree_attributesJava1(A, B, E) :-
	breakT(A, _, _, _, _),
	B=breakT,
	get_ast_node_termJava1(A, C),
	C=..[breakT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _],
	    E=[]
	;   D=[_, _, _|F],
	    'extract_attributes_.ast_arglabel1'(F, E)
	).
tree_attributesJava1(A, B, C) :-
	caseT(A, _, _, _),
	B=caseT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[caseT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	).
tree_attributesJava1(A, B, C) :-
	conditionalT(A, _, _, _, _, _),
	B=conditionalT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[conditionalT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	;   E=[_, _, _, _, _]
	;   E=[_, _, _, _, _, _]
	).
tree_attributesJava1(A, B, E) :-
	continueT(A, _, _, _, _),
	B=continueT,
	get_ast_node_termJava1(A, C),
	C=..[continueT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _],
	    E=[]
	;   D=[_, _, _|F],
	    'extract_attributes_.ast_arglabel1'(F, E)
	).
tree_attributesJava1(A, B, C) :-
	doLoopT(A, _, _, _, _),
	B=doLoopT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[doLoopT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	;   E=[_, _, _, _, _]
	).
tree_attributesJava1(A, B, C) :-
	execT(A, _, _, _),
	B=execT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[execT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	).
tree_attributesJava1(A, B, C) :-
	catchT(A, _, _, _, _),
	B=catchT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[catchT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	;   E=[_, _, _, _, _]
	).
tree_attributesJava1(A, B, C) :-
	forLoopT(A, _, _, _, _, _, _),
	B=forLoopT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[forLoopT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	;   E=[_, _, _, _, _]
	;   E=[_, _, _, _, _, _]
	;   E=[_, _, _, _, _, _, _]
	).
tree_attributesJava1(A, B, E) :-
	getFieldT(A, _, _, _, _, _),
	B=getFieldT,
	get_ast_node_termJava1(A, C),
	C=..[getFieldT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _],
	    E=[]
	;   D=[_, _, _],
	    E=[]
	;   D=[_, _, _, _|F],
	    'extract_attributes_.ast_argname7'(F, E)
	).
tree_attributesJava1(A, B, C) :-
	ifT(A, _, _, _, _, _),
	B=ifT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[ifT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	;   E=[_, _, _, _, _]
	;   E=[_, _, _, _, _, _]
	).
tree_attributesJava1(A, B, C) :-
	importT(A, _, _),
	B=importT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[importT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	).
tree_attributesJava1(A, B, C) :-
	indexedT(A, _, _, _, _),
	B=indexedT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[indexedT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	;   E=[_, _, _, _, _]
	).
tree_attributesJava1(A, B, E) :-
	labelT(A, _, _, _, _),
	B=labelT,
	get_ast_node_termJava1(A, C),
	C=..[labelT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _],
	    E=[]
	;   D=[_, _, _],
	    E=[]
	;   D=[_, _, _, _|F],
	    'extract_attributes_.ast_arglabel2'(F, E)
	).
tree_attributesJava1(A, B, E) :-
	literalT(A, _, _, _, _),
	B=literalT,
	get_ast_node_termJava1(A, C),
	C=..[literalT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _],
	    E=[]
	;   D=[_, _, _|F],
	    'extract_attributes_.ast_argtype4'(F, E)
	).
tree_attributesJava1(A, B, E) :-
	localDefT(A, _, _, _, _, _),
	B=localDefT,
	get_ast_node_termJava1(A, C),
	C=..[localDefT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _],
	    E=[]
	;   D=[_, _, _|F],
	    'extract_attributes_.ast_argtype5'(F, E)
	).
tree_attributesJava1(A, B, E) :-
	newArrayT(A, _, _, _, _, _),
	B=newArrayT,
	get_ast_node_termJava1(A, C),
	C=..[newArrayT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _],
	    E=[]
	;   D=[_, _, _],
	    E=[]
	;   D=[_, _, _, _],
	    E=[]
	;   D=[_, _, _, _, _|F],
	    'extract_attributes_.ast_argtype6'(F, E)
	).
tree_attributesJava1(A, B, C) :-
	newClassT(A, _, _, _, _, _, _, _),
	B=newClassT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[newClassT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	;   E=[_, _, _, _, _]
	;   E=[_, _, _, _, _, _]
	;   E=[_, _, _, _, _, _, _]
	;   E=[_, _, _, _, _, _, _, _]
	).
tree_attributesJava1(A, B, C) :-
	nopT(A, _, _),
	B=nopT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[nopT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	).
tree_attributesJava1(A, B, E) :-
	operationT(A, _, _, _, _, _),
	B=operationT,
	get_ast_node_termJava1(A, C),
	C=..[operationT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _],
	    E=[]
	;   D=[_, _, _],
	    E=[]
	;   D=[_, _, _, _|F],
	    'extract_attributes_.ast_argop1'(F, E)
	).
tree_attributesJava1(A, B, C) :-
	precedenceT(A, _, _, _),
	B=precedenceT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[precedenceT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	).
tree_attributesJava1(A, B, C) :-
	returnT(A, _, _, _),
	B=returnT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[returnT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	).
tree_attributesJava1(A, B, E) :-
	selectT(A, _, _, _, _, _),
	B=selectT,
	get_ast_node_termJava1(A, C),
	C=..[selectT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _],
	    E=[]
	;   D=[_, _, _|F],
	    'extract_attributes_.ast_argname9'(F, E)
	).
tree_attributesJava1(A, B, E) :-
	identT(A, _, _, _, _),
	B=identT,
	get_ast_node_termJava1(A, C),
	C=..[identT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _],
	    E=[]
	;   D=[_, _, _|F],
	    'extract_attributes_.ast_argname10'(F, E)
	).
tree_attributesJava1(A, B, C) :-
	switchT(A, _, _, _, _),
	B=switchT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[switchT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	;   E=[_, _, _, _, _]
	).
tree_attributesJava1(A, B, C) :-
	synchronizedT(A, _, _, _, _),
	B=synchronizedT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[synchronizedT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	;   E=[_, _, _, _, _]
	).
tree_attributesJava1(A, B, C) :-
	throwT(A, _, _, _),
	B=throwT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[throwT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	).
tree_attributesJava1(A, B, E) :-
	toplevelT(A, _, _, _),
	B=toplevelT,
	get_ast_node_termJava1(A, C),
	C=..[toplevelT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _|F],
	    'extract_attributes_.ast_argfile1'(F, E)
	).
tree_attributesJava1(A, B, C) :-
	tryT(A, _, _, _, _, _),
	B=tryT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[tryT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	;   E=[_, _, _, _, _]
	;   E=[_, _, _, _, _, _]
	).
tree_attributesJava1(A, B, E) :-
	typeCastT(A, _, _, _, _),
	B=typeCastT,
	get_ast_node_termJava1(A, C),
	C=..[typeCastT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _],
	    E=[]
	;   D=[_, _, _|F],
	    'extract_attributes_.ast_argtype7'(F, E)
	).
tree_attributesJava1(A, B, E) :-
	typeTestT(A, _, _, _, _),
	B=typeTestT,
	get_ast_node_termJava1(A, C),
	C=..[typeTestT|D],
	(   D=[],
	    E=[]
	;   D=[_],
	    E=[]
	;   D=[_, _],
	    E=[]
	;   D=[_, _, _|F],
	    'extract_attributes_.ast_argtype7'(F, E)
	).
tree_attributesJava1(A, B, C) :-
	whileLoopT(A, _, _, _, _),
	B=whileLoopT,
	get_ast_node_termJava1(A, D),
	C=[],
	D=..[whileLoopT|E],
	(   E=[]
	;   E=[_]
	;   E=[_, _]
	;   E=[_, _, _]
	;   E=[_, _, _, _]
	;   E=[_, _, _, _, _]
	).

% original definition
:- dynamic packageT/2.
packageT(null, '').

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_term('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_termJava1(A, B) :-
	packageT(A, C), !,
	B=packageT(A, C).
get_ast_node_termJava1(A, B) :-
	classDefT(A, C, D, E), !,
	B=classDefT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	methodDefT(A, C, D, E, F, G, H), !,
	B=methodDefT(A, C, D, E, F, G, H).
get_ast_node_termJava1(A, B) :-
	fieldDefT(A, C, D, E, F), !,
	B=fieldDefT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	paramDefT(A, C, D, E), !,
	B=paramDefT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	applyT(A, C, D, E, F, G, H), !,
	B=applyT(A, C, D, E, F, G, H).
get_ast_node_termJava1(A, B) :-
	assertT(A, C, D, E, F), !,
	B=assertT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	assignT(A, C, D, E, F), !,
	B=assignT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	assignopT(A, C, D, E, F, G), !,
	B=assignopT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	blockT(A, C, D, E), !,
	B=blockT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	breakT(A, C, D, E, F), !,
	B=breakT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	caseT(A, C, D, E), !,
	B=caseT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	conditionalT(A, C, D, E, F, G), !,
	B=conditionalT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	continueT(A, C, D, E, F), !,
	B=continueT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	doLoopT(A, C, D, E, F), !,
	B=doLoopT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	execT(A, C, D, E), !,
	B=execT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	catchT(A, C, D, E, F), !,
	B=catchT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	forLoopT(A, C, D, E, F, G, H), !,
	B=forLoopT(A, C, D, E, F, G, H).
get_ast_node_termJava1(A, B) :-
	getFieldT(A, C, D, E, F, G), !,
	B=getFieldT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	ifT(A, C, D, E, F, G), !,
	B=ifT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	importT(A, C, D), !,
	B=importT(A, C, D).
get_ast_node_termJava1(A, B) :-
	indexedT(A, C, D, E, F), !,
	B=indexedT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	labelT(A, C, D, E, F), !,
	B=labelT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	literalT(A, C, D, E, F), !,
	B=literalT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	localDefT(A, C, D, E, F, G), !,
	B=localDefT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	newArrayT(A, C, D, E, F, G), !,
	B=newArrayT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	newClassT(A, C, D, E, F, G, H, I), !,
	B=newClassT(A, C, D, E, F, G, H, I).
get_ast_node_termJava1(A, B) :-
	nopT(A, C, D), !,
	B=nopT(A, C, D).
get_ast_node_termJava1(A, B) :-
	operationT(A, C, D, E, F, G), !,
	B=operationT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	precedenceT(A, C, D, E), !,
	B=precedenceT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	returnT(A, C, D, E), !,
	B=returnT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	selectT(A, C, D, E, F, G), !,
	B=selectT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	identT(A, C, D, E, F), !,
	B=identT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	switchT(A, C, D, E, F), !,
	B=switchT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	synchronizedT(A, C, D, E, F), !,
	B=synchronizedT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	throwT(A, C, D, E), !,
	B=throwT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	toplevelT(A, C, D, E), !,
	B=toplevelT(A, C, D, E).
get_ast_node_termJava1(A, B) :-
	tryT(A, C, D, E, F, G), !,
	B=tryT(A, C, D, E, F, G).
get_ast_node_termJava1(A, B) :-
	typeCastT(A, C, D, E, F), !,
	B=typeCastT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	typeTestT(A, C, D, E, F), !,
	B=typeTestT(A, C, D, E, F).
get_ast_node_termJava1(A, B) :-
	whileLoopT(A, C, D, E, F), !,
	B=whileLoopT(A, C, D, E, F).

% original definition
:- dynamic classDefT/4.

% original definition
:- dynamic methodDefT/7.

% original definition
:- dynamic fieldDefT/5.

% original definition
:- dynamic paramDefT/4.

% original definition
:- dynamic applyT/7.

% original definition
:- dynamic assertT/5.

% original definition
:- dynamic assignT/5.

% original definition
:- dynamic assignopT/6.

% original definition
:- dynamic blockT/4.

% original definition
:- dynamic breakT/5.

% original definition
:- dynamic caseT/4.

% original definition
:- dynamic conditionalT/6.

% original definition
:- dynamic continueT/5.

% original definition
:- dynamic doLoopT/5.

% original definition
:- dynamic execT/4.

% original definition
:- dynamic catchT/5.

% original definition
:- dynamic forLoopT/7.

% original definition
:- dynamic getFieldT/6.

% original definition
:- dynamic ifT/6.

% original definition
:- dynamic importT/3.

% original definition
:- dynamic indexedT/5.

% original definition
:- dynamic labelT/5.

% original definition
:- dynamic literalT/5.

% original definition
:- dynamic localDefT/6.

% original definition
:- dynamic newArrayT/6.

% original definition
:- dynamic newClassT/8.

% original definition
:- dynamic nopT/3.

% original definition
:- dynamic operationT/6.

% original definition
:- dynamic precedenceT/4.

% original definition
:- dynamic returnT/4.

% original definition
:- dynamic selectT/6.

% original definition
:- dynamic identT/5.

% original definition
:- dynamic switchT/5.

% original definition
:- dynamic synchronizedT/5.

% original definition
:- dynamic throwT/4.

% original definition
:- dynamic toplevelT/4.

% original definition
:- dynamic tryT/6.

% original definition
:- dynamic typeCastT/5.

% original definition
:- dynamic typeTestT/5.

% original definition
:- dynamic whileLoopT/5.

% 'extract_attributes_.ast_argname1'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(name, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argname1'([], []).
'extract_attributes_.ast_argname1'([A|B], [A|C]) :- !,
	B=[],
	C=[].
'extract_attributes_.ast_argname1'([_], []).

% 'extract_attributes_.ast_argname2'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argname2'([], []).
'extract_attributes_.ast_argname2'([A|B], [A|C]) :- !,
	(   B=[],
	    C=[]
	;   B=[_],
	    C=[]
	;   B=[_, _],
	    C=[]
	;   B=[_, _, _|D],
	    'extract_attributes_.ast_arghasModif1'(D, C)
	).
'extract_attributes_.ast_argname2'([_], []).
'extract_attributes_.ast_argname2'([_, _], []).
'extract_attributes_.ast_argname2'([_, _, _], []).
'extract_attributes_.ast_argname2'([_, _, _, _|A], B) :-
	'extract_attributes_.ast_arghasModif1'(A, B).

% 'extract_attributes_.ast_arghasModif1'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_arghasModif1'([], []).
'extract_attributes_.ast_arghasModif1'([A|C], [A|B]) :- !,
	B=[],
	(   C=[]
	;   C=[_]
	;   C=[_, _]
	).
'extract_attributes_.ast_arghasModif1'([_], []).
'extract_attributes_.ast_arghasModif1'([_, _], []).
'extract_attributes_.ast_arghasModif1'([_, _, _], []).

% 'extract_attributes_.ast_argname3'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argname3'([], []).
'extract_attributes_.ast_argname3'([A|B], [A|C]) :- !,
	(   B=[],
	    C=[]
	;   B=[_|D],
	    'extract_attributes_.ast_argtype1'(D, C)
	).
'extract_attributes_.ast_argname3'([_], []).
'extract_attributes_.ast_argname3'([_, _|A], B) :-
	'extract_attributes_.ast_argtype1'(A, B).

% 'extract_attributes_.ast_argtype1'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argtype1'([], []).
'extract_attributes_.ast_argtype1'([A|B], [A|C]) :- !,
	(   B=[],
	    C=[]
	;   B=[_],
	    C=[]
	;   B=[_, _|D],
	    'extract_attributes_.ast_arghasModif2'(D, C)
	).
'extract_attributes_.ast_argtype1'([_], []).
'extract_attributes_.ast_argtype1'([_, _], []).
'extract_attributes_.ast_argtype1'([_, _, _|A], B) :-
	'extract_attributes_.ast_arghasModif2'(A, B).

% 'extract_attributes_.ast_arghasModif2'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_arghasModif2'([], []).
'extract_attributes_.ast_arghasModif2'([A|B], [A|C]) :- !,
	B=[],
	C=[].
'extract_attributes_.ast_arghasModif2'([_], []).

% 'extract_attributes_.ast_argtype2'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argtype2'([], []).
'extract_attributes_.ast_argtype2'([A|B], [A|C]) :- !,
	'extract_attributes_.ast_argname4'(B, C).
'extract_attributes_.ast_argtype2'([_|A], B) :-
	'extract_attributes_.ast_argname4'(A, B).

% 'extract_attributes_.ast_argname4'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argname4'([], []).
'extract_attributes_.ast_argname4'([A|B], [A|C]) :- !,
	(   B=[],
	    C=[]
	;   B=[_|D],
	    'extract_attributes_.ast_arghasModif2'(D, C)
	).
'extract_attributes_.ast_argname4'([_], []).
'extract_attributes_.ast_argname4'([_, _|A], B) :-
	'extract_attributes_.ast_arghasModif2'(A, B).

% 'extract_attributes_.ast_argtype3'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argtype3'([], []).
'extract_attributes_.ast_argtype3'([A|B], [A|C]) :- !,
	'extract_attributes_.ast_argname5'(B, C).
'extract_attributes_.ast_argtype3'([_|A], B) :-
	'extract_attributes_.ast_argname5'(A, B).

% 'extract_attributes_.ast_argname5'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argname5'([], []).
'extract_attributes_.ast_argname5'([A|B], [A|C]) :- !,
	'extract_attributes_.ast_arghasModif2'(B, C).
'extract_attributes_.ast_argname5'([_|A], B) :-
	'extract_attributes_.ast_arghasModif2'(A, B).

% 'extract_attributes_.ast_argname6'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argname6'([], []).
'extract_attributes_.ast_argname6'([A|C], [A|B]) :- !,
	B=[],
	(   C=[]
	;   C=[_]
	;   C=[_, _]
	).
'extract_attributes_.ast_argname6'([_], []).
'extract_attributes_.ast_argname6'([_, _], []).
'extract_attributes_.ast_argname6'([_, _, _], []).

% 'extract_attributes_.ast_argoperator1'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argoperator1'([], []).
'extract_attributes_.ast_argoperator1'([A|C], [A|B]) :- !,
	B=[],
	(   C=[]
	;   C=[_]
	).
'extract_attributes_.ast_argoperator1'([_], []).
'extract_attributes_.ast_argoperator1'([_, _], []).

% 'extract_attributes_.ast_arglabel1'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_arglabel1'([], []).
'extract_attributes_.ast_arglabel1'([A|C], [A|B]) :- !,
	B=[],
	(   C=[]
	;   C=[_]
	).
'extract_attributes_.ast_arglabel1'([_], []).
'extract_attributes_.ast_arglabel1'([_, _], []).

% 'extract_attributes_.ast_argname7'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argname7'([], []).
'extract_attributes_.ast_argname7'([A|C], [A|B]) :- !,
	B=[],
	(   C=[]
	;   C=[_]
	).
'extract_attributes_.ast_argname7'([_], []).
'extract_attributes_.ast_argname7'([_, _], []).

% 'extract_attributes_.ast_arglabel2'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(label, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_arglabel2'([], []).
'extract_attributes_.ast_arglabel2'([A|B], [A|C]) :- !,
	B=[],
	C=[].
'extract_attributes_.ast_arglabel2'([_], []).

% 'extract_attributes_.ast_argtype4'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(value, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argtype4'([], []).
'extract_attributes_.ast_argtype4'([A|B], [A|C]) :- !,
	'extract_attributes_.ast_argvalue1'(B, C).
'extract_attributes_.ast_argtype4'([_|A], B) :-
	'extract_attributes_.ast_argvalue1'(A, B).

% 'extract_attributes_.ast_argvalue1'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(value, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argvalue1'([], []).
'extract_attributes_.ast_argvalue1'([A|B], [A|C]) :- !,
	B=[],
	C=[].
'extract_attributes_.ast_argvalue1'([_], []).

% 'extract_attributes_.ast_argtype5'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argtype5'([], []).
'extract_attributes_.ast_argtype5'([A|B], [A|C]) :- !,
	'extract_attributes_.ast_argname8'(B, C).
'extract_attributes_.ast_argtype5'([_|A], B) :-
	'extract_attributes_.ast_argname8'(A, B).

% 'extract_attributes_.ast_argname8'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argname8'([], []).
'extract_attributes_.ast_argname8'([A|C], [A|B]) :- !,
	B=[],
	(   C=[]
	;   C=[_]
	).
'extract_attributes_.ast_argname8'([_], []).
'extract_attributes_.ast_argname8'([_, _], []).

% 'extract_attributes_.ast_argtype6'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(type, mult(1, 1, no), attr, [typeTermType])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argtype6'([], []).
'extract_attributes_.ast_argtype6'([A|B], [A|C]) :- !,
	B=[],
	C=[].
'extract_attributes_.ast_argtype6'([_], []).

% 'extract_attributes_.ast_argop1'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argop1'([], []).
'extract_attributes_.ast_argop1'([A|C], [A|B]) :- !,
	B=[],
	(   C=[]
	;   C=[_]
	).
'extract_attributes_.ast_argop1'([_], []).
'extract_attributes_.ast_argop1'([_, _], []).

% 'extract_attributes_.ast_argname9'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argname9'([], []).
'extract_attributes_.ast_argname9'([A|C], [A|B]) :- !,
	B=[],
	(   C=[]
	;   C=[_]
	;   C=[_, _]
	).
'extract_attributes_.ast_argname9'([_], []).
'extract_attributes_.ast_argname9'([_, _], []).
'extract_attributes_.ast_argname9'([_, _, _], []).

% 'extract_attributes_.ast_argname10'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT, localDefT])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argname10'([], []).
'extract_attributes_.ast_argname10'([A|C], [A|B]) :- !,
	B=[],
	(   C=[]
	;   C=[_]
	).
'extract_attributes_.ast_argname10'([_], []).
'extract_attributes_.ast_argname10'([_, _], []).

% 'extract_attributes_.ast_argfile1'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(file, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argfile1'([], []).
'extract_attributes_.ast_argfile1'([A|C], [A|B]) :- !,
	B=[],
	(   C=[]
	;   C=[_]
	).
'extract_attributes_.ast_argfile1'([_], []).
'extract_attributes_.ast_argfile1'([_, _], []).

% 'extract_attributes_.ast_argtype7'('$VAR'(0), '$VAR'(1)):-extract_attributes_([ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'extract_attributes_.ast_argtype7'([], []).
'extract_attributes_.ast_argtype7'([A|C], [A|B]) :- !,
	B=[],
	(   C=[]
	;   C=[_]
	).
'extract_attributes_.ast_argtype7'([_], []).
'extract_attributes_.ast_argtype7'([_, _], []).
