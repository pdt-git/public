retractTrees('Java', A) :-
	retractTreesJava1(A).

% retractTreesJava1('$VAR'(0)):-retractTrees('Java', '$VAR'(0))
retractTreesJava1([]).
retractTreesJava1([A, C]) :-
	packageT(A, B), !,
	retract(packageT(A, B)),
	retractTreesJava1(C).
retractTreesJava1([A, E]) :-
	classDefT(A, B, C, D), !,
	retract(classDefT(A, B, C, D)),
	retractTreesJava1(E).
retractTreesJava1([A, H]) :-
	methodDefT(A, B, C, D, E, F, G), !,
	retract(methodDefT(A, B, C, D, E, F, G)),
	retractTreesJava1(H).
retractTreesJava1([A, F]) :-
	fieldDefT(A, B, C, D, E), !,
	retract(fieldDefT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, E]) :-
	paramDefT(A, B, C, D), !,
	retract(paramDefT(A, B, C, D)),
	retractTreesJava1(E).
retractTreesJava1([A, H]) :-
	applyT(A, B, C, D, E, F, G), !,
	retract(applyT(A, B, C, D, E, F, G)),
	retractTreesJava1(H).
retractTreesJava1([A, F]) :-
	assertT(A, B, C, D, E), !,
	retract(assertT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, F]) :-
	assignT(A, B, C, D, E), !,
	retract(assignT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, G]) :-
	assignopT(A, B, C, D, E, F), !,
	retract(assignopT(A, B, C, D, E, F)),
	retractTreesJava1(G).
retractTreesJava1([A, E]) :-
	blockT(A, B, C, D), !,
	retract(blockT(A, B, C, D)),
	retractTreesJava1(E).
retractTreesJava1([A, F]) :-
	breakT(A, B, C, D, E), !,
	retract(breakT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, E]) :-
	caseT(A, B, C, D), !,
	retract(caseT(A, B, C, D)),
	retractTreesJava1(E).
retractTreesJava1([A, G]) :-
	conditionalT(A, B, C, D, E, F), !,
	retract(conditionalT(A, B, C, D, E, F)),
	retractTreesJava1(G).
retractTreesJava1([A, F]) :-
	continueT(A, B, C, D, E), !,
	retract(continueT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, F]) :-
	doLoopT(A, B, C, D, E), !,
	retract(doLoopT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, E]) :-
	execT(A, B, C, D), !,
	retract(execT(A, B, C, D)),
	retractTreesJava1(E).
retractTreesJava1([A, F]) :-
	catchT(A, B, C, D, E), !,
	retract(catchT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, H]) :-
	forLoopT(A, B, C, D, E, F, G), !,
	retract(forLoopT(A, B, C, D, E, F, G)),
	retractTreesJava1(H).
retractTreesJava1([A, G]) :-
	getFieldT(A, B, C, D, E, F), !,
	retract(getFieldT(A, B, C, D, E, F)),
	retractTreesJava1(G).
retractTreesJava1([A, G]) :-
	ifT(A, B, C, D, E, F), !,
	retract(ifT(A, B, C, D, E, F)),
	retractTreesJava1(G).
retractTreesJava1([A, D]) :-
	importT(A, B, C), !,
	retract(importT(A, B, C)),
	retractTreesJava1(D).
retractTreesJava1([A, F]) :-
	indexedT(A, B, C, D, E), !,
	retract(indexedT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, F]) :-
	labelT(A, B, C, D, E), !,
	retract(labelT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, F]) :-
	literalT(A, B, C, D, E), !,
	retract(literalT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, G]) :-
	localDefT(A, B, C, D, E, F), !,
	retract(localDefT(A, B, C, D, E, F)),
	retractTreesJava1(G).
retractTreesJava1([A, G]) :-
	newArrayT(A, B, C, D, E, F), !,
	retract(newArrayT(A, B, C, D, E, F)),
	retractTreesJava1(G).
retractTreesJava1([A, I]) :-
	newClassT(A, B, C, D, E, F, G, H), !,
	retract(newClassT(A, B, C, D, E, F, G, H)),
	retractTreesJava1(I).
retractTreesJava1([A, D]) :-
	nopT(A, B, C), !,
	retract(nopT(A, B, C)),
	retractTreesJava1(D).
retractTreesJava1([A, G]) :-
	operationT(A, B, C, D, E, F), !,
	retract(operationT(A, B, C, D, E, F)),
	retractTreesJava1(G).
retractTreesJava1([A, E]) :-
	precedenceT(A, B, C, D), !,
	retract(precedenceT(A, B, C, D)),
	retractTreesJava1(E).
retractTreesJava1([A, E]) :-
	returnT(A, B, C, D), !,
	retract(returnT(A, B, C, D)),
	retractTreesJava1(E).
retractTreesJava1([A, G]) :-
	selectT(A, B, C, D, E, F), !,
	retract(selectT(A, B, C, D, E, F)),
	retractTreesJava1(G).
retractTreesJava1([A, F]) :-
	identT(A, B, C, D, E), !,
	retract(identT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, F]) :-
	switchT(A, B, C, D, E), !,
	retract(switchT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, F]) :-
	synchronizedT(A, B, C, D, E), !,
	retract(synchronizedT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, E]) :-
	throwT(A, B, C, D), !,
	retract(throwT(A, B, C, D)),
	retractTreesJava1(E).
retractTreesJava1([A, E]) :-
	toplevelT(A, B, C, D), !,
	retract(toplevelT(A, B, C, D)),
	retractTreesJava1(E).
retractTreesJava1([A, G]) :-
	tryT(A, B, C, D, E, F), !,
	retract(tryT(A, B, C, D, E, F)),
	retractTreesJava1(G).
retractTreesJava1([A, F]) :-
	typeCastT(A, B, C, D, E), !,
	retract(typeCastT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, F]) :-
	typeTestT(A, B, C, D, E), !,
	retract(typeTestT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, F]) :-
	whileLoopT(A, B, C, D, E), !,
	retract(whileLoopT(A, B, C, D, E)),
	retractTreesJava1(F).
retractTreesJava1([A, D]) :-
	nopT(A, B, C), !,
	retract(nopT(A, B, C)),
	retractTreesJava1(D).
retractTreesJava1([A, B]) :-
	not(tree(A, _, _)),
	format('could not retract id: ~a~n', [A]), !,
	retractTreesJava1(B).

% original definition
:- dynamic packageT/2.
packageT(null, '').

% original definition
:- dynamic classDefT/4.

% original definition
:- dynamic methodDefT/7.

% original definition
:- dynamic fieldDefT/5.

% original definition
:- dynamic paramDefT/4.

% original definition
:- dynamic applyT/7.

% original definition
:- dynamic assertT/5.

% original definition
:- dynamic assignT/5.

% original definition
:- dynamic assignopT/6.

% original definition
:- dynamic blockT/4.

% original definition
:- dynamic breakT/5.

% original definition
:- dynamic caseT/4.

% original definition
:- dynamic conditionalT/6.

% original definition
:- dynamic continueT/5.

% original definition
:- dynamic doLoopT/5.

% original definition
:- dynamic execT/4.

% original definition
:- dynamic catchT/5.

% original definition
:- dynamic forLoopT/7.

% original definition
:- dynamic getFieldT/6.

% original definition
:- dynamic ifT/6.

% original definition
:- dynamic importT/3.

% original definition
:- dynamic indexedT/5.

% original definition
:- dynamic labelT/5.

% original definition
:- dynamic literalT/5.

% original definition
:- dynamic localDefT/6.

% original definition
:- dynamic newArrayT/6.

% original definition
:- dynamic newClassT/8.

% original definition
:- dynamic nopT/3.

% original definition
:- dynamic operationT/6.

% original definition
:- dynamic precedenceT/4.

% original definition
:- dynamic returnT/4.

% original definition
:- dynamic selectT/6.

% original definition
:- dynamic identT/5.

% original definition
:- dynamic switchT/5.

% original definition
:- dynamic synchronizedT/5.

% original definition
:- dynamic throwT/4.

% original definition
:- dynamic toplevelT/4.

% original definition
:- dynamic tryT/6.

% original definition
:- dynamic typeCastT/5.

% original definition
:- dynamic typeTestT/5.

% original definition
:- dynamic whileLoopT/5.
