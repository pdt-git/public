get_ast_node_enclosing('Java', A, B) :-
	get_ast_node_enclosingJava1(A, B).

% get_ast_node_enclosingJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_enclosing('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_enclosingJava1(A, B) :-
	applyT(A, _, B, _, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	assertT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	assignT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	assignopT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	blockT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	breakT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	caseT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	conditionalT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	continueT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	doLoopT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	execT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	catchT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	forLoopT(A, _, B, _, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	getFieldT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	ifT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	indexedT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	labelT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	literalT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	localDefT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	newArrayT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	newClassT(A, _, B, _, _, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	nopT(A, _, B).
get_ast_node_enclosingJava1(A, B) :-
	operationT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	precedenceT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	returnT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	selectT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	identT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	switchT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	synchronizedT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	throwT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	tryT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	typeCastT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	typeTestT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	whileLoopT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, A) :-
	packageT(A, _), !.
get_ast_node_enclosingJava1(A, B) :-
	classDefT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	paramDefT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	fieldDefT(A, B, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	methodDefT(A, B, _, _, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	toplevelT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	importT(A, _, B), !.

% original definition
:- dynamic applyT/7.

% original definition
:- dynamic assertT/5.

% original definition
:- dynamic assignT/5.

% original definition
:- dynamic assignopT/6.

% original definition
:- dynamic blockT/4.

% original definition
:- dynamic breakT/5.

% original definition
:- dynamic caseT/4.

% original definition
:- dynamic conditionalT/6.

% original definition
:- dynamic continueT/5.

% original definition
:- dynamic doLoopT/5.

% original definition
:- dynamic execT/4.

% original definition
:- dynamic catchT/5.

% original definition
:- dynamic forLoopT/7.

% original definition
:- dynamic getFieldT/6.

% original definition
:- dynamic ifT/6.

% original definition
:- dynamic indexedT/5.

% original definition
:- dynamic labelT/5.

% original definition
:- dynamic literalT/5.

% original definition
:- dynamic localDefT/6.

% original definition
:- dynamic newArrayT/6.

% original definition
:- dynamic newClassT/8.

% original definition
:- dynamic nopT/3.

% original definition
:- dynamic operationT/6.

% original definition
:- dynamic precedenceT/4.

% original definition
:- dynamic returnT/4.

% original definition
:- dynamic selectT/6.

% original definition
:- dynamic identT/5.

% original definition
:- dynamic switchT/5.

% original definition
:- dynamic synchronizedT/5.

% original definition
:- dynamic throwT/4.

% original definition
:- dynamic tryT/6.

% original definition
:- dynamic typeCastT/5.

% original definition
:- dynamic typeTestT/5.

% original definition
:- dynamic whileLoopT/5.

% original definition
:- dynamic packageT/2.
packageT(null, '').

% original definition
:- dynamic classDefT/4.

% original definition
:- dynamic paramDefT/4.

% original definition
:- dynamic fieldDefT/5.

% original definition
:- dynamic methodDefT/7.

% original definition
:- dynamic toplevelT/4.

% original definition
:- dynamic importT/3.
