ast_node_signature('JavaAttributes', A, B) :-
	ast_node_signatureJavaAttributes1(A, B).

% ast_node_signatureJavaAttributes1('$VAR'(0), '$VAR'(1)):-ast_node_signature('JavaAttributes', '$VAR'(0), '$VAR'(1))
ast_node_signatureJavaAttributes1(extendsT, 2).
ast_node_signatureJavaAttributes1(modifierT, 2).
ast_node_signatureJavaAttributes1(implementsT, 2).
ast_node_signatureJavaAttributes1(externT, 1).
ast_node_signatureJavaAttributes1(interfaceT, 1).
ast_node_signatureJavaAttributes1(sourceLocation, 4).
ast_node_signatureJavaAttributes1(projectLocationT, 3).
ast_node_signatureJavaAttributes1(slT, 3).
