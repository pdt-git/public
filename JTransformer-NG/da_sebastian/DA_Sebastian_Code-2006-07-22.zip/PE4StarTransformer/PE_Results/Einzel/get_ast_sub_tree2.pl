get_ast_sub_tree2('Java', A, B) :-
	get_ast_sub_tree2Java1(A, B).

% get_ast_sub_tree2Java1('$VAR'(0), '$VAR'(1)):-get_ast_sub_tree2('Java', '$VAR'(0), '$VAR'(1))
get_ast_sub_tree2Java1(A, D) :-
	methodDefT(A, _, _, C, _, _, B), !,
	(   B=null,
	    append([], C, D)
	;   append(B, C, D)
	).
get_ast_sub_tree2Java1(A, C) :-
	packageT(A, _), !,
	findall(B, (classDefT(B, A, _, _);toplevelT(B, A, _, _)), C).
get_ast_sub_tree2Java1(A, B) :-
	packageT(A, _), !,
	flatten([], B).
get_ast_sub_tree2Java1(A, F) :-
	classDefT(A, B, C, D), !,
	extract_sub_trees2Java1(A, B, C, D, E),
	flatten(E, F).
get_ast_sub_tree2Java1(A, I) :-
	methodDefT(A, B, C, D, E, F, G), !,
	extract_sub_trees2Java1(A, B, C, D, E, F, G, H),
	flatten(H, I).
get_ast_sub_tree2Java1(A, G) :-
	fieldDefT(A, B, C, D, E), !,
	extract_sub_trees2Java2(A, B, C, D, E, F),
	flatten(F, G).
get_ast_sub_tree2Java1(A, B) :-
	paramDefT(A, _, _, _), !,
	flatten([], B).
get_ast_sub_tree2Java1(A, I) :-
	applyT(A, B, C, D, E, F, G), !,
	extract_sub_trees2Java2(A, B, C, D, E, F, G, H),
	flatten(H, I).
get_ast_sub_tree2Java1(A, G) :-
	assertT(A, B, C, D, E), !,
	extract_sub_trees2Java4(A, B, C, D, E, F),
	flatten(F, G).
get_ast_sub_tree2Java1(A, G) :-
	assignT(A, B, C, D, E), !,
	extract_sub_trees2Java5(A, B, C, D, E, F),
	flatten(F, G).
get_ast_sub_tree2Java1(A, H) :-
	assignopT(A, B, C, D, E, F), !,
	extract_sub_trees2Java3(A, B, C, D, E, F, G),
	flatten(G, H).
get_ast_sub_tree2Java1(A, F) :-
	blockT(A, B, C, D), !,
	extract_sub_trees2Java8(A, B, C, D, E),
	flatten(E, F).
get_ast_sub_tree2Java1(A, B) :-
	breakT(A, _, _, _, _), !,
	flatten([], B).
get_ast_sub_tree2Java1(A, F) :-
	caseT(A, B, C, D), !,
	extract_sub_trees2Java9(A, B, C, D, E),
	flatten(E, F).
get_ast_sub_tree2Java1(A, H) :-
	conditionalT(A, B, C, D, E, F), !,
	extract_sub_trees2Java4(A, B, C, D, E, F, G),
	flatten(G, H).
get_ast_sub_tree2Java1(A, B) :-
	continueT(A, _, _, _, _), !,
	flatten([], B).
get_ast_sub_tree2Java1(A, G) :-
	doLoopT(A, B, C, D, E), !,
	extract_sub_trees2Java8(A, B, C, D, E, F),
	flatten(F, G).
get_ast_sub_tree2Java1(A, F) :-
	execT(A, B, C, D), !,
	extract_sub_trees2Java12(A, B, C, D, E),
	flatten(E, F).
get_ast_sub_tree2Java1(A, G) :-
	catchT(A, B, C, D, E), !,
	extract_sub_trees2Java9(A, B, C, D, E, F),
	flatten(F, G).
get_ast_sub_tree2Java1(A, I) :-
	forLoopT(A, B, C, D, E, F, G), !,
	extract_sub_trees2Java3(A, B, C, D, E, F, G, H),
	flatten(H, I).
get_ast_sub_tree2Java1(A, H) :-
	getFieldT(A, B, C, D, E, F), !,
	extract_sub_trees2Java6(A, B, C, D, E, F, G),
	flatten(G, H).
get_ast_sub_tree2Java1(A, H) :-
	ifT(A, B, C, D, E, F), !,
	extract_sub_trees2Java7(A, B, C, D, E, F, G),
	flatten(G, H).
get_ast_sub_tree2Java1(A, B) :-
	importT(A, _, _), !,
	flatten([], B).
get_ast_sub_tree2Java1(A, G) :-
	indexedT(A, B, C, D, E), !,
	extract_sub_trees2Java13(A, B, C, D, E, F),
	flatten(F, G).
get_ast_sub_tree2Java1(A, G) :-
	labelT(A, B, C, D, E), !,
	extract_sub_trees2Java14(A, B, C, D, E, F),
	flatten(F, G).
get_ast_sub_tree2Java1(A, B) :-
	literalT(A, _, _, _, _), !,
	flatten([], B).
get_ast_sub_tree2Java1(A, H) :-
	localDefT(A, B, C, D, E, F), !,
	extract_sub_trees2Java8(A, B, C, D, E, F, G),
	flatten(G, H).
get_ast_sub_tree2Java1(A, H) :-
	newArrayT(A, B, C, D, E, F), !,
	extract_sub_trees2Java9(A, B, C, D, E, F, G),
	flatten(G, H).
get_ast_sub_tree2Java1(A, J) :-
	newClassT(A, B, C, D, E, F, G, H), !,
	extract_sub_trees2Java1(A, B, C, D, E, F, G, H, I),
	flatten(I, J).
get_ast_sub_tree2Java1(A, B) :-
	nopT(A, _, _), !,
	flatten([], B).
get_ast_sub_tree2Java1(A, H) :-
	operationT(A, B, C, D, E, F), !,
	extract_sub_trees2Java11(A, B, C, D, E, F, G),
	flatten(G, H).
get_ast_sub_tree2Java1(A, F) :-
	precedenceT(A, B, C, D), !,
	extract_sub_trees2Java23(A, B, C, D, E),
	flatten(E, F).
get_ast_sub_tree2Java1(A, F) :-
	returnT(A, B, C, D), !,
	extract_sub_trees2Java24(A, B, C, D, E),
	flatten(E, F).
get_ast_sub_tree2Java1(A, H) :-
	selectT(A, B, C, D, E, F), !,
	extract_sub_trees2Java12(A, B, C, D, E, F, G),
	flatten(G, H).
get_ast_sub_tree2Java1(A, B) :-
	identT(A, _, _, _, _), !,
	flatten([], B).
get_ast_sub_tree2Java1(A, G) :-
	switchT(A, B, C, D, E), !,
	extract_sub_trees2Java20(A, B, C, D, E, F),
	flatten(F, G).
get_ast_sub_tree2Java1(A, G) :-
	synchronizedT(A, B, C, D, E), !,
	extract_sub_trees2Java21(A, B, C, D, E, F),
	flatten(F, G).
get_ast_sub_tree2Java1(A, F) :-
	throwT(A, B, C, D), !,
	extract_sub_trees2Java28(A, B, C, D, E),
	flatten(E, F).
get_ast_sub_tree2Java1(A, F) :-
	toplevelT(A, B, C, D), !,
	extract_sub_trees2Java29(A, B, C, D, E),
	flatten(E, F).
get_ast_sub_tree2Java1(A, H) :-
	tryT(A, B, C, D, E, F), !,
	extract_sub_trees2Java13(A, B, C, D, E, F, G),
	flatten(G, H).
get_ast_sub_tree2Java1(A, G) :-
	typeCastT(A, B, C, D, E), !,
	extract_sub_trees2Java23(A, B, C, D, E, F),
	flatten(F, G).
get_ast_sub_tree2Java1(A, G) :-
	typeTestT(A, B, C, D, E), !,
	extract_sub_trees2Java24(A, B, C, D, E, F),
	flatten(F, G).
get_ast_sub_tree2Java1(A, G) :-
	whileLoopT(A, B, C, D, E), !,
	extract_sub_trees2Java25(A, B, C, D, E, F),
	flatten(F, G).

% original definition
:- dynamic methodDefT/7.

% original definition
:- dynamic packageT/2.
packageT(null, '').

% original definition
:- dynamic classDefT/4.

% original definition
:- dynamic toplevelT/4.

% extract_sub_trees2Java1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', classDefT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(id, mult(1, 1, no), id, [classDefT]), ast_arg(parent, mult(1, 1, no), id, [execT, packageT, classDefT, newClassT, blockT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(4))
extract_sub_trees2Java1(A, B, C, D, [A|E]) :-
	member(id, [defs]),
	extract_sub_trees2Java1(B, C, D, E), !.
extract_sub_trees2Java1(_, A, B, C, D) :-
	extract_sub_trees2Java1(A, B, C, D).

% extract_sub_trees2Java1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', classDefT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(parent, mult(1, 1, no), id, [execT, packageT, classDefT, newClassT, blockT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(3))
extract_sub_trees2Java1(A, B, C, [A|D]) :-
	member(parent, [defs]),
	extract_sub_trees2Java1(B, C, D), !.
extract_sub_trees2Java1(_, A, B, C) :-
	extract_sub_trees2Java1(A, B, C).

% extract_sub_trees2Java1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', classDefT, ['$VAR'(0), '$VAR'(1)], [ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(2))
extract_sub_trees2Java1(A, B, [A|C]) :-
	member(name, [defs]),
	extract_sub_trees2Java1(B, C), !.
extract_sub_trees2Java1(_, A, B) :-
	extract_sub_trees2Java1(A, B).

% extract_sub_trees2Java1('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', classDefT, ['$VAR'(0)], [ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(1))
extract_sub_trees2Java1(A, [A|B]) :-
	member(defs, [defs]),
	B=[], !.
extract_sub_trees2Java1(_, []).

% extract_sub_trees2Java1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-extract_sub_trees2('Java', methodDefT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)], [ast_arg(id, mult(1, 1, no), id, [methodDefT]), ast_arg(parent, mult(1, 1, no), id, [classDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(7))
extract_sub_trees2Java1(A, B, C, D, E, F, G, [A|H]) :-
	member(id, [params, body]),
	extract_sub_trees2Java1(B, C, D, E, F, G, H), !.
extract_sub_trees2Java1(_, A, B, C, D, E, F, G) :-
	extract_sub_trees2Java1(A, B, C, D, E, F, G).

% extract_sub_trees2Java1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-extract_sub_trees2('Java', methodDefT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)], [ast_arg(parent, mult(1, 1, no), id, [classDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(6))
extract_sub_trees2Java1(A, B, C, D, E, F, [A|G]) :-
	member(parent, [params, body]),
	extract_sub_trees2Java1(B, C, D, E, F, G), !.
extract_sub_trees2Java1(_, A, B, C, D, E, F) :-
	extract_sub_trees2Java1(A, B, C, D, E, F).

% extract_sub_trees2Java1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', methodDefT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(5))
extract_sub_trees2Java1(A, B, C, D, E, [A|F]) :-
	member(name, [params, body]),
	extract_sub_trees2Java2(B, C, D, E, F), !.
extract_sub_trees2Java1(_, A, B, C, D, E) :-
	extract_sub_trees2Java2(A, B, C, D, E).

% extract_sub_trees2Java2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', methodDefT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(4))
extract_sub_trees2Java2(A, B, C, D, [A|E]) :-
	member(params, [params, body]),
	extract_sub_trees2Java2(B, C, D, E), !.
extract_sub_trees2Java2(_, A, B, C, D) :-
	extract_sub_trees2Java2(A, B, C, D).

% extract_sub_trees2Java2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', methodDefT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(3))
extract_sub_trees2Java2(A, B, C, [A|D]) :-
	member(type, [params, body]),
	extract_sub_trees2Java2(B, C, D), !.
extract_sub_trees2Java2(_, A, B, C) :-
	extract_sub_trees2Java2(A, B, C).

% extract_sub_trees2Java2('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', methodDefT, ['$VAR'(0), '$VAR'(1)], [ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(2))
extract_sub_trees2Java2(A, B, [A|C]) :-
	member(excepts, [params, body]),
	extract_sub_trees2Java2(B, C), !.
extract_sub_trees2Java2(_, A, B) :-
	extract_sub_trees2Java2(A, B).

% extract_sub_trees2Java2('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', methodDefT, ['$VAR'(0)], [ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(1))
extract_sub_trees2Java2(A, [A|B]) :-
	member(body, [params, body]),
	B=[], !.
extract_sub_trees2Java2(_, []).

% original definition
:- dynamic fieldDefT/5.

% extract_sub_trees2Java2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', fieldDefT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(id, mult(1, 1, no), id, [fieldDefT]), ast_arg(parent, mult(1, 1, no), id, [classDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(5))
extract_sub_trees2Java2(A, B, C, D, E, [A|F]) :-
	member(id, [expr]),
	extract_sub_trees2Java3(B, C, D, E, F), !.
extract_sub_trees2Java2(_, A, B, C, D, E) :-
	extract_sub_trees2Java3(A, B, C, D, E).

% extract_sub_trees2Java3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', fieldDefT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(parent, mult(1, 1, no), id, [classDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(4))
extract_sub_trees2Java3(A, B, C, D, [A|E]) :-
	member(parent, [expr]),
	extract_sub_trees2Java3(B, C, D, E), !.
extract_sub_trees2Java3(_, A, B, C, D) :-
	extract_sub_trees2Java3(A, B, C, D).

% extract_sub_trees2Java3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', fieldDefT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(3))
extract_sub_trees2Java3(A, B, C, [A|D]) :-
	member(type, [expr]),
	extract_sub_trees2Java3(B, C, D), !.
extract_sub_trees2Java3(_, A, B, C) :-
	extract_sub_trees2Java3(A, B, C).

% extract_sub_trees2Java3('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', fieldDefT, ['$VAR'(0), '$VAR'(1)], [ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(2))
extract_sub_trees2Java3(A, B, [A|C]) :-
	member(name, [expr]),
	extract_sub_trees2Java3(B, C), !.
extract_sub_trees2Java3(_, A, B) :-
	extract_sub_trees2Java3(A, B).

% extract_sub_trees2Java3('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', fieldDefT, ['$VAR'(0)], [ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(1))
extract_sub_trees2Java3(A, [A|B]) :-
	member(expr, [expr]),
	B=[], !.
extract_sub_trees2Java3(_, []).

% original definition
:- dynamic paramDefT/4.

% original definition
:- dynamic applyT/7.

% extract_sub_trees2Java2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-extract_sub_trees2('Java', applyT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)], [ast_arg(id, mult(1, 1, no), id, [applyT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(7))
extract_sub_trees2Java2(A, B, C, D, E, F, G, [A|H]) :-
	member(id, [expr, args]),
	extract_sub_trees2Java2(B, C, D, E, F, G, H), !.
extract_sub_trees2Java2(_, A, B, C, D, E, F, G) :-
	extract_sub_trees2Java2(A, B, C, D, E, F, G).

% extract_sub_trees2Java2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-extract_sub_trees2('Java', applyT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(6))
extract_sub_trees2Java2(A, B, C, D, E, F, [A|G]) :-
	member(parent, [expr, args]),
	extract_sub_trees2Java3(B, C, D, E, F, G), !.
extract_sub_trees2Java2(_, A, B, C, D, E, F) :-
	extract_sub_trees2Java3(A, B, C, D, E, F).

% extract_sub_trees2Java3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', applyT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(5))
extract_sub_trees2Java3(A, B, C, D, E, [A|F]) :-
	member(encl, [expr, args]),
	extract_sub_trees2Java4(B, C, D, E, F), !.
extract_sub_trees2Java3(_, A, B, C, D, E) :-
	extract_sub_trees2Java4(A, B, C, D, E).

% extract_sub_trees2Java4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', applyT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(4))
extract_sub_trees2Java4(A, B, C, D, [A|E]) :-
	member(expr, [expr, args]),
	extract_sub_trees2Java4(B, C, D, E), !.
extract_sub_trees2Java4(_, A, B, C, D) :-
	extract_sub_trees2Java4(A, B, C, D).

% extract_sub_trees2Java4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', applyT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(3))
extract_sub_trees2Java4(A, B, C, [A|D]) :-
	member(name, [expr, args]),
	extract_sub_trees2Java4(B, C, D), !.
extract_sub_trees2Java4(_, A, B, C) :-
	extract_sub_trees2Java4(A, B, C).

% extract_sub_trees2Java4('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', applyT, ['$VAR'(0), '$VAR'(1)], [ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(2))
extract_sub_trees2Java4(A, B, [A|C]) :-
	member(args, [expr, args]),
	extract_sub_trees2Java4(B, C), !.
extract_sub_trees2Java4(_, A, B) :-
	extract_sub_trees2Java4(A, B).

% extract_sub_trees2Java4('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', applyT, ['$VAR'(0)], [ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(1))
extract_sub_trees2Java4(A, [A|B]) :-
	member(ref, [expr, args]),
	B=[], !.
extract_sub_trees2Java4(_, []).

% original definition
:- dynamic assertT/5.

% extract_sub_trees2Java4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', assertT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(id, mult(1, 1, no), id, [assertT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(msg, mult(0, 1, no), id, [expressionType])], '$VAR'(5))
extract_sub_trees2Java4(A, B, C, D, E, [A|F]) :-
	member(id, [expr, msg]),
	extract_sub_trees2Java5(B, C, D, E, F), !.
extract_sub_trees2Java4(_, A, B, C, D, E) :-
	extract_sub_trees2Java5(A, B, C, D, E).

% extract_sub_trees2Java5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', assertT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(msg, mult(0, 1, no), id, [expressionType])], '$VAR'(4))
extract_sub_trees2Java5(A, B, C, D, [A|E]) :-
	member(parent, [expr, msg]),
	extract_sub_trees2Java5(B, C, D, E), !.
extract_sub_trees2Java5(_, A, B, C, D) :-
	extract_sub_trees2Java5(A, B, C, D).

% extract_sub_trees2Java5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', assertT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(msg, mult(0, 1, no), id, [expressionType])], '$VAR'(3))
extract_sub_trees2Java5(A, B, C, [A|D]) :-
	member(encl, [expr, msg]),
	extract_sub_trees2Java5(B, C, D), !.
extract_sub_trees2Java5(_, A, B, C) :-
	extract_sub_trees2Java5(A, B, C).

% extract_sub_trees2Java5('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', assertT, ['$VAR'(0), '$VAR'(1)], [ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(msg, mult(0, 1, no), id, [expressionType])], '$VAR'(2))
extract_sub_trees2Java5(A, B, [A|C]) :-
	member(expr, [expr, msg]),
	extract_sub_trees2Java5(B, C), !.
extract_sub_trees2Java5(_, A, B) :-
	extract_sub_trees2Java5(A, B).

% extract_sub_trees2Java5('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', assertT, ['$VAR'(0)], [ast_arg(msg, mult(0, 1, no), id, [expressionType])], '$VAR'(1))
extract_sub_trees2Java5(A, [A|B]) :-
	member(msg, [expr, msg]),
	B=[], !.
extract_sub_trees2Java5(_, []).

% original definition
:- dynamic assignT/5.

% extract_sub_trees2Java5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', assignT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(id, mult(1, 1, no), id, [assignT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(5))
extract_sub_trees2Java5(A, B, C, D, E, [A|F]) :-
	member(id, [lhs, expr]),
	extract_sub_trees2Java6(B, C, D, E, F), !.
extract_sub_trees2Java5(_, A, B, C, D, E) :-
	extract_sub_trees2Java6(A, B, C, D, E).

% extract_sub_trees2Java6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', assignT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(4))
extract_sub_trees2Java6(A, B, C, D, [A|E]) :-
	member(parent, [lhs, expr]),
	extract_sub_trees2Java6(B, C, D, E), !.
extract_sub_trees2Java6(_, A, B, C, D) :-
	extract_sub_trees2Java6(A, B, C, D).

% extract_sub_trees2Java6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', assignT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(3))
extract_sub_trees2Java6(A, B, C, [A|D]) :-
	member(encl, [lhs, expr]),
	extract_sub_trees2Java6(B, C, D), !.
extract_sub_trees2Java6(_, A, B, C) :-
	extract_sub_trees2Java6(A, B, C).

% extract_sub_trees2Java6('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', assignT, ['$VAR'(0), '$VAR'(1)], [ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(2))
extract_sub_trees2Java6(A, B, [A|C]) :-
	member(lhs, [lhs, expr]),
	extract_sub_trees2Java6(B, C), !.
extract_sub_trees2Java6(_, A, B) :-
	extract_sub_trees2Java6(A, B).

% extract_sub_trees2Java6('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', assignT, ['$VAR'(0)], [ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(1))
extract_sub_trees2Java6(A, [A|B]) :-
	member(expr, [lhs, expr]),
	B=[], !.
extract_sub_trees2Java6(_, []).

% original definition
:- dynamic assignopT/6.

% extract_sub_trees2Java3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-extract_sub_trees2('Java', assignopT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)], [ast_arg(id, mult(1, 1, no), id, [assignopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(6))
extract_sub_trees2Java3(A, B, C, D, E, F, [A|G]) :-
	member(id, [lhs, expr]),
	extract_sub_trees2Java6(B, C, D, E, F, G), !.
extract_sub_trees2Java3(_, A, B, C, D, E, F) :-
	extract_sub_trees2Java6(A, B, C, D, E, F).

% extract_sub_trees2Java6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', assignopT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(5))
extract_sub_trees2Java6(A, B, C, D, E, [A|F]) :-
	member(parent, [lhs, expr]),
	extract_sub_trees2Java7(B, C, D, E, F), !.
extract_sub_trees2Java6(_, A, B, C, D, E) :-
	extract_sub_trees2Java7(A, B, C, D, E).

% extract_sub_trees2Java7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', assignopT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(4))
extract_sub_trees2Java7(A, B, C, D, [A|E]) :-
	member(encl, [lhs, expr]),
	extract_sub_trees2Java7(B, C, D, E), !.
extract_sub_trees2Java7(_, A, B, C, D) :-
	extract_sub_trees2Java7(A, B, C, D).

% extract_sub_trees2Java7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', assignopT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(3))
extract_sub_trees2Java7(A, B, C, [A|D]) :-
	member(lhs, [lhs, expr]),
	extract_sub_trees2Java7(B, C, D), !.
extract_sub_trees2Java7(_, A, B, C) :-
	extract_sub_trees2Java7(A, B, C).

% extract_sub_trees2Java7('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', assignopT, ['$VAR'(0), '$VAR'(1)], [ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(2))
extract_sub_trees2Java7(A, B, [A|C]) :-
	member(operator, [lhs, expr]),
	extract_sub_trees2Java7(B, C), !.
extract_sub_trees2Java7(_, A, B) :-
	extract_sub_trees2Java7(A, B).

% extract_sub_trees2Java7('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', assignopT, ['$VAR'(0)], [ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(1))
extract_sub_trees2Java7(A, [A|B]) :-
	member(expr, [lhs, expr]),
	B=[], !.
extract_sub_trees2Java7(_, []).

% original definition
:- dynamic blockT/4.

% extract_sub_trees2Java8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', blockT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(id, mult(1, 1, no), id, [blockT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(stmts, mult(0, *, ord), id, [statementType])], '$VAR'(4))
extract_sub_trees2Java8(A, B, C, D, [A|E]) :-
	member(id, [stmts]),
	extract_sub_trees2Java8(B, C, D, E), !.
extract_sub_trees2Java8(_, A, B, C, D) :-
	extract_sub_trees2Java8(A, B, C, D).

% extract_sub_trees2Java8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', blockT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(stmts, mult(0, *, ord), id, [statementType])], '$VAR'(3))
extract_sub_trees2Java8(A, B, C, [A|D]) :-
	member(parent, [stmts]),
	extract_sub_trees2Java8(B, C, D), !.
extract_sub_trees2Java8(_, A, B, C) :-
	extract_sub_trees2Java8(A, B, C).

% extract_sub_trees2Java8('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', blockT, ['$VAR'(0), '$VAR'(1)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(stmts, mult(0, *, ord), id, [statementType])], '$VAR'(2))
extract_sub_trees2Java8(A, B, [A|C]) :-
	member(encl, [stmts]),
	extract_sub_trees2Java8(B, C), !.
extract_sub_trees2Java8(_, A, B) :-
	extract_sub_trees2Java8(A, B).

% extract_sub_trees2Java8('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', blockT, ['$VAR'(0)], [ast_arg(stmts, mult(0, *, ord), id, [statementType])], '$VAR'(1))
extract_sub_trees2Java8(A, [A|B]) :-
	member(stmts, [stmts]),
	B=[], !.
extract_sub_trees2Java8(_, []).

% original definition
:- dynamic breakT/5.

% original definition
:- dynamic caseT/4.

% extract_sub_trees2Java9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', caseT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(id, mult(1, 1, no), id, [caseT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(4))
extract_sub_trees2Java9(A, B, C, D, [A|E]) :-
	member(id, [expr]),
	extract_sub_trees2Java9(B, C, D, E), !.
extract_sub_trees2Java9(_, A, B, C, D) :-
	extract_sub_trees2Java9(A, B, C, D).

% extract_sub_trees2Java9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', caseT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(3))
extract_sub_trees2Java9(A, B, C, [A|D]) :-
	member(parent, [expr]),
	extract_sub_trees2Java9(B, C, D), !.
extract_sub_trees2Java9(_, A, B, C) :-
	extract_sub_trees2Java9(A, B, C).

% extract_sub_trees2Java9('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', caseT, ['$VAR'(0), '$VAR'(1)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(2))
extract_sub_trees2Java9(A, B, [A|C]) :-
	member(encl, [expr]),
	extract_sub_trees2Java9(B, C), !.
extract_sub_trees2Java9(_, A, B) :-
	extract_sub_trees2Java9(A, B).

% extract_sub_trees2Java9('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', caseT, ['$VAR'(0)], [ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(1))
extract_sub_trees2Java9(A, [A|B]) :-
	member(expr, [expr]),
	B=[], !.
extract_sub_trees2Java9(_, []).

% original definition
:- dynamic conditionalT/6.

% extract_sub_trees2Java4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-extract_sub_trees2('Java', conditionalT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)], [ast_arg(id, mult(1, 1, no), id, [conditionalT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])], '$VAR'(6))
extract_sub_trees2Java4(A, B, C, D, E, F, [A|G]) :-
	member(id, [cond, thenexpr, elseexpr]),
	extract_sub_trees2Java7(B, C, D, E, F, G), !.
extract_sub_trees2Java4(_, A, B, C, D, E, F) :-
	extract_sub_trees2Java7(A, B, C, D, E, F).

% extract_sub_trees2Java7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', conditionalT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])], '$VAR'(5))
extract_sub_trees2Java7(A, B, C, D, E, [A|F]) :-
	member(parent, [cond, thenexpr, elseexpr]),
	extract_sub_trees2Java10(B, C, D, E, F), !.
extract_sub_trees2Java7(_, A, B, C, D, E) :-
	extract_sub_trees2Java10(A, B, C, D, E).

% extract_sub_trees2Java10('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', conditionalT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])], '$VAR'(4))
extract_sub_trees2Java10(A, B, C, D, [A|E]) :-
	member(encl, [cond, thenexpr, elseexpr]),
	extract_sub_trees2Java10(B, C, D, E), !.
extract_sub_trees2Java10(_, A, B, C, D) :-
	extract_sub_trees2Java10(A, B, C, D).

% extract_sub_trees2Java10('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', conditionalT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])], '$VAR'(3))
extract_sub_trees2Java10(A, B, C, [A|D]) :-
	member(cond, [cond, thenexpr, elseexpr]),
	extract_sub_trees2Java10(B, C, D), !.
extract_sub_trees2Java10(_, A, B, C) :-
	extract_sub_trees2Java10(A, B, C).

% extract_sub_trees2Java10('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', conditionalT, ['$VAR'(0), '$VAR'(1)], [ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])], '$VAR'(2))
extract_sub_trees2Java10(A, B, [A|C]) :-
	member(thenexpr, [cond, thenexpr, elseexpr]),
	extract_sub_trees2Java10(B, C), !.
extract_sub_trees2Java10(_, A, B) :-
	extract_sub_trees2Java10(A, B).

% extract_sub_trees2Java10('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', conditionalT, ['$VAR'(0)], [ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])], '$VAR'(1))
extract_sub_trees2Java10(A, [A|B]) :-
	member(elseexpr, [cond, thenexpr, elseexpr]),
	B=[], !.
extract_sub_trees2Java10(_, []).

% original definition
:- dynamic continueT/5.

% original definition
:- dynamic doLoopT/5.

% extract_sub_trees2Java8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', doLoopT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(id, mult(1, 1, no), id, [doLoopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(5))
extract_sub_trees2Java8(A, B, C, D, E, [A|F]) :-
	member(id, [cond, body]),
	extract_sub_trees2Java11(B, C, D, E, F), !.
extract_sub_trees2Java8(_, A, B, C, D, E) :-
	extract_sub_trees2Java11(A, B, C, D, E).

% extract_sub_trees2Java11('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', doLoopT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(4))
extract_sub_trees2Java11(A, B, C, D, [A|E]) :-
	member(parent, [cond, body]),
	extract_sub_trees2Java11(B, C, D, E), !.
extract_sub_trees2Java11(_, A, B, C, D) :-
	extract_sub_trees2Java11(A, B, C, D).

% extract_sub_trees2Java11('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', doLoopT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(3))
extract_sub_trees2Java11(A, B, C, [A|D]) :-
	member(encl, [cond, body]),
	extract_sub_trees2Java11(B, C, D), !.
extract_sub_trees2Java11(_, A, B, C) :-
	extract_sub_trees2Java11(A, B, C).

% extract_sub_trees2Java11('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', doLoopT, ['$VAR'(0), '$VAR'(1)], [ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(2))
extract_sub_trees2Java11(A, B, [A|C]) :-
	member(cond, [cond, body]),
	extract_sub_trees2Java11(B, C), !.
extract_sub_trees2Java11(_, A, B) :-
	extract_sub_trees2Java11(A, B).

% extract_sub_trees2Java11('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', doLoopT, ['$VAR'(0)], [ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(1))
extract_sub_trees2Java11(A, [A|B]) :-
	member(body, [cond, body]),
	B=[], !.
extract_sub_trees2Java11(_, []).

% original definition
:- dynamic execT/4.

% extract_sub_trees2Java12('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', execT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(id, mult(1, 1, no), id, [execT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(4))
extract_sub_trees2Java12(A, B, C, D, [A|E]) :-
	member(id, [expr]),
	extract_sub_trees2Java12(B, C, D, E), !.
extract_sub_trees2Java12(_, A, B, C, D) :-
	extract_sub_trees2Java12(A, B, C, D).

% extract_sub_trees2Java12('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', execT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(3))
extract_sub_trees2Java12(A, B, C, [A|D]) :-
	member(parent, [expr]),
	extract_sub_trees2Java12(B, C, D), !.
extract_sub_trees2Java12(_, A, B, C) :-
	extract_sub_trees2Java12(A, B, C).

% extract_sub_trees2Java12('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', execT, ['$VAR'(0), '$VAR'(1)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(2))
extract_sub_trees2Java12(A, B, [A|C]) :-
	member(encl, [expr]),
	extract_sub_trees2Java12(B, C), !.
extract_sub_trees2Java12(_, A, B) :-
	extract_sub_trees2Java12(A, B).

% extract_sub_trees2Java12('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', execT, ['$VAR'(0)], [ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(1))
extract_sub_trees2Java12(A, [A|B]) :-
	member(expr, [expr]),
	B=[], !.
extract_sub_trees2Java12(_, []).

% original definition
:- dynamic catchT/5.

% extract_sub_trees2Java9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', catchT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(id, mult(1, 1, no), id, [catchT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(param, mult(1, 1, no), id, [paramDefT]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(5))
extract_sub_trees2Java9(A, B, C, D, E, [A|F]) :-
	member(id, [param, body]),
	extract_sub_trees2Java13(B, C, D, E, F), !.
extract_sub_trees2Java9(_, A, B, C, D, E) :-
	extract_sub_trees2Java13(A, B, C, D, E).

% extract_sub_trees2Java13('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', catchT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(param, mult(1, 1, no), id, [paramDefT]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(4))
extract_sub_trees2Java13(A, B, C, D, [A|E]) :-
	member(parent, [param, body]),
	extract_sub_trees2Java13(B, C, D, E), !.
extract_sub_trees2Java13(_, A, B, C, D) :-
	extract_sub_trees2Java13(A, B, C, D).

% extract_sub_trees2Java13('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', catchT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(param, mult(1, 1, no), id, [paramDefT]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(3))
extract_sub_trees2Java13(A, B, C, [A|D]) :-
	member(encl, [param, body]),
	extract_sub_trees2Java13(B, C, D), !.
extract_sub_trees2Java13(_, A, B, C) :-
	extract_sub_trees2Java13(A, B, C).

% extract_sub_trees2Java13('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', catchT, ['$VAR'(0), '$VAR'(1)], [ast_arg(param, mult(1, 1, no), id, [paramDefT]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(2))
extract_sub_trees2Java13(A, B, [A|C]) :-
	member(param, [param, body]),
	extract_sub_trees2Java13(B, C), !.
extract_sub_trees2Java13(_, A, B) :-
	extract_sub_trees2Java13(A, B).

% extract_sub_trees2Java13('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', catchT, ['$VAR'(0)], [ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(1))
extract_sub_trees2Java13(A, [A|B]) :-
	member(body, [param, body]),
	B=[], !.
extract_sub_trees2Java13(_, []).

% original definition
:- dynamic forLoopT/7.

% extract_sub_trees2Java3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-extract_sub_trees2('Java', forLoopT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)], [ast_arg(id, mult(1, 1, no), id, [forLoopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(inits, mult(0, *, ord), id, [[expressionType, localDefT]]), ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(7))
extract_sub_trees2Java3(A, B, C, D, E, F, G, [A|H]) :-
	member(id, [inits, cond, updaters, body]),
	extract_sub_trees2Java5(B, C, D, E, F, G, H), !.
extract_sub_trees2Java3(_, A, B, C, D, E, F, G) :-
	extract_sub_trees2Java5(A, B, C, D, E, F, G).

% extract_sub_trees2Java5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-extract_sub_trees2('Java', forLoopT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(inits, mult(0, *, ord), id, [[expressionType, localDefT]]), ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(6))
extract_sub_trees2Java5(A, B, C, D, E, F, [A|G]) :-
	member(parent, [inits, cond, updaters, body]),
	extract_sub_trees2Java10(B, C, D, E, F, G), !.
extract_sub_trees2Java5(_, A, B, C, D, E, F) :-
	extract_sub_trees2Java10(A, B, C, D, E, F).

% extract_sub_trees2Java10('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', forLoopT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(inits, mult(0, *, ord), id, [[expressionType, localDefT]]), ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(5))
extract_sub_trees2Java10(A, B, C, D, E, [A|F]) :-
	member(encl, [inits, cond, updaters, body]),
	extract_sub_trees2Java14(B, C, D, E, F), !.
extract_sub_trees2Java10(_, A, B, C, D, E) :-
	extract_sub_trees2Java14(A, B, C, D, E).

% extract_sub_trees2Java14('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', forLoopT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(inits, mult(0, *, ord), id, [[expressionType, localDefT]]), ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(4))
extract_sub_trees2Java14(A, B, C, D, [A|E]) :-
	member(inits, [inits, cond, updaters, body]),
	extract_sub_trees2Java14(B, C, D, E), !.
extract_sub_trees2Java14(_, A, B, C, D) :-
	extract_sub_trees2Java14(A, B, C, D).

% extract_sub_trees2Java14('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', forLoopT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(3))
extract_sub_trees2Java14(A, B, C, [A|D]) :-
	member(cond, [inits, cond, updaters, body]),
	extract_sub_trees2Java14(B, C, D), !.
extract_sub_trees2Java14(_, A, B, C) :-
	extract_sub_trees2Java14(A, B, C).

% extract_sub_trees2Java14('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', forLoopT, ['$VAR'(0), '$VAR'(1)], [ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(2))
extract_sub_trees2Java14(A, B, [A|C]) :-
	member(updaters, [inits, cond, updaters, body]),
	extract_sub_trees2Java14(B, C), !.
extract_sub_trees2Java14(_, A, B) :-
	extract_sub_trees2Java14(A, B).

% extract_sub_trees2Java14('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', forLoopT, ['$VAR'(0)], [ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(1))
extract_sub_trees2Java14(A, [A|B]) :-
	member(body, [inits, cond, updaters, body]),
	B=[], !.
extract_sub_trees2Java14(_, []).

% original definition
:- dynamic getFieldT/6.

% extract_sub_trees2Java6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-extract_sub_trees2('Java', getFieldT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)], [ast_arg(id, mult(1, 1, no), id, [getFieldT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])], '$VAR'(6))
extract_sub_trees2Java6(A, B, C, D, E, F, [A|G]) :-
	member(id, [expr]),
	extract_sub_trees2Java11(B, C, D, E, F, G), !.
extract_sub_trees2Java6(_, A, B, C, D, E, F) :-
	extract_sub_trees2Java11(A, B, C, D, E, F).

% extract_sub_trees2Java11('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', getFieldT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])], '$VAR'(5))
extract_sub_trees2Java11(A, B, C, D, E, [A|F]) :-
	member(parent, [expr]),
	extract_sub_trees2Java15(B, C, D, E, F), !.
extract_sub_trees2Java11(_, A, B, C, D, E) :-
	extract_sub_trees2Java15(A, B, C, D, E).

% extract_sub_trees2Java15('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', getFieldT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])], '$VAR'(4))
extract_sub_trees2Java15(A, B, C, D, [A|E]) :-
	member(encl, [expr]),
	extract_sub_trees2Java15(B, C, D, E), !.
extract_sub_trees2Java15(_, A, B, C, D) :-
	extract_sub_trees2Java15(A, B, C, D).

% extract_sub_trees2Java15('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', getFieldT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])], '$VAR'(3))
extract_sub_trees2Java15(A, B, C, [A|D]) :-
	member(expr, [expr]),
	extract_sub_trees2Java15(B, C, D), !.
extract_sub_trees2Java15(_, A, B, C) :-
	extract_sub_trees2Java15(A, B, C).

% extract_sub_trees2Java15('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', getFieldT, ['$VAR'(0), '$VAR'(1)], [ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])], '$VAR'(2))
extract_sub_trees2Java15(A, B, [A|C]) :-
	member(name, [expr]),
	extract_sub_trees2Java15(B, C), !.
extract_sub_trees2Java15(_, A, B) :-
	extract_sub_trees2Java15(A, B).

% extract_sub_trees2Java15('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', getFieldT, ['$VAR'(0)], [ast_arg(field, mult(1, 1, no), id, [fieldDefT])], '$VAR'(1))
extract_sub_trees2Java15(A, [A|B]) :-
	member(field, [expr]),
	B=[], !.
extract_sub_trees2Java15(_, []).

% original definition
:- dynamic ifT/6.

% extract_sub_trees2Java7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-extract_sub_trees2('Java', ifT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)], [ast_arg(id, mult(1, 1, no), id, [ifT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])], '$VAR'(6))
extract_sub_trees2Java7(A, B, C, D, E, F, [A|G]) :-
	member(id, [cond, then, else]),
	extract_sub_trees2Java12(B, C, D, E, F, G), !.
extract_sub_trees2Java7(_, A, B, C, D, E, F) :-
	extract_sub_trees2Java12(A, B, C, D, E, F).

% extract_sub_trees2Java12('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', ifT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])], '$VAR'(5))
extract_sub_trees2Java12(A, B, C, D, E, [A|F]) :-
	member(parent, [cond, then, else]),
	extract_sub_trees2Java16(B, C, D, E, F), !.
extract_sub_trees2Java12(_, A, B, C, D, E) :-
	extract_sub_trees2Java16(A, B, C, D, E).

% extract_sub_trees2Java16('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', ifT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])], '$VAR'(4))
extract_sub_trees2Java16(A, B, C, D, [A|E]) :-
	member(encl, [cond, then, else]),
	extract_sub_trees2Java16(B, C, D, E), !.
extract_sub_trees2Java16(_, A, B, C, D) :-
	extract_sub_trees2Java16(A, B, C, D).

% extract_sub_trees2Java16('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', ifT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])], '$VAR'(3))
extract_sub_trees2Java16(A, B, C, [A|D]) :-
	member(cond, [cond, then, else]),
	extract_sub_trees2Java16(B, C, D), !.
extract_sub_trees2Java16(_, A, B, C) :-
	extract_sub_trees2Java16(A, B, C).

% extract_sub_trees2Java16('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', ifT, ['$VAR'(0), '$VAR'(1)], [ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])], '$VAR'(2))
extract_sub_trees2Java16(A, B, [A|C]) :-
	member(then, [cond, then, else]),
	extract_sub_trees2Java16(B, C), !.
extract_sub_trees2Java16(_, A, B) :-
	extract_sub_trees2Java16(A, B).

% extract_sub_trees2Java16('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', ifT, ['$VAR'(0)], [ast_arg(else, mult(0, 1, no), id, [blockT, statementType])], '$VAR'(1))
extract_sub_trees2Java16(A, [A|B]) :-
	member(else, [cond, then, else]),
	B=[], !.
extract_sub_trees2Java16(_, []).

% original definition
:- dynamic importT/3.

% original definition
:- dynamic indexedT/5.

% extract_sub_trees2Java13('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', indexedT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(id, mult(1, 1, no), id, [indexedT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(index, mult(1, 1, no), id, [expressionType]), ast_arg(indexed, mult(1, 1, no), id, [expressionType])], '$VAR'(5))
extract_sub_trees2Java13(A, B, C, D, E, [A|F]) :-
	member(id, [index, indexed]),
	extract_sub_trees2Java17(B, C, D, E, F), !.
extract_sub_trees2Java13(_, A, B, C, D, E) :-
	extract_sub_trees2Java17(A, B, C, D, E).

% extract_sub_trees2Java17('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', indexedT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(index, mult(1, 1, no), id, [expressionType]), ast_arg(indexed, mult(1, 1, no), id, [expressionType])], '$VAR'(4))
extract_sub_trees2Java17(A, B, C, D, [A|E]) :-
	member(parent, [index, indexed]),
	extract_sub_trees2Java17(B, C, D, E), !.
extract_sub_trees2Java17(_, A, B, C, D) :-
	extract_sub_trees2Java17(A, B, C, D).

% extract_sub_trees2Java17('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', indexedT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(index, mult(1, 1, no), id, [expressionType]), ast_arg(indexed, mult(1, 1, no), id, [expressionType])], '$VAR'(3))
extract_sub_trees2Java17(A, B, C, [A|D]) :-
	member(encl, [index, indexed]),
	extract_sub_trees2Java17(B, C, D), !.
extract_sub_trees2Java17(_, A, B, C) :-
	extract_sub_trees2Java17(A, B, C).

% extract_sub_trees2Java17('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', indexedT, ['$VAR'(0), '$VAR'(1)], [ast_arg(index, mult(1, 1, no), id, [expressionType]), ast_arg(indexed, mult(1, 1, no), id, [expressionType])], '$VAR'(2))
extract_sub_trees2Java17(A, B, [A|C]) :-
	member(index, [index, indexed]),
	extract_sub_trees2Java17(B, C), !.
extract_sub_trees2Java17(_, A, B) :-
	extract_sub_trees2Java17(A, B).

% extract_sub_trees2Java17('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', indexedT, ['$VAR'(0)], [ast_arg(indexed, mult(1, 1, no), id, [expressionType])], '$VAR'(1))
extract_sub_trees2Java17(A, [A|B]) :-
	member(indexed, [index, indexed]),
	B=[], !.
extract_sub_trees2Java17(_, []).

% original definition
:- dynamic labelT/5.

% extract_sub_trees2Java14('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', labelT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(id, mult(1, 1, no), id, [labelT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(body, mult(1, 1, no), id, [statementType]), ast_arg(label, mult(1, 1, no), attr, [atom])], '$VAR'(5))
extract_sub_trees2Java14(A, B, C, D, E, [A|F]) :-
	member(id, [body]),
	extract_sub_trees2Java18(B, C, D, E, F), !.
extract_sub_trees2Java14(_, A, B, C, D, E) :-
	extract_sub_trees2Java18(A, B, C, D, E).

% extract_sub_trees2Java18('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', labelT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(body, mult(1, 1, no), id, [statementType]), ast_arg(label, mult(1, 1, no), attr, [atom])], '$VAR'(4))
extract_sub_trees2Java18(A, B, C, D, [A|E]) :-
	member(parent, [body]),
	extract_sub_trees2Java18(B, C, D, E), !.
extract_sub_trees2Java18(_, A, B, C, D) :-
	extract_sub_trees2Java18(A, B, C, D).

% extract_sub_trees2Java18('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', labelT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(body, mult(1, 1, no), id, [statementType]), ast_arg(label, mult(1, 1, no), attr, [atom])], '$VAR'(3))
extract_sub_trees2Java18(A, B, C, [A|D]) :-
	member(encl, [body]),
	extract_sub_trees2Java18(B, C, D), !.
extract_sub_trees2Java18(_, A, B, C) :-
	extract_sub_trees2Java18(A, B, C).

% extract_sub_trees2Java18('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', labelT, ['$VAR'(0), '$VAR'(1)], [ast_arg(body, mult(1, 1, no), id, [statementType]), ast_arg(label, mult(1, 1, no), attr, [atom])], '$VAR'(2))
extract_sub_trees2Java18(A, B, [A|C]) :-
	member(body, [body]),
	extract_sub_trees2Java18(B, C), !.
extract_sub_trees2Java18(_, A, B) :-
	extract_sub_trees2Java18(A, B).

% extract_sub_trees2Java18('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', labelT, ['$VAR'(0)], [ast_arg(label, mult(1, 1, no), attr, [atom])], '$VAR'(1))
extract_sub_trees2Java18(A, [A|B]) :-
	member(label, [body]),
	B=[], !.
extract_sub_trees2Java18(_, []).

% original definition
:- dynamic literalT/5.

% original definition
:- dynamic localDefT/6.

% extract_sub_trees2Java8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-extract_sub_trees2('Java', localDefT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)], [ast_arg(id, mult(1, 1, no), id, [localDefT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(6))
extract_sub_trees2Java8(A, B, C, D, E, F, [A|G]) :-
	member(id, [expr]),
	extract_sub_trees2Java15(B, C, D, E, F, G), !.
extract_sub_trees2Java8(_, A, B, C, D, E, F) :-
	extract_sub_trees2Java15(A, B, C, D, E, F).

% extract_sub_trees2Java15('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', localDefT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(5))
extract_sub_trees2Java15(A, B, C, D, E, [A|F]) :-
	member(parent, [expr]),
	extract_sub_trees2Java19(B, C, D, E, F), !.
extract_sub_trees2Java15(_, A, B, C, D, E) :-
	extract_sub_trees2Java19(A, B, C, D, E).

% extract_sub_trees2Java19('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', localDefT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(4))
extract_sub_trees2Java19(A, B, C, D, [A|E]) :-
	member(encl, [expr]),
	extract_sub_trees2Java19(B, C, D, E), !.
extract_sub_trees2Java19(_, A, B, C, D) :-
	extract_sub_trees2Java19(A, B, C, D).

% extract_sub_trees2Java19('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', localDefT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(3))
extract_sub_trees2Java19(A, B, C, [A|D]) :-
	member(type, [expr]),
	extract_sub_trees2Java19(B, C, D), !.
extract_sub_trees2Java19(_, A, B, C) :-
	extract_sub_trees2Java19(A, B, C).

% extract_sub_trees2Java19('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', localDefT, ['$VAR'(0), '$VAR'(1)], [ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(2))
extract_sub_trees2Java19(A, B, [A|C]) :-
	member(name, [expr]),
	extract_sub_trees2Java19(B, C), !.
extract_sub_trees2Java19(_, A, B) :-
	extract_sub_trees2Java19(A, B).

% extract_sub_trees2Java19('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', localDefT, ['$VAR'(0)], [ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(1))
extract_sub_trees2Java19(A, [A|B]) :-
	member(expr, [expr]),
	B=[], !.
extract_sub_trees2Java19(_, []).

% original definition
:- dynamic newArrayT/6.

% extract_sub_trees2Java9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-extract_sub_trees2('Java', newArrayT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)], [ast_arg(id, mult(1, 1, no), id, [newArrayT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(dims, mult(1, *, ord), id, [expressionType]), ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])], '$VAR'(6))
extract_sub_trees2Java9(A, B, C, D, E, F, [A|G]) :-
	member(id, [dims, elems]),
	extract_sub_trees2Java16(B, C, D, E, F, G), !.
extract_sub_trees2Java9(_, A, B, C, D, E, F) :-
	extract_sub_trees2Java16(A, B, C, D, E, F).

% extract_sub_trees2Java16('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', newArrayT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(dims, mult(1, *, ord), id, [expressionType]), ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])], '$VAR'(5))
extract_sub_trees2Java16(A, B, C, D, E, [A|F]) :-
	member(parent, [dims, elems]),
	extract_sub_trees2Java20(B, C, D, E, F), !.
extract_sub_trees2Java16(_, A, B, C, D, E) :-
	extract_sub_trees2Java20(A, B, C, D, E).

% extract_sub_trees2Java20('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', newArrayT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(dims, mult(1, *, ord), id, [expressionType]), ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])], '$VAR'(4))
extract_sub_trees2Java20(A, B, C, D, [A|E]) :-
	member(encl, [dims, elems]),
	extract_sub_trees2Java20(B, C, D, E), !.
extract_sub_trees2Java20(_, A, B, C, D) :-
	extract_sub_trees2Java20(A, B, C, D).

% extract_sub_trees2Java20('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', newArrayT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(dims, mult(1, *, ord), id, [expressionType]), ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])], '$VAR'(3))
extract_sub_trees2Java20(A, B, C, [A|D]) :-
	member(dims, [dims, elems]),
	extract_sub_trees2Java20(B, C, D), !.
extract_sub_trees2Java20(_, A, B, C) :-
	extract_sub_trees2Java20(A, B, C).

% extract_sub_trees2Java20('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', newArrayT, ['$VAR'(0), '$VAR'(1)], [ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])], '$VAR'(2))
extract_sub_trees2Java20(A, B, [A|C]) :-
	member(elems, [dims, elems]),
	extract_sub_trees2Java20(B, C), !.
extract_sub_trees2Java20(_, A, B) :-
	extract_sub_trees2Java20(A, B).

% extract_sub_trees2Java20('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', newArrayT, ['$VAR'(0)], [ast_arg(type, mult(1, 1, no), attr, [typeTermType])], '$VAR'(1))
extract_sub_trees2Java20(A, [A|B]) :-
	member(type, [dims, elems]),
	B=[], !.
extract_sub_trees2Java20(_, []).

% original definition
:- dynamic newClassT/8.

% extract_sub_trees2Java1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7), '$VAR'(8)):-extract_sub_trees2('Java', newClassT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)], [ast_arg(id, mult(1, 1, no), id, [newClassT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(constr, mult(0, 1, no), id, [methodDefT]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(8))
extract_sub_trees2Java1(A, B, C, D, E, F, G, H, [A|I]) :-
	member(id, [args, clident, def, encltype]),
	extract_sub_trees2Java4(B, C, D, E, F, G, H, I), !.
extract_sub_trees2Java1(_, A, B, C, D, E, F, G, H) :-
	extract_sub_trees2Java4(A, B, C, D, E, F, G, H).

% extract_sub_trees2Java4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-extract_sub_trees2('Java', newClassT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(constr, mult(0, 1, no), id, [methodDefT]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(7))
extract_sub_trees2Java4(A, B, C, D, E, F, G, [A|H]) :-
	member(parent, [args, clident, def, encltype]),
	extract_sub_trees2Java10(B, C, D, E, F, G, H), !.
extract_sub_trees2Java4(_, A, B, C, D, E, F, G) :-
	extract_sub_trees2Java10(A, B, C, D, E, F, G).

% extract_sub_trees2Java10('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-extract_sub_trees2('Java', newClassT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(constr, mult(0, 1, no), id, [methodDefT]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(6))
extract_sub_trees2Java10(A, B, C, D, E, F, [A|G]) :-
	member(encl, [args, clident, def, encltype]),
	extract_sub_trees2Java17(B, C, D, E, F, G), !.
extract_sub_trees2Java10(_, A, B, C, D, E, F) :-
	extract_sub_trees2Java17(A, B, C, D, E, F).

% extract_sub_trees2Java17('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', newClassT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(constr, mult(0, 1, no), id, [methodDefT]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(5))
extract_sub_trees2Java17(A, B, C, D, E, [A|F]) :-
	member(constr, [args, clident, def, encltype]),
	extract_sub_trees2Java21(B, C, D, E, F), !.
extract_sub_trees2Java17(_, A, B, C, D, E) :-
	extract_sub_trees2Java21(A, B, C, D, E).

% extract_sub_trees2Java21('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', newClassT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(4))
extract_sub_trees2Java21(A, B, C, D, [A|E]) :-
	member(args, [args, clident, def, encltype]),
	extract_sub_trees2Java21(B, C, D, E), !.
extract_sub_trees2Java21(_, A, B, C, D) :-
	extract_sub_trees2Java21(A, B, C, D).

% extract_sub_trees2Java21('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', newClassT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(3))
extract_sub_trees2Java21(A, B, C, [A|D]) :-
	member(clident, [args, clident, def, encltype]),
	extract_sub_trees2Java21(B, C, D), !.
extract_sub_trees2Java21(_, A, B, C) :-
	extract_sub_trees2Java21(A, B, C).

% extract_sub_trees2Java21('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', newClassT, ['$VAR'(0), '$VAR'(1)], [ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(2))
extract_sub_trees2Java21(A, B, [A|C]) :-
	member(def, [args, clident, def, encltype]),
	extract_sub_trees2Java21(B, C), !.
extract_sub_trees2Java21(_, A, B) :-
	extract_sub_trees2Java21(A, B).

% extract_sub_trees2Java21('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', newClassT, ['$VAR'(0)], [ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(1))
extract_sub_trees2Java21(A, [A|B]) :-
	member(encltype, [args, clident, def, encltype]),
	B=[], !.
extract_sub_trees2Java21(_, []).

% original definition
:- dynamic nopT/3.

% original definition
:- dynamic operationT/6.

% extract_sub_trees2Java11('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-extract_sub_trees2('Java', operationT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)], [ast_arg(id, mult(1, 1, no), id, [operationT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(args, mult(1, 1, ord), id, [expressionType]), ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])], '$VAR'(6))
extract_sub_trees2Java11(A, B, C, D, E, F, [A|G]) :-
	member(id, [args]),
	extract_sub_trees2Java18(B, C, D, E, F, G), !.
extract_sub_trees2Java11(_, A, B, C, D, E, F) :-
	extract_sub_trees2Java18(A, B, C, D, E, F).

% extract_sub_trees2Java18('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', operationT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(args, mult(1, 1, ord), id, [expressionType]), ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])], '$VAR'(5))
extract_sub_trees2Java18(A, B, C, D, E, [A|F]) :-
	member(parent, [args]),
	extract_sub_trees2Java22(B, C, D, E, F), !.
extract_sub_trees2Java18(_, A, B, C, D, E) :-
	extract_sub_trees2Java22(A, B, C, D, E).

% extract_sub_trees2Java22('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', operationT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(args, mult(1, 1, ord), id, [expressionType]), ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])], '$VAR'(4))
extract_sub_trees2Java22(A, B, C, D, [A|E]) :-
	member(encl, [args]),
	extract_sub_trees2Java22(B, C, D, E), !.
extract_sub_trees2Java22(_, A, B, C, D) :-
	extract_sub_trees2Java22(A, B, C, D).

% extract_sub_trees2Java22('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', operationT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(args, mult(1, 1, ord), id, [expressionType]), ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])], '$VAR'(3))
extract_sub_trees2Java22(A, B, C, [A|D]) :-
	member(args, [args]),
	extract_sub_trees2Java22(B, C, D), !.
extract_sub_trees2Java22(_, A, B, C) :-
	extract_sub_trees2Java22(A, B, C).

% extract_sub_trees2Java22('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', operationT, ['$VAR'(0), '$VAR'(1)], [ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])], '$VAR'(2))
extract_sub_trees2Java22(A, B, [A|C]) :-
	member(op, [args]),
	extract_sub_trees2Java22(B, C), !.
extract_sub_trees2Java22(_, A, B) :-
	extract_sub_trees2Java22(A, B).

% extract_sub_trees2Java22('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', operationT, ['$VAR'(0)], [ast_arg(pos, mult(1, 1, no), id, [number])], '$VAR'(1))
extract_sub_trees2Java22(A, [A|B]) :-
	member(pos, [args]),
	B=[], !.
extract_sub_trees2Java22(_, []).

% original definition
:- dynamic precedenceT/4.

% extract_sub_trees2Java23('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', precedenceT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(id, mult(1, 1, no), id, [precedenceT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(4))
extract_sub_trees2Java23(A, B, C, D, [A|E]) :-
	member(id, [expr]),
	extract_sub_trees2Java23(B, C, D, E), !.
extract_sub_trees2Java23(_, A, B, C, D) :-
	extract_sub_trees2Java23(A, B, C, D).

% extract_sub_trees2Java23('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', precedenceT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(3))
extract_sub_trees2Java23(A, B, C, [A|D]) :-
	member(parent, [expr]),
	extract_sub_trees2Java23(B, C, D), !.
extract_sub_trees2Java23(_, A, B, C) :-
	extract_sub_trees2Java23(A, B, C).

% extract_sub_trees2Java23('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', precedenceT, ['$VAR'(0), '$VAR'(1)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(2))
extract_sub_trees2Java23(A, B, [A|C]) :-
	member(encl, [expr]),
	extract_sub_trees2Java23(B, C), !.
extract_sub_trees2Java23(_, A, B) :-
	extract_sub_trees2Java23(A, B).

% extract_sub_trees2Java23('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', precedenceT, ['$VAR'(0)], [ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(1))
extract_sub_trees2Java23(A, [A|B]) :-
	member(expr, [expr]),
	B=[], !.
extract_sub_trees2Java23(_, []).

% original definition
:- dynamic returnT/4.

% extract_sub_trees2Java24('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', returnT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(id, mult(1, 1, no), id, [execT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(4))
extract_sub_trees2Java24(A, B, C, D, [A|E]) :-
	member(id, [expr]),
	extract_sub_trees2Java24(B, C, D, E), !.
extract_sub_trees2Java24(_, A, B, C, D) :-
	extract_sub_trees2Java24(A, B, C, D).

% extract_sub_trees2Java24('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', returnT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(3))
extract_sub_trees2Java24(A, B, C, [A|D]) :-
	member(parent, [expr]),
	extract_sub_trees2Java24(B, C, D), !.
extract_sub_trees2Java24(_, A, B, C) :-
	extract_sub_trees2Java24(A, B, C).

% extract_sub_trees2Java24('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', returnT, ['$VAR'(0), '$VAR'(1)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(2))
extract_sub_trees2Java24(A, B, [A|C]) :-
	member(encl, [expr]),
	extract_sub_trees2Java24(B, C), !.
extract_sub_trees2Java24(_, A, B) :-
	extract_sub_trees2Java24(A, B).

% extract_sub_trees2Java24('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', returnT, ['$VAR'(0)], [ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(1))
extract_sub_trees2Java24(A, [A|B]) :-
	member(expr, [expr]),
	B=[], !.
extract_sub_trees2Java24(_, []).

% original definition
:- dynamic selectT/6.

% extract_sub_trees2Java12('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-extract_sub_trees2('Java', selectT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)], [ast_arg(id, mult(1, 1, no), id, [selectT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], '$VAR'(6))
extract_sub_trees2Java12(A, B, C, D, E, F, [A|G]) :-
	member(id, [selected]),
	extract_sub_trees2Java19(B, C, D, E, F, G), !.
extract_sub_trees2Java12(_, A, B, C, D, E, F) :-
	extract_sub_trees2Java19(A, B, C, D, E, F).

% extract_sub_trees2Java19('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', selectT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], '$VAR'(5))
extract_sub_trees2Java19(A, B, C, D, E, [A|F]) :-
	member(parent, [selected]),
	extract_sub_trees2Java25(B, C, D, E, F), !.
extract_sub_trees2Java19(_, A, B, C, D, E) :-
	extract_sub_trees2Java25(A, B, C, D, E).

% extract_sub_trees2Java25('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', selectT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], '$VAR'(4))
extract_sub_trees2Java25(A, B, C, D, [A|E]) :-
	member(encl, [selected]),
	extract_sub_trees2Java25(B, C, D, E), !.
extract_sub_trees2Java25(_, A, B, C, D) :-
	extract_sub_trees2Java25(A, B, C, D).

% extract_sub_trees2Java25('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', selectT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], '$VAR'(3))
extract_sub_trees2Java25(A, B, C, [A|D]) :-
	member(name, [selected]),
	extract_sub_trees2Java25(B, C, D), !.
extract_sub_trees2Java25(_, A, B, C) :-
	extract_sub_trees2Java25(A, B, C).

% extract_sub_trees2Java25('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', selectT, ['$VAR'(0), '$VAR'(1)], [ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], '$VAR'(2))
extract_sub_trees2Java25(A, B, [A|C]) :-
	member(selected, [selected]),
	extract_sub_trees2Java25(B, C), !.
extract_sub_trees2Java25(_, A, B) :-
	extract_sub_trees2Java25(A, B).

% extract_sub_trees2Java25('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', selectT, ['$VAR'(0)], [ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], '$VAR'(1))
extract_sub_trees2Java25(A, [A|B]) :-
	member(ref, [selected]),
	B=[], !.
extract_sub_trees2Java25(_, []).

% original definition
:- dynamic identT/5.

% original definition
:- dynamic switchT/5.

% extract_sub_trees2Java20('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', switchT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(id, mult(1, 1, no), id, [switchT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(stmts, mult(1, 1, no), id, [statementType])], '$VAR'(5))
extract_sub_trees2Java20(A, B, C, D, E, [A|F]) :-
	member(id, [cond, stmts]),
	extract_sub_trees2Java26(B, C, D, E, F), !.
extract_sub_trees2Java20(_, A, B, C, D, E) :-
	extract_sub_trees2Java26(A, B, C, D, E).

% extract_sub_trees2Java26('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', switchT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(stmts, mult(1, 1, no), id, [statementType])], '$VAR'(4))
extract_sub_trees2Java26(A, B, C, D, [A|E]) :-
	member(parent, [cond, stmts]),
	extract_sub_trees2Java26(B, C, D, E), !.
extract_sub_trees2Java26(_, A, B, C, D) :-
	extract_sub_trees2Java26(A, B, C, D).

% extract_sub_trees2Java26('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', switchT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(stmts, mult(1, 1, no), id, [statementType])], '$VAR'(3))
extract_sub_trees2Java26(A, B, C, [A|D]) :-
	member(encl, [cond, stmts]),
	extract_sub_trees2Java26(B, C, D), !.
extract_sub_trees2Java26(_, A, B, C) :-
	extract_sub_trees2Java26(A, B, C).

% extract_sub_trees2Java26('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', switchT, ['$VAR'(0), '$VAR'(1)], [ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(stmts, mult(1, 1, no), id, [statementType])], '$VAR'(2))
extract_sub_trees2Java26(A, B, [A|C]) :-
	member(cond, [cond, stmts]),
	extract_sub_trees2Java26(B, C), !.
extract_sub_trees2Java26(_, A, B) :-
	extract_sub_trees2Java26(A, B).

% extract_sub_trees2Java26('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', switchT, ['$VAR'(0)], [ast_arg(stmts, mult(1, 1, no), id, [statementType])], '$VAR'(1))
extract_sub_trees2Java26(A, [A|B]) :-
	member(stmts, [cond, stmts]),
	B=[], !.
extract_sub_trees2Java26(_, []).

% original definition
:- dynamic synchronizedT/5.

% extract_sub_trees2Java21('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', synchronizedT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(id, mult(1, 1, no), id, [synchronizedT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(lock, mult(1, 1, no), id, [expressionType]), ast_arg(block, mult(1, 1, no), id, [blockT])], '$VAR'(5))
extract_sub_trees2Java21(A, B, C, D, E, [A|F]) :-
	member(id, [lock, block]),
	extract_sub_trees2Java27(B, C, D, E, F), !.
extract_sub_trees2Java21(_, A, B, C, D, E) :-
	extract_sub_trees2Java27(A, B, C, D, E).

% extract_sub_trees2Java27('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', synchronizedT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(lock, mult(1, 1, no), id, [expressionType]), ast_arg(block, mult(1, 1, no), id, [blockT])], '$VAR'(4))
extract_sub_trees2Java27(A, B, C, D, [A|E]) :-
	member(parent, [lock, block]),
	extract_sub_trees2Java27(B, C, D, E), !.
extract_sub_trees2Java27(_, A, B, C, D) :-
	extract_sub_trees2Java27(A, B, C, D).

% extract_sub_trees2Java27('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', synchronizedT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(lock, mult(1, 1, no), id, [expressionType]), ast_arg(block, mult(1, 1, no), id, [blockT])], '$VAR'(3))
extract_sub_trees2Java27(A, B, C, [A|D]) :-
	member(encl, [lock, block]),
	extract_sub_trees2Java27(B, C, D), !.
extract_sub_trees2Java27(_, A, B, C) :-
	extract_sub_trees2Java27(A, B, C).

% extract_sub_trees2Java27('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', synchronizedT, ['$VAR'(0), '$VAR'(1)], [ast_arg(lock, mult(1, 1, no), id, [expressionType]), ast_arg(block, mult(1, 1, no), id, [blockT])], '$VAR'(2))
extract_sub_trees2Java27(A, B, [A|C]) :-
	member(lock, [lock, block]),
	extract_sub_trees2Java27(B, C), !.
extract_sub_trees2Java27(_, A, B) :-
	extract_sub_trees2Java27(A, B).

% extract_sub_trees2Java27('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', synchronizedT, ['$VAR'(0)], [ast_arg(block, mult(1, 1, no), id, [blockT])], '$VAR'(1))
extract_sub_trees2Java27(A, [A|B]) :-
	member(block, [lock, block]),
	B=[], !.
extract_sub_trees2Java27(_, []).

% original definition
:- dynamic throwT/4.

% extract_sub_trees2Java28('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', throwT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(id, mult(1, 1, no), id, [throwT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(4))
extract_sub_trees2Java28(A, B, C, D, [A|E]) :-
	member(id, [expr]),
	extract_sub_trees2Java28(B, C, D, E), !.
extract_sub_trees2Java28(_, A, B, C, D) :-
	extract_sub_trees2Java28(A, B, C, D).

% extract_sub_trees2Java28('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', throwT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(3))
extract_sub_trees2Java28(A, B, C, [A|D]) :-
	member(parent, [expr]),
	extract_sub_trees2Java28(B, C, D), !.
extract_sub_trees2Java28(_, A, B, C) :-
	extract_sub_trees2Java28(A, B, C).

% extract_sub_trees2Java28('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', throwT, ['$VAR'(0), '$VAR'(1)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(2))
extract_sub_trees2Java28(A, B, [A|C]) :-
	member(encl, [expr]),
	extract_sub_trees2Java28(B, C), !.
extract_sub_trees2Java28(_, A, B) :-
	extract_sub_trees2Java28(A, B).

% extract_sub_trees2Java28('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', throwT, ['$VAR'(0)], [ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(1))
extract_sub_trees2Java28(A, [A|B]) :-
	member(expr, [expr]),
	B=[], !.
extract_sub_trees2Java28(_, []).

% extract_sub_trees2Java29('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', toplevelT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(id, mult(1, 1, no), id, [toplevelT]), ast_arg(parent, mult(0, 1, no), id, [packageT]), ast_arg(file, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])], '$VAR'(4))
extract_sub_trees2Java29(A, B, C, D, [A|E]) :-
	member(id, [defs]),
	extract_sub_trees2Java29(B, C, D, E), !.
extract_sub_trees2Java29(_, A, B, C, D) :-
	extract_sub_trees2Java29(A, B, C, D).

% extract_sub_trees2Java29('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', toplevelT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(parent, mult(0, 1, no), id, [packageT]), ast_arg(file, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])], '$VAR'(3))
extract_sub_trees2Java29(A, B, C, [A|D]) :-
	member(parent, [defs]),
	extract_sub_trees2Java29(B, C, D), !.
extract_sub_trees2Java29(_, A, B, C) :-
	extract_sub_trees2Java29(A, B, C).

% extract_sub_trees2Java29('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', toplevelT, ['$VAR'(0), '$VAR'(1)], [ast_arg(file, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])], '$VAR'(2))
extract_sub_trees2Java29(A, B, [A|C]) :-
	member(file, [defs]),
	extract_sub_trees2Java29(B, C), !.
extract_sub_trees2Java29(_, A, B) :-
	extract_sub_trees2Java29(A, B).

% extract_sub_trees2Java29('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', toplevelT, ['$VAR'(0)], [ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])], '$VAR'(1))
extract_sub_trees2Java29(A, [A|B]) :-
	member(defs, [defs]),
	B=[], !.
extract_sub_trees2Java29(_, []).

% original definition
:- dynamic tryT/6.

% extract_sub_trees2Java13('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-extract_sub_trees2('Java', tryT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)], [ast_arg(id, mult(1, 1, no), id, [tryT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(block, mult(1, 1, no), id, [blockT]), ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])], '$VAR'(6))
extract_sub_trees2Java13(A, B, C, D, E, F, [A|G]) :-
	member(id, [block, catchers, finalize]),
	extract_sub_trees2Java22(B, C, D, E, F, G), !.
extract_sub_trees2Java13(_, A, B, C, D, E, F) :-
	extract_sub_trees2Java22(A, B, C, D, E, F).

% extract_sub_trees2Java22('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', tryT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(block, mult(1, 1, no), id, [blockT]), ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])], '$VAR'(5))
extract_sub_trees2Java22(A, B, C, D, E, [A|F]) :-
	member(parent, [block, catchers, finalize]),
	extract_sub_trees2Java30(B, C, D, E, F), !.
extract_sub_trees2Java22(_, A, B, C, D, E) :-
	extract_sub_trees2Java30(A, B, C, D, E).

% extract_sub_trees2Java30('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', tryT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(block, mult(1, 1, no), id, [blockT]), ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])], '$VAR'(4))
extract_sub_trees2Java30(A, B, C, D, [A|E]) :-
	member(encl, [block, catchers, finalize]),
	extract_sub_trees2Java30(B, C, D, E), !.
extract_sub_trees2Java30(_, A, B, C, D) :-
	extract_sub_trees2Java30(A, B, C, D).

% extract_sub_trees2Java30('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', tryT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(block, mult(1, 1, no), id, [blockT]), ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])], '$VAR'(3))
extract_sub_trees2Java30(A, B, C, [A|D]) :-
	member(block, [block, catchers, finalize]),
	extract_sub_trees2Java30(B, C, D), !.
extract_sub_trees2Java30(_, A, B, C) :-
	extract_sub_trees2Java30(A, B, C).

% extract_sub_trees2Java30('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', tryT, ['$VAR'(0), '$VAR'(1)], [ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])], '$VAR'(2))
extract_sub_trees2Java30(A, B, [A|C]) :-
	member(catchers, [block, catchers, finalize]),
	extract_sub_trees2Java30(B, C), !.
extract_sub_trees2Java30(_, A, B) :-
	extract_sub_trees2Java30(A, B).

% extract_sub_trees2Java30('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', tryT, ['$VAR'(0)], [ast_arg(finalize, mult(0, 1, no), id, [blockT])], '$VAR'(1))
extract_sub_trees2Java30(A, [A|B]) :-
	member(finalize, [block, catchers, finalize]),
	B=[], !.
extract_sub_trees2Java30(_, []).

% original definition
:- dynamic typeCastT/5.

% extract_sub_trees2Java23('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', typeCastT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(id, mult(1, 1, no), id, [typeCastT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(5))
extract_sub_trees2Java23(A, B, C, D, E, [A|F]) :-
	member(id, [expr]),
	extract_sub_trees2Java31(B, C, D, E, F), !.
extract_sub_trees2Java23(_, A, B, C, D, E) :-
	extract_sub_trees2Java31(A, B, C, D, E).

% extract_sub_trees2Java31('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', typeCastT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(4))
extract_sub_trees2Java31(A, B, C, D, [A|E]) :-
	member(parent, [expr]),
	extract_sub_trees2Java31(B, C, D, E), !.
extract_sub_trees2Java31(_, A, B, C, D) :-
	extract_sub_trees2Java31(A, B, C, D).

% extract_sub_trees2Java31('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', typeCastT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(3))
extract_sub_trees2Java31(A, B, C, [A|D]) :-
	member(encl, [expr]),
	extract_sub_trees2Java31(B, C, D), !.
extract_sub_trees2Java31(_, A, B, C) :-
	extract_sub_trees2Java31(A, B, C).

% extract_sub_trees2Java31('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', typeCastT, ['$VAR'(0), '$VAR'(1)], [ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(2))
extract_sub_trees2Java31(A, B, [A|C]) :-
	member(type, [expr]),
	extract_sub_trees2Java31(B, C), !.
extract_sub_trees2Java31(_, A, B) :-
	extract_sub_trees2Java31(A, B).

% extract_sub_trees2Java31('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', typeCastT, ['$VAR'(0)], [ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(1))
extract_sub_trees2Java31(A, [A|B]) :-
	member(expr, [expr]),
	B=[], !.
extract_sub_trees2Java31(_, []).

% original definition
:- dynamic typeTestT/5.

% extract_sub_trees2Java24('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', typeTestT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(id, mult(1, 1, no), id, [typeTestT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(5))
extract_sub_trees2Java24(A, B, C, D, E, [A|F]) :-
	member(id, [expr]),
	extract_sub_trees2Java32(B, C, D, E, F), !.
extract_sub_trees2Java24(_, A, B, C, D, E) :-
	extract_sub_trees2Java32(A, B, C, D, E).

% extract_sub_trees2Java32('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', typeTestT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(4))
extract_sub_trees2Java32(A, B, C, D, [A|E]) :-
	member(parent, [expr]),
	extract_sub_trees2Java32(B, C, D, E), !.
extract_sub_trees2Java32(_, A, B, C, D) :-
	extract_sub_trees2Java32(A, B, C, D).

% extract_sub_trees2Java32('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', typeTestT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(3))
extract_sub_trees2Java32(A, B, C, [A|D]) :-
	member(encl, [expr]),
	extract_sub_trees2Java32(B, C, D), !.
extract_sub_trees2Java32(_, A, B, C) :-
	extract_sub_trees2Java32(A, B, C).

% extract_sub_trees2Java32('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', typeTestT, ['$VAR'(0), '$VAR'(1)], [ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(2))
extract_sub_trees2Java32(A, B, [A|C]) :-
	member(type, [expr]),
	extract_sub_trees2Java32(B, C), !.
extract_sub_trees2Java32(_, A, B) :-
	extract_sub_trees2Java32(A, B).

% extract_sub_trees2Java32('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', typeTestT, ['$VAR'(0)], [ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(1))
extract_sub_trees2Java32(A, [A|B]) :-
	member(expr, [expr]),
	B=[], !.
extract_sub_trees2Java32(_, []).

% original definition
:- dynamic whileLoopT/5.

% extract_sub_trees2Java25('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-extract_sub_trees2('Java', whileLoopT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)], [ast_arg(id, mult(1, 1, no), id, [whileLoopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(5))
extract_sub_trees2Java25(A, B, C, D, E, [A|F]) :-
	member(id, [cond, body]),
	extract_sub_trees2Java33(B, C, D, E, F), !.
extract_sub_trees2Java25(_, A, B, C, D, E) :-
	extract_sub_trees2Java33(A, B, C, D, E).

% extract_sub_trees2Java33('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-extract_sub_trees2('Java', whileLoopT, ['$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)], [ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(4))
extract_sub_trees2Java33(A, B, C, D, [A|E]) :-
	member(parent, [cond, body]),
	extract_sub_trees2Java33(B, C, D, E), !.
extract_sub_trees2Java33(_, A, B, C, D) :-
	extract_sub_trees2Java33(A, B, C, D).

% extract_sub_trees2Java33('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-extract_sub_trees2('Java', whileLoopT, ['$VAR'(0), '$VAR'(1), '$VAR'(2)], [ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(3))
extract_sub_trees2Java33(A, B, C, [A|D]) :-
	member(encl, [cond, body]),
	extract_sub_trees2Java33(B, C, D), !.
extract_sub_trees2Java33(_, A, B, C) :-
	extract_sub_trees2Java33(A, B, C).

% extract_sub_trees2Java33('$VAR'(0), '$VAR'(1), '$VAR'(2)):-extract_sub_trees2('Java', whileLoopT, ['$VAR'(0), '$VAR'(1)], [ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(2))
extract_sub_trees2Java33(A, B, [A|C]) :-
	member(cond, [cond, body]),
	extract_sub_trees2Java33(B, C), !.
extract_sub_trees2Java33(_, A, B) :-
	extract_sub_trees2Java33(A, B).

% extract_sub_trees2Java33('$VAR'(0), '$VAR'(1)):-extract_sub_trees2('Java', whileLoopT, ['$VAR'(0)], [ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(1))
extract_sub_trees2Java33(A, [A|B]) :-
	member(body, [cond, body]),
	B=[], !.
extract_sub_trees2Java33(_, []).
