get_ast_node_label('Java', A, B) :-
	get_ast_node_labelJava1(A, B).

% get_ast_node_labelJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_label('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_labelJava1(A, B) :-
	packageT(A, _),
	B=packageT.
get_ast_node_labelJava1(A, B) :-
	classDefT(A, _, _, _),
	B=classDefT.
get_ast_node_labelJava1(A, B) :-
	methodDefT(A, _, _, _, _, _, _),
	B=methodDefT.
get_ast_node_labelJava1(A, B) :-
	fieldDefT(A, _, _, _, _),
	B=fieldDefT.
get_ast_node_labelJava1(A, B) :-
	paramDefT(A, _, _, _),
	B=paramDefT.
get_ast_node_labelJava1(A, B) :-
	applyT(A, _, _, _, _, _, _),
	B=applyT.
get_ast_node_labelJava1(A, B) :-
	assertT(A, _, _, _, _),
	B=assertT.
get_ast_node_labelJava1(A, B) :-
	assignT(A, _, _, _, _),
	B=assignT.
get_ast_node_labelJava1(A, B) :-
	assignopT(A, _, _, _, _, _),
	B=assignopT.
get_ast_node_labelJava1(A, B) :-
	blockT(A, _, _, _),
	B=blockT.
get_ast_node_labelJava1(A, B) :-
	breakT(A, _, _, _, _),
	B=breakT.
get_ast_node_labelJava1(A, B) :-
	caseT(A, _, _, _),
	B=caseT.
get_ast_node_labelJava1(A, B) :-
	conditionalT(A, _, _, _, _, _),
	B=conditionalT.
get_ast_node_labelJava1(A, B) :-
	continueT(A, _, _, _, _),
	B=continueT.
get_ast_node_labelJava1(A, B) :-
	doLoopT(A, _, _, _, _),
	B=doLoopT.
get_ast_node_labelJava1(A, B) :-
	execT(A, _, _, _),
	B=execT.
get_ast_node_labelJava1(A, B) :-
	catchT(A, _, _, _, _),
	B=catchT.
get_ast_node_labelJava1(A, B) :-
	forLoopT(A, _, _, _, _, _, _),
	B=forLoopT.
get_ast_node_labelJava1(A, B) :-
	getFieldT(A, _, _, _, _, _),
	B=getFieldT.
get_ast_node_labelJava1(A, B) :-
	ifT(A, _, _, _, _, _),
	B=ifT.
get_ast_node_labelJava1(A, B) :-
	importT(A, _, _),
	B=importT.
get_ast_node_labelJava1(A, B) :-
	indexedT(A, _, _, _, _),
	B=indexedT.
get_ast_node_labelJava1(A, B) :-
	labelT(A, _, _, _, _),
	B=labelT.
get_ast_node_labelJava1(A, B) :-
	literalT(A, _, _, _, _),
	B=literalT.
get_ast_node_labelJava1(A, B) :-
	localDefT(A, _, _, _, _, _),
	B=localDefT.
get_ast_node_labelJava1(A, B) :-
	newArrayT(A, _, _, _, _, _),
	B=newArrayT.
get_ast_node_labelJava1(A, B) :-
	newClassT(A, _, _, _, _, _, _, _),
	B=newClassT.
get_ast_node_labelJava1(A, B) :-
	nopT(A, _, _),
	B=nopT.
get_ast_node_labelJava1(A, B) :-
	operationT(A, _, _, _, _, _),
	B=operationT.
get_ast_node_labelJava1(A, B) :-
	precedenceT(A, _, _, _),
	B=precedenceT.
get_ast_node_labelJava1(A, B) :-
	returnT(A, _, _, _),
	B=returnT.
get_ast_node_labelJava1(A, B) :-
	selectT(A, _, _, _, _, _),
	B=selectT.
get_ast_node_labelJava1(A, B) :-
	identT(A, _, _, _, _),
	B=identT.
get_ast_node_labelJava1(A, B) :-
	switchT(A, _, _, _, _),
	B=switchT.
get_ast_node_labelJava1(A, B) :-
	synchronizedT(A, _, _, _, _),
	B=synchronizedT.
get_ast_node_labelJava1(A, B) :-
	throwT(A, _, _, _),
	B=throwT.
get_ast_node_labelJava1(A, B) :-
	toplevelT(A, _, _, _),
	B=toplevelT.
get_ast_node_labelJava1(A, B) :-
	tryT(A, _, _, _, _, _),
	B=tryT.
get_ast_node_labelJava1(A, B) :-
	typeCastT(A, _, _, _, _),
	B=typeCastT.
get_ast_node_labelJava1(A, B) :-
	typeTestT(A, _, _, _, _),
	B=typeTestT.
get_ast_node_labelJava1(A, B) :-
	whileLoopT(A, _, _, _, _),
	B=whileLoopT.

% original definition
:- dynamic packageT/2.
packageT(null, '').

% original definition
:- dynamic classDefT/4.

% original definition
:- dynamic methodDefT/7.

% original definition
:- dynamic fieldDefT/5.

% original definition
:- dynamic paramDefT/4.

% original definition
:- dynamic applyT/7.

% original definition
:- dynamic assertT/5.

% original definition
:- dynamic assignT/5.

% original definition
:- dynamic assignopT/6.

% original definition
:- dynamic blockT/4.

% original definition
:- dynamic breakT/5.

% original definition
:- dynamic caseT/4.

% original definition
:- dynamic conditionalT/6.

% original definition
:- dynamic continueT/5.

% original definition
:- dynamic doLoopT/5.

% original definition
:- dynamic execT/4.

% original definition
:- dynamic catchT/5.

% original definition
:- dynamic forLoopT/7.

% original definition
:- dynamic getFieldT/6.

% original definition
:- dynamic ifT/6.

% original definition
:- dynamic importT/3.

% original definition
:- dynamic indexedT/5.

% original definition
:- dynamic labelT/5.

% original definition
:- dynamic literalT/5.

% original definition
:- dynamic localDefT/6.

% original definition
:- dynamic newArrayT/6.

% original definition
:- dynamic newClassT/8.

% original definition
:- dynamic nopT/3.

% original definition
:- dynamic operationT/6.

% original definition
:- dynamic precedenceT/4.

% original definition
:- dynamic returnT/4.

% original definition
:- dynamic selectT/6.

% original definition
:- dynamic identT/5.

% original definition
:- dynamic switchT/5.

% original definition
:- dynamic synchronizedT/5.

% original definition
:- dynamic throwT/4.

% original definition
:- dynamic toplevelT/4.

% original definition
:- dynamic tryT/6.

% original definition
:- dynamic typeCastT/5.

% original definition
:- dynamic typeTestT/5.

% original definition
:- dynamic whileLoopT/5.
