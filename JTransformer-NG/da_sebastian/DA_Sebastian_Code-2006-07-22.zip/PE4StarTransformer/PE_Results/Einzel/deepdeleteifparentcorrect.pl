deepDeleteIfParentCorrect('Java', A, B) :-
	deepDeleteIfParentCorrectJava1(A, B).

% deepDeleteIfParentCorrectJava1('$VAR'(0), '$VAR'(1)):-deepDeleteIfParentCorrect('Java', '$VAR'(0), '$VAR'(1))
deepDeleteIfParentCorrectJava1([], _).
deepDeleteIfParentCorrectJava1([A|D], B) :-
	tree(A, B, _), !,
	sub_trees1(A, C),
	deepDeleteIfParentCorrectJava1(C, A),
	retractTreeJava1(A),
	deepDeleteIfParentCorrectJava1(D, B).
deepDeleteIfParentCorrectJava1([A|_], C) :-
	get_ast_node_parent(A, B),
	not(equals(B, C)), !.
deepDeleteIfParentCorrectJava1(A, B) :-
	get_ast_node_termJava1(A), !,
	deepDeleteIfParentCorrectJava1([A], B).
deepDeleteIfParentCorrectJava1([A|_], B) :-
	not(get_ast_node_parent('Java', A, B)), !.

% sub_trees1('$VAR'(0), '$VAR'(1)):-sub_trees('$VAR'(0), '$VAR'(1))
sub_trees1(A, B) :-
	blockT(A, _, _, B), !.
sub_trees1(A, C) :-
	packageT(A, _), !,
	findall(B, (classDefT(B, A, _, _);toplevelT(B, A, _, _)), C).
sub_trees1(A, [B]) :-
	precedenceT(A, _, _, B), !.
sub_trees1(A, B) :-
	toplevelT(A, _, _, B), !.
sub_trees1(A, B) :-
	classDefT(A, _, _, B), !.
sub_trees1(A, D) :-
	methodDefT(A, _, _, C, _, _, B), !,
	(   B=null,
	    append([], C, D)
	;   append(B, C, D)
	).
sub_trees1(A, C) :-
	fieldDefT(A, _, _, _, B), !,
	(   B=null,
	    C=[]
	;   C=B
	).
sub_trees1(A, []) :-
	paramDefT(A, _, _, _), !.
sub_trees1(A, C) :-
	localDefT(A, _, _, _, _, B), !,
	(   B=null,
	    C=[]
	;   C=B
	).
sub_trees1(A, [B, C]) :-
	doLoopT(A, _, _, B, C), !.
sub_trees1(A, [B, C]) :-
	whileLoopT(A, _, _, B, C), !.
sub_trees1(A, [B|G]) :-
	forLoopT(A, _, _, D, C, E, B), !,
	(   C=null,
	    append(D, E, F),
	    append([], F, G)
	;   append(D, E, H),
	    append(C, H, G)
	).
sub_trees1(A, [B]) :-
	labelT(A, _, _, B, _), !.
sub_trees1(A, [B|C]) :-
	switchT(A, _, _, B, C), !.
sub_trees1(A, C) :-
	caseT(A, _, _, B), !,
	(   B=null,
	    C=[]
	;   C=B
	).
sub_trees1(A, [B, C]) :-
	synchronizedT(A, _, _, B, C), !.
sub_trees1(A, [B|E]) :-
	tryT(A, _, _, B, C, D), !,
	(   C=null,
	    D=null,
	    append([], [], E)
	;   C=null,
	    append([], [D], E)
	;   D=null,
	    append([C], [], E)
	;   append([C], [D], E)
	).
sub_trees1(A, [B, C]) :-
	catchT(A, _, _, B, C), !.
sub_trees1(A, [B, C]) :-
	assertT(A, _, _, B, C), !.
sub_trees1(A, [B|E]) :-
	ifT(A, _, _, B, D, C), !,
	(   C=null,
	    append([D], [], E)
	;   append([D], C, E)
	).
sub_trees1(A, [B, C, D]) :-
	conditionalT(A, _, _, B, C, D), !.
sub_trees1(A, [B]) :-
	execT(A, _, _, B), !.
sub_trees1(A, C) :-
	returnT(A, _, _, B), !,
	(   B=null,
	    C=[]
	;   C=B
	).
sub_trees1(A, []) :-
	breakT(A, _, _, _, _), !.
sub_trees1(A, []) :-
	continueT(A, _, _, _, _), !.
sub_trees1(A, [B]) :-
	throwT(A, _, _, B), !.
sub_trees1(A, D) :-
	applyT(A, _, _, B, _, C, _), !,
	(   B=null,
	    append([], C, D)
	;   append(B, C, D)
	).
sub_trees1(A, [B|G]) :-
	newClassT(A, _, _, _, F, B, D, C), !,
	(   C=null,
	    D=null,
	    append([], [], E),
	    append(E, F, G)
	;   C=null,
	    append([], D, H),
	    append(H, F, G)
	;   D=null,
	    append(C, [], I),
	    append(I, F, G)
	;   append(C, D, J),
	    append(J, F, G)
	).
sub_trees1(A, D) :-
	newArrayT(A, _, _, B, C, _), !,
	(   B=null,
	    C=null,
	    append([], [], D)
	;   B=null,
	    append([], [C], D)
	;   C=null,
	    append([B], [], D)
	;   append([B], [C], D)
	).
sub_trees1(A, [B, C]) :-
	assignT(A, _, _, B, C), !.
sub_trees1(A, [B, C]) :-
	assignopT(A, _, _, B, _, C), !.
sub_trees1(A, B) :-
	operationT(A, _, _, B, _, _), !.
sub_trees1(A, [B]) :-
	typeCastT(A, _, _, _, B), !.
sub_trees1(A, [B]) :-
	typeTestT(A, _, _, _, B), !.
sub_trees1(A, [B, C]) :-
	indexedT(A, _, _, B, C), !.
sub_trees1(A, [B]) :-
	selectT(A, _, _, _, B, _), !.
sub_trees1(A, C) :-
	getFieldT(A, _, _, B, _, _), !,
	(   B==null
	->  C=[]
	;   C=[B]
	).
sub_trees1(A, []) :-
	importT(A, _, _), !.
sub_trees1(A, []) :-
	literalT(A, _, _, _, _), !.
sub_trees1(A, []) :-
	identT(A, _, _, _, _), !.
sub_trees1(A, []) :-
	nopT(A, _, _), !.
sub_trees1(A, []) :-
	tree(A, B, C), !,
	format('ERROR: sub_trees: ~a, ~a, ~a~n', [A, B, C]).
sub_trees1(A, null) :-
	not(tree(A, _, _)), !.

% original definition
:- dynamic blockT/4.

% original definition
:- dynamic packageT/2.
packageT(null, '').

% original definition
:- dynamic classDefT/4.

% original definition
:- dynamic toplevelT/4.

% original definition
:- dynamic precedenceT/4.

% original definition
:- dynamic methodDefT/7.

% original definition
:- dynamic fieldDefT/5.

% original definition
:- dynamic paramDefT/4.

% original definition
:- dynamic localDefT/6.

% original definition
:- dynamic doLoopT/5.

% original definition
:- dynamic whileLoopT/5.

% original definition
:- dynamic forLoopT/7.

% original definition
:- dynamic labelT/5.

% original definition
:- dynamic switchT/5.

% original definition
:- dynamic caseT/4.

% original definition
:- dynamic synchronizedT/5.

% original definition
:- dynamic tryT/6.

% original definition
:- dynamic catchT/5.

% original definition
:- dynamic assertT/5.

% original definition
:- dynamic ifT/6.

% original definition
:- dynamic conditionalT/6.

% original definition
:- dynamic execT/4.

% original definition
:- dynamic returnT/4.

% original definition
:- dynamic breakT/5.

% original definition
:- dynamic continueT/5.

% original definition
:- dynamic throwT/4.

% original definition
:- dynamic applyT/7.

% original definition
:- dynamic newClassT/8.

% original definition
:- dynamic newArrayT/6.

% original definition
:- dynamic assignT/5.

% original definition
:- dynamic assignopT/6.

% original definition
:- dynamic operationT/6.

% original definition
:- dynamic typeCastT/5.

% original definition
:- dynamic typeTestT/5.

% original definition
:- dynamic indexedT/5.

% original definition
:- dynamic selectT/6.

% original definition
:- dynamic getFieldT/6.

% original definition
:- dynamic importT/3.

% original definition
:- dynamic literalT/5.

% original definition
:- dynamic identT/5.

% original definition
:- dynamic nopT/3.

% retractTreeJava1('$VAR'(0)):-retractTree('Java', '$VAR'(0))
retractTreeJava1(A) :-
	packageT(A, B), !,
	retract(packageT(A, B)).
retractTreeJava1(A) :-
	classDefT(A, B, C, D), !,
	retract(classDefT(A, B, C, D)).
retractTreeJava1(A) :-
	methodDefT(A, B, C, D, E, F, G), !,
	retract(methodDefT(A, B, C, D, E, F, G)).
retractTreeJava1(A) :-
	fieldDefT(A, B, C, D, E), !,
	retract(fieldDefT(A, B, C, D, E)).
retractTreeJava1(A) :-
	paramDefT(A, B, C, D), !,
	retract(paramDefT(A, B, C, D)).
retractTreeJava1(A) :-
	applyT(A, B, C, D, E, F, G), !,
	retract(applyT(A, B, C, D, E, F, G)).
retractTreeJava1(A) :-
	assertT(A, B, C, D, E), !,
	retract(assertT(A, B, C, D, E)).
retractTreeJava1(A) :-
	assignT(A, B, C, D, E), !,
	retract(assignT(A, B, C, D, E)).
retractTreeJava1(A) :-
	assignopT(A, B, C, D, E, F), !,
	retract(assignopT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	blockT(A, B, C, D), !,
	retract(blockT(A, B, C, D)).
retractTreeJava1(A) :-
	breakT(A, B, C, D, E), !,
	retract(breakT(A, B, C, D, E)).
retractTreeJava1(A) :-
	caseT(A, B, C, D), !,
	retract(caseT(A, B, C, D)).
retractTreeJava1(A) :-
	conditionalT(A, B, C, D, E, F), !,
	retract(conditionalT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	continueT(A, B, C, D, E), !,
	retract(continueT(A, B, C, D, E)).
retractTreeJava1(A) :-
	doLoopT(A, B, C, D, E), !,
	retract(doLoopT(A, B, C, D, E)).
retractTreeJava1(A) :-
	execT(A, B, C, D), !,
	retract(execT(A, B, C, D)).
retractTreeJava1(A) :-
	catchT(A, B, C, D, E), !,
	retract(catchT(A, B, C, D, E)).
retractTreeJava1(A) :-
	forLoopT(A, B, C, D, E, F, G), !,
	retract(forLoopT(A, B, C, D, E, F, G)).
retractTreeJava1(A) :-
	getFieldT(A, B, C, D, E, F), !,
	retract(getFieldT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	ifT(A, B, C, D, E, F), !,
	retract(ifT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	importT(A, B, C), !,
	retract(importT(A, B, C)).
retractTreeJava1(A) :-
	indexedT(A, B, C, D, E), !,
	retract(indexedT(A, B, C, D, E)).
retractTreeJava1(A) :-
	labelT(A, B, C, D, E), !,
	retract(labelT(A, B, C, D, E)).
retractTreeJava1(A) :-
	literalT(A, B, C, D, E), !,
	retract(literalT(A, B, C, D, E)).
retractTreeJava1(A) :-
	localDefT(A, B, C, D, E, F), !,
	retract(localDefT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	newArrayT(A, B, C, D, E, F), !,
	retract(newArrayT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	newClassT(A, B, C, D, E, F, G, H), !,
	retract(newClassT(A, B, C, D, E, F, G, H)).
retractTreeJava1(A) :-
	nopT(A, B, C), !,
	retract(nopT(A, B, C)).
retractTreeJava1(A) :-
	operationT(A, B, C, D, E, F), !,
	retract(operationT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	precedenceT(A, B, C, D), !,
	retract(precedenceT(A, B, C, D)).
retractTreeJava1(A) :-
	returnT(A, B, C, D), !,
	retract(returnT(A, B, C, D)).
retractTreeJava1(A) :-
	selectT(A, B, C, D, E, F), !,
	retract(selectT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	identT(A, B, C, D, E), !,
	retract(identT(A, B, C, D, E)).
retractTreeJava1(A) :-
	switchT(A, B, C, D, E), !,
	retract(switchT(A, B, C, D, E)).
retractTreeJava1(A) :-
	synchronizedT(A, B, C, D, E), !,
	retract(synchronizedT(A, B, C, D, E)).
retractTreeJava1(A) :-
	throwT(A, B, C, D), !,
	retract(throwT(A, B, C, D)).
retractTreeJava1(A) :-
	toplevelT(A, B, C, D), !,
	retract(toplevelT(A, B, C, D)).
retractTreeJava1(A) :-
	tryT(A, B, C, D, E, F), !,
	retract(tryT(A, B, C, D, E, F)).
retractTreeJava1(A) :-
	typeCastT(A, B, C, D, E), !,
	retract(typeCastT(A, B, C, D, E)).
retractTreeJava1(A) :-
	typeTestT(A, B, C, D, E), !,
	retract(typeTestT(A, B, C, D, E)).
retractTreeJava1(A) :-
	whileLoopT(A, B, C, D, E), !,
	retract(whileLoopT(A, B, C, D, E)).
retractTreeJava1(A) :-
	nopT(A, B, C), !,
	retract(nopT(A, B, C)).
retractTreeJava1(A) :-
	not(tree(A, _, _)),
	format('could not retract id: ~a~n', [A]), !.

% get_ast_node_termJava1('$VAR'(0)):-get_ast_node_term('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_termJava1(A) :-
	packageT(A, _), !.
get_ast_node_termJava1(A) :-
	classDefT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	methodDefT(A, _, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	fieldDefT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	paramDefT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	applyT(A, _, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	assertT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	assignT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	assignopT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	blockT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	breakT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	caseT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	conditionalT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	continueT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	doLoopT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	execT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	catchT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	forLoopT(A, _, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	getFieldT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	ifT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	importT(A, _, _), !.
get_ast_node_termJava1(A) :-
	indexedT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	labelT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	literalT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	localDefT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	newArrayT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	newClassT(A, _, _, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	nopT(A, _, _), !.
get_ast_node_termJava1(A) :-
	operationT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	precedenceT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	returnT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	selectT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	identT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	switchT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	synchronizedT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	throwT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	toplevelT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	tryT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	typeCastT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	typeTestT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	whileLoopT(A, _, _, _, _), !.
