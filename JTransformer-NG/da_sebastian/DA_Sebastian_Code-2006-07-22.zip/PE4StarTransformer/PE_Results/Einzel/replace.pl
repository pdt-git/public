replace('Java', A) :-
	replaceJava1(A).

% replaceJava1('$VAR'(0)):-replace('Java', '$VAR'(0))
replaceJava1(A) :-
	A=..[_, B|_],
	(   packageT(B, C), !,
	    flush_output,
	    retract(packageT(B, C)),
	    markEnclAsDirtyJava1(B, C),
	    asserta(rollback(assert(packageT(B, C)))),
	    addJava1(A)
	;   classDefT(B, D, E, F), !,
	    flush_output,
	    retract(classDefT(B, D, E, F)),
	    markEnclAsDirtyJava1(B, D, E, F),
	    asserta(rollback(assert(classDefT(B, D, E, F)))),
	    addJava1(A)
	;   methodDefT(B, G, H, I, J, K, L), !,
	    flush_output,
	    retract(methodDefT(B, G, H, I, J, K, L)),
	    markEnclAsDirtyJava1(B, G, H, I, J, K, L),
	    asserta(rollback(assert(methodDefT(B, G, H, I, J, K, L)))),
	    addJava1(A)
	;   fieldDefT(B, M, N, O, P), !,
	    flush_output,
	    retract(fieldDefT(B, M, N, O, P)),
	    markEnclAsDirtyJava1(B, M, N, O, P),
	    asserta(rollback(assert(fieldDefT(B, M, N, O, P)))),
	    addJava1(A)
	;   paramDefT(B, Q, R, S), !,
	    flush_output,
	    retract(paramDefT(B, Q, R, S)),
	    markEnclAsDirtyJava2(B, Q, R, S),
	    asserta(rollback(assert(paramDefT(B, Q, R, S)))),
	    addJava1(A)
	;   applyT(B, T, U, V, W, X, Y), !,
	    flush_output,
	    retract(applyT(B, T, U, V, W, X, Y)),
	    markEnclAsDirtyJava2(B, T, U, V, W, X, Y),
	    asserta(rollback(assert(applyT(B, T, U, V, W, X, Y)))),
	    addJava1(A)
	;   assertT(B, Z, A1, B1, C1), !,
	    flush_output,
	    retract(assertT(B, Z, A1, B1, C1)),
	    markEnclAsDirtyJava2(B, Z, A1, B1, C1),
	    asserta(rollback(assert(assertT(B, Z, A1, B1, C1)))),
	    addJava1(A)
	;   assignT(B, D1, E1, F1, G1), !,
	    flush_output,
	    retract(assignT(B, D1, E1, F1, G1)),
	    markEnclAsDirtyJava3(B, D1, E1, F1, G1),
	    asserta(rollback(assert(assignT(B, D1, E1, F1, G1)))),
	    addJava1(A)
	;   assignopT(B, H1, I1, J1, K1, L1), !,
	    flush_output,
	    retract(assignopT(B, H1, I1, J1, K1, L1)),
	    markEnclAsDirtyJava1(B, H1, I1, J1, K1, L1),
	    asserta(rollback(assert(assignopT(B, H1, I1, J1, K1, L1)))),
	    addJava1(A)
	;   blockT(B, M1, N1, O1), !,
	    flush_output,
	    retract(blockT(B, M1, N1, O1)),
	    markEnclAsDirtyJava3(B, M1, N1, O1),
	    asserta(rollback(assert(blockT(B, M1, N1, O1)))),
	    addJava1(A)
	;   breakT(B, P1, Q1, R1, S1), !,
	    flush_output,
	    retract(breakT(B, P1, Q1, R1, S1)),
	    markEnclAsDirtyJava4(B, P1, Q1, R1, S1),
	    asserta(rollback(assert(breakT(B, P1, Q1, R1, S1)))),
	    addJava1(A)
	;   caseT(B, T1, U1, V1), !,
	    flush_output,
	    retract(caseT(B, T1, U1, V1)),
	    markEnclAsDirtyJava4(B, T1, U1, V1),
	    asserta(rollback(assert(caseT(B, T1, U1, V1)))),
	    addJava1(A)
	;   conditionalT(B, W1, X1, Y1, Z1, A2), !,
	    flush_output,
	    retract(conditionalT(B, W1, X1, Y1, Z1, A2)),
	    markEnclAsDirtyJava2(B, W1, X1, Y1, Z1, A2),
	    asserta(rollback(assert(conditionalT(B, W1, X1, Y1, Z1, A2)))),
	    addJava1(A)
	;   continueT(B, B2, C2, D2, E2), !,
	    flush_output,
	    retract(continueT(B, B2, C2, D2, E2)),
	    markEnclAsDirtyJava5(B, B2, C2, D2, E2),
	    asserta(rollback(assert(continueT(B, B2, C2, D2, E2)))),
	    addJava1(A)
	;   doLoopT(B, F2, G2, H2, I2), !,
	    flush_output,
	    retract(doLoopT(B, F2, G2, H2, I2)),
	    markEnclAsDirtyJava6(B, F2, G2, H2, I2),
	    asserta(rollback(assert(doLoopT(B, F2, G2, H2, I2)))),
	    addJava1(A)
	;   execT(B, J2, K2, L2), !,
	    flush_output,
	    retract(execT(B, J2, K2, L2)),
	    markEnclAsDirtyJava5(B, J2, K2, L2),
	    asserta(rollback(assert(execT(B, J2, K2, L2)))),
	    addJava1(A)
	;   catchT(B, M2, N2, O2, P2), !,
	    flush_output,
	    retract(catchT(B, M2, N2, O2, P2)),
	    markEnclAsDirtyJava7(B, M2, N2, O2, P2),
	    asserta(rollback(assert(catchT(B, M2, N2, O2, P2)))),
	    addJava1(A)
	;   forLoopT(B, Q2, R2, S2, T2, U2, V2), !,
	    flush_output,
	    retract(forLoopT(B, Q2, R2, S2, T2, U2, V2)),
	    markEnclAsDirtyJava3(B, Q2, R2, S2, T2, U2, V2),
	    asserta(rollback(assert(forLoopT(B, Q2, R2, S2, T2, U2, V2)))),
	    addJava1(A)
	;   getFieldT(B, W2, X2, Y2, Z2, A3), !,
	    flush_output,
	    retract(getFieldT(B, W2, X2, Y2, Z2, A3)),
	    markEnclAsDirtyJava3(B, W2, X2, Y2, Z2, A3),
	    asserta(rollback(assert(getFieldT(B, W2, X2, Y2, Z2, A3)))),
	    addJava1(A)
	;   ifT(B, B3, C3, D3, E3, F3), !,
	    flush_output,
	    retract(ifT(B, B3, C3, D3, E3, F3)),
	    markEnclAsDirtyJava4(B, B3, C3, D3, E3, F3),
	    asserta(rollback(assert(ifT(B, B3, C3, D3, E3, F3)))),
	    addJava1(A)
	;   importT(B, G3, H3), !,
	    flush_output,
	    retract(importT(B, G3, H3)),
	    markEnclAsDirtyJava1(B, G3, H3),
	    asserta(rollback(assert(importT(B, G3, H3)))),
	    addJava1(A)
	;   indexedT(B, I3, J3, K3, L3), !,
	    flush_output,
	    retract(indexedT(B, I3, J3, K3, L3)),
	    markEnclAsDirtyJava8(B, I3, J3, K3, L3),
	    asserta(rollback(assert(indexedT(B, I3, J3, K3, L3)))),
	    addJava1(A)
	;   labelT(B, M3, N3, O3, P3), !,
	    flush_output,
	    retract(labelT(B, M3, N3, O3, P3)),
	    markEnclAsDirtyJava9(B, M3, N3, O3, P3),
	    asserta(rollback(assert(labelT(B, M3, N3, O3, P3)))),
	    addJava1(A)
	;   literalT(B, Q3, R3, S3, T3), !,
	    flush_output,
	    retract(literalT(B, Q3, R3, S3, T3)),
	    markEnclAsDirtyJava10(B, Q3, R3, S3, T3),
	    asserta(rollback(assert(literalT(B, Q3, R3, S3, T3)))),
	    addJava1(A)
	;   localDefT(B, U3, V3, W3, X3, Y3), !,
	    flush_output,
	    retract(localDefT(B, U3, V3, W3, X3, Y3)),
	    markEnclAsDirtyJava5(B, U3, V3, W3, X3, Y3),
	    asserta(rollback(assert(localDefT(B, U3, V3, W3, X3, Y3)))),
	    addJava1(A)
	;   newArrayT(B, Z3, A4, B4, C4, D4), !,
	    flush_output,
	    retract(newArrayT(B, Z3, A4, B4, C4, D4)),
	    markEnclAsDirtyJava6(B, Z3, A4, B4, C4, D4),
	    asserta(rollback(assert(newArrayT(B, Z3, A4, B4, C4, D4)))),
	    addJava1(A)
	;   newClassT(B, E4, F4, G4, H4, I4, J4, K4), !,
	    flush_output,
	    retract(newClassT(B, E4, F4, G4, H4, I4, J4, K4)),
	    markEnclAsDirtyJava1(B, E4, F4, G4, H4, I4, J4, K4),
	    asserta(rollback(assert(newClassT(B, E4, F4, G4, H4, I4, J4, K4)))),
	    addJava1(A)
	;   nopT(B, L4, M4), !,
	    flush_output,
	    retract(nopT(B, L4, M4)),
	    markEnclAsDirtyJava2(B, L4, M4),
	    asserta(rollback(assert(nopT(B, L4, M4)))),
	    addJava1(A)
	;   operationT(B, N4, O4, P4, Q4, R4), !,
	    flush_output,
	    retract(operationT(B, N4, O4, P4, Q4, R4)),
	    markEnclAsDirtyJava7(B, N4, O4, P4, Q4, R4),
	    asserta(rollback(assert(operationT(B, N4, O4, P4, Q4, R4)))),
	    addJava1(A)
	;   precedenceT(B, S4, T4, U4), !,
	    flush_output,
	    retract(precedenceT(B, S4, T4, U4)),
	    markEnclAsDirtyJava6(B, S4, T4, U4),
	    asserta(rollback(assert(precedenceT(B, S4, T4, U4)))),
	    addJava1(A)
	;   returnT(B, V4, W4, X4), !,
	    flush_output,
	    retract(returnT(B, V4, W4, X4)),
	    markEnclAsDirtyJava7(B, V4, W4, X4),
	    asserta(rollback(assert(returnT(B, V4, W4, X4)))),
	    addJava1(A)
	;   selectT(B, Y4, Z4, A5, B5, C5), !,
	    flush_output,
	    retract(selectT(B, Y4, Z4, A5, B5, C5)),
	    markEnclAsDirtyJava8(B, Y4, Z4, A5, B5, C5),
	    asserta(rollback(assert(selectT(B, Y4, Z4, A5, B5, C5)))),
	    addJava1(A)
	;   identT(B, D5, E5, F5, G5), !,
	    flush_output,
	    retract(identT(B, D5, E5, F5, G5)),
	    markEnclAsDirtyJava11(B, D5, E5, F5, G5),
	    asserta(rollback(assert(identT(B, D5, E5, F5, G5)))),
	    addJava1(A)
	;   switchT(B, H5, I5, J5, K5), !,
	    flush_output,
	    retract(switchT(B, H5, I5, J5, K5)),
	    markEnclAsDirtyJava12(B, H5, I5, J5, K5),
	    asserta(rollback(assert(switchT(B, H5, I5, J5, K5)))),
	    addJava1(A)
	;   synchronizedT(B, L5, M5, N5, O5), !,
	    flush_output,
	    retract(synchronizedT(B, L5, M5, N5, O5)),
	    markEnclAsDirtyJava13(B, L5, M5, N5, O5),
	    asserta(rollback(assert(synchronizedT(B, L5, M5, N5, O5)))),
	    addJava1(A)
	;   throwT(B, P5, Q5, R5), !,
	    flush_output,
	    retract(throwT(B, P5, Q5, R5)),
	    markEnclAsDirtyJava8(B, P5, Q5, R5),
	    asserta(rollback(assert(throwT(B, P5, Q5, R5)))),
	    addJava1(A)
	;   toplevelT(B, S5, T5, U5), !,
	    flush_output,
	    retract(toplevelT(B, S5, T5, U5)),
	    markEnclAsDirtyJava9(B, S5, T5, U5),
	    asserta(rollback(assert(toplevelT(B, S5, T5, U5)))),
	    addJava1(A)
	;   tryT(B, V5, W5, X5, Y5, Z5), !,
	    flush_output,
	    retract(tryT(B, V5, W5, X5, Y5, Z5)),
	    markEnclAsDirtyJava9(B, V5, W5, X5, Y5, Z5),
	    asserta(rollback(assert(tryT(B, V5, W5, X5, Y5, Z5)))),
	    addJava1(A)
	;   typeCastT(B, A6, B6, C6, D6), !,
	    flush_output,
	    retract(typeCastT(B, A6, B6, C6, D6)),
	    markEnclAsDirtyJava14(B, A6, B6, C6, D6),
	    asserta(rollback(assert(typeCastT(B, A6, B6, C6, D6)))),
	    addJava1(A)
	;   typeTestT(B, E6, F6, G6, H6), !,
	    flush_output,
	    retract(typeTestT(B, E6, F6, G6, H6)),
	    markEnclAsDirtyJava15(B, E6, F6, G6, H6),
	    asserta(rollback(assert(typeTestT(B, E6, F6, G6, H6)))),
	    addJava1(A)
	;   whileLoopT(B, I6, J6, K6, L6), !,
	    flush_output,
	    retract(whileLoopT(B, I6, J6, K6, L6)),
	    markEnclAsDirtyJava16(B, I6, J6, K6, L6),
	    asserta(rollback(assert(whileLoopT(B, I6, J6, K6, L6)))),
	    addJava1(A)
	).

% original definition
:- dynamic packageT/2.
packageT(null, '').

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1)):-markEnclAsDirty('Java', packageT('$VAR'(0), '$VAR'(1)))
markEnclAsDirtyJava1(A, B) :-
	get_ast_node_termJava1(A, B, C),
	'\\+checkIfTopLevelJava1'(C),
	(   get_ast_node_enclosingJava1(C, D),
	    '\\+=1'(D),
	    '\\+checkIfTopLevelJava1'(D),
	    assert1T(dirty_tree('Java', D)), !
	;   assert1T(dirty_tree('Java', C)), !
	).
markEnclAsDirtyJava1(_, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-get_ast_node_term('Java', '$VAR'(2), packageT('$VAR'(0), '$VAR'(1)))
get_ast_node_termJava1(B, D, A) :-
	packageT(A, C), !,
	A=B,
	C=D.
get_ast_node_termJava1(_, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% original definition
:- dynamic classDefT/4.

% original definition
:- dynamic methodDefT/7.

% original definition
:- dynamic fieldDefT/5.

% original definition
:- dynamic paramDefT/4.

% original definition
:- dynamic applyT/7.

% original definition
:- dynamic assertT/5.

% original definition
:- dynamic assignT/5.

% original definition
:- dynamic assignopT/6.

% original definition
:- dynamic blockT/4.

% original definition
:- dynamic breakT/5.

% original definition
:- dynamic caseT/4.

% original definition
:- dynamic conditionalT/6.

% original definition
:- dynamic continueT/5.

% original definition
:- dynamic doLoopT/5.

% original definition
:- dynamic execT/4.

% original definition
:- dynamic catchT/5.

% original definition
:- dynamic forLoopT/7.

% original definition
:- dynamic getFieldT/6.

% original definition
:- dynamic ifT/6.

% original definition
:- dynamic importT/3.

% original definition
:- dynamic indexedT/5.

% original definition
:- dynamic labelT/5.

% original definition
:- dynamic literalT/5.

% original definition
:- dynamic localDefT/6.

% original definition
:- dynamic newArrayT/6.

% original definition
:- dynamic newClassT/8.

% original definition
:- dynamic nopT/3.

% original definition
:- dynamic operationT/6.

% original definition
:- dynamic precedenceT/4.

% original definition
:- dynamic returnT/4.

% original definition
:- dynamic selectT/6.

% original definition
:- dynamic identT/5.

% original definition
:- dynamic switchT/5.

% original definition
:- dynamic synchronizedT/5.

% original definition
:- dynamic throwT/4.

% original definition
:- dynamic toplevelT/4.

% original definition
:- dynamic tryT/6.

% original definition
:- dynamic typeCastT/5.

% original definition
:- dynamic typeTestT/5.

% original definition
:- dynamic whileLoopT/5.

% '\\+checkIfTopLevelJava1'('$VAR'(0)):- \+checkIfTopLevel('Java', '$VAR'(0))
'\\+checkIfTopLevelJava1'(A) :-
	checkIfTopLevelJava1(A), !,
	fail.
'\\+checkIfTopLevelJava1'(_).

% checkIfTopLevelJava1('$VAR'(0)):-checkIfTopLevel('Java', '$VAR'(0))
checkIfTopLevelJava1(A) :-
	classDefT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	paramDefT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assertT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assignT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	blockT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	breakT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	caseT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	continueT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	execT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	catchT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	importT(A, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	indexedT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	labelT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	literalT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	nopT(A, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	precedenceT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	returnT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	identT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	switchT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	throwT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	toplevelT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	packageT(A, _), !,
	fail.
checkIfTopLevelJava1(_).

% get_ast_node_enclosingJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_enclosing('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_enclosingJava1(A, B) :-
	applyT(A, _, B, _, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	assertT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	assignT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	assignopT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	blockT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	breakT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	caseT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	conditionalT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	continueT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	doLoopT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	execT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	catchT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	forLoopT(A, _, B, _, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	getFieldT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	ifT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	indexedT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	labelT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	literalT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	localDefT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	newArrayT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	newClassT(A, _, B, _, _, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	nopT(A, _, B).
get_ast_node_enclosingJava1(A, B) :-
	operationT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	precedenceT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	returnT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	selectT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	identT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	switchT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	synchronizedT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	throwT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	tryT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	typeCastT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	typeTestT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	whileLoopT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, A) :-
	packageT(A, _), !.
get_ast_node_enclosingJava1(A, B) :-
	classDefT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	paramDefT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	fieldDefT(A, B, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	methodDefT(A, B, _, _, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	toplevelT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	importT(A, _, B), !.

% '\\+=1'('$VAR'(0)):- \+'$VAR'(0)=null
'\\+=1'(null) :- !,
	fail.
'\\+=1'(_).

% addJava1('$VAR'(0)):-add('Java', '$VAR'(0))
addJava1(java_fq(A)) :- !,
	java_fq_to_pef1(A, B),
	addJava1(B).
addJava1(A) :-
	nonvar(A),
	call(A), !,
	format('~nWARNING: element: already exists: ~w~n.', [A]).
addJava1(A) :-
	nonvar(A),
	assert(A),
	asserta(rollback(retract(A))),
	(   get_ast_node_termJava1(A, B),
	    '\\+checkIfTopLevelJava1'(B),
	    (   get_ast_node_enclosingJava1(B, C),
		'\\+=1'(C),
		'\\+checkIfTopLevelJava1'(C),
		assert1T(dirty_tree('Java', C)), !
	    ;   assert1T(dirty_tree('Java', B)), !
	    )
	;   true
	).

% java_fq_to_pef1('$VAR'(0), '$VAR'(1)):-java_fq_to_pef('$VAR'(0), '$VAR'(1))
java_fq_to_pef1(A, E) :-
	not(ground(A)),
	sformat(B, 'compiler error, term not ground: ~w', [A]),
	t_i_based_error_handling(B),
	A=..[C|D],
	(   C=packageT, !,
	    'bindArgs.ast_argid1'(D, F),
	    E=..[packageT|F]
	;   C=classDefT, !,
	    'bindArgs.ast_argid2'(D, G),
	    E=..[classDefT|G]
	;   C=methodDefT, !,
	    'bindArgs.ast_argid3'(D, H),
	    E=..[methodDefT|H]
	;   C=fieldDefT, !,
	    'bindArgs.ast_argid4'(D, I),
	    E=..[fieldDefT|I]
	;   C=paramDefT, !,
	    'bindArgs.ast_argid5'(D, J),
	    E=..[paramDefT|J]
	;   C=applyT, !,
	    'bindArgs.ast_argid6'(D, K),
	    E=..[applyT|K]
	;   C=assertT, !,
	    'bindArgs.ast_argid7'(D, L),
	    E=..[assertT|L]
	;   C=assignT, !,
	    'bindArgs.ast_argid8'(D, M),
	    E=..[assignT|M]
	;   C=assignopT, !,
	    'bindArgs.ast_argid9'(D, N),
	    E=..[assignopT|N]
	;   C=blockT, !,
	    'bindArgs.ast_argid10'(D, O),
	    E=..[blockT|O]
	;   C=breakT, !,
	    'bindArgs.ast_argid11'(D, P),
	    E=..[breakT|P]
	;   C=caseT, !,
	    'bindArgs.ast_argid12'(D, Q),
	    E=..[caseT|Q]
	;   C=conditionalT, !,
	    'bindArgs.ast_argid13'(D, R),
	    E=..[conditionalT|R]
	;   C=continueT, !,
	    'bindArgs.ast_argid14'(D, S),
	    E=..[continueT|S]
	;   C=doLoopT, !,
	    'bindArgs.ast_argid15'(D, T),
	    E=..[doLoopT|T]
	;   C=execT, !,
	    'bindArgs.ast_argid16'(D, U),
	    E=..[execT|U]
	;   C=catchT, !,
	    'bindArgs.ast_argid17'(D, V),
	    E=..[catchT|V]
	;   C=forLoopT, !,
	    'bindArgs.ast_argid18'(D, W),
	    E=..[forLoopT|W]
	;   C=getFieldT, !,
	    'bindArgs.ast_argid19'(D, X),
	    E=..[getFieldT|X]
	;   C=ifT, !,
	    'bindArgs.ast_argid20'(D, Y),
	    E=..[ifT|Y]
	;   C=importT, !,
	    'bindArgs.ast_argid21'(D, Z),
	    E=..[importT|Z]
	;   C=indexedT, !,
	    'bindArgs.ast_argid22'(D, A1),
	    E=..[indexedT|A1]
	;   C=labelT, !,
	    'bindArgs.ast_argid23'(D, B1),
	    E=..[labelT|B1]
	;   C=literalT, !,
	    'bindArgs.ast_argid24'(D, C1),
	    E=..[literalT|C1]
	;   C=localDefT, !,
	    'bindArgs.ast_argid25'(D, D1),
	    E=..[localDefT|D1]
	;   C=newArrayT, !,
	    'bindArgs.ast_argid26'(D, E1),
	    E=..[newArrayT|E1]
	;   C=newClassT, !,
	    'bindArgs.ast_argid27'(D, F1),
	    E=..[newClassT|F1]
	;   C=nopT, !,
	    'bindArgs.ast_argid28'(D, G1),
	    E=..[nopT|G1]
	;   C=operationT, !,
	    'bindArgs.ast_argid29'(D, H1),
	    E=..[operationT|H1]
	;   C=precedenceT, !,
	    'bindArgs.ast_argid30'(D, I1),
	    E=..[precedenceT|I1]
	;   C=returnT, !,
	    'bindArgs.ast_argid16'(D, J1),
	    E=..[returnT|J1]
	;   C=selectT, !,
	    'bindArgs.ast_argid31'(D, K1),
	    E=..[selectT|K1]
	;   C=identT, !,
	    'bindArgs.ast_argid32'(D, L1),
	    E=..[identT|L1]
	;   C=switchT, !,
	    'bindArgs.ast_argid33'(D, M1),
	    E=..[switchT|M1]
	;   C=synchronizedT, !,
	    'bindArgs.ast_argid34'(D, N1),
	    E=..[synchronizedT|N1]
	;   C=throwT, !,
	    'bindArgs.ast_argid35'(D, O1),
	    E=..[throwT|O1]
	;   C=toplevelT, !,
	    'bindArgs.ast_argid36'(D, P1),
	    E=..[toplevelT|P1]
	;   C=tryT, !,
	    'bindArgs.ast_argid37'(D, Q1),
	    E=..[tryT|Q1]
	;   C=typeCastT, !,
	    'bindArgs.ast_argid38'(D, R1),
	    E=..[typeCastT|R1]
	;   C=typeTestT, !,
	    'bindArgs.ast_argid39'(D, S1),
	    E=..[typeTestT|S1]
	;   C=whileLoopT, !,
	    'bindArgs.ast_argid40'(D, T1),
	    E=..[whileLoopT|T1]
	).
java_fq_to_pef1(A, D) :-
	A=..[B|C],
	(   B=packageT, !,
	    'bindArgs.ast_argid1'(C, E),
	    D=..[packageT|E]
	;   B=classDefT, !,
	    'bindArgs.ast_argid2'(C, F),
	    D=..[classDefT|F]
	;   B=methodDefT, !,
	    'bindArgs.ast_argid3'(C, G),
	    D=..[methodDefT|G]
	;   B=fieldDefT, !,
	    'bindArgs.ast_argid4'(C, H),
	    D=..[fieldDefT|H]
	;   B=paramDefT, !,
	    'bindArgs.ast_argid5'(C, I),
	    D=..[paramDefT|I]
	;   B=applyT, !,
	    'bindArgs.ast_argid6'(C, J),
	    D=..[applyT|J]
	;   B=assertT, !,
	    'bindArgs.ast_argid7'(C, K),
	    D=..[assertT|K]
	;   B=assignT, !,
	    'bindArgs.ast_argid8'(C, L),
	    D=..[assignT|L]
	;   B=assignopT, !,
	    'bindArgs.ast_argid9'(C, M),
	    D=..[assignopT|M]
	;   B=blockT, !,
	    'bindArgs.ast_argid10'(C, N),
	    D=..[blockT|N]
	;   B=breakT, !,
	    'bindArgs.ast_argid11'(C, O),
	    D=..[breakT|O]
	;   B=caseT, !,
	    'bindArgs.ast_argid12'(C, P),
	    D=..[caseT|P]
	;   B=conditionalT, !,
	    'bindArgs.ast_argid13'(C, Q),
	    D=..[conditionalT|Q]
	;   B=continueT, !,
	    'bindArgs.ast_argid14'(C, R),
	    D=..[continueT|R]
	;   B=doLoopT, !,
	    'bindArgs.ast_argid15'(C, S),
	    D=..[doLoopT|S]
	;   B=execT, !,
	    'bindArgs.ast_argid16'(C, T),
	    D=..[execT|T]
	;   B=catchT, !,
	    'bindArgs.ast_argid17'(C, U),
	    D=..[catchT|U]
	;   B=forLoopT, !,
	    'bindArgs.ast_argid18'(C, V),
	    D=..[forLoopT|V]
	;   B=getFieldT, !,
	    'bindArgs.ast_argid19'(C, W),
	    D=..[getFieldT|W]
	;   B=ifT, !,
	    'bindArgs.ast_argid20'(C, X),
	    D=..[ifT|X]
	;   B=importT, !,
	    'bindArgs.ast_argid21'(C, Y),
	    D=..[importT|Y]
	;   B=indexedT, !,
	    'bindArgs.ast_argid22'(C, Z),
	    D=..[indexedT|Z]
	;   B=labelT, !,
	    'bindArgs.ast_argid23'(C, A1),
	    D=..[labelT|A1]
	;   B=literalT, !,
	    'bindArgs.ast_argid24'(C, B1),
	    D=..[literalT|B1]
	;   B=localDefT, !,
	    'bindArgs.ast_argid25'(C, C1),
	    D=..[localDefT|C1]
	;   B=newArrayT, !,
	    'bindArgs.ast_argid26'(C, D1),
	    D=..[newArrayT|D1]
	;   B=newClassT, !,
	    'bindArgs.ast_argid27'(C, E1),
	    D=..[newClassT|E1]
	;   B=nopT, !,
	    'bindArgs.ast_argid28'(C, F1),
	    D=..[nopT|F1]
	;   B=operationT, !,
	    'bindArgs.ast_argid29'(C, G1),
	    D=..[operationT|G1]
	;   B=precedenceT, !,
	    'bindArgs.ast_argid30'(C, H1),
	    D=..[precedenceT|H1]
	;   B=returnT, !,
	    'bindArgs.ast_argid16'(C, I1),
	    D=..[returnT|I1]
	;   B=selectT, !,
	    'bindArgs.ast_argid31'(C, J1),
	    D=..[selectT|J1]
	;   B=identT, !,
	    'bindArgs.ast_argid32'(C, K1),
	    D=..[identT|K1]
	;   B=switchT, !,
	    'bindArgs.ast_argid33'(C, L1),
	    D=..[switchT|L1]
	;   B=synchronizedT, !,
	    'bindArgs.ast_argid34'(C, M1),
	    D=..[synchronizedT|M1]
	;   B=throwT, !,
	    'bindArgs.ast_argid35'(C, N1),
	    D=..[throwT|N1]
	;   B=toplevelT, !,
	    'bindArgs.ast_argid36'(C, O1),
	    D=..[toplevelT|O1]
	;   B=tryT, !,
	    'bindArgs.ast_argid37'(C, P1),
	    D=..[tryT|P1]
	;   B=typeCastT, !,
	    'bindArgs.ast_argid38'(C, Q1),
	    D=..[typeCastT|Q1]
	;   B=typeTestT, !,
	    'bindArgs.ast_argid39'(C, R1),
	    D=..[typeTestT|R1]
	;   B=whileLoopT, !,
	    'bindArgs.ast_argid40'(C, S1),
	    D=..[whileLoopT|S1]
	).
java_fq_to_pef1(A, D) :-
	A=..[B|C],
	(   B=extendsT, !,
	    'bindArgs.ast_argsub1'(C, E),
	    D=..[extendsT|E]
	;   B=modifierT, !,
	    'bindArgs.ast_argid41'(C, F),
	    D=..[modifierT|F]
	;   B=implementsT, !,
	    'bindArgs.ast_argsub1'(C, G),
	    D=..[implementsT|G]
	;   B=externT, !,
	    'bindArgs.ast_argid42'(C, H),
	    D=..[externT|H]
	;   B=interfaceT, !,
	    'bindArgs.ast_argid42'(C, I),
	    D=..[interfaceT|I]
	;   B=sourceLocation, !,
	    'bindArgs.ast_arg1'(C, J),
	    D=..[sourceLocation|J]
	;   B=projectLocationT, !,
	    'bindArgs.ast_arg2'(C, K),
	    D=..[projectLocationT|K]
	;   B=slT,
	    'bindArgs.ast_arg2'(C, L),
	    D=..[slT|L]
	).

% 'bindArgs.ast_argid1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [id]), ast_arg(name, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid1'([], []) :- !.
'bindArgs.ast_argid1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argname1'(B, C).
'bindArgs.ast_argid1'([null|A], [null|B]) :-
	'bindArgs.ast_argname1'(A, B), !.
'bindArgs.ast_argid1'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argname1'(C, D), !.
'bindArgs.ast_argid1'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argname1'(B, C), !.
'bindArgs.ast_argid1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argname1'(B, C), !.
'bindArgs.ast_argid1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argname1'(B, C), !.
'bindArgs.ast_argid1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argname1'(C, D), !.
'bindArgs.ast_argid1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argname1'(B, C), !.
'bindArgs.ast_argid1'([A|B], [A|C]) :-
	'bindArgs.ast_argname1'(B, C).

% 'bindArgs.ast_argname1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(name, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argname1'([], []) :- !.
'bindArgs.ast_argname1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argname1'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argname1'([A], [A]) :- !.
'bindArgs.ast_argname1'([A], [A]).

% map_type_term1('$VAR'(0), '$VAR'(1)):-map_type_term('$VAR'(1), '$VAR'(0))
map_type_term1(A, type(class, null, 0)) :-
	nonvar(A),
	A=null.
map_type_term1(A, D) :-
	nonvar(A),
	nonvar(A),
	arity_for_square_brackets1(A, C, B),
	map_to_basic_or_class1(B, C, D), !.
map_type_term1(A, type(class, B, 0)) :-
	fullQualifiedName1(A, B), !.
map_type_term1(E, type(class, A, G)) :-
	classDefT(A, B, D, _),
	classDefT(B, _, _, _),
	fullQualifiedName2(B, C),
	stringAppend(C, '.', D, F),
	nonvar(E),
	arity_for_square_brackets2(E, F, G), !.
map_type_term1(F, type(class, A, H)) :-
	classDefT(A, B, E, _),
	not(classDefT(B, _, _, _)),
	not(packageT(B, _)),
	enclClass1(B, C),
	fullQualifiedName2(C, D),
	stringAppend(D, '.', E, G),
	nonvar(F),
	arity_for_square_brackets2(F, G, H), !.
map_type_term1(B, type(class, A, D)) :-
	classDefT(A, null, C, _), !,
	nonvar(B),
	arity_for_square_brackets2(B, C, D).

% arity_for_square_brackets1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-arity_for_square_brackets('$VAR'(1), '$VAR'(0), '$VAR'(2))
arity_for_square_brackets1(A, 0, A) :-
	not(atom_concat(_, [], A)), !.
arity_for_square_brackets1(A, E, C) :-
	nonvar(A),
	atom_concat(B, [], A),
	arity_for_square_brackets1(B, D, C),
	succ(D, E), !.

% map_to_basic_or_class1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-map_to_basic_or_class('$VAR'(0), '$VAR'(1), '$VAR'(2))
map_to_basic_or_class1(A, C, B) :-
	basicType(A),
	B=type(basic, A, C), !.
map_to_basic_or_class1(A, D, B) :-
	nonvar(A),
	globalIds(A, C), !,
	B=type(class, C, D).
map_to_basic_or_class1(D, G, E) :-
	classDefT(F, A, C, _),
	classDefT(A, _, _, _),
	fullQualifiedName2(A, B),
	stringAppend(B, '.', C, D),
	E=type(class, F, G), !.
map_to_basic_or_class1(E, H, F) :-
	classDefT(G, A, D, _),
	not(classDefT(A, _, _, _)),
	not(packageT(A, _)),
	enclClass1(A, B),
	fullQualifiedName2(B, C),
	stringAppend(C, '.', D, E),
	F=type(class, G, H), !.
map_to_basic_or_class1(A, D, B) :-
	classDefT(C, null, A, _), !,
	B=type(class, C, D).

% original definition
:- dynamic globalIds/2.

% fullQualifiedName2('$VAR'(0), '$VAR'(1)):-fullQualifiedName('$VAR'(0), '$VAR'(1))
fullQualifiedName2(A, B) :-
	nonvar(A),
	classDefT(A, null, B, _), !.
fullQualifiedName2(A, E) :-
	nonvar(A),
	classDefT(A, B, D, _),
	packageT(B, C),
	stringAppend(C, '.', D, E), !.
fullQualifiedName2(A, E) :-
	classDefT(A, B, D, _),
	classDefT(B, _, _, _),
	fullQualifiedName2(B, C),
	stringAppend(C, '.', D, E).
fullQualifiedName2(A, F) :-
	classDefT(A, B, E, _),
	not(classDefT(B, _, _, _)),
	not(packageT(B, _)),
	enclClass1(B, C),
	fullQualifiedName2(C, D),
	stringAppend(D, '.', E, F).
fullQualifiedName2(A, B) :-
	classDefT(A, null, B, _), !.

% enclClass1('$VAR'(0), '$VAR'(1)):-enclClass('$VAR'(0), '$VAR'(1))
enclClass1(A, A) :-
	classDefT(A, _, _, _), !.
enclClass1(A, A) :-
	packageT(A, _), !,
	fail.
enclClass1(A, C) :-
	get_ast_node_enclosingJava1(A, B),
	enclClass1(B, C), !.
enclClass1(_, null).

% fullQualifiedName1('$VAR'(0), '$VAR'(1)):-fullQualifiedName('$VAR'(1), '$VAR'(0))
fullQualifiedName1(A, B) :-
	nonvar(A),
	globalIds(A, B), !.
fullQualifiedName1(E, A) :-
	classDefT(A, B, D, _),
	classDefT(B, _, _, _),
	fullQualifiedName2(B, C),
	stringAppend(C, '.', D, E).
fullQualifiedName1(F, A) :-
	classDefT(A, B, E, _),
	not(classDefT(B, _, _, _)),
	not(packageT(B, _)),
	enclClass1(B, C),
	fullQualifiedName2(C, D),
	stringAppend(D, '.', E, F).
fullQualifiedName1(B, A) :-
	classDefT(A, null, B, _), !.

% arity_for_square_brackets2('$VAR'(0), '$VAR'(1), '$VAR'(2)):-arity_for_square_brackets('$VAR'(2), '$VAR'(0), '$VAR'(1))
arity_for_square_brackets2(A, A, 0) :-
	not(atom_concat(_, [], A)), !.
arity_for_square_brackets2(A, C, E) :-
	nonvar(A),
	atom_concat(B, [], A),
	arity_for_square_brackets2(B, C, D),
	succ(D, E), !.

% '\\+number1'('$VAR'(0)):- \+number('$VAR'(0))
'\\+number1'(A) :-
	number(A), !,
	fail.
'\\+number1'(_).

% 'bindArgs.ast_argid2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [classDefT]), ast_arg(parent, mult(1, 1, no), id, [execT, packageT, classDefT, newClassT, blockT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid2'([], []) :- !.
'bindArgs.ast_argid2'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent1'(B, C).
'bindArgs.ast_argid2'([null|A], [null|B]) :-
	'bindArgs.ast_argparent1'(A, B), !.
'bindArgs.ast_argid2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent1'(C, D), !.
'bindArgs.ast_argid2'([A|C], [B|D]) :-
	member(typeTermType, [classDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent1'(C, D), !.
'bindArgs.ast_argid2'([A|B], [A|C]) :-
	not(member(classDefT, [classDefT])),
	'bindArgs.ast_argparent1'(B, C), !.
'bindArgs.ast_argid2'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent1'(B, C), !.
'bindArgs.ast_argid2'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent1'(B, C), !.
'bindArgs.ast_argid2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent1'(C, D), !.
'bindArgs.ast_argid2'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent1'(B, C), !.
'bindArgs.ast_argid2'([A|B], [A|C]) :-
	'bindArgs.ast_argparent1'(B, C).

% 'bindArgs.ast_argparent1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [execT, packageT, classDefT, newClassT, blockT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent1'([], []) :- !.
'bindArgs.ast_argparent1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argname2'(B, C).
'bindArgs.ast_argparent1'([null|A], [null|B]) :-
	'bindArgs.ast_argname2'(A, B), !.
'bindArgs.ast_argparent1'([A|C], [B|D]) :-
	member(typeTermType, [execT, packageT, classDefT, newClassT, blockT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argname2'(C, D), !.
'bindArgs.ast_argparent1'([A|B], [A|C]) :-
	not(member(classDefT, [execT, packageT, classDefT, newClassT, blockT])),
	'bindArgs.ast_argname2'(B, C), !.
'bindArgs.ast_argparent1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argname2'(B, C), !.
'bindArgs.ast_argparent1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argname2'(B, C), !.
'bindArgs.ast_argparent1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argname2'(C, D), !.
'bindArgs.ast_argparent1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argname2'(B, C), !.
'bindArgs.ast_argparent1'([A|B], [A|C]) :-
	'bindArgs.ast_argname2'(B, C).

% 'bindArgs.ast_argname2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argname2'([], []) :- !.
'bindArgs.ast_argname2'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argdefs1'(B, C).
'bindArgs.ast_argname2'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argdefs1'(C, D), !.
'bindArgs.ast_argname2'([A|B], [A|C]) :-
	'bindArgs.ast_argdefs1'(B, C), !.
'bindArgs.ast_argname2'([A|B], [A|C]) :-
	'bindArgs.ast_argdefs1'(B, C).

% 'bindArgs.ast_argdefs1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argdefs1'([], []) :- !.
'bindArgs.ast_argdefs1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argextends1'(B, C).
'bindArgs.ast_argdefs1'([A|C], [B|D]) :-
	member(classDefT, [methodDefT, fieldDefT, classDefT]), !,
	replaceFQNsWithClassIds1(A, B),
	'bindArgs.ast_argextends1'(C, D), !.
'bindArgs.ast_argdefs1'([null|A], [null|B]) :-
	'bindArgs.ast_argextends1'(A, B), !.
'bindArgs.ast_argdefs1'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT, classDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argextends1'(C, D), !.
'bindArgs.ast_argdefs1'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT, classDefT])),
	'bindArgs.ast_argextends1'(B, C), !.
'bindArgs.ast_argdefs1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argextends1'(B, C), !.
'bindArgs.ast_argdefs1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argextends1'(B, C), !.
'bindArgs.ast_argdefs1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argextends1'(C, D), !.
'bindArgs.ast_argdefs1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argextends1'(B, C), !.
'bindArgs.ast_argdefs1'([A|B], [A|C]) :-
	'bindArgs.ast_argextends1'(B, C).

% 'bindArgs.ast_argextends1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argextends1'([], []) :- !.
'bindArgs.ast_argextends1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argimplems1'(B, C).
'bindArgs.ast_argextends1'([null|A], [null|B]) :-
	'bindArgs.ast_argimplems1'(A, B), !.
'bindArgs.ast_argextends1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argimplems1'(C, D), !.
'bindArgs.ast_argextends1'([A|C], [B|D]) :-
	member(typeTermType, [classDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argimplems1'(C, D), !.
'bindArgs.ast_argextends1'([A|B], [A|C]) :-
	not(member(classDefT, [classDefT])),
	'bindArgs.ast_argimplems1'(B, C), !.
'bindArgs.ast_argextends1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argimplems1'(B, C), !.
'bindArgs.ast_argextends1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argimplems1'(B, C), !.
'bindArgs.ast_argextends1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argimplems1'(C, D), !.
'bindArgs.ast_argextends1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argimplems1'(B, C), !.
'bindArgs.ast_argextends1'([A|B], [A|C]) :-
	'bindArgs.ast_argimplems1'(B, C).

% 'bindArgs.ast_argimplems1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argimplems1'([], []) :- !.
'bindArgs.ast_argimplems1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_arghasModif1'(B, C).
'bindArgs.ast_argimplems1'([null|A], [null|B]) :-
	'bindArgs.ast_arghasModif1'(A, B), !.
'bindArgs.ast_argimplems1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arghasModif1'(C, D), !.
'bindArgs.ast_argimplems1'([A|C], [B|D]) :-
	member(typeTermType, [classDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_arghasModif1'(C, D), !.
'bindArgs.ast_argimplems1'([A|B], [A|C]) :-
	not(member(classDefT, [classDefT])),
	'bindArgs.ast_arghasModif1'(B, C), !.
'bindArgs.ast_argimplems1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_arghasModif1'(B, C), !.
'bindArgs.ast_argimplems1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_arghasModif1'(B, C), !.
'bindArgs.ast_argimplems1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arghasModif1'(C, D), !.
'bindArgs.ast_argimplems1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_arghasModif1'(B, C), !.
'bindArgs.ast_argimplems1'([A|B], [A|C]) :-
	'bindArgs.ast_arghasModif1'(B, C).

% 'bindArgs.ast_arghasModif1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_arghasModif1'([], []) :- !.
'bindArgs.ast_arghasModif1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argisInterf1'(B, C).
'bindArgs.ast_arghasModif1'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argisInterf1'(C, D), !.
'bindArgs.ast_arghasModif1'([A|B], [A|C]) :-
	'bindArgs.ast_argisInterf1'(B, C), !.
'bindArgs.ast_arghasModif1'([A|B], [A|C]) :-
	'bindArgs.ast_argisInterf1'(B, C).

% 'bindArgs.ast_argisInterf1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argisInterf1'([], []) :- !.
'bindArgs.ast_argisInterf1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argisExtern1'(B, C).
'bindArgs.ast_argisInterf1'([A|C], [B|D]) :-
	member(typeTermType, []), !,
	map_type_term1(A, B),
	'bindArgs.ast_argisExtern1'(C, D), !.
'bindArgs.ast_argisInterf1'([A|B], [A|C]) :-
	'bindArgs.ast_argisExtern1'(B, C).

% 'bindArgs.ast_argisExtern1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(isExtern, mult(0, 1, no), flag, [])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argisExtern1'([], []) :- !.
'bindArgs.ast_argisExtern1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argisExtern1'([A|C], [B|D]) :-
	member(typeTermType, []), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argisExtern1'([A], [A]).

% replaceFQNsWithClassIds1('$VAR'(0), '$VAR'(1)):-replaceFQNsWithClassIds('$VAR'(0), '$VAR'(1))
replaceFQNsWithClassIds1([], []).
replaceFQNsWithClassIds1([A|B], [_|C]) :-
	var(A), !,
	replaceFQNsWithClassIds1(B, C), !.
replaceFQNsWithClassIds1([A|C], [B|D]) :-
	fullQualifiedName1(A, B), !,
	replaceFQNsWithClassIds1(C, D), !.
replaceFQNsWithClassIds1([A|B], [A|C]) :-
	replaceFQNsWithClassIds1(B, C), !.

% 'bindArgs.ast_argid3'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [methodDefT]), ast_arg(parent, mult(1, 1, no), id, [classDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid3'([], []) :- !.
'bindArgs.ast_argid3'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent2'(B, C).
'bindArgs.ast_argid3'([null|A], [null|B]) :-
	'bindArgs.ast_argparent2'(A, B), !.
'bindArgs.ast_argid3'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent2'(C, D), !.
'bindArgs.ast_argid3'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_argparent2'(B, C), !.
'bindArgs.ast_argid3'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent2'(B, C), !.
'bindArgs.ast_argid3'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent2'(B, C), !.
'bindArgs.ast_argid3'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent2'(C, D), !.
'bindArgs.ast_argid3'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent2'(B, C), !.
'bindArgs.ast_argid3'([A|B], [A|C]) :-
	'bindArgs.ast_argparent2'(B, C).

% 'bindArgs.ast_argparent2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [classDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent2'([], []) :- !.
'bindArgs.ast_argparent2'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argname3'(B, C).
'bindArgs.ast_argparent2'([null|A], [null|B]) :-
	'bindArgs.ast_argname3'(A, B), !.
'bindArgs.ast_argparent2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argname3'(C, D), !.
'bindArgs.ast_argparent2'([A|C], [B|D]) :-
	member(typeTermType, [classDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argname3'(C, D), !.
'bindArgs.ast_argparent2'([A|B], [A|C]) :-
	not(member(classDefT, [classDefT])),
	'bindArgs.ast_argname3'(B, C), !.
'bindArgs.ast_argparent2'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argname3'(B, C), !.
'bindArgs.ast_argparent2'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argname3'(B, C), !.
'bindArgs.ast_argparent2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argname3'(C, D), !.
'bindArgs.ast_argparent2'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argname3'(B, C), !.
'bindArgs.ast_argparent2'([A|B], [A|C]) :-
	'bindArgs.ast_argname3'(B, C).

% 'bindArgs.ast_argname3'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argname3'([], []) :- !.
'bindArgs.ast_argname3'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparams1'(B, C).
'bindArgs.ast_argname3'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparams1'(C, D), !.
'bindArgs.ast_argname3'([A|B], [A|C]) :-
	'bindArgs.ast_argparams1'(B, C), !.
'bindArgs.ast_argname3'([A|B], [A|C]) :-
	'bindArgs.ast_argparams1'(B, C).

% 'bindArgs.ast_argparams1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparams1'([], []) :- !.
'bindArgs.ast_argparams1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argtype1'(B, C).
'bindArgs.ast_argparams1'([A|C], [B|D]) :-
	member(classDefT, [paramDefT]), !,
	replaceFQNsWithClassIds1(A, B),
	'bindArgs.ast_argtype1'(C, D), !.
'bindArgs.ast_argparams1'([null|A], [null|B]) :-
	'bindArgs.ast_argtype1'(A, B), !.
'bindArgs.ast_argparams1'([A|C], [B|D]) :-
	member(typeTermType, [paramDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argtype1'(C, D), !.
'bindArgs.ast_argparams1'([A|B], [A|C]) :-
	not(member(classDefT, [paramDefT])),
	'bindArgs.ast_argtype1'(B, C), !.
'bindArgs.ast_argparams1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argtype1'(B, C), !.
'bindArgs.ast_argparams1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argtype1'(B, C), !.
'bindArgs.ast_argparams1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argtype1'(C, D), !.
'bindArgs.ast_argparams1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argtype1'(B, C), !.
'bindArgs.ast_argparams1'([A|B], [A|C]) :-
	'bindArgs.ast_argtype1'(B, C).

% 'bindArgs.ast_argtype1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argtype1'([], []) :- !.
'bindArgs.ast_argtype1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argexcepts1'(B, C).
'bindArgs.ast_argtype1'([A|C], [B|D]) :-
	member(typeTermType, [typeTermType, nullType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argexcepts1'(C, D), !.
'bindArgs.ast_argtype1'([A|B], [A|C]) :-
	'bindArgs.ast_argexcepts1'(B, C), !.
'bindArgs.ast_argtype1'([A|B], [A|C]) :-
	'bindArgs.ast_argexcepts1'(B, C).

% 'bindArgs.ast_argexcepts1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argexcepts1'([], []) :- !.
'bindArgs.ast_argexcepts1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argbody1'(B, C).
'bindArgs.ast_argexcepts1'([A|C], [B|D]) :-
	member(classDefT, [classDefT]), !,
	replaceFQNsWithClassIds1(A, B),
	'bindArgs.ast_argbody1'(C, D), !.
'bindArgs.ast_argexcepts1'([null|A], [null|B]) :-
	'bindArgs.ast_argbody1'(A, B), !.
'bindArgs.ast_argexcepts1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argbody1'(C, D), !.
'bindArgs.ast_argexcepts1'([A|C], [B|D]) :-
	member(typeTermType, [classDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argbody1'(C, D), !.
'bindArgs.ast_argexcepts1'([A|B], [A|C]) :-
	not(member(classDefT, [classDefT])),
	'bindArgs.ast_argbody1'(B, C), !.
'bindArgs.ast_argexcepts1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argbody1'(B, C), !.
'bindArgs.ast_argexcepts1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argbody1'(B, C), !.
'bindArgs.ast_argexcepts1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argbody1'(C, D), !.
'bindArgs.ast_argexcepts1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argbody1'(B, C), !.
'bindArgs.ast_argexcepts1'([A|B], [A|C]) :-
	'bindArgs.ast_argbody1'(B, C).

% 'bindArgs.ast_argbody1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argbody1'([], []) :- !.
'bindArgs.ast_argbody1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_arghasModif2'(B, C).
'bindArgs.ast_argbody1'([null|A], [null|B]) :-
	'bindArgs.ast_arghasModif2'(A, B), !.
'bindArgs.ast_argbody1'([A|C], [B|D]) :-
	member(typeTermType, [blockT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_arghasModif2'(C, D), !.
'bindArgs.ast_argbody1'([A|B], [A|C]) :-
	not(member(classDefT, [blockT])),
	'bindArgs.ast_arghasModif2'(B, C), !.
'bindArgs.ast_argbody1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_arghasModif2'(B, C), !.
'bindArgs.ast_argbody1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_arghasModif2'(B, C), !.
'bindArgs.ast_argbody1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arghasModif2'(C, D), !.
'bindArgs.ast_argbody1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_arghasModif2'(B, C), !.
'bindArgs.ast_argbody1'([A|B], [A|C]) :-
	'bindArgs.ast_arghasModif2'(B, C).

% 'bindArgs.ast_arghasModif2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_arghasModif2'([], []) :- !.
'bindArgs.ast_arghasModif2'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_arghasModif2'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_arghasModif2'([A], [A]) :- !.
'bindArgs.ast_arghasModif2'([A], [A]).

% 'bindArgs.ast_argid4'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [fieldDefT]), ast_arg(parent, mult(1, 1, no), id, [classDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid4'([], []) :- !.
'bindArgs.ast_argid4'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent3'(B, C).
'bindArgs.ast_argid4'([null|A], [null|B]) :-
	'bindArgs.ast_argparent3'(A, B), !.
'bindArgs.ast_argid4'([A|C], [B|D]) :-
	member(typeTermType, [fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent3'(C, D), !.
'bindArgs.ast_argid4'([A|B], [A|C]) :-
	not(member(classDefT, [fieldDefT])),
	'bindArgs.ast_argparent3'(B, C), !.
'bindArgs.ast_argid4'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent3'(B, C), !.
'bindArgs.ast_argid4'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent3'(B, C), !.
'bindArgs.ast_argid4'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent3'(C, D), !.
'bindArgs.ast_argid4'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent3'(B, C), !.
'bindArgs.ast_argid4'([A|B], [A|C]) :-
	'bindArgs.ast_argparent3'(B, C).

% 'bindArgs.ast_argparent3'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [classDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent3'([], []) :- !.
'bindArgs.ast_argparent3'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argtype2'(B, C).
'bindArgs.ast_argparent3'([null|A], [null|B]) :-
	'bindArgs.ast_argtype2'(A, B), !.
'bindArgs.ast_argparent3'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argtype2'(C, D), !.
'bindArgs.ast_argparent3'([A|C], [B|D]) :-
	member(typeTermType, [classDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argtype2'(C, D), !.
'bindArgs.ast_argparent3'([A|B], [A|C]) :-
	not(member(classDefT, [classDefT])),
	'bindArgs.ast_argtype2'(B, C), !.
'bindArgs.ast_argparent3'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argtype2'(B, C), !.
'bindArgs.ast_argparent3'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argtype2'(B, C), !.
'bindArgs.ast_argparent3'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argtype2'(C, D), !.
'bindArgs.ast_argparent3'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argtype2'(B, C), !.
'bindArgs.ast_argparent3'([A|B], [A|C]) :-
	'bindArgs.ast_argtype2'(B, C).

% 'bindArgs.ast_argtype2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argtype2'([], []) :- !.
'bindArgs.ast_argtype2'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argname4'(B, C).
'bindArgs.ast_argtype2'([A|C], [B|D]) :-
	member(typeTermType, [typeTermType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argname4'(C, D), !.
'bindArgs.ast_argtype2'([A|B], [A|C]) :-
	'bindArgs.ast_argname4'(B, C), !.
'bindArgs.ast_argtype2'([A|B], [A|C]) :-
	'bindArgs.ast_argname4'(B, C).

% 'bindArgs.ast_argname4'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argname4'([], []) :- !.
'bindArgs.ast_argname4'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argexpr1'(B, C).
'bindArgs.ast_argname4'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argexpr1'(C, D), !.
'bindArgs.ast_argname4'([A|B], [A|C]) :-
	'bindArgs.ast_argexpr1'(B, C), !.
'bindArgs.ast_argname4'([A|B], [A|C]) :-
	'bindArgs.ast_argexpr1'(B, C).

% 'bindArgs.ast_argexpr1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argexpr1'([], []) :- !.
'bindArgs.ast_argexpr1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_arghasModif2'(B, C).
'bindArgs.ast_argexpr1'([null|A], [null|B]) :-
	'bindArgs.ast_arghasModif2'(A, B), !.
'bindArgs.ast_argexpr1'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_arghasModif2'(C, D), !.
'bindArgs.ast_argexpr1'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_arghasModif2'(B, C), !.
'bindArgs.ast_argexpr1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_arghasModif2'(B, C), !.
'bindArgs.ast_argexpr1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_arghasModif2'(B, C), !.
'bindArgs.ast_argexpr1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arghasModif2'(C, D), !.
'bindArgs.ast_argexpr1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_arghasModif2'(B, C), !.
'bindArgs.ast_argexpr1'([A|B], [A|C]) :-
	'bindArgs.ast_arghasModif2'(B, C).

% 'bindArgs.ast_argid5'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [paramDefT]), ast_arg(parent, mult(1, 1, no), id, [methodDefT, catchT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid5'([], []) :- !.
'bindArgs.ast_argid5'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent4'(B, C).
'bindArgs.ast_argid5'([null|A], [null|B]) :-
	'bindArgs.ast_argparent4'(A, B), !.
'bindArgs.ast_argid5'([A|C], [B|D]) :-
	member(typeTermType, [paramDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent4'(C, D), !.
'bindArgs.ast_argid5'([A|B], [A|C]) :-
	not(member(classDefT, [paramDefT])),
	'bindArgs.ast_argparent4'(B, C), !.
'bindArgs.ast_argid5'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent4'(B, C), !.
'bindArgs.ast_argid5'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent4'(B, C), !.
'bindArgs.ast_argid5'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent4'(C, D), !.
'bindArgs.ast_argid5'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent4'(B, C), !.
'bindArgs.ast_argid5'([A|B], [A|C]) :-
	'bindArgs.ast_argparent4'(B, C).

% 'bindArgs.ast_argparent4'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [methodDefT, catchT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent4'([], []) :- !.
'bindArgs.ast_argparent4'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argtype3'(B, C).
'bindArgs.ast_argparent4'([null|A], [null|B]) :-
	'bindArgs.ast_argtype3'(A, B), !.
'bindArgs.ast_argparent4'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, catchT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argtype3'(C, D), !.
'bindArgs.ast_argparent4'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, catchT])),
	'bindArgs.ast_argtype3'(B, C), !.
'bindArgs.ast_argparent4'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argtype3'(B, C), !.
'bindArgs.ast_argparent4'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argtype3'(B, C), !.
'bindArgs.ast_argparent4'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argtype3'(C, D), !.
'bindArgs.ast_argparent4'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argtype3'(B, C), !.
'bindArgs.ast_argparent4'([A|B], [A|C]) :-
	'bindArgs.ast_argtype3'(B, C).

% 'bindArgs.ast_argtype3'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argtype3'([], []) :- !.
'bindArgs.ast_argtype3'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argname5'(B, C).
'bindArgs.ast_argtype3'([A|C], [B|D]) :-
	member(typeTermType, [typeTermType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argname5'(C, D), !.
'bindArgs.ast_argtype3'([A|B], [A|C]) :-
	'bindArgs.ast_argname5'(B, C), !.
'bindArgs.ast_argtype3'([A|B], [A|C]) :-
	'bindArgs.ast_argname5'(B, C).

% 'bindArgs.ast_argname5'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argname5'([], []) :- !.
'bindArgs.ast_argname5'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_arghasModif2'(B, C).
'bindArgs.ast_argname5'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	'bindArgs.ast_arghasModif2'(C, D), !.
'bindArgs.ast_argname5'([A|B], [A|C]) :-
	'bindArgs.ast_arghasModif2'(B, C), !.
'bindArgs.ast_argname5'([A|B], [A|C]) :-
	'bindArgs.ast_arghasModif2'(B, C).

% 'bindArgs.ast_argid6'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [applyT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid6'([], []) :- !.
'bindArgs.ast_argid6'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent5'(B, C).
'bindArgs.ast_argid6'([null|A], [null|B]) :-
	'bindArgs.ast_argparent5'(A, B), !.
'bindArgs.ast_argid6'([A|C], [B|D]) :-
	member(typeTermType, [applyT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent5'(C, D), !.
'bindArgs.ast_argid6'([A|B], [A|C]) :-
	not(member(classDefT, [applyT])),
	'bindArgs.ast_argparent5'(B, C), !.
'bindArgs.ast_argid6'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent5'(B, C), !.
'bindArgs.ast_argid6'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent5'(B, C), !.
'bindArgs.ast_argid6'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent5'(C, D), !.
'bindArgs.ast_argid6'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent5'(B, C), !.
'bindArgs.ast_argid6'([A|B], [A|C]) :-
	'bindArgs.ast_argparent5'(B, C).

% 'bindArgs.ast_argparent5'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent5'([], []) :- !.
'bindArgs.ast_argparent5'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl1'(B, C).
'bindArgs.ast_argparent5'([null|A], [null|B]) :-
	'bindArgs.ast_argencl1'(A, B), !.
'bindArgs.ast_argparent5'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl1'(C, D), !.
'bindArgs.ast_argparent5'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl1'(B, C), !.
'bindArgs.ast_argparent5'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl1'(B, C), !.
'bindArgs.ast_argparent5'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl1'(B, C), !.
'bindArgs.ast_argparent5'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl1'(C, D), !.
'bindArgs.ast_argparent5'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl1'(B, C), !.
'bindArgs.ast_argparent5'([A|B], [A|C]) :-
	'bindArgs.ast_argencl1'(B, C).

% 'bindArgs.ast_argencl1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl1'([], []) :- !.
'bindArgs.ast_argencl1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argexpr2'(B, C).
'bindArgs.ast_argencl1'([null|A], [null|B]) :-
	'bindArgs.ast_argexpr2'(A, B), !.
'bindArgs.ast_argencl1'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argexpr2'(C, D), !.
'bindArgs.ast_argencl1'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT])),
	'bindArgs.ast_argexpr2'(B, C), !.
'bindArgs.ast_argencl1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argexpr2'(B, C), !.
'bindArgs.ast_argencl1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argexpr2'(B, C), !.
'bindArgs.ast_argencl1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argexpr2'(C, D), !.
'bindArgs.ast_argencl1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argexpr2'(B, C), !.
'bindArgs.ast_argencl1'([A|B], [A|C]) :-
	'bindArgs.ast_argexpr2'(B, C).

% 'bindArgs.ast_argexpr2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argexpr2'([], []) :- !.
'bindArgs.ast_argexpr2'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argname6'(B, C).
'bindArgs.ast_argexpr2'([null|A], [null|B]) :-
	'bindArgs.ast_argname6'(A, B), !.
'bindArgs.ast_argexpr2'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argname6'(C, D), !.
'bindArgs.ast_argexpr2'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_argname6'(B, C), !.
'bindArgs.ast_argexpr2'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argname6'(B, C), !.
'bindArgs.ast_argexpr2'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argname6'(B, C), !.
'bindArgs.ast_argexpr2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argname6'(C, D), !.
'bindArgs.ast_argexpr2'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argname6'(B, C), !.
'bindArgs.ast_argexpr2'([A|B], [A|C]) :-
	'bindArgs.ast_argname6'(B, C).

% 'bindArgs.ast_argname6'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argname6'([], []) :- !.
'bindArgs.ast_argname6'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argargs1'(B, C).
'bindArgs.ast_argname6'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argargs1'(C, D), !.
'bindArgs.ast_argname6'([A|B], [A|C]) :-
	'bindArgs.ast_argargs1'(B, C), !.
'bindArgs.ast_argname6'([A|B], [A|C]) :-
	'bindArgs.ast_argargs1'(B, C).

% 'bindArgs.ast_argargs1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argargs1'([], []) :- !.
'bindArgs.ast_argargs1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argref1'(B, C).
'bindArgs.ast_argargs1'([A|C], [B|D]) :-
	member(classDefT, [expressionType]), !,
	replaceFQNsWithClassIds1(A, B),
	'bindArgs.ast_argref1'(C, D), !.
'bindArgs.ast_argargs1'([null|A], [null|B]) :-
	'bindArgs.ast_argref1'(A, B), !.
'bindArgs.ast_argargs1'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argref1'(C, D), !.
'bindArgs.ast_argargs1'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_argref1'(B, C), !.
'bindArgs.ast_argargs1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argref1'(B, C), !.
'bindArgs.ast_argargs1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argref1'(B, C), !.
'bindArgs.ast_argargs1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argref1'(C, D), !.
'bindArgs.ast_argargs1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argref1'(B, C), !.
'bindArgs.ast_argargs1'([A|B], [A|C]) :-
	'bindArgs.ast_argref1'(B, C).

% 'bindArgs.ast_argref1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(ref, mult(1, 1, no), id, [methodDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argref1'([], []) :- !.
'bindArgs.ast_argref1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argref1'([null], [null]) :- !.
'bindArgs.ast_argref1'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argref1'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	B=[],
	C=[], !.
'bindArgs.ast_argref1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argref1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argref1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argref1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argref1'([A], [A]).

% 'bindArgs.ast_argid7'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [assertT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(msg, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid7'([], []) :- !.
'bindArgs.ast_argid7'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent6'(B, C).
'bindArgs.ast_argid7'([null|A], [null|B]) :-
	'bindArgs.ast_argparent6'(A, B), !.
'bindArgs.ast_argid7'([A|C], [B|D]) :-
	member(typeTermType, [assertT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent6'(C, D), !.
'bindArgs.ast_argid7'([A|B], [A|C]) :-
	not(member(classDefT, [assertT])),
	'bindArgs.ast_argparent6'(B, C), !.
'bindArgs.ast_argid7'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent6'(B, C), !.
'bindArgs.ast_argid7'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent6'(B, C), !.
'bindArgs.ast_argid7'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent6'(C, D), !.
'bindArgs.ast_argid7'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent6'(B, C), !.
'bindArgs.ast_argid7'([A|B], [A|C]) :-
	'bindArgs.ast_argparent6'(B, C).

% 'bindArgs.ast_argparent6'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(msg, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent6'([], []) :- !.
'bindArgs.ast_argparent6'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl2'(B, C).
'bindArgs.ast_argparent6'([null|A], [null|B]) :-
	'bindArgs.ast_argencl2'(A, B), !.
'bindArgs.ast_argparent6'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl2'(C, D), !.
'bindArgs.ast_argparent6'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl2'(B, C), !.
'bindArgs.ast_argparent6'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl2'(B, C), !.
'bindArgs.ast_argparent6'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl2'(B, C), !.
'bindArgs.ast_argparent6'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl2'(C, D), !.
'bindArgs.ast_argparent6'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl2'(B, C), !.
'bindArgs.ast_argparent6'([A|B], [A|C]) :-
	'bindArgs.ast_argencl2'(B, C).

% 'bindArgs.ast_argencl2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(msg, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl2'([], []) :- !.
'bindArgs.ast_argencl2'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argexpr3'(B, C).
'bindArgs.ast_argencl2'([null|A], [null|B]) :-
	'bindArgs.ast_argexpr3'(A, B), !.
'bindArgs.ast_argencl2'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argexpr3'(C, D), !.
'bindArgs.ast_argencl2'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_argexpr3'(B, C), !.
'bindArgs.ast_argencl2'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argexpr3'(B, C), !.
'bindArgs.ast_argencl2'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argexpr3'(B, C), !.
'bindArgs.ast_argencl2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argexpr3'(C, D), !.
'bindArgs.ast_argencl2'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argexpr3'(B, C), !.
'bindArgs.ast_argencl2'([A|B], [A|C]) :-
	'bindArgs.ast_argexpr3'(B, C).

% 'bindArgs.ast_argexpr3'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(msg, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argexpr3'([], []) :- !.
'bindArgs.ast_argexpr3'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argmsg1'(B, C).
'bindArgs.ast_argexpr3'([null|A], [null|B]) :-
	'bindArgs.ast_argmsg1'(A, B), !.
'bindArgs.ast_argexpr3'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argmsg1'(C, D), !.
'bindArgs.ast_argexpr3'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_argmsg1'(B, C), !.
'bindArgs.ast_argexpr3'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argmsg1'(B, C), !.
'bindArgs.ast_argexpr3'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argmsg1'(B, C), !.
'bindArgs.ast_argexpr3'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argmsg1'(C, D), !.
'bindArgs.ast_argexpr3'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argmsg1'(B, C), !.
'bindArgs.ast_argexpr3'([A|B], [A|C]) :-
	'bindArgs.ast_argmsg1'(B, C).

% 'bindArgs.ast_argmsg1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(msg, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argmsg1'([], []) :- !.
'bindArgs.ast_argmsg1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argmsg1'([null], [null]) :- !.
'bindArgs.ast_argmsg1'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argmsg1'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	B=[],
	C=[], !.
'bindArgs.ast_argmsg1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argmsg1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argmsg1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argmsg1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argmsg1'([A], [A]).

% 'bindArgs.ast_argid8'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [assignT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid8'([], []) :- !.
'bindArgs.ast_argid8'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent7'(B, C).
'bindArgs.ast_argid8'([null|A], [null|B]) :-
	'bindArgs.ast_argparent7'(A, B), !.
'bindArgs.ast_argid8'([A|C], [B|D]) :-
	member(typeTermType, [assignT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent7'(C, D), !.
'bindArgs.ast_argid8'([A|B], [A|C]) :-
	not(member(classDefT, [assignT])),
	'bindArgs.ast_argparent7'(B, C), !.
'bindArgs.ast_argid8'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent7'(B, C), !.
'bindArgs.ast_argid8'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent7'(B, C), !.
'bindArgs.ast_argid8'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent7'(C, D), !.
'bindArgs.ast_argid8'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent7'(B, C), !.
'bindArgs.ast_argid8'([A|B], [A|C]) :-
	'bindArgs.ast_argparent7'(B, C).

% 'bindArgs.ast_argparent7'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent7'([], []) :- !.
'bindArgs.ast_argparent7'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl3'(B, C).
'bindArgs.ast_argparent7'([null|A], [null|B]) :-
	'bindArgs.ast_argencl3'(A, B), !.
'bindArgs.ast_argparent7'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl3'(C, D), !.
'bindArgs.ast_argparent7'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl3'(B, C), !.
'bindArgs.ast_argparent7'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl3'(B, C), !.
'bindArgs.ast_argparent7'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl3'(B, C), !.
'bindArgs.ast_argparent7'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl3'(C, D), !.
'bindArgs.ast_argparent7'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl3'(B, C), !.
'bindArgs.ast_argparent7'([A|B], [A|C]) :-
	'bindArgs.ast_argencl3'(B, C).

% 'bindArgs.ast_argencl3'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl3'([], []) :- !.
'bindArgs.ast_argencl3'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_arglhs1'(B, C).
'bindArgs.ast_argencl3'([null|A], [null|B]) :-
	'bindArgs.ast_arglhs1'(A, B), !.
'bindArgs.ast_argencl3'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_arglhs1'(C, D), !.
'bindArgs.ast_argencl3'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT])),
	'bindArgs.ast_arglhs1'(B, C), !.
'bindArgs.ast_argencl3'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_arglhs1'(B, C), !.
'bindArgs.ast_argencl3'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_arglhs1'(B, C), !.
'bindArgs.ast_argencl3'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arglhs1'(C, D), !.
'bindArgs.ast_argencl3'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_arglhs1'(B, C), !.
'bindArgs.ast_argencl3'([A|B], [A|C]) :-
	'bindArgs.ast_arglhs1'(B, C).

% 'bindArgs.ast_arglhs1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_arglhs1'([], []) :- !.
'bindArgs.ast_arglhs1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argexpr4'(B, C).
'bindArgs.ast_arglhs1'([null|A], [null|B]) :-
	'bindArgs.ast_argexpr4'(A, B), !.
'bindArgs.ast_arglhs1'([A|C], [B|D]) :-
	member(typeTermType, [getFieldT, identT, indexedT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argexpr4'(C, D), !.
'bindArgs.ast_arglhs1'([A|B], [A|C]) :-
	not(member(classDefT, [getFieldT, identT, indexedT])),
	'bindArgs.ast_argexpr4'(B, C), !.
'bindArgs.ast_arglhs1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argexpr4'(B, C), !.
'bindArgs.ast_arglhs1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argexpr4'(B, C), !.
'bindArgs.ast_arglhs1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argexpr4'(C, D), !.
'bindArgs.ast_arglhs1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argexpr4'(B, C), !.
'bindArgs.ast_arglhs1'([A|B], [A|C]) :-
	'bindArgs.ast_argexpr4'(B, C).

% 'bindArgs.ast_argexpr4'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argexpr4'([], []) :- !.
'bindArgs.ast_argexpr4'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argexpr4'([null], [null]) :- !.
'bindArgs.ast_argexpr4'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argexpr4'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	B=[],
	C=[], !.
'bindArgs.ast_argexpr4'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argexpr4'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argexpr4'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argexpr4'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argexpr4'([A], [A]).

% 'bindArgs.ast_argid9'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [assignopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid9'([], []) :- !.
'bindArgs.ast_argid9'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent8'(B, C).
'bindArgs.ast_argid9'([null|A], [null|B]) :-
	'bindArgs.ast_argparent8'(A, B), !.
'bindArgs.ast_argid9'([A|C], [B|D]) :-
	member(typeTermType, [assignopT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent8'(C, D), !.
'bindArgs.ast_argid9'([A|B], [A|C]) :-
	not(member(classDefT, [assignopT])),
	'bindArgs.ast_argparent8'(B, C), !.
'bindArgs.ast_argid9'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent8'(B, C), !.
'bindArgs.ast_argid9'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent8'(B, C), !.
'bindArgs.ast_argid9'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent8'(C, D), !.
'bindArgs.ast_argid9'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent8'(B, C), !.
'bindArgs.ast_argid9'([A|B], [A|C]) :-
	'bindArgs.ast_argparent8'(B, C).

% 'bindArgs.ast_argparent8'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent8'([], []) :- !.
'bindArgs.ast_argparent8'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl4'(B, C).
'bindArgs.ast_argparent8'([null|A], [null|B]) :-
	'bindArgs.ast_argencl4'(A, B), !.
'bindArgs.ast_argparent8'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl4'(C, D), !.
'bindArgs.ast_argparent8'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl4'(B, C), !.
'bindArgs.ast_argparent8'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl4'(B, C), !.
'bindArgs.ast_argparent8'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl4'(B, C), !.
'bindArgs.ast_argparent8'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl4'(C, D), !.
'bindArgs.ast_argparent8'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl4'(B, C), !.
'bindArgs.ast_argparent8'([A|B], [A|C]) :-
	'bindArgs.ast_argencl4'(B, C).

% 'bindArgs.ast_argencl4'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl4'([], []) :- !.
'bindArgs.ast_argencl4'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_arglhs2'(B, C).
'bindArgs.ast_argencl4'([null|A], [null|B]) :-
	'bindArgs.ast_arglhs2'(A, B), !.
'bindArgs.ast_argencl4'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_arglhs2'(C, D), !.
'bindArgs.ast_argencl4'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT])),
	'bindArgs.ast_arglhs2'(B, C), !.
'bindArgs.ast_argencl4'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_arglhs2'(B, C), !.
'bindArgs.ast_argencl4'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_arglhs2'(B, C), !.
'bindArgs.ast_argencl4'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arglhs2'(C, D), !.
'bindArgs.ast_argencl4'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_arglhs2'(B, C), !.
'bindArgs.ast_argencl4'([A|B], [A|C]) :-
	'bindArgs.ast_arglhs2'(B, C).

% 'bindArgs.ast_arglhs2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_arglhs2'([], []) :- !.
'bindArgs.ast_arglhs2'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argoperator1'(B, C).
'bindArgs.ast_arglhs2'([null|A], [null|B]) :-
	'bindArgs.ast_argoperator1'(A, B), !.
'bindArgs.ast_arglhs2'([A|C], [B|D]) :-
	member(typeTermType, [getFieldT, identT, indexedT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argoperator1'(C, D), !.
'bindArgs.ast_arglhs2'([A|B], [A|C]) :-
	not(member(classDefT, [getFieldT, identT, indexedT])),
	'bindArgs.ast_argoperator1'(B, C), !.
'bindArgs.ast_arglhs2'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argoperator1'(B, C), !.
'bindArgs.ast_arglhs2'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argoperator1'(B, C), !.
'bindArgs.ast_arglhs2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argoperator1'(C, D), !.
'bindArgs.ast_arglhs2'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argoperator1'(B, C), !.
'bindArgs.ast_arglhs2'([A|B], [A|C]) :-
	'bindArgs.ast_argoperator1'(B, C).

% 'bindArgs.ast_argoperator1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argoperator1'([], []) :- !.
'bindArgs.ast_argoperator1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argexpr4'(B, C).
'bindArgs.ast_argoperator1'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argexpr4'(C, D), !.
'bindArgs.ast_argoperator1'([A|B], [A|C]) :-
	'bindArgs.ast_argexpr4'(B, C), !.
'bindArgs.ast_argoperator1'([A|B], [A|C]) :-
	'bindArgs.ast_argexpr4'(B, C).

% 'bindArgs.ast_argid10'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [blockT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(stmts, mult(0, *, ord), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid10'([], []) :- !.
'bindArgs.ast_argid10'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent9'(B, C).
'bindArgs.ast_argid10'([null|A], [null|B]) :-
	'bindArgs.ast_argparent9'(A, B), !.
'bindArgs.ast_argid10'([A|C], [B|D]) :-
	member(typeTermType, [blockT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent9'(C, D), !.
'bindArgs.ast_argid10'([A|B], [A|C]) :-
	not(member(classDefT, [blockT])),
	'bindArgs.ast_argparent9'(B, C), !.
'bindArgs.ast_argid10'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent9'(B, C), !.
'bindArgs.ast_argid10'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent9'(B, C), !.
'bindArgs.ast_argid10'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent9'(C, D), !.
'bindArgs.ast_argid10'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent9'(B, C), !.
'bindArgs.ast_argid10'([A|B], [A|C]) :-
	'bindArgs.ast_argparent9'(B, C).

% 'bindArgs.ast_argparent9'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(stmts, mult(0, *, ord), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent9'([], []) :- !.
'bindArgs.ast_argparent9'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl5'(B, C).
'bindArgs.ast_argparent9'([null|A], [null|B]) :-
	'bindArgs.ast_argencl5'(A, B), !.
'bindArgs.ast_argparent9'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl5'(C, D), !.
'bindArgs.ast_argparent9'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl5'(B, C), !.
'bindArgs.ast_argparent9'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl5'(B, C), !.
'bindArgs.ast_argparent9'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl5'(B, C), !.
'bindArgs.ast_argparent9'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl5'(C, D), !.
'bindArgs.ast_argparent9'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl5'(B, C), !.
'bindArgs.ast_argparent9'([A|B], [A|C]) :-
	'bindArgs.ast_argencl5'(B, C).

% 'bindArgs.ast_argencl5'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(stmts, mult(0, *, ord), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl5'([], []) :- !.
'bindArgs.ast_argencl5'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argstmts1'(B, C).
'bindArgs.ast_argencl5'([null|A], [null|B]) :-
	'bindArgs.ast_argstmts1'(A, B), !.
'bindArgs.ast_argencl5'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argstmts1'(C, D), !.
'bindArgs.ast_argencl5'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_argstmts1'(B, C), !.
'bindArgs.ast_argencl5'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argstmts1'(B, C), !.
'bindArgs.ast_argencl5'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argstmts1'(B, C), !.
'bindArgs.ast_argencl5'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argstmts1'(C, D), !.
'bindArgs.ast_argencl5'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argstmts1'(B, C), !.
'bindArgs.ast_argencl5'([A|B], [A|C]) :-
	'bindArgs.ast_argstmts1'(B, C).

% 'bindArgs.ast_argstmts1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(stmts, mult(0, *, ord), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argstmts1'([], []) :- !.
'bindArgs.ast_argstmts1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argstmts1'([A|C], [B|D]) :-
	member(classDefT, [statementType]), !,
	replaceFQNsWithClassIds1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argstmts1'([null], [null]) :- !.
'bindArgs.ast_argstmts1'([A|C], [B|D]) :-
	member(typeTermType, [statementType]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argstmts1'([A|B], [A|C]) :-
	not(member(classDefT, [statementType])),
	B=[],
	C=[], !.
'bindArgs.ast_argstmts1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argstmts1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argstmts1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argstmts1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argstmts1'([A], [A]).

% 'bindArgs.ast_argid11'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [breakT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid11'([], []) :- !.
'bindArgs.ast_argid11'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent10'(B, C).
'bindArgs.ast_argid11'([null|A], [null|B]) :-
	'bindArgs.ast_argparent10'(A, B), !.
'bindArgs.ast_argid11'([A|C], [B|D]) :-
	member(typeTermType, [breakT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent10'(C, D), !.
'bindArgs.ast_argid11'([A|B], [A|C]) :-
	not(member(classDefT, [breakT])),
	'bindArgs.ast_argparent10'(B, C), !.
'bindArgs.ast_argid11'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent10'(B, C), !.
'bindArgs.ast_argid11'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent10'(B, C), !.
'bindArgs.ast_argid11'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent10'(C, D), !.
'bindArgs.ast_argid11'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent10'(B, C), !.
'bindArgs.ast_argid11'([A|B], [A|C]) :-
	'bindArgs.ast_argparent10'(B, C).

% 'bindArgs.ast_argparent10'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent10'([], []) :- !.
'bindArgs.ast_argparent10'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl6'(B, C).
'bindArgs.ast_argparent10'([null|A], [null|B]) :-
	'bindArgs.ast_argencl6'(A, B), !.
'bindArgs.ast_argparent10'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl6'(C, D), !.
'bindArgs.ast_argparent10'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl6'(B, C), !.
'bindArgs.ast_argparent10'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl6'(B, C), !.
'bindArgs.ast_argparent10'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl6'(B, C), !.
'bindArgs.ast_argparent10'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl6'(C, D), !.
'bindArgs.ast_argparent10'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl6'(B, C), !.
'bindArgs.ast_argparent10'([A|B], [A|C]) :-
	'bindArgs.ast_argencl6'(B, C).

% 'bindArgs.ast_argencl6'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl6'([], []) :- !.
'bindArgs.ast_argencl6'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_arglabel1'(B, C).
'bindArgs.ast_argencl6'([null|A], [null|B]) :-
	'bindArgs.ast_arglabel1'(A, B), !.
'bindArgs.ast_argencl6'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_arglabel1'(C, D), !.
'bindArgs.ast_argencl6'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_arglabel1'(B, C), !.
'bindArgs.ast_argencl6'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_arglabel1'(B, C), !.
'bindArgs.ast_argencl6'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_arglabel1'(B, C), !.
'bindArgs.ast_argencl6'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arglabel1'(C, D), !.
'bindArgs.ast_argencl6'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_arglabel1'(B, C), !.
'bindArgs.ast_argencl6'([A|B], [A|C]) :-
	'bindArgs.ast_arglabel1'(B, C).

% 'bindArgs.ast_arglabel1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_arglabel1'([], []) :- !.
'bindArgs.ast_arglabel1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argtarget1'(B, C).
'bindArgs.ast_arglabel1'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argtarget1'(C, D), !.
'bindArgs.ast_arglabel1'([A|B], [A|C]) :-
	'bindArgs.ast_argtarget1'(B, C), !.
'bindArgs.ast_arglabel1'([A|B], [A|C]) :-
	'bindArgs.ast_argtarget1'(B, C).

% 'bindArgs.ast_argtarget1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(target, mult(0, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argtarget1'([], []) :- !.
'bindArgs.ast_argtarget1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argtarget1'([null], [null]) :- !.
'bindArgs.ast_argtarget1'([A|C], [B|D]) :-
	member(typeTermType, [statementType]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argtarget1'([A|B], [A|C]) :-
	not(member(classDefT, [statementType])),
	B=[],
	C=[], !.
'bindArgs.ast_argtarget1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argtarget1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argtarget1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argtarget1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argtarget1'([A], [A]).

% 'bindArgs.ast_argid12'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [caseT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid12'([], []) :- !.
'bindArgs.ast_argid12'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent11'(B, C).
'bindArgs.ast_argid12'([null|A], [null|B]) :-
	'bindArgs.ast_argparent11'(A, B), !.
'bindArgs.ast_argid12'([A|C], [B|D]) :-
	member(typeTermType, [caseT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent11'(C, D), !.
'bindArgs.ast_argid12'([A|B], [A|C]) :-
	not(member(classDefT, [caseT])),
	'bindArgs.ast_argparent11'(B, C), !.
'bindArgs.ast_argid12'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent11'(B, C), !.
'bindArgs.ast_argid12'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent11'(B, C), !.
'bindArgs.ast_argid12'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent11'(C, D), !.
'bindArgs.ast_argid12'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent11'(B, C), !.
'bindArgs.ast_argid12'([A|B], [A|C]) :-
	'bindArgs.ast_argparent11'(B, C).

% 'bindArgs.ast_argparent11'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent11'([], []) :- !.
'bindArgs.ast_argparent11'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl7'(B, C).
'bindArgs.ast_argparent11'([null|A], [null|B]) :-
	'bindArgs.ast_argencl7'(A, B), !.
'bindArgs.ast_argparent11'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl7'(C, D), !.
'bindArgs.ast_argparent11'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl7'(B, C), !.
'bindArgs.ast_argparent11'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl7'(B, C), !.
'bindArgs.ast_argparent11'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl7'(B, C), !.
'bindArgs.ast_argparent11'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl7'(C, D), !.
'bindArgs.ast_argparent11'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl7'(B, C), !.
'bindArgs.ast_argparent11'([A|B], [A|C]) :-
	'bindArgs.ast_argencl7'(B, C).

% 'bindArgs.ast_argencl7'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl7'([], []) :- !.
'bindArgs.ast_argencl7'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argexpr5'(B, C).
'bindArgs.ast_argencl7'([null|A], [null|B]) :-
	'bindArgs.ast_argexpr5'(A, B), !.
'bindArgs.ast_argencl7'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argexpr5'(C, D), !.
'bindArgs.ast_argencl7'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_argexpr5'(B, C), !.
'bindArgs.ast_argencl7'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argexpr5'(B, C), !.
'bindArgs.ast_argencl7'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argexpr5'(B, C), !.
'bindArgs.ast_argencl7'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argexpr5'(C, D), !.
'bindArgs.ast_argencl7'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argexpr5'(B, C), !.
'bindArgs.ast_argencl7'([A|B], [A|C]) :-
	'bindArgs.ast_argexpr5'(B, C).

% 'bindArgs.ast_argexpr5'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argexpr5'([], []) :- !.
'bindArgs.ast_argexpr5'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argexpr5'([null], [null]) :- !.
'bindArgs.ast_argexpr5'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argexpr5'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	B=[],
	C=[], !.
'bindArgs.ast_argexpr5'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argexpr5'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argexpr5'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argexpr5'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argexpr5'([A], [A]).

% 'bindArgs.ast_argid13'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [conditionalT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid13'([], []) :- !.
'bindArgs.ast_argid13'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent12'(B, C).
'bindArgs.ast_argid13'([null|A], [null|B]) :-
	'bindArgs.ast_argparent12'(A, B), !.
'bindArgs.ast_argid13'([A|C], [B|D]) :-
	member(typeTermType, [conditionalT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent12'(C, D), !.
'bindArgs.ast_argid13'([A|B], [A|C]) :-
	not(member(classDefT, [conditionalT])),
	'bindArgs.ast_argparent12'(B, C), !.
'bindArgs.ast_argid13'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent12'(B, C), !.
'bindArgs.ast_argid13'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent12'(B, C), !.
'bindArgs.ast_argid13'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent12'(C, D), !.
'bindArgs.ast_argid13'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent12'(B, C), !.
'bindArgs.ast_argid13'([A|B], [A|C]) :-
	'bindArgs.ast_argparent12'(B, C).

% 'bindArgs.ast_argparent12'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent12'([], []) :- !.
'bindArgs.ast_argparent12'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl8'(B, C).
'bindArgs.ast_argparent12'([null|A], [null|B]) :-
	'bindArgs.ast_argencl8'(A, B), !.
'bindArgs.ast_argparent12'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl8'(C, D), !.
'bindArgs.ast_argparent12'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl8'(B, C), !.
'bindArgs.ast_argparent12'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl8'(B, C), !.
'bindArgs.ast_argparent12'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl8'(B, C), !.
'bindArgs.ast_argparent12'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl8'(C, D), !.
'bindArgs.ast_argparent12'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl8'(B, C), !.
'bindArgs.ast_argparent12'([A|B], [A|C]) :-
	'bindArgs.ast_argencl8'(B, C).

% 'bindArgs.ast_argencl8'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl8'([], []) :- !.
'bindArgs.ast_argencl8'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argcond1'(B, C).
'bindArgs.ast_argencl8'([null|A], [null|B]) :-
	'bindArgs.ast_argcond1'(A, B), !.
'bindArgs.ast_argencl8'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argcond1'(C, D), !.
'bindArgs.ast_argencl8'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT])),
	'bindArgs.ast_argcond1'(B, C), !.
'bindArgs.ast_argencl8'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argcond1'(B, C), !.
'bindArgs.ast_argencl8'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argcond1'(B, C), !.
'bindArgs.ast_argencl8'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argcond1'(C, D), !.
'bindArgs.ast_argencl8'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argcond1'(B, C), !.
'bindArgs.ast_argencl8'([A|B], [A|C]) :-
	'bindArgs.ast_argcond1'(B, C).

% 'bindArgs.ast_argcond1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argcond1'([], []) :- !.
'bindArgs.ast_argcond1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argthenexpr1'(B, C).
'bindArgs.ast_argcond1'([null|A], [null|B]) :-
	'bindArgs.ast_argthenexpr1'(A, B), !.
'bindArgs.ast_argcond1'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argthenexpr1'(C, D), !.
'bindArgs.ast_argcond1'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_argthenexpr1'(B, C), !.
'bindArgs.ast_argcond1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argthenexpr1'(B, C), !.
'bindArgs.ast_argcond1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argthenexpr1'(B, C), !.
'bindArgs.ast_argcond1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argthenexpr1'(C, D), !.
'bindArgs.ast_argcond1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argthenexpr1'(B, C), !.
'bindArgs.ast_argcond1'([A|B], [A|C]) :-
	'bindArgs.ast_argthenexpr1'(B, C).

% 'bindArgs.ast_argthenexpr1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argthenexpr1'([], []) :- !.
'bindArgs.ast_argthenexpr1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argelseexpr1'(B, C).
'bindArgs.ast_argthenexpr1'([null|A], [null|B]) :-
	'bindArgs.ast_argelseexpr1'(A, B), !.
'bindArgs.ast_argthenexpr1'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argelseexpr1'(C, D), !.
'bindArgs.ast_argthenexpr1'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_argelseexpr1'(B, C), !.
'bindArgs.ast_argthenexpr1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argelseexpr1'(B, C), !.
'bindArgs.ast_argthenexpr1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argelseexpr1'(B, C), !.
'bindArgs.ast_argthenexpr1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argelseexpr1'(C, D), !.
'bindArgs.ast_argthenexpr1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argelseexpr1'(B, C), !.
'bindArgs.ast_argthenexpr1'([A|B], [A|C]) :-
	'bindArgs.ast_argelseexpr1'(B, C).

% 'bindArgs.ast_argelseexpr1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argelseexpr1'([], []) :- !.
'bindArgs.ast_argelseexpr1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argelseexpr1'([null], [null]) :- !.
'bindArgs.ast_argelseexpr1'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argelseexpr1'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	B=[],
	C=[], !.
'bindArgs.ast_argelseexpr1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argelseexpr1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argelseexpr1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argelseexpr1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argelseexpr1'([A], [A]).

% 'bindArgs.ast_argid14'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [continueT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid14'([], []) :- !.
'bindArgs.ast_argid14'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent10'(B, C).
'bindArgs.ast_argid14'([null|A], [null|B]) :-
	'bindArgs.ast_argparent10'(A, B), !.
'bindArgs.ast_argid14'([A|C], [B|D]) :-
	member(typeTermType, [continueT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent10'(C, D), !.
'bindArgs.ast_argid14'([A|B], [A|C]) :-
	not(member(classDefT, [continueT])),
	'bindArgs.ast_argparent10'(B, C), !.
'bindArgs.ast_argid14'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent10'(B, C), !.
'bindArgs.ast_argid14'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent10'(B, C), !.
'bindArgs.ast_argid14'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent10'(C, D), !.
'bindArgs.ast_argid14'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent10'(B, C), !.
'bindArgs.ast_argid14'([A|B], [A|C]) :-
	'bindArgs.ast_argparent10'(B, C).

% 'bindArgs.ast_argid15'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [doLoopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid15'([], []) :- !.
'bindArgs.ast_argid15'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent13'(B, C).
'bindArgs.ast_argid15'([null|A], [null|B]) :-
	'bindArgs.ast_argparent13'(A, B), !.
'bindArgs.ast_argid15'([A|C], [B|D]) :-
	member(typeTermType, [doLoopT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent13'(C, D), !.
'bindArgs.ast_argid15'([A|B], [A|C]) :-
	not(member(classDefT, [doLoopT])),
	'bindArgs.ast_argparent13'(B, C), !.
'bindArgs.ast_argid15'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent13'(B, C), !.
'bindArgs.ast_argid15'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent13'(B, C), !.
'bindArgs.ast_argid15'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent13'(C, D), !.
'bindArgs.ast_argid15'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent13'(B, C), !.
'bindArgs.ast_argid15'([A|B], [A|C]) :-
	'bindArgs.ast_argparent13'(B, C).

% 'bindArgs.ast_argparent13'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent13'([], []) :- !.
'bindArgs.ast_argparent13'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl9'(B, C).
'bindArgs.ast_argparent13'([null|A], [null|B]) :-
	'bindArgs.ast_argencl9'(A, B), !.
'bindArgs.ast_argparent13'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl9'(C, D), !.
'bindArgs.ast_argparent13'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl9'(B, C), !.
'bindArgs.ast_argparent13'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl9'(B, C), !.
'bindArgs.ast_argparent13'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl9'(B, C), !.
'bindArgs.ast_argparent13'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl9'(C, D), !.
'bindArgs.ast_argparent13'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl9'(B, C), !.
'bindArgs.ast_argparent13'([A|B], [A|C]) :-
	'bindArgs.ast_argencl9'(B, C).

% 'bindArgs.ast_argencl9'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl9'([], []) :- !.
'bindArgs.ast_argencl9'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argcond2'(B, C).
'bindArgs.ast_argencl9'([null|A], [null|B]) :-
	'bindArgs.ast_argcond2'(A, B), !.
'bindArgs.ast_argencl9'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argcond2'(C, D), !.
'bindArgs.ast_argencl9'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_argcond2'(B, C), !.
'bindArgs.ast_argencl9'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argcond2'(B, C), !.
'bindArgs.ast_argencl9'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argcond2'(B, C), !.
'bindArgs.ast_argencl9'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argcond2'(C, D), !.
'bindArgs.ast_argencl9'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argcond2'(B, C), !.
'bindArgs.ast_argencl9'([A|B], [A|C]) :-
	'bindArgs.ast_argcond2'(B, C).

% 'bindArgs.ast_argcond2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argcond2'([], []) :- !.
'bindArgs.ast_argcond2'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argbody2'(B, C).
'bindArgs.ast_argcond2'([null|A], [null|B]) :-
	'bindArgs.ast_argbody2'(A, B), !.
'bindArgs.ast_argcond2'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argbody2'(C, D), !.
'bindArgs.ast_argcond2'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_argbody2'(B, C), !.
'bindArgs.ast_argcond2'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argbody2'(B, C), !.
'bindArgs.ast_argcond2'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argbody2'(B, C), !.
'bindArgs.ast_argcond2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argbody2'(C, D), !.
'bindArgs.ast_argcond2'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argbody2'(B, C), !.
'bindArgs.ast_argcond2'([A|B], [A|C]) :-
	'bindArgs.ast_argbody2'(B, C).

% 'bindArgs.ast_argbody2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argbody2'([], []) :- !.
'bindArgs.ast_argbody2'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argbody2'([null], [null]) :- !.
'bindArgs.ast_argbody2'([A|C], [B|D]) :-
	member(typeTermType, [statementType]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argbody2'([A|B], [A|C]) :-
	not(member(classDefT, [statementType])),
	B=[],
	C=[], !.
'bindArgs.ast_argbody2'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argbody2'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argbody2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argbody2'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argbody2'([A], [A]).

% 'bindArgs.ast_argid16'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [execT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid16'([], []) :- !.
'bindArgs.ast_argid16'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent14'(B, C).
'bindArgs.ast_argid16'([null|A], [null|B]) :-
	'bindArgs.ast_argparent14'(A, B), !.
'bindArgs.ast_argid16'([A|C], [B|D]) :-
	member(typeTermType, [execT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent14'(C, D), !.
'bindArgs.ast_argid16'([A|B], [A|C]) :-
	not(member(classDefT, [execT])),
	'bindArgs.ast_argparent14'(B, C), !.
'bindArgs.ast_argid16'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent14'(B, C), !.
'bindArgs.ast_argid16'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent14'(B, C), !.
'bindArgs.ast_argid16'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent14'(C, D), !.
'bindArgs.ast_argid16'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent14'(B, C), !.
'bindArgs.ast_argid16'([A|B], [A|C]) :-
	'bindArgs.ast_argparent14'(B, C).

% 'bindArgs.ast_argparent14'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent14'([], []) :- !.
'bindArgs.ast_argparent14'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl10'(B, C).
'bindArgs.ast_argparent14'([null|A], [null|B]) :-
	'bindArgs.ast_argencl10'(A, B), !.
'bindArgs.ast_argparent14'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl10'(C, D), !.
'bindArgs.ast_argparent14'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl10'(B, C), !.
'bindArgs.ast_argparent14'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl10'(B, C), !.
'bindArgs.ast_argparent14'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl10'(B, C), !.
'bindArgs.ast_argparent14'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl10'(C, D), !.
'bindArgs.ast_argparent14'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl10'(B, C), !.
'bindArgs.ast_argparent14'([A|B], [A|C]) :-
	'bindArgs.ast_argencl10'(B, C).

% 'bindArgs.ast_argencl10'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl10'([], []) :- !.
'bindArgs.ast_argencl10'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argexpr4'(B, C).
'bindArgs.ast_argencl10'([null|A], [null|B]) :-
	'bindArgs.ast_argexpr4'(A, B), !.
'bindArgs.ast_argencl10'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argexpr4'(C, D), !.
'bindArgs.ast_argencl10'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_argexpr4'(B, C), !.
'bindArgs.ast_argencl10'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argexpr4'(B, C), !.
'bindArgs.ast_argencl10'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argexpr4'(B, C), !.
'bindArgs.ast_argencl10'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argexpr4'(C, D), !.
'bindArgs.ast_argencl10'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argexpr4'(B, C), !.
'bindArgs.ast_argencl10'([A|B], [A|C]) :-
	'bindArgs.ast_argexpr4'(B, C).

% 'bindArgs.ast_argid17'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [catchT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(param, mult(1, 1, no), id, [paramDefT]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid17'([], []) :- !.
'bindArgs.ast_argid17'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent15'(B, C).
'bindArgs.ast_argid17'([null|A], [null|B]) :-
	'bindArgs.ast_argparent15'(A, B), !.
'bindArgs.ast_argid17'([A|C], [B|D]) :-
	member(typeTermType, [catchT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent15'(C, D), !.
'bindArgs.ast_argid17'([A|B], [A|C]) :-
	not(member(classDefT, [catchT])),
	'bindArgs.ast_argparent15'(B, C), !.
'bindArgs.ast_argid17'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent15'(B, C), !.
'bindArgs.ast_argid17'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent15'(B, C), !.
'bindArgs.ast_argid17'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent15'(C, D), !.
'bindArgs.ast_argid17'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent15'(B, C), !.
'bindArgs.ast_argid17'([A|B], [A|C]) :-
	'bindArgs.ast_argparent15'(B, C).

% 'bindArgs.ast_argparent15'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(param, mult(1, 1, no), id, [paramDefT]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent15'([], []) :- !.
'bindArgs.ast_argparent15'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl11'(B, C).
'bindArgs.ast_argparent15'([null|A], [null|B]) :-
	'bindArgs.ast_argencl11'(A, B), !.
'bindArgs.ast_argparent15'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl11'(C, D), !.
'bindArgs.ast_argparent15'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl11'(B, C), !.
'bindArgs.ast_argparent15'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl11'(B, C), !.
'bindArgs.ast_argparent15'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl11'(B, C), !.
'bindArgs.ast_argparent15'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl11'(C, D), !.
'bindArgs.ast_argparent15'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl11'(B, C), !.
'bindArgs.ast_argparent15'([A|B], [A|C]) :-
	'bindArgs.ast_argencl11'(B, C).

% 'bindArgs.ast_argencl11'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(param, mult(1, 1, no), id, [paramDefT]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl11'([], []) :- !.
'bindArgs.ast_argencl11'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparam1'(B, C).
'bindArgs.ast_argencl11'([null|A], [null|B]) :-
	'bindArgs.ast_argparam1'(A, B), !.
'bindArgs.ast_argencl11'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparam1'(C, D), !.
'bindArgs.ast_argencl11'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_argparam1'(B, C), !.
'bindArgs.ast_argencl11'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparam1'(B, C), !.
'bindArgs.ast_argencl11'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparam1'(B, C), !.
'bindArgs.ast_argencl11'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparam1'(C, D), !.
'bindArgs.ast_argencl11'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparam1'(B, C), !.
'bindArgs.ast_argencl11'([A|B], [A|C]) :-
	'bindArgs.ast_argparam1'(B, C).

% 'bindArgs.ast_argparam1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(param, mult(1, 1, no), id, [paramDefT]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparam1'([], []) :- !.
'bindArgs.ast_argparam1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argbody3'(B, C).
'bindArgs.ast_argparam1'([null|A], [null|B]) :-
	'bindArgs.ast_argbody3'(A, B), !.
'bindArgs.ast_argparam1'([A|C], [B|D]) :-
	member(typeTermType, [paramDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argbody3'(C, D), !.
'bindArgs.ast_argparam1'([A|B], [A|C]) :-
	not(member(classDefT, [paramDefT])),
	'bindArgs.ast_argbody3'(B, C), !.
'bindArgs.ast_argparam1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argbody3'(B, C), !.
'bindArgs.ast_argparam1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argbody3'(B, C), !.
'bindArgs.ast_argparam1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argbody3'(C, D), !.
'bindArgs.ast_argparam1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argbody3'(B, C), !.
'bindArgs.ast_argparam1'([A|B], [A|C]) :-
	'bindArgs.ast_argbody3'(B, C).

% 'bindArgs.ast_argbody3'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argbody3'([], []) :- !.
'bindArgs.ast_argbody3'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argbody3'([null], [null]) :- !.
'bindArgs.ast_argbody3'([A|C], [B|D]) :-
	member(typeTermType, [blockT]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argbody3'([A|B], [A|C]) :-
	not(member(classDefT, [blockT])),
	B=[],
	C=[], !.
'bindArgs.ast_argbody3'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argbody3'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argbody3'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argbody3'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argbody3'([A], [A]).

% 'bindArgs.ast_argid18'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [forLoopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(inits, mult(0, *, ord), id, [[expressionType, localDefT]]), ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid18'([], []) :- !.
'bindArgs.ast_argid18'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent16'(B, C).
'bindArgs.ast_argid18'([null|A], [null|B]) :-
	'bindArgs.ast_argparent16'(A, B), !.
'bindArgs.ast_argid18'([A|C], [B|D]) :-
	member(typeTermType, [forLoopT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent16'(C, D), !.
'bindArgs.ast_argid18'([A|B], [A|C]) :-
	not(member(classDefT, [forLoopT])),
	'bindArgs.ast_argparent16'(B, C), !.
'bindArgs.ast_argid18'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent16'(B, C), !.
'bindArgs.ast_argid18'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent16'(B, C), !.
'bindArgs.ast_argid18'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent16'(C, D), !.
'bindArgs.ast_argid18'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent16'(B, C), !.
'bindArgs.ast_argid18'([A|B], [A|C]) :-
	'bindArgs.ast_argparent16'(B, C).

% 'bindArgs.ast_argparent16'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(inits, mult(0, *, ord), id, [[expressionType, localDefT]]), ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent16'([], []) :- !.
'bindArgs.ast_argparent16'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl12'(B, C).
'bindArgs.ast_argparent16'([null|A], [null|B]) :-
	'bindArgs.ast_argencl12'(A, B), !.
'bindArgs.ast_argparent16'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl12'(C, D), !.
'bindArgs.ast_argparent16'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl12'(B, C), !.
'bindArgs.ast_argparent16'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl12'(B, C), !.
'bindArgs.ast_argparent16'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl12'(B, C), !.
'bindArgs.ast_argparent16'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl12'(C, D), !.
'bindArgs.ast_argparent16'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl12'(B, C), !.
'bindArgs.ast_argparent16'([A|B], [A|C]) :-
	'bindArgs.ast_argencl12'(B, C).

% 'bindArgs.ast_argencl12'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(inits, mult(0, *, ord), id, [[expressionType, localDefT]]), ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl12'([], []) :- !.
'bindArgs.ast_argencl12'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_arginits1'(B, C).
'bindArgs.ast_argencl12'([null|A], [null|B]) :-
	'bindArgs.ast_arginits1'(A, B), !.
'bindArgs.ast_argencl12'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_arginits1'(C, D), !.
'bindArgs.ast_argencl12'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_arginits1'(B, C), !.
'bindArgs.ast_argencl12'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_arginits1'(B, C), !.
'bindArgs.ast_argencl12'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_arginits1'(B, C), !.
'bindArgs.ast_argencl12'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arginits1'(C, D), !.
'bindArgs.ast_argencl12'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_arginits1'(B, C), !.
'bindArgs.ast_argencl12'([A|B], [A|C]) :-
	'bindArgs.ast_arginits1'(B, C).

% 'bindArgs.ast_arginits1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(inits, mult(0, *, ord), id, [[expressionType, localDefT]]), ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_arginits1'([], []) :- !.
'bindArgs.ast_arginits1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argcond3'(B, C).
'bindArgs.ast_arginits1'([A|C], [B|D]) :-
	member(classDefT, [[expressionType, localDefT]]), !,
	replaceFQNsWithClassIds1(A, B),
	'bindArgs.ast_argcond3'(C, D), !.
'bindArgs.ast_arginits1'([null|A], [null|B]) :-
	'bindArgs.ast_argcond3'(A, B), !.
'bindArgs.ast_arginits1'([A|C], [B|D]) :-
	member(typeTermType, [[expressionType, localDefT]]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argcond3'(C, D), !.
'bindArgs.ast_arginits1'([A|B], [A|C]) :-
	not(member(classDefT, [[expressionType, localDefT]])),
	'bindArgs.ast_argcond3'(B, C), !.
'bindArgs.ast_arginits1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argcond3'(B, C), !.
'bindArgs.ast_arginits1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argcond3'(B, C), !.
'bindArgs.ast_arginits1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argcond3'(C, D), !.
'bindArgs.ast_arginits1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argcond3'(B, C), !.
'bindArgs.ast_arginits1'([A|B], [A|C]) :-
	'bindArgs.ast_argcond3'(B, C).

% 'bindArgs.ast_argcond3'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argcond3'([], []) :- !.
'bindArgs.ast_argcond3'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argupdaters1'(B, C).
'bindArgs.ast_argcond3'([null|A], [null|B]) :-
	'bindArgs.ast_argupdaters1'(A, B), !.
'bindArgs.ast_argcond3'([A|C], [B|D]) :-
	member(typeTermType, [[expressionType]]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argupdaters1'(C, D), !.
'bindArgs.ast_argcond3'([A|B], [A|C]) :-
	not(member(classDefT, [[expressionType]])),
	'bindArgs.ast_argupdaters1'(B, C), !.
'bindArgs.ast_argcond3'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argupdaters1'(B, C), !.
'bindArgs.ast_argcond3'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argupdaters1'(B, C), !.
'bindArgs.ast_argcond3'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argupdaters1'(C, D), !.
'bindArgs.ast_argcond3'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argupdaters1'(B, C), !.
'bindArgs.ast_argcond3'([A|B], [A|C]) :-
	'bindArgs.ast_argupdaters1'(B, C).

% 'bindArgs.ast_argupdaters1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argupdaters1'([], []) :- !.
'bindArgs.ast_argupdaters1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argbody3'(B, C).
'bindArgs.ast_argupdaters1'([A|C], [B|D]) :-
	member(classDefT, [[expressionType]]), !,
	replaceFQNsWithClassIds1(A, B),
	'bindArgs.ast_argbody3'(C, D), !.
'bindArgs.ast_argupdaters1'([null|A], [null|B]) :-
	'bindArgs.ast_argbody3'(A, B), !.
'bindArgs.ast_argupdaters1'([A|C], [B|D]) :-
	member(typeTermType, [[expressionType]]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argbody3'(C, D), !.
'bindArgs.ast_argupdaters1'([A|B], [A|C]) :-
	not(member(classDefT, [[expressionType]])),
	'bindArgs.ast_argbody3'(B, C), !.
'bindArgs.ast_argupdaters1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argbody3'(B, C), !.
'bindArgs.ast_argupdaters1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argbody3'(B, C), !.
'bindArgs.ast_argupdaters1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argbody3'(C, D), !.
'bindArgs.ast_argupdaters1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argbody3'(B, C), !.
'bindArgs.ast_argupdaters1'([A|B], [A|C]) :-
	'bindArgs.ast_argbody3'(B, C).

% 'bindArgs.ast_argid19'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [getFieldT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid19'([], []) :- !.
'bindArgs.ast_argid19'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent17'(B, C).
'bindArgs.ast_argid19'([null|A], [null|B]) :-
	'bindArgs.ast_argparent17'(A, B), !.
'bindArgs.ast_argid19'([A|C], [B|D]) :-
	member(typeTermType, [getFieldT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent17'(C, D), !.
'bindArgs.ast_argid19'([A|B], [A|C]) :-
	not(member(classDefT, [getFieldT])),
	'bindArgs.ast_argparent17'(B, C), !.
'bindArgs.ast_argid19'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent17'(B, C), !.
'bindArgs.ast_argid19'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent17'(B, C), !.
'bindArgs.ast_argid19'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent17'(C, D), !.
'bindArgs.ast_argid19'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent17'(B, C), !.
'bindArgs.ast_argid19'([A|B], [A|C]) :-
	'bindArgs.ast_argparent17'(B, C).

% 'bindArgs.ast_argparent17'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent17'([], []) :- !.
'bindArgs.ast_argparent17'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl13'(B, C).
'bindArgs.ast_argparent17'([null|A], [null|B]) :-
	'bindArgs.ast_argencl13'(A, B), !.
'bindArgs.ast_argparent17'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl13'(C, D), !.
'bindArgs.ast_argparent17'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl13'(B, C), !.
'bindArgs.ast_argparent17'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl13'(B, C), !.
'bindArgs.ast_argparent17'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl13'(B, C), !.
'bindArgs.ast_argparent17'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl13'(C, D), !.
'bindArgs.ast_argparent17'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl13'(B, C), !.
'bindArgs.ast_argparent17'([A|B], [A|C]) :-
	'bindArgs.ast_argencl13'(B, C).

% 'bindArgs.ast_argencl13'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl13'([], []) :- !.
'bindArgs.ast_argencl13'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argexpr6'(B, C).
'bindArgs.ast_argencl13'([null|A], [null|B]) :-
	'bindArgs.ast_argexpr6'(A, B), !.
'bindArgs.ast_argencl13'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argexpr6'(C, D), !.
'bindArgs.ast_argencl13'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT])),
	'bindArgs.ast_argexpr6'(B, C), !.
'bindArgs.ast_argencl13'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argexpr6'(B, C), !.
'bindArgs.ast_argencl13'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argexpr6'(B, C), !.
'bindArgs.ast_argencl13'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argexpr6'(C, D), !.
'bindArgs.ast_argencl13'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argexpr6'(B, C), !.
'bindArgs.ast_argencl13'([A|B], [A|C]) :-
	'bindArgs.ast_argexpr6'(B, C).

% 'bindArgs.ast_argexpr6'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argexpr6'([], []) :- !.
'bindArgs.ast_argexpr6'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argname7'(B, C).
'bindArgs.ast_argexpr6'([null|A], [null|B]) :-
	'bindArgs.ast_argname7'(A, B), !.
'bindArgs.ast_argexpr6'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argname7'(C, D), !.
'bindArgs.ast_argexpr6'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_argname7'(B, C), !.
'bindArgs.ast_argexpr6'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argname7'(B, C), !.
'bindArgs.ast_argexpr6'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argname7'(B, C), !.
'bindArgs.ast_argexpr6'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argname7'(C, D), !.
'bindArgs.ast_argexpr6'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argname7'(B, C), !.
'bindArgs.ast_argexpr6'([A|B], [A|C]) :-
	'bindArgs.ast_argname7'(B, C).

% 'bindArgs.ast_argname7'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argname7'([], []) :- !.
'bindArgs.ast_argname7'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argfield1'(B, C).
'bindArgs.ast_argname7'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argfield1'(C, D), !.
'bindArgs.ast_argname7'([A|B], [A|C]) :-
	'bindArgs.ast_argfield1'(B, C), !.
'bindArgs.ast_argname7'([A|B], [A|C]) :-
	'bindArgs.ast_argfield1'(B, C).

% 'bindArgs.ast_argfield1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(field, mult(1, 1, no), id, [fieldDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argfield1'([], []) :- !.
'bindArgs.ast_argfield1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argfield1'([null], [null]) :- !.
'bindArgs.ast_argfield1'([A|C], [B|D]) :-
	member(typeTermType, [fieldDefT]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argfield1'([A|B], [A|C]) :-
	not(member(classDefT, [fieldDefT])),
	B=[],
	C=[], !.
'bindArgs.ast_argfield1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argfield1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argfield1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argfield1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argfield1'([A], [A]).

% 'bindArgs.ast_argid20'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [ifT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid20'([], []) :- !.
'bindArgs.ast_argid20'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent18'(B, C).
'bindArgs.ast_argid20'([null|A], [null|B]) :-
	'bindArgs.ast_argparent18'(A, B), !.
'bindArgs.ast_argid20'([A|C], [B|D]) :-
	member(typeTermType, [ifT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent18'(C, D), !.
'bindArgs.ast_argid20'([A|B], [A|C]) :-
	not(member(classDefT, [ifT])),
	'bindArgs.ast_argparent18'(B, C), !.
'bindArgs.ast_argid20'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent18'(B, C), !.
'bindArgs.ast_argid20'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent18'(B, C), !.
'bindArgs.ast_argid20'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent18'(C, D), !.
'bindArgs.ast_argid20'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent18'(B, C), !.
'bindArgs.ast_argid20'([A|B], [A|C]) :-
	'bindArgs.ast_argparent18'(B, C).

% 'bindArgs.ast_argparent18'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent18'([], []) :- !.
'bindArgs.ast_argparent18'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl14'(B, C).
'bindArgs.ast_argparent18'([null|A], [null|B]) :-
	'bindArgs.ast_argencl14'(A, B), !.
'bindArgs.ast_argparent18'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl14'(C, D), !.
'bindArgs.ast_argparent18'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl14'(B, C), !.
'bindArgs.ast_argparent18'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl14'(B, C), !.
'bindArgs.ast_argparent18'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl14'(B, C), !.
'bindArgs.ast_argparent18'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl14'(C, D), !.
'bindArgs.ast_argparent18'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl14'(B, C), !.
'bindArgs.ast_argparent18'([A|B], [A|C]) :-
	'bindArgs.ast_argencl14'(B, C).

% 'bindArgs.ast_argencl14'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl14'([], []) :- !.
'bindArgs.ast_argencl14'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argcond4'(B, C).
'bindArgs.ast_argencl14'([null|A], [null|B]) :-
	'bindArgs.ast_argcond4'(A, B), !.
'bindArgs.ast_argencl14'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argcond4'(C, D), !.
'bindArgs.ast_argencl14'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_argcond4'(B, C), !.
'bindArgs.ast_argencl14'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argcond4'(B, C), !.
'bindArgs.ast_argencl14'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argcond4'(B, C), !.
'bindArgs.ast_argencl14'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argcond4'(C, D), !.
'bindArgs.ast_argencl14'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argcond4'(B, C), !.
'bindArgs.ast_argencl14'([A|B], [A|C]) :-
	'bindArgs.ast_argcond4'(B, C).

% 'bindArgs.ast_argcond4'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argcond4'([], []) :- !.
'bindArgs.ast_argcond4'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argthen1'(B, C).
'bindArgs.ast_argcond4'([null|A], [null|B]) :-
	'bindArgs.ast_argthen1'(A, B), !.
'bindArgs.ast_argcond4'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argthen1'(C, D), !.
'bindArgs.ast_argcond4'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_argthen1'(B, C), !.
'bindArgs.ast_argcond4'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argthen1'(B, C), !.
'bindArgs.ast_argcond4'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argthen1'(B, C), !.
'bindArgs.ast_argcond4'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argthen1'(C, D), !.
'bindArgs.ast_argcond4'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argthen1'(B, C), !.
'bindArgs.ast_argcond4'([A|B], [A|C]) :-
	'bindArgs.ast_argthen1'(B, C).

% 'bindArgs.ast_argthen1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argthen1'([], []) :- !.
'bindArgs.ast_argthen1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argelse1'(B, C).
'bindArgs.ast_argthen1'([null|A], [null|B]) :-
	'bindArgs.ast_argelse1'(A, B), !.
'bindArgs.ast_argthen1'([A|C], [B|D]) :-
	member(typeTermType, [blockT, statementType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argelse1'(C, D), !.
'bindArgs.ast_argthen1'([A|B], [A|C]) :-
	not(member(classDefT, [blockT, statementType])),
	'bindArgs.ast_argelse1'(B, C), !.
'bindArgs.ast_argthen1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argelse1'(B, C), !.
'bindArgs.ast_argthen1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argelse1'(B, C), !.
'bindArgs.ast_argthen1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argelse1'(C, D), !.
'bindArgs.ast_argthen1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argelse1'(B, C), !.
'bindArgs.ast_argthen1'([A|B], [A|C]) :-
	'bindArgs.ast_argelse1'(B, C).

% 'bindArgs.ast_argelse1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(else, mult(0, 1, no), id, [blockT, statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argelse1'([], []) :- !.
'bindArgs.ast_argelse1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argelse1'([null], [null]) :- !.
'bindArgs.ast_argelse1'([A|C], [B|D]) :-
	member(typeTermType, [blockT, statementType]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argelse1'([A|B], [A|C]) :-
	not(member(classDefT, [blockT, statementType])),
	B=[],
	C=[], !.
'bindArgs.ast_argelse1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argelse1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argelse1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argelse1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argelse1'([A], [A]).

% 'bindArgs.ast_argid21'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [importT]), ast_arg(parent, mult(1, 1, no), id, [toplevelT]), ast_arg(import, mult(1, 1, no), id, [packageT, classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid21'([], []) :- !.
'bindArgs.ast_argid21'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent19'(B, C).
'bindArgs.ast_argid21'([null|A], [null|B]) :-
	'bindArgs.ast_argparent19'(A, B), !.
'bindArgs.ast_argid21'([A|C], [B|D]) :-
	member(typeTermType, [importT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent19'(C, D), !.
'bindArgs.ast_argid21'([A|B], [A|C]) :-
	not(member(classDefT, [importT])),
	'bindArgs.ast_argparent19'(B, C), !.
'bindArgs.ast_argid21'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent19'(B, C), !.
'bindArgs.ast_argid21'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent19'(B, C), !.
'bindArgs.ast_argid21'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent19'(C, D), !.
'bindArgs.ast_argid21'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent19'(B, C), !.
'bindArgs.ast_argid21'([A|B], [A|C]) :-
	'bindArgs.ast_argparent19'(B, C).

% 'bindArgs.ast_argparent19'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [toplevelT]), ast_arg(import, mult(1, 1, no), id, [packageT, classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent19'([], []) :- !.
'bindArgs.ast_argparent19'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argimport1'(B, C).
'bindArgs.ast_argparent19'([null|A], [null|B]) :-
	'bindArgs.ast_argimport1'(A, B), !.
'bindArgs.ast_argparent19'([A|C], [B|D]) :-
	member(typeTermType, [toplevelT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argimport1'(C, D), !.
'bindArgs.ast_argparent19'([A|B], [A|C]) :-
	not(member(classDefT, [toplevelT])),
	'bindArgs.ast_argimport1'(B, C), !.
'bindArgs.ast_argparent19'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argimport1'(B, C), !.
'bindArgs.ast_argparent19'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argimport1'(B, C), !.
'bindArgs.ast_argparent19'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argimport1'(C, D), !.
'bindArgs.ast_argparent19'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argimport1'(B, C), !.
'bindArgs.ast_argparent19'([A|B], [A|C]) :-
	'bindArgs.ast_argimport1'(B, C).

% 'bindArgs.ast_argimport1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(import, mult(1, 1, no), id, [packageT, classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argimport1'([], []) :- !.
'bindArgs.ast_argimport1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argimport1'([null], [null]) :- !.
'bindArgs.ast_argimport1'([A|C], [B|D]) :-
	member(typeTermType, [packageT, classDefT]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argimport1'([A|B], [A|C]) :-
	not(member(classDefT, [packageT, classDefT])),
	B=[],
	C=[], !.
'bindArgs.ast_argimport1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argimport1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argimport1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argimport1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argimport1'([A], [A]).

% 'bindArgs.ast_argid22'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [indexedT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(index, mult(1, 1, no), id, [expressionType]), ast_arg(indexed, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid22'([], []) :- !.
'bindArgs.ast_argid22'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent20'(B, C).
'bindArgs.ast_argid22'([null|A], [null|B]) :-
	'bindArgs.ast_argparent20'(A, B), !.
'bindArgs.ast_argid22'([A|C], [B|D]) :-
	member(typeTermType, [indexedT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent20'(C, D), !.
'bindArgs.ast_argid22'([A|B], [A|C]) :-
	not(member(classDefT, [indexedT])),
	'bindArgs.ast_argparent20'(B, C), !.
'bindArgs.ast_argid22'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent20'(B, C), !.
'bindArgs.ast_argid22'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent20'(B, C), !.
'bindArgs.ast_argid22'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent20'(C, D), !.
'bindArgs.ast_argid22'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent20'(B, C), !.
'bindArgs.ast_argid22'([A|B], [A|C]) :-
	'bindArgs.ast_argparent20'(B, C).

% 'bindArgs.ast_argparent20'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(index, mult(1, 1, no), id, [expressionType]), ast_arg(indexed, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent20'([], []) :- !.
'bindArgs.ast_argparent20'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl15'(B, C).
'bindArgs.ast_argparent20'([null|A], [null|B]) :-
	'bindArgs.ast_argencl15'(A, B), !.
'bindArgs.ast_argparent20'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl15'(C, D), !.
'bindArgs.ast_argparent20'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl15'(B, C), !.
'bindArgs.ast_argparent20'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl15'(B, C), !.
'bindArgs.ast_argparent20'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl15'(B, C), !.
'bindArgs.ast_argparent20'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl15'(C, D), !.
'bindArgs.ast_argparent20'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl15'(B, C), !.
'bindArgs.ast_argparent20'([A|B], [A|C]) :-
	'bindArgs.ast_argencl15'(B, C).

% 'bindArgs.ast_argencl15'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(index, mult(1, 1, no), id, [expressionType]), ast_arg(indexed, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl15'([], []) :- !.
'bindArgs.ast_argencl15'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argindex1'(B, C).
'bindArgs.ast_argencl15'([null|A], [null|B]) :-
	'bindArgs.ast_argindex1'(A, B), !.
'bindArgs.ast_argencl15'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argindex1'(C, D), !.
'bindArgs.ast_argencl15'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT])),
	'bindArgs.ast_argindex1'(B, C), !.
'bindArgs.ast_argencl15'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argindex1'(B, C), !.
'bindArgs.ast_argencl15'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argindex1'(B, C), !.
'bindArgs.ast_argencl15'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argindex1'(C, D), !.
'bindArgs.ast_argencl15'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argindex1'(B, C), !.
'bindArgs.ast_argencl15'([A|B], [A|C]) :-
	'bindArgs.ast_argindex1'(B, C).

% 'bindArgs.ast_argindex1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(index, mult(1, 1, no), id, [expressionType]), ast_arg(indexed, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argindex1'([], []) :- !.
'bindArgs.ast_argindex1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argindexed1'(B, C).
'bindArgs.ast_argindex1'([null|A], [null|B]) :-
	'bindArgs.ast_argindexed1'(A, B), !.
'bindArgs.ast_argindex1'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argindexed1'(C, D), !.
'bindArgs.ast_argindex1'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_argindexed1'(B, C), !.
'bindArgs.ast_argindex1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argindexed1'(B, C), !.
'bindArgs.ast_argindex1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argindexed1'(B, C), !.
'bindArgs.ast_argindex1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argindexed1'(C, D), !.
'bindArgs.ast_argindex1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argindexed1'(B, C), !.
'bindArgs.ast_argindex1'([A|B], [A|C]) :-
	'bindArgs.ast_argindexed1'(B, C).

% 'bindArgs.ast_argindexed1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(indexed, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argindexed1'([], []) :- !.
'bindArgs.ast_argindexed1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argindexed1'([null], [null]) :- !.
'bindArgs.ast_argindexed1'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argindexed1'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	B=[],
	C=[], !.
'bindArgs.ast_argindexed1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argindexed1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argindexed1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argindexed1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argindexed1'([A], [A]).

% 'bindArgs.ast_argid23'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [labelT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(body, mult(1, 1, no), id, [statementType]), ast_arg(label, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid23'([], []) :- !.
'bindArgs.ast_argid23'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent21'(B, C).
'bindArgs.ast_argid23'([null|A], [null|B]) :-
	'bindArgs.ast_argparent21'(A, B), !.
'bindArgs.ast_argid23'([A|C], [B|D]) :-
	member(typeTermType, [labelT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent21'(C, D), !.
'bindArgs.ast_argid23'([A|B], [A|C]) :-
	not(member(classDefT, [labelT])),
	'bindArgs.ast_argparent21'(B, C), !.
'bindArgs.ast_argid23'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent21'(B, C), !.
'bindArgs.ast_argid23'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent21'(B, C), !.
'bindArgs.ast_argid23'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent21'(C, D), !.
'bindArgs.ast_argid23'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent21'(B, C), !.
'bindArgs.ast_argid23'([A|B], [A|C]) :-
	'bindArgs.ast_argparent21'(B, C).

% 'bindArgs.ast_argparent21'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(body, mult(1, 1, no), id, [statementType]), ast_arg(label, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent21'([], []) :- !.
'bindArgs.ast_argparent21'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl16'(B, C).
'bindArgs.ast_argparent21'([null|A], [null|B]) :-
	'bindArgs.ast_argencl16'(A, B), !.
'bindArgs.ast_argparent21'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl16'(C, D), !.
'bindArgs.ast_argparent21'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl16'(B, C), !.
'bindArgs.ast_argparent21'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl16'(B, C), !.
'bindArgs.ast_argparent21'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl16'(B, C), !.
'bindArgs.ast_argparent21'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl16'(C, D), !.
'bindArgs.ast_argparent21'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl16'(B, C), !.
'bindArgs.ast_argparent21'([A|B], [A|C]) :-
	'bindArgs.ast_argencl16'(B, C).

% 'bindArgs.ast_argencl16'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(body, mult(1, 1, no), id, [statementType]), ast_arg(label, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl16'([], []) :- !.
'bindArgs.ast_argencl16'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argbody4'(B, C).
'bindArgs.ast_argencl16'([null|A], [null|B]) :-
	'bindArgs.ast_argbody4'(A, B), !.
'bindArgs.ast_argencl16'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argbody4'(C, D), !.
'bindArgs.ast_argencl16'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT])),
	'bindArgs.ast_argbody4'(B, C), !.
'bindArgs.ast_argencl16'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argbody4'(B, C), !.
'bindArgs.ast_argencl16'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argbody4'(B, C), !.
'bindArgs.ast_argencl16'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argbody4'(C, D), !.
'bindArgs.ast_argencl16'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argbody4'(B, C), !.
'bindArgs.ast_argencl16'([A|B], [A|C]) :-
	'bindArgs.ast_argbody4'(B, C).

% 'bindArgs.ast_argbody4'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(body, mult(1, 1, no), id, [statementType]), ast_arg(label, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argbody4'([], []) :- !.
'bindArgs.ast_argbody4'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_arglabel2'(B, C).
'bindArgs.ast_argbody4'([null|A], [null|B]) :-
	'bindArgs.ast_arglabel2'(A, B), !.
'bindArgs.ast_argbody4'([A|C], [B|D]) :-
	member(typeTermType, [statementType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_arglabel2'(C, D), !.
'bindArgs.ast_argbody4'([A|B], [A|C]) :-
	not(member(classDefT, [statementType])),
	'bindArgs.ast_arglabel2'(B, C), !.
'bindArgs.ast_argbody4'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_arglabel2'(B, C), !.
'bindArgs.ast_argbody4'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_arglabel2'(B, C), !.
'bindArgs.ast_argbody4'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arglabel2'(C, D), !.
'bindArgs.ast_argbody4'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_arglabel2'(B, C), !.
'bindArgs.ast_argbody4'([A|B], [A|C]) :-
	'bindArgs.ast_arglabel2'(B, C).

% 'bindArgs.ast_arglabel2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(label, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_arglabel2'([], []) :- !.
'bindArgs.ast_arglabel2'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_arglabel2'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_arglabel2'([A], [A]) :- !.
'bindArgs.ast_arglabel2'([A], [A]).

% 'bindArgs.ast_argid24'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [literalT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(value, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid24'([], []) :- !.
'bindArgs.ast_argid24'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent22'(B, C).
'bindArgs.ast_argid24'([null|A], [null|B]) :-
	'bindArgs.ast_argparent22'(A, B), !.
'bindArgs.ast_argid24'([A|C], [B|D]) :-
	member(typeTermType, [literalT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent22'(C, D), !.
'bindArgs.ast_argid24'([A|B], [A|C]) :-
	not(member(classDefT, [literalT])),
	'bindArgs.ast_argparent22'(B, C), !.
'bindArgs.ast_argid24'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent22'(B, C), !.
'bindArgs.ast_argid24'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent22'(B, C), !.
'bindArgs.ast_argid24'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent22'(C, D), !.
'bindArgs.ast_argid24'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent22'(B, C), !.
'bindArgs.ast_argid24'([A|B], [A|C]) :-
	'bindArgs.ast_argparent22'(B, C).

% 'bindArgs.ast_argparent22'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(value, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent22'([], []) :- !.
'bindArgs.ast_argparent22'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl17'(B, C).
'bindArgs.ast_argparent22'([null|A], [null|B]) :-
	'bindArgs.ast_argencl17'(A, B), !.
'bindArgs.ast_argparent22'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl17'(C, D), !.
'bindArgs.ast_argparent22'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl17'(B, C), !.
'bindArgs.ast_argparent22'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl17'(B, C), !.
'bindArgs.ast_argparent22'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl17'(B, C), !.
'bindArgs.ast_argparent22'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl17'(C, D), !.
'bindArgs.ast_argparent22'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl17'(B, C), !.
'bindArgs.ast_argparent22'([A|B], [A|C]) :-
	'bindArgs.ast_argencl17'(B, C).

% 'bindArgs.ast_argencl17'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(value, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl17'([], []) :- !.
'bindArgs.ast_argencl17'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argtype4'(B, C).
'bindArgs.ast_argencl17'([null|A], [null|B]) :-
	'bindArgs.ast_argtype4'(A, B), !.
'bindArgs.ast_argencl17'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argtype4'(C, D), !.
'bindArgs.ast_argencl17'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT])),
	'bindArgs.ast_argtype4'(B, C), !.
'bindArgs.ast_argencl17'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argtype4'(B, C), !.
'bindArgs.ast_argencl17'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argtype4'(B, C), !.
'bindArgs.ast_argencl17'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argtype4'(C, D), !.
'bindArgs.ast_argencl17'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argtype4'(B, C), !.
'bindArgs.ast_argencl17'([A|B], [A|C]) :-
	'bindArgs.ast_argtype4'(B, C).

% 'bindArgs.ast_argtype4'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(value, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argtype4'([], []) :- !.
'bindArgs.ast_argtype4'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argvalue1'(B, C).
'bindArgs.ast_argtype4'([A|C], [B|D]) :-
	member(typeTermType, [typeTermType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argvalue1'(C, D), !.
'bindArgs.ast_argtype4'([A|B], [A|C]) :-
	'bindArgs.ast_argvalue1'(B, C), !.
'bindArgs.ast_argtype4'([A|B], [A|C]) :-
	'bindArgs.ast_argvalue1'(B, C).

% 'bindArgs.ast_argvalue1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(value, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argvalue1'([], []) :- !.
'bindArgs.ast_argvalue1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argvalue1'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argvalue1'([A], [A]) :- !.
'bindArgs.ast_argvalue1'([A], [A]).

% 'bindArgs.ast_argid25'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [localDefT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid25'([], []) :- !.
'bindArgs.ast_argid25'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent23'(B, C).
'bindArgs.ast_argid25'([null|A], [null|B]) :-
	'bindArgs.ast_argparent23'(A, B), !.
'bindArgs.ast_argid25'([A|C], [B|D]) :-
	member(typeTermType, [localDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent23'(C, D), !.
'bindArgs.ast_argid25'([A|B], [A|C]) :-
	not(member(classDefT, [localDefT])),
	'bindArgs.ast_argparent23'(B, C), !.
'bindArgs.ast_argid25'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent23'(B, C), !.
'bindArgs.ast_argid25'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent23'(B, C), !.
'bindArgs.ast_argid25'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent23'(C, D), !.
'bindArgs.ast_argid25'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent23'(B, C), !.
'bindArgs.ast_argid25'([A|B], [A|C]) :-
	'bindArgs.ast_argparent23'(B, C).

% 'bindArgs.ast_argparent23'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent23'([], []) :- !.
'bindArgs.ast_argparent23'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl18'(B, C).
'bindArgs.ast_argparent23'([null|A], [null|B]) :-
	'bindArgs.ast_argencl18'(A, B), !.
'bindArgs.ast_argparent23'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl18'(C, D), !.
'bindArgs.ast_argparent23'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl18'(B, C), !.
'bindArgs.ast_argparent23'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl18'(B, C), !.
'bindArgs.ast_argparent23'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl18'(B, C), !.
'bindArgs.ast_argparent23'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl18'(C, D), !.
'bindArgs.ast_argparent23'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl18'(B, C), !.
'bindArgs.ast_argparent23'([A|B], [A|C]) :-
	'bindArgs.ast_argencl18'(B, C).

% 'bindArgs.ast_argencl18'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl18'([], []) :- !.
'bindArgs.ast_argencl18'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argtype5'(B, C).
'bindArgs.ast_argencl18'([null|A], [null|B]) :-
	'bindArgs.ast_argtype5'(A, B), !.
'bindArgs.ast_argencl18'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argtype5'(C, D), !.
'bindArgs.ast_argencl18'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_argtype5'(B, C), !.
'bindArgs.ast_argencl18'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argtype5'(B, C), !.
'bindArgs.ast_argencl18'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argtype5'(B, C), !.
'bindArgs.ast_argencl18'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argtype5'(C, D), !.
'bindArgs.ast_argencl18'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argtype5'(B, C), !.
'bindArgs.ast_argencl18'([A|B], [A|C]) :-
	'bindArgs.ast_argtype5'(B, C).

% 'bindArgs.ast_argtype5'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argtype5'([], []) :- !.
'bindArgs.ast_argtype5'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argname8'(B, C).
'bindArgs.ast_argtype5'([A|C], [B|D]) :-
	member(typeTermType, [typeTermType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argname8'(C, D), !.
'bindArgs.ast_argtype5'([A|B], [A|C]) :-
	'bindArgs.ast_argname8'(B, C), !.
'bindArgs.ast_argtype5'([A|B], [A|C]) :-
	'bindArgs.ast_argname8'(B, C).

% 'bindArgs.ast_argname8'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argname8'([], []) :- !.
'bindArgs.ast_argname8'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argexpr5'(B, C).
'bindArgs.ast_argname8'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argexpr5'(C, D), !.
'bindArgs.ast_argname8'([A|B], [A|C]) :-
	'bindArgs.ast_argexpr5'(B, C), !.
'bindArgs.ast_argname8'([A|B], [A|C]) :-
	'bindArgs.ast_argexpr5'(B, C).

% 'bindArgs.ast_argid26'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [newArrayT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(dims, mult(1, *, ord), id, [expressionType]), ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid26'([], []) :- !.
'bindArgs.ast_argid26'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent24'(B, C).
'bindArgs.ast_argid26'([null|A], [null|B]) :-
	'bindArgs.ast_argparent24'(A, B), !.
'bindArgs.ast_argid26'([A|C], [B|D]) :-
	member(typeTermType, [newArrayT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent24'(C, D), !.
'bindArgs.ast_argid26'([A|B], [A|C]) :-
	not(member(classDefT, [newArrayT])),
	'bindArgs.ast_argparent24'(B, C), !.
'bindArgs.ast_argid26'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent24'(B, C), !.
'bindArgs.ast_argid26'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent24'(B, C), !.
'bindArgs.ast_argid26'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent24'(C, D), !.
'bindArgs.ast_argid26'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent24'(B, C), !.
'bindArgs.ast_argid26'([A|B], [A|C]) :-
	'bindArgs.ast_argparent24'(B, C).

% 'bindArgs.ast_argparent24'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(dims, mult(1, *, ord), id, [expressionType]), ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent24'([], []) :- !.
'bindArgs.ast_argparent24'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl19'(B, C).
'bindArgs.ast_argparent24'([null|A], [null|B]) :-
	'bindArgs.ast_argencl19'(A, B), !.
'bindArgs.ast_argparent24'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl19'(C, D), !.
'bindArgs.ast_argparent24'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl19'(B, C), !.
'bindArgs.ast_argparent24'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl19'(B, C), !.
'bindArgs.ast_argparent24'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl19'(B, C), !.
'bindArgs.ast_argparent24'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl19'(C, D), !.
'bindArgs.ast_argparent24'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl19'(B, C), !.
'bindArgs.ast_argparent24'([A|B], [A|C]) :-
	'bindArgs.ast_argencl19'(B, C).

% 'bindArgs.ast_argencl19'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(dims, mult(1, *, ord), id, [expressionType]), ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl19'([], []) :- !.
'bindArgs.ast_argencl19'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argdims1'(B, C).
'bindArgs.ast_argencl19'([null|A], [null|B]) :-
	'bindArgs.ast_argdims1'(A, B), !.
'bindArgs.ast_argencl19'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argdims1'(C, D), !.
'bindArgs.ast_argencl19'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT])),
	'bindArgs.ast_argdims1'(B, C), !.
'bindArgs.ast_argencl19'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argdims1'(B, C), !.
'bindArgs.ast_argencl19'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argdims1'(B, C), !.
'bindArgs.ast_argencl19'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argdims1'(C, D), !.
'bindArgs.ast_argencl19'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argdims1'(B, C), !.
'bindArgs.ast_argencl19'([A|B], [A|C]) :-
	'bindArgs.ast_argdims1'(B, C).

% 'bindArgs.ast_argdims1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(dims, mult(1, *, ord), id, [expressionType]), ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argdims1'([], []) :- !.
'bindArgs.ast_argdims1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argelems1'(B, C).
'bindArgs.ast_argdims1'([A|C], [B|D]) :-
	member(classDefT, [expressionType]), !,
	replaceFQNsWithClassIds1(A, B),
	'bindArgs.ast_argelems1'(C, D), !.
'bindArgs.ast_argdims1'([null|A], [null|B]) :-
	'bindArgs.ast_argelems1'(A, B), !.
'bindArgs.ast_argdims1'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argelems1'(C, D), !.
'bindArgs.ast_argdims1'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_argelems1'(B, C), !.
'bindArgs.ast_argdims1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argelems1'(B, C), !.
'bindArgs.ast_argdims1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argelems1'(B, C), !.
'bindArgs.ast_argdims1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argelems1'(C, D), !.
'bindArgs.ast_argdims1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argelems1'(B, C), !.
'bindArgs.ast_argdims1'([A|B], [A|C]) :-
	'bindArgs.ast_argelems1'(B, C).

% 'bindArgs.ast_argelems1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argelems1'([], []) :- !.
'bindArgs.ast_argelems1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argtype6'(B, C).
'bindArgs.ast_argelems1'([A|C], [B|D]) :-
	member(classDefT, [expressionType]), !,
	replaceFQNsWithClassIds1(A, B),
	'bindArgs.ast_argtype6'(C, D), !.
'bindArgs.ast_argelems1'([null|A], [null|B]) :-
	'bindArgs.ast_argtype6'(A, B), !.
'bindArgs.ast_argelems1'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argtype6'(C, D), !.
'bindArgs.ast_argelems1'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_argtype6'(B, C), !.
'bindArgs.ast_argelems1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argtype6'(B, C), !.
'bindArgs.ast_argelems1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argtype6'(B, C), !.
'bindArgs.ast_argelems1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argtype6'(C, D), !.
'bindArgs.ast_argelems1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argtype6'(B, C), !.
'bindArgs.ast_argelems1'([A|B], [A|C]) :-
	'bindArgs.ast_argtype6'(B, C).

% 'bindArgs.ast_argtype6'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(type, mult(1, 1, no), attr, [typeTermType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argtype6'([], []) :- !.
'bindArgs.ast_argtype6'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argtype6'([A|C], [B|D]) :-
	member(typeTermType, [typeTermType]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argtype6'([A], [A]) :- !.
'bindArgs.ast_argtype6'([A], [A]).

% 'bindArgs.ast_argid27'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [newClassT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(constr, mult(0, 1, no), id, [methodDefT]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid27'([], []) :- !.
'bindArgs.ast_argid27'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent25'(B, C).
'bindArgs.ast_argid27'([null|A], [null|B]) :-
	'bindArgs.ast_argparent25'(A, B), !.
'bindArgs.ast_argid27'([A|C], [B|D]) :-
	member(typeTermType, [newClassT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent25'(C, D), !.
'bindArgs.ast_argid27'([A|B], [A|C]) :-
	not(member(classDefT, [newClassT])),
	'bindArgs.ast_argparent25'(B, C), !.
'bindArgs.ast_argid27'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent25'(B, C), !.
'bindArgs.ast_argid27'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent25'(B, C), !.
'bindArgs.ast_argid27'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent25'(C, D), !.
'bindArgs.ast_argid27'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent25'(B, C), !.
'bindArgs.ast_argid27'([A|B], [A|C]) :-
	'bindArgs.ast_argparent25'(B, C).

% 'bindArgs.ast_argparent25'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(constr, mult(0, 1, no), id, [methodDefT]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent25'([], []) :- !.
'bindArgs.ast_argparent25'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl20'(B, C).
'bindArgs.ast_argparent25'([null|A], [null|B]) :-
	'bindArgs.ast_argencl20'(A, B), !.
'bindArgs.ast_argparent25'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl20'(C, D), !.
'bindArgs.ast_argparent25'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl20'(B, C), !.
'bindArgs.ast_argparent25'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl20'(B, C), !.
'bindArgs.ast_argparent25'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl20'(B, C), !.
'bindArgs.ast_argparent25'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl20'(C, D), !.
'bindArgs.ast_argparent25'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl20'(B, C), !.
'bindArgs.ast_argparent25'([A|B], [A|C]) :-
	'bindArgs.ast_argencl20'(B, C).

% 'bindArgs.ast_argencl20'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(constr, mult(0, 1, no), id, [methodDefT]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl20'([], []) :- !.
'bindArgs.ast_argencl20'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argconstr1'(B, C).
'bindArgs.ast_argencl20'([null|A], [null|B]) :-
	'bindArgs.ast_argconstr1'(A, B), !.
'bindArgs.ast_argencl20'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argconstr1'(C, D), !.
'bindArgs.ast_argencl20'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT])),
	'bindArgs.ast_argconstr1'(B, C), !.
'bindArgs.ast_argencl20'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argconstr1'(B, C), !.
'bindArgs.ast_argencl20'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argconstr1'(B, C), !.
'bindArgs.ast_argencl20'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argconstr1'(C, D), !.
'bindArgs.ast_argencl20'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argconstr1'(B, C), !.
'bindArgs.ast_argencl20'([A|B], [A|C]) :-
	'bindArgs.ast_argconstr1'(B, C).

% 'bindArgs.ast_argconstr1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(constr, mult(0, 1, no), id, [methodDefT]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argconstr1'([], []) :- !.
'bindArgs.ast_argconstr1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argargs2'(B, C).
'bindArgs.ast_argconstr1'([null|A], [null|B]) :-
	'bindArgs.ast_argargs2'(A, B), !.
'bindArgs.ast_argconstr1'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argargs2'(C, D), !.
'bindArgs.ast_argconstr1'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_argargs2'(B, C), !.
'bindArgs.ast_argconstr1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argargs2'(B, C), !.
'bindArgs.ast_argconstr1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argargs2'(B, C), !.
'bindArgs.ast_argconstr1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argargs2'(C, D), !.
'bindArgs.ast_argconstr1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argargs2'(B, C), !.
'bindArgs.ast_argconstr1'([A|B], [A|C]) :-
	'bindArgs.ast_argargs2'(B, C).

% 'bindArgs.ast_argargs2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argargs2'([], []) :- !.
'bindArgs.ast_argargs2'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argclident1'(B, C).
'bindArgs.ast_argargs2'([A|C], [B|D]) :-
	member(classDefT, [expressionType]), !,
	replaceFQNsWithClassIds1(A, B),
	'bindArgs.ast_argclident1'(C, D), !.
'bindArgs.ast_argargs2'([null|A], [null|B]) :-
	'bindArgs.ast_argclident1'(A, B), !.
'bindArgs.ast_argargs2'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argclident1'(C, D), !.
'bindArgs.ast_argargs2'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_argclident1'(B, C), !.
'bindArgs.ast_argargs2'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argclident1'(B, C), !.
'bindArgs.ast_argargs2'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argclident1'(B, C), !.
'bindArgs.ast_argargs2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argclident1'(C, D), !.
'bindArgs.ast_argargs2'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argclident1'(B, C), !.
'bindArgs.ast_argargs2'([A|B], [A|C]) :-
	'bindArgs.ast_argclident1'(B, C).

% 'bindArgs.ast_argclident1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argclident1'([], []) :- !.
'bindArgs.ast_argclident1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argdef1'(B, C).
'bindArgs.ast_argclident1'([null|A], [null|B]) :-
	'bindArgs.ast_argdef1'(A, B), !.
'bindArgs.ast_argclident1'([A|C], [B|D]) :-
	member(typeTermType, [identT, selectT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argdef1'(C, D), !.
'bindArgs.ast_argclident1'([A|B], [A|C]) :-
	not(member(classDefT, [identT, selectT])),
	'bindArgs.ast_argdef1'(B, C), !.
'bindArgs.ast_argclident1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argdef1'(B, C), !.
'bindArgs.ast_argclident1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argdef1'(B, C), !.
'bindArgs.ast_argclident1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argdef1'(C, D), !.
'bindArgs.ast_argclident1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argdef1'(B, C), !.
'bindArgs.ast_argclident1'([A|B], [A|C]) :-
	'bindArgs.ast_argdef1'(B, C).

% 'bindArgs.ast_argdef1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argdef1'([], []) :- !.
'bindArgs.ast_argdef1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencltype1'(B, C).
'bindArgs.ast_argdef1'([null|A], [null|B]) :-
	'bindArgs.ast_argencltype1'(A, B), !.
'bindArgs.ast_argdef1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencltype1'(C, D), !.
'bindArgs.ast_argdef1'([A|C], [B|D]) :-
	member(typeTermType, [classDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencltype1'(C, D), !.
'bindArgs.ast_argdef1'([A|B], [A|C]) :-
	not(member(classDefT, [classDefT])),
	'bindArgs.ast_argencltype1'(B, C), !.
'bindArgs.ast_argdef1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencltype1'(B, C), !.
'bindArgs.ast_argdef1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencltype1'(B, C), !.
'bindArgs.ast_argdef1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencltype1'(C, D), !.
'bindArgs.ast_argdef1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencltype1'(B, C), !.
'bindArgs.ast_argdef1'([A|B], [A|C]) :-
	'bindArgs.ast_argencltype1'(B, C).

% 'bindArgs.ast_argencltype1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encltype, mult(0, 1, no), id, [classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencltype1'([], []) :- !.
'bindArgs.ast_argencltype1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argencltype1'([null], [null]) :- !.
'bindArgs.ast_argencltype1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argencltype1'([A|C], [B|D]) :-
	member(typeTermType, [classDefT]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argencltype1'([A|B], [A|C]) :-
	not(member(classDefT, [classDefT])),
	B=[],
	C=[], !.
'bindArgs.ast_argencltype1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argencltype1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argencltype1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argencltype1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argencltype1'([A], [A]).

% 'bindArgs.ast_argid28'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [nopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid28'([], []) :- !.
'bindArgs.ast_argid28'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent26'(B, C).
'bindArgs.ast_argid28'([null|A], [null|B]) :-
	'bindArgs.ast_argparent26'(A, B), !.
'bindArgs.ast_argid28'([A|C], [B|D]) :-
	member(typeTermType, [nopT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent26'(C, D), !.
'bindArgs.ast_argid28'([A|B], [A|C]) :-
	not(member(classDefT, [nopT])),
	'bindArgs.ast_argparent26'(B, C), !.
'bindArgs.ast_argid28'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent26'(B, C), !.
'bindArgs.ast_argid28'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent26'(B, C), !.
'bindArgs.ast_argid28'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent26'(C, D), !.
'bindArgs.ast_argid28'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent26'(B, C), !.
'bindArgs.ast_argid28'([A|B], [A|C]) :-
	'bindArgs.ast_argparent26'(B, C).

% 'bindArgs.ast_argparent26'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent26'([], []) :- !.
'bindArgs.ast_argparent26'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl21'(B, C).
'bindArgs.ast_argparent26'([null|A], [null|B]) :-
	'bindArgs.ast_argencl21'(A, B), !.
'bindArgs.ast_argparent26'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl21'(C, D), !.
'bindArgs.ast_argparent26'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl21'(B, C), !.
'bindArgs.ast_argparent26'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl21'(B, C), !.
'bindArgs.ast_argparent26'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl21'(B, C), !.
'bindArgs.ast_argparent26'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl21'(C, D), !.
'bindArgs.ast_argparent26'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl21'(B, C), !.
'bindArgs.ast_argparent26'([A|B], [A|C]) :-
	'bindArgs.ast_argencl21'(B, C).

% 'bindArgs.ast_argencl21'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl21'([], []) :- !.
'bindArgs.ast_argencl21'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argencl21'([null], [null]) :- !.
'bindArgs.ast_argencl21'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argencl21'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	B=[],
	C=[], !.
'bindArgs.ast_argencl21'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argencl21'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argencl21'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argencl21'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argencl21'([A], [A]).

% 'bindArgs.ast_argid29'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [operationT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(args, mult(1, 1, ord), id, [expressionType]), ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid29'([], []) :- !.
'bindArgs.ast_argid29'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent27'(B, C).
'bindArgs.ast_argid29'([null|A], [null|B]) :-
	'bindArgs.ast_argparent27'(A, B), !.
'bindArgs.ast_argid29'([A|C], [B|D]) :-
	member(typeTermType, [operationT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent27'(C, D), !.
'bindArgs.ast_argid29'([A|B], [A|C]) :-
	not(member(classDefT, [operationT])),
	'bindArgs.ast_argparent27'(B, C), !.
'bindArgs.ast_argid29'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent27'(B, C), !.
'bindArgs.ast_argid29'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent27'(B, C), !.
'bindArgs.ast_argid29'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent27'(C, D), !.
'bindArgs.ast_argid29'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent27'(B, C), !.
'bindArgs.ast_argid29'([A|B], [A|C]) :-
	'bindArgs.ast_argparent27'(B, C).

% 'bindArgs.ast_argparent27'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(args, mult(1, 1, ord), id, [expressionType]), ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent27'([], []) :- !.
'bindArgs.ast_argparent27'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl22'(B, C).
'bindArgs.ast_argparent27'([null|A], [null|B]) :-
	'bindArgs.ast_argencl22'(A, B), !.
'bindArgs.ast_argparent27'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl22'(C, D), !.
'bindArgs.ast_argparent27'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl22'(B, C), !.
'bindArgs.ast_argparent27'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl22'(B, C), !.
'bindArgs.ast_argparent27'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl22'(B, C), !.
'bindArgs.ast_argparent27'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl22'(C, D), !.
'bindArgs.ast_argparent27'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl22'(B, C), !.
'bindArgs.ast_argparent27'([A|B], [A|C]) :-
	'bindArgs.ast_argencl22'(B, C).

% 'bindArgs.ast_argencl22'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(args, mult(1, 1, ord), id, [expressionType]), ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl22'([], []) :- !.
'bindArgs.ast_argencl22'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argargs3'(B, C).
'bindArgs.ast_argencl22'([null|A], [null|B]) :-
	'bindArgs.ast_argargs3'(A, B), !.
'bindArgs.ast_argencl22'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argargs3'(C, D), !.
'bindArgs.ast_argencl22'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT])),
	'bindArgs.ast_argargs3'(B, C), !.
'bindArgs.ast_argencl22'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argargs3'(B, C), !.
'bindArgs.ast_argencl22'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argargs3'(B, C), !.
'bindArgs.ast_argencl22'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argargs3'(C, D), !.
'bindArgs.ast_argencl22'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argargs3'(B, C), !.
'bindArgs.ast_argencl22'([A|B], [A|C]) :-
	'bindArgs.ast_argargs3'(B, C).

% 'bindArgs.ast_argargs3'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(args, mult(1, 1, ord), id, [expressionType]), ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argargs3'([], []) :- !.
'bindArgs.ast_argargs3'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argop1'(B, C).
'bindArgs.ast_argargs3'([A|C], [B|D]) :-
	member(classDefT, [expressionType]), !,
	replaceFQNsWithClassIds1(A, B),
	'bindArgs.ast_argop1'(C, D), !.
'bindArgs.ast_argargs3'([null|A], [null|B]) :-
	'bindArgs.ast_argop1'(A, B), !.
'bindArgs.ast_argargs3'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argop1'(C, D), !.
'bindArgs.ast_argargs3'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_argop1'(B, C), !.
'bindArgs.ast_argargs3'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argop1'(B, C), !.
'bindArgs.ast_argargs3'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argop1'(B, C), !.
'bindArgs.ast_argargs3'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argop1'(C, D), !.
'bindArgs.ast_argargs3'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argop1'(B, C), !.
'bindArgs.ast_argargs3'([A|B], [A|C]) :-
	'bindArgs.ast_argop1'(B, C).

% 'bindArgs.ast_argop1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argop1'([], []) :- !.
'bindArgs.ast_argop1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argpos1'(B, C).
'bindArgs.ast_argop1'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argpos1'(C, D), !.
'bindArgs.ast_argop1'([A|B], [A|C]) :-
	'bindArgs.ast_argpos1'(B, C), !.
'bindArgs.ast_argop1'([A|B], [A|C]) :-
	'bindArgs.ast_argpos1'(B, C).

% 'bindArgs.ast_argpos1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(pos, mult(1, 1, no), id, [number])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argpos1'([], []) :- !.
'bindArgs.ast_argpos1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argpos1'([null], [null]) :- !.
'bindArgs.ast_argpos1'([A|C], [B|D]) :-
	member(typeTermType, [number]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argpos1'([A|B], [A|C]) :-
	not(member(classDefT, [number])),
	B=[],
	C=[], !.
'bindArgs.ast_argpos1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argpos1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argpos1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argpos1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argpos1'([A], [A]).

% 'bindArgs.ast_argid30'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [precedenceT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid30'([], []) :- !.
'bindArgs.ast_argid30'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent28'(B, C).
'bindArgs.ast_argid30'([null|A], [null|B]) :-
	'bindArgs.ast_argparent28'(A, B), !.
'bindArgs.ast_argid30'([A|C], [B|D]) :-
	member(typeTermType, [precedenceT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent28'(C, D), !.
'bindArgs.ast_argid30'([A|B], [A|C]) :-
	not(member(classDefT, [precedenceT])),
	'bindArgs.ast_argparent28'(B, C), !.
'bindArgs.ast_argid30'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent28'(B, C), !.
'bindArgs.ast_argid30'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent28'(B, C), !.
'bindArgs.ast_argid30'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent28'(C, D), !.
'bindArgs.ast_argid30'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent28'(B, C), !.
'bindArgs.ast_argid30'([A|B], [A|C]) :-
	'bindArgs.ast_argparent28'(B, C).

% 'bindArgs.ast_argparent28'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent28'([], []) :- !.
'bindArgs.ast_argparent28'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl23'(B, C).
'bindArgs.ast_argparent28'([null|A], [null|B]) :-
	'bindArgs.ast_argencl23'(A, B), !.
'bindArgs.ast_argparent28'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl23'(C, D), !.
'bindArgs.ast_argparent28'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl23'(B, C), !.
'bindArgs.ast_argparent28'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl23'(B, C), !.
'bindArgs.ast_argparent28'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl23'(B, C), !.
'bindArgs.ast_argparent28'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl23'(C, D), !.
'bindArgs.ast_argparent28'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl23'(B, C), !.
'bindArgs.ast_argparent28'([A|B], [A|C]) :-
	'bindArgs.ast_argencl23'(B, C).

% 'bindArgs.ast_argencl23'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl23'([], []) :- !.
'bindArgs.ast_argencl23'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argexpr4'(B, C).
'bindArgs.ast_argencl23'([null|A], [null|B]) :-
	'bindArgs.ast_argexpr4'(A, B), !.
'bindArgs.ast_argencl23'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argexpr4'(C, D), !.
'bindArgs.ast_argencl23'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT])),
	'bindArgs.ast_argexpr4'(B, C), !.
'bindArgs.ast_argencl23'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argexpr4'(B, C), !.
'bindArgs.ast_argencl23'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argexpr4'(B, C), !.
'bindArgs.ast_argencl23'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argexpr4'(C, D), !.
'bindArgs.ast_argencl23'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argexpr4'(B, C), !.
'bindArgs.ast_argencl23'([A|B], [A|C]) :-
	'bindArgs.ast_argexpr4'(B, C).

% 'bindArgs.ast_argid31'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [selectT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid31'([], []) :- !.
'bindArgs.ast_argid31'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent29'(B, C).
'bindArgs.ast_argid31'([null|A], [null|B]) :-
	'bindArgs.ast_argparent29'(A, B), !.
'bindArgs.ast_argid31'([A|C], [B|D]) :-
	member(typeTermType, [selectT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent29'(C, D), !.
'bindArgs.ast_argid31'([A|B], [A|C]) :-
	not(member(classDefT, [selectT])),
	'bindArgs.ast_argparent29'(B, C), !.
'bindArgs.ast_argid31'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent29'(B, C), !.
'bindArgs.ast_argid31'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent29'(B, C), !.
'bindArgs.ast_argid31'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent29'(C, D), !.
'bindArgs.ast_argid31'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent29'(B, C), !.
'bindArgs.ast_argid31'([A|B], [A|C]) :-
	'bindArgs.ast_argparent29'(B, C).

% 'bindArgs.ast_argparent29'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent29'([], []) :- !.
'bindArgs.ast_argparent29'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl24'(B, C).
'bindArgs.ast_argparent29'([null|A], [null|B]) :-
	'bindArgs.ast_argencl24'(A, B), !.
'bindArgs.ast_argparent29'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl24'(C, D), !.
'bindArgs.ast_argparent29'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl24'(B, C), !.
'bindArgs.ast_argparent29'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl24'(B, C), !.
'bindArgs.ast_argparent29'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl24'(B, C), !.
'bindArgs.ast_argparent29'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl24'(C, D), !.
'bindArgs.ast_argparent29'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl24'(B, C), !.
'bindArgs.ast_argparent29'([A|B], [A|C]) :-
	'bindArgs.ast_argencl24'(B, C).

% 'bindArgs.ast_argencl24'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl24'([], []) :- !.
'bindArgs.ast_argencl24'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argname9'(B, C).
'bindArgs.ast_argencl24'([null|A], [null|B]) :-
	'bindArgs.ast_argname9'(A, B), !.
'bindArgs.ast_argencl24'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argname9'(C, D), !.
'bindArgs.ast_argencl24'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT])),
	'bindArgs.ast_argname9'(B, C), !.
'bindArgs.ast_argencl24'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argname9'(B, C), !.
'bindArgs.ast_argencl24'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argname9'(B, C), !.
'bindArgs.ast_argencl24'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argname9'(C, D), !.
'bindArgs.ast_argencl24'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argname9'(B, C), !.
'bindArgs.ast_argencl24'([A|B], [A|C]) :-
	'bindArgs.ast_argname9'(B, C).

% 'bindArgs.ast_argname9'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argname9'([], []) :- !.
'bindArgs.ast_argname9'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argselected1'(B, C).
'bindArgs.ast_argname9'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argselected1'(C, D), !.
'bindArgs.ast_argname9'([A|B], [A|C]) :-
	'bindArgs.ast_argselected1'(B, C), !.
'bindArgs.ast_argname9'([A|B], [A|C]) :-
	'bindArgs.ast_argselected1'(B, C).

% 'bindArgs.ast_argselected1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argselected1'([], []) :- !.
'bindArgs.ast_argselected1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argref2'(B, C).
'bindArgs.ast_argselected1'([null|A], [null|B]) :-
	'bindArgs.ast_argref2'(A, B), !.
'bindArgs.ast_argselected1'([A|C], [B|D]) :-
	member(typeTermType, [selectT, identT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argref2'(C, D), !.
'bindArgs.ast_argselected1'([A|B], [A|C]) :-
	not(member(classDefT, [selectT, identT])),
	'bindArgs.ast_argref2'(B, C), !.
'bindArgs.ast_argselected1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argref2'(B, C), !.
'bindArgs.ast_argselected1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argref2'(B, C), !.
'bindArgs.ast_argselected1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argref2'(C, D), !.
'bindArgs.ast_argselected1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argref2'(B, C), !.
'bindArgs.ast_argselected1'([A|B], [A|C]) :-
	'bindArgs.ast_argref2'(B, C).

% 'bindArgs.ast_argref2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argref2'([], []) :- !.
'bindArgs.ast_argref2'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argref2'([null], [null]) :- !.
'bindArgs.ast_argref2'([A|C], [B|D]) :-
	member(typeTermType, [classDefT, packageT]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argref2'([A|B], [A|C]) :-
	not(member(classDefT, [classDefT, packageT])),
	B=[],
	C=[], !.
'bindArgs.ast_argref2'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argref2'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argref2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argref2'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argref2'([A], [A]).

% 'bindArgs.ast_argid32'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [identT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT, localDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid32'([], []) :- !.
'bindArgs.ast_argid32'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent30'(B, C).
'bindArgs.ast_argid32'([null|A], [null|B]) :-
	'bindArgs.ast_argparent30'(A, B), !.
'bindArgs.ast_argid32'([A|C], [B|D]) :-
	member(typeTermType, [identT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent30'(C, D), !.
'bindArgs.ast_argid32'([A|B], [A|C]) :-
	not(member(classDefT, [identT])),
	'bindArgs.ast_argparent30'(B, C), !.
'bindArgs.ast_argid32'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent30'(B, C), !.
'bindArgs.ast_argid32'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent30'(B, C), !.
'bindArgs.ast_argid32'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent30'(C, D), !.
'bindArgs.ast_argid32'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent30'(B, C), !.
'bindArgs.ast_argid32'([A|B], [A|C]) :-
	'bindArgs.ast_argparent30'(B, C).

% 'bindArgs.ast_argparent30'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT, localDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent30'([], []) :- !.
'bindArgs.ast_argparent30'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl25'(B, C).
'bindArgs.ast_argparent30'([null|A], [null|B]) :-
	'bindArgs.ast_argencl25'(A, B), !.
'bindArgs.ast_argparent30'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl25'(C, D), !.
'bindArgs.ast_argparent30'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl25'(B, C), !.
'bindArgs.ast_argparent30'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl25'(B, C), !.
'bindArgs.ast_argparent30'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl25'(B, C), !.
'bindArgs.ast_argparent30'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl25'(C, D), !.
'bindArgs.ast_argparent30'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl25'(B, C), !.
'bindArgs.ast_argparent30'([A|B], [A|C]) :-
	'bindArgs.ast_argencl25'(B, C).

% 'bindArgs.ast_argencl25'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT, localDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl25'([], []) :- !.
'bindArgs.ast_argencl25'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argname10'(B, C).
'bindArgs.ast_argencl25'([null|A], [null|B]) :-
	'bindArgs.ast_argname10'(A, B), !.
'bindArgs.ast_argencl25'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argname10'(C, D), !.
'bindArgs.ast_argencl25'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT])),
	'bindArgs.ast_argname10'(B, C), !.
'bindArgs.ast_argencl25'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argname10'(B, C), !.
'bindArgs.ast_argencl25'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argname10'(B, C), !.
'bindArgs.ast_argencl25'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argname10'(C, D), !.
'bindArgs.ast_argencl25'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argname10'(B, C), !.
'bindArgs.ast_argencl25'([A|B], [A|C]) :-
	'bindArgs.ast_argname10'(B, C).

% 'bindArgs.ast_argname10'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT, localDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argname10'([], []) :- !.
'bindArgs.ast_argname10'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argref3'(B, C).
'bindArgs.ast_argname10'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argref3'(C, D), !.
'bindArgs.ast_argname10'([A|B], [A|C]) :-
	'bindArgs.ast_argref3'(B, C), !.
'bindArgs.ast_argname10'([A|B], [A|C]) :-
	'bindArgs.ast_argref3'(B, C).

% 'bindArgs.ast_argref3'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT, localDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argref3'([], []) :- !.
'bindArgs.ast_argref3'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argref3'([null], [null]) :- !.
'bindArgs.ast_argref3'([A|C], [B|D]) :-
	member(typeTermType, [classDefT, packageT, localDefT]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argref3'([A|B], [A|C]) :-
	not(member(classDefT, [classDefT, packageT, localDefT])),
	B=[],
	C=[], !.
'bindArgs.ast_argref3'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argref3'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argref3'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argref3'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argref3'([A], [A]).

% 'bindArgs.ast_argid33'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [switchT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(stmts, mult(1, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid33'([], []) :- !.
'bindArgs.ast_argid33'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent31'(B, C).
'bindArgs.ast_argid33'([null|A], [null|B]) :-
	'bindArgs.ast_argparent31'(A, B), !.
'bindArgs.ast_argid33'([A|C], [B|D]) :-
	member(typeTermType, [switchT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent31'(C, D), !.
'bindArgs.ast_argid33'([A|B], [A|C]) :-
	not(member(classDefT, [switchT])),
	'bindArgs.ast_argparent31'(B, C), !.
'bindArgs.ast_argid33'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent31'(B, C), !.
'bindArgs.ast_argid33'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent31'(B, C), !.
'bindArgs.ast_argid33'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent31'(C, D), !.
'bindArgs.ast_argid33'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent31'(B, C), !.
'bindArgs.ast_argid33'([A|B], [A|C]) :-
	'bindArgs.ast_argparent31'(B, C).

% 'bindArgs.ast_argparent31'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(stmts, mult(1, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent31'([], []) :- !.
'bindArgs.ast_argparent31'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl26'(B, C).
'bindArgs.ast_argparent31'([null|A], [null|B]) :-
	'bindArgs.ast_argencl26'(A, B), !.
'bindArgs.ast_argparent31'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl26'(C, D), !.
'bindArgs.ast_argparent31'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl26'(B, C), !.
'bindArgs.ast_argparent31'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl26'(B, C), !.
'bindArgs.ast_argparent31'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl26'(B, C), !.
'bindArgs.ast_argparent31'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl26'(C, D), !.
'bindArgs.ast_argparent31'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl26'(B, C), !.
'bindArgs.ast_argparent31'([A|B], [A|C]) :-
	'bindArgs.ast_argencl26'(B, C).

% 'bindArgs.ast_argencl26'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(stmts, mult(1, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl26'([], []) :- !.
'bindArgs.ast_argencl26'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argcond5'(B, C).
'bindArgs.ast_argencl26'([null|A], [null|B]) :-
	'bindArgs.ast_argcond5'(A, B), !.
'bindArgs.ast_argencl26'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argcond5'(C, D), !.
'bindArgs.ast_argencl26'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_argcond5'(B, C), !.
'bindArgs.ast_argencl26'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argcond5'(B, C), !.
'bindArgs.ast_argencl26'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argcond5'(B, C), !.
'bindArgs.ast_argencl26'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argcond5'(C, D), !.
'bindArgs.ast_argencl26'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argcond5'(B, C), !.
'bindArgs.ast_argencl26'([A|B], [A|C]) :-
	'bindArgs.ast_argcond5'(B, C).

% 'bindArgs.ast_argcond5'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(stmts, mult(1, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argcond5'([], []) :- !.
'bindArgs.ast_argcond5'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argstmts2'(B, C).
'bindArgs.ast_argcond5'([null|A], [null|B]) :-
	'bindArgs.ast_argstmts2'(A, B), !.
'bindArgs.ast_argcond5'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argstmts2'(C, D), !.
'bindArgs.ast_argcond5'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_argstmts2'(B, C), !.
'bindArgs.ast_argcond5'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argstmts2'(B, C), !.
'bindArgs.ast_argcond5'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argstmts2'(B, C), !.
'bindArgs.ast_argcond5'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argstmts2'(C, D), !.
'bindArgs.ast_argcond5'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argstmts2'(B, C), !.
'bindArgs.ast_argcond5'([A|B], [A|C]) :-
	'bindArgs.ast_argstmts2'(B, C).

% 'bindArgs.ast_argstmts2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(stmts, mult(1, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argstmts2'([], []) :- !.
'bindArgs.ast_argstmts2'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argstmts2'([null], [null]) :- !.
'bindArgs.ast_argstmts2'([A|C], [B|D]) :-
	member(typeTermType, [statementType]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argstmts2'([A|B], [A|C]) :-
	not(member(classDefT, [statementType])),
	B=[],
	C=[], !.
'bindArgs.ast_argstmts2'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argstmts2'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argstmts2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argstmts2'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argstmts2'([A], [A]).

% 'bindArgs.ast_argid34'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [synchronizedT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(lock, mult(1, 1, no), id, [expressionType]), ast_arg(block, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid34'([], []) :- !.
'bindArgs.ast_argid34'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent32'(B, C).
'bindArgs.ast_argid34'([null|A], [null|B]) :-
	'bindArgs.ast_argparent32'(A, B), !.
'bindArgs.ast_argid34'([A|C], [B|D]) :-
	member(typeTermType, [synchronizedT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent32'(C, D), !.
'bindArgs.ast_argid34'([A|B], [A|C]) :-
	not(member(classDefT, [synchronizedT])),
	'bindArgs.ast_argparent32'(B, C), !.
'bindArgs.ast_argid34'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent32'(B, C), !.
'bindArgs.ast_argid34'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent32'(B, C), !.
'bindArgs.ast_argid34'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent32'(C, D), !.
'bindArgs.ast_argid34'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent32'(B, C), !.
'bindArgs.ast_argid34'([A|B], [A|C]) :-
	'bindArgs.ast_argparent32'(B, C).

% 'bindArgs.ast_argparent32'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(lock, mult(1, 1, no), id, [expressionType]), ast_arg(block, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent32'([], []) :- !.
'bindArgs.ast_argparent32'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl27'(B, C).
'bindArgs.ast_argparent32'([null|A], [null|B]) :-
	'bindArgs.ast_argencl27'(A, B), !.
'bindArgs.ast_argparent32'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl27'(C, D), !.
'bindArgs.ast_argparent32'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl27'(B, C), !.
'bindArgs.ast_argparent32'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl27'(B, C), !.
'bindArgs.ast_argparent32'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl27'(B, C), !.
'bindArgs.ast_argparent32'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl27'(C, D), !.
'bindArgs.ast_argparent32'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl27'(B, C), !.
'bindArgs.ast_argparent32'([A|B], [A|C]) :-
	'bindArgs.ast_argencl27'(B, C).

% 'bindArgs.ast_argencl27'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(lock, mult(1, 1, no), id, [expressionType]), ast_arg(block, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl27'([], []) :- !.
'bindArgs.ast_argencl27'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_arglock1'(B, C).
'bindArgs.ast_argencl27'([null|A], [null|B]) :-
	'bindArgs.ast_arglock1'(A, B), !.
'bindArgs.ast_argencl27'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_arglock1'(C, D), !.
'bindArgs.ast_argencl27'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_arglock1'(B, C), !.
'bindArgs.ast_argencl27'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_arglock1'(B, C), !.
'bindArgs.ast_argencl27'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_arglock1'(B, C), !.
'bindArgs.ast_argencl27'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arglock1'(C, D), !.
'bindArgs.ast_argencl27'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_arglock1'(B, C), !.
'bindArgs.ast_argencl27'([A|B], [A|C]) :-
	'bindArgs.ast_arglock1'(B, C).

% 'bindArgs.ast_arglock1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(lock, mult(1, 1, no), id, [expressionType]), ast_arg(block, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_arglock1'([], []) :- !.
'bindArgs.ast_arglock1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argblock1'(B, C).
'bindArgs.ast_arglock1'([null|A], [null|B]) :-
	'bindArgs.ast_argblock1'(A, B), !.
'bindArgs.ast_arglock1'([A|C], [B|D]) :-
	member(typeTermType, [expressionType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argblock1'(C, D), !.
'bindArgs.ast_arglock1'([A|B], [A|C]) :-
	not(member(classDefT, [expressionType])),
	'bindArgs.ast_argblock1'(B, C), !.
'bindArgs.ast_arglock1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argblock1'(B, C), !.
'bindArgs.ast_arglock1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argblock1'(B, C), !.
'bindArgs.ast_arglock1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argblock1'(C, D), !.
'bindArgs.ast_arglock1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argblock1'(B, C), !.
'bindArgs.ast_arglock1'([A|B], [A|C]) :-
	'bindArgs.ast_argblock1'(B, C).

% 'bindArgs.ast_argblock1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(block, mult(1, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argblock1'([], []) :- !.
'bindArgs.ast_argblock1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argblock1'([null], [null]) :- !.
'bindArgs.ast_argblock1'([A|C], [B|D]) :-
	member(typeTermType, [blockT]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argblock1'([A|B], [A|C]) :-
	not(member(classDefT, [blockT])),
	B=[],
	C=[], !.
'bindArgs.ast_argblock1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argblock1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argblock1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argblock1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argblock1'([A], [A]).

% 'bindArgs.ast_argid35'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [throwT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid35'([], []) :- !.
'bindArgs.ast_argid35'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent14'(B, C).
'bindArgs.ast_argid35'([null|A], [null|B]) :-
	'bindArgs.ast_argparent14'(A, B), !.
'bindArgs.ast_argid35'([A|C], [B|D]) :-
	member(typeTermType, [throwT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent14'(C, D), !.
'bindArgs.ast_argid35'([A|B], [A|C]) :-
	not(member(classDefT, [throwT])),
	'bindArgs.ast_argparent14'(B, C), !.
'bindArgs.ast_argid35'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent14'(B, C), !.
'bindArgs.ast_argid35'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent14'(B, C), !.
'bindArgs.ast_argid35'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent14'(C, D), !.
'bindArgs.ast_argid35'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent14'(B, C), !.
'bindArgs.ast_argid35'([A|B], [A|C]) :-
	'bindArgs.ast_argparent14'(B, C).

% 'bindArgs.ast_argid36'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [toplevelT]), ast_arg(parent, mult(0, 1, no), id, [packageT]), ast_arg(file, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid36'([], []) :- !.
'bindArgs.ast_argid36'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent33'(B, C).
'bindArgs.ast_argid36'([null|A], [null|B]) :-
	'bindArgs.ast_argparent33'(A, B), !.
'bindArgs.ast_argid36'([A|C], [B|D]) :-
	member(typeTermType, [toplevelT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent33'(C, D), !.
'bindArgs.ast_argid36'([A|B], [A|C]) :-
	not(member(classDefT, [toplevelT])),
	'bindArgs.ast_argparent33'(B, C), !.
'bindArgs.ast_argid36'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent33'(B, C), !.
'bindArgs.ast_argid36'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent33'(B, C), !.
'bindArgs.ast_argid36'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent33'(C, D), !.
'bindArgs.ast_argid36'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent33'(B, C), !.
'bindArgs.ast_argid36'([A|B], [A|C]) :-
	'bindArgs.ast_argparent33'(B, C).

% 'bindArgs.ast_argparent33'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(0, 1, no), id, [packageT]), ast_arg(file, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent33'([], []) :- !.
'bindArgs.ast_argparent33'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argfile1'(B, C).
'bindArgs.ast_argparent33'([null|A], [null|B]) :-
	'bindArgs.ast_argfile1'(A, B), !.
'bindArgs.ast_argparent33'([A|C], [B|D]) :-
	member(typeTermType, [packageT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argfile1'(C, D), !.
'bindArgs.ast_argparent33'([A|B], [A|C]) :-
	not(member(classDefT, [packageT])),
	'bindArgs.ast_argfile1'(B, C), !.
'bindArgs.ast_argparent33'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argfile1'(B, C), !.
'bindArgs.ast_argparent33'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argfile1'(B, C), !.
'bindArgs.ast_argparent33'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argfile1'(C, D), !.
'bindArgs.ast_argparent33'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argfile1'(B, C), !.
'bindArgs.ast_argparent33'([A|B], [A|C]) :-
	'bindArgs.ast_argfile1'(B, C).

% 'bindArgs.ast_argfile1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(file, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argfile1'([], []) :- !.
'bindArgs.ast_argfile1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argdefs2'(B, C).
'bindArgs.ast_argfile1'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argdefs2'(C, D), !.
'bindArgs.ast_argfile1'([A|B], [A|C]) :-
	'bindArgs.ast_argdefs2'(B, C), !.
'bindArgs.ast_argfile1'([A|B], [A|C]) :-
	'bindArgs.ast_argdefs2'(B, C).

% 'bindArgs.ast_argdefs2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argdefs2'([], []) :- !.
'bindArgs.ast_argdefs2'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argdefs2'([A|C], [B|D]) :-
	member(classDefT, [importT, classDefT]), !,
	replaceFQNsWithClassIds1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argdefs2'([null], [null]) :- !.
'bindArgs.ast_argdefs2'([A|C], [B|D]) :-
	member(typeTermType, [importT, classDefT]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argdefs2'([A|B], [A|C]) :-
	not(member(classDefT, [importT, classDefT])),
	B=[],
	C=[], !.
'bindArgs.ast_argdefs2'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argdefs2'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argdefs2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argdefs2'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argdefs2'([A], [A]).

% 'bindArgs.ast_argid37'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [tryT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(block, mult(1, 1, no), id, [blockT]), ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid37'([], []) :- !.
'bindArgs.ast_argid37'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent34'(B, C).
'bindArgs.ast_argid37'([null|A], [null|B]) :-
	'bindArgs.ast_argparent34'(A, B), !.
'bindArgs.ast_argid37'([A|C], [B|D]) :-
	member(typeTermType, [tryT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent34'(C, D), !.
'bindArgs.ast_argid37'([A|B], [A|C]) :-
	not(member(classDefT, [tryT])),
	'bindArgs.ast_argparent34'(B, C), !.
'bindArgs.ast_argid37'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent34'(B, C), !.
'bindArgs.ast_argid37'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent34'(B, C), !.
'bindArgs.ast_argid37'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent34'(C, D), !.
'bindArgs.ast_argid37'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent34'(B, C), !.
'bindArgs.ast_argid37'([A|B], [A|C]) :-
	'bindArgs.ast_argparent34'(B, C).

% 'bindArgs.ast_argparent34'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(block, mult(1, 1, no), id, [blockT]), ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent34'([], []) :- !.
'bindArgs.ast_argparent34'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl28'(B, C).
'bindArgs.ast_argparent34'([null|A], [null|B]) :-
	'bindArgs.ast_argencl28'(A, B), !.
'bindArgs.ast_argparent34'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl28'(C, D), !.
'bindArgs.ast_argparent34'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl28'(B, C), !.
'bindArgs.ast_argparent34'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl28'(B, C), !.
'bindArgs.ast_argparent34'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl28'(B, C), !.
'bindArgs.ast_argparent34'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl28'(C, D), !.
'bindArgs.ast_argparent34'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl28'(B, C), !.
'bindArgs.ast_argparent34'([A|B], [A|C]) :-
	'bindArgs.ast_argencl28'(B, C).

% 'bindArgs.ast_argencl28'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(block, mult(1, 1, no), id, [blockT]), ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl28'([], []) :- !.
'bindArgs.ast_argencl28'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argblock2'(B, C).
'bindArgs.ast_argencl28'([null|A], [null|B]) :-
	'bindArgs.ast_argblock2'(A, B), !.
'bindArgs.ast_argencl28'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argblock2'(C, D), !.
'bindArgs.ast_argencl28'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_argblock2'(B, C), !.
'bindArgs.ast_argencl28'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argblock2'(B, C), !.
'bindArgs.ast_argencl28'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argblock2'(B, C), !.
'bindArgs.ast_argencl28'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argblock2'(C, D), !.
'bindArgs.ast_argencl28'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argblock2'(B, C), !.
'bindArgs.ast_argencl28'([A|B], [A|C]) :-
	'bindArgs.ast_argblock2'(B, C).

% 'bindArgs.ast_argblock2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(block, mult(1, 1, no), id, [blockT]), ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argblock2'([], []) :- !.
'bindArgs.ast_argblock2'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argcatchers1'(B, C).
'bindArgs.ast_argblock2'([null|A], [null|B]) :-
	'bindArgs.ast_argcatchers1'(A, B), !.
'bindArgs.ast_argblock2'([A|C], [B|D]) :-
	member(typeTermType, [blockT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argcatchers1'(C, D), !.
'bindArgs.ast_argblock2'([A|B], [A|C]) :-
	not(member(classDefT, [blockT])),
	'bindArgs.ast_argcatchers1'(B, C), !.
'bindArgs.ast_argblock2'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argcatchers1'(B, C), !.
'bindArgs.ast_argblock2'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argcatchers1'(B, C), !.
'bindArgs.ast_argblock2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argcatchers1'(C, D), !.
'bindArgs.ast_argblock2'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argcatchers1'(B, C), !.
'bindArgs.ast_argblock2'([A|B], [A|C]) :-
	'bindArgs.ast_argcatchers1'(B, C).

% 'bindArgs.ast_argcatchers1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argcatchers1'([], []) :- !.
'bindArgs.ast_argcatchers1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argfinalize1'(B, C).
'bindArgs.ast_argcatchers1'([A|C], [B|D]) :-
	member(classDefT, [catchT]), !,
	replaceFQNsWithClassIds1(A, B),
	'bindArgs.ast_argfinalize1'(C, D), !.
'bindArgs.ast_argcatchers1'([null|A], [null|B]) :-
	'bindArgs.ast_argfinalize1'(A, B), !.
'bindArgs.ast_argcatchers1'([A|C], [B|D]) :-
	member(typeTermType, [catchT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argfinalize1'(C, D), !.
'bindArgs.ast_argcatchers1'([A|B], [A|C]) :-
	not(member(classDefT, [catchT])),
	'bindArgs.ast_argfinalize1'(B, C), !.
'bindArgs.ast_argcatchers1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argfinalize1'(B, C), !.
'bindArgs.ast_argcatchers1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argfinalize1'(B, C), !.
'bindArgs.ast_argcatchers1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argfinalize1'(C, D), !.
'bindArgs.ast_argcatchers1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argfinalize1'(B, C), !.
'bindArgs.ast_argcatchers1'([A|B], [A|C]) :-
	'bindArgs.ast_argfinalize1'(B, C).

% 'bindArgs.ast_argfinalize1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(finalize, mult(0, 1, no), id, [blockT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argfinalize1'([], []) :- !.
'bindArgs.ast_argfinalize1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argfinalize1'([null], [null]) :- !.
'bindArgs.ast_argfinalize1'([A|C], [B|D]) :-
	member(typeTermType, [blockT]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argfinalize1'([A|B], [A|C]) :-
	not(member(classDefT, [blockT])),
	B=[],
	C=[], !.
'bindArgs.ast_argfinalize1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argfinalize1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argfinalize1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argfinalize1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argfinalize1'([A], [A]).

% 'bindArgs.ast_argid38'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [typeCastT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid38'([], []) :- !.
'bindArgs.ast_argid38'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent35'(B, C).
'bindArgs.ast_argid38'([null|A], [null|B]) :-
	'bindArgs.ast_argparent35'(A, B), !.
'bindArgs.ast_argid38'([A|C], [B|D]) :-
	member(typeTermType, [typeCastT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent35'(C, D), !.
'bindArgs.ast_argid38'([A|B], [A|C]) :-
	not(member(classDefT, [typeCastT])),
	'bindArgs.ast_argparent35'(B, C), !.
'bindArgs.ast_argid38'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent35'(B, C), !.
'bindArgs.ast_argid38'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent35'(B, C), !.
'bindArgs.ast_argid38'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent35'(C, D), !.
'bindArgs.ast_argid38'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent35'(B, C), !.
'bindArgs.ast_argid38'([A|B], [A|C]) :-
	'bindArgs.ast_argparent35'(B, C).

% 'bindArgs.ast_argparent35'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent35'([], []) :- !.
'bindArgs.ast_argparent35'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl29'(B, C).
'bindArgs.ast_argparent35'([null|A], [null|B]) :-
	'bindArgs.ast_argencl29'(A, B), !.
'bindArgs.ast_argparent35'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl29'(C, D), !.
'bindArgs.ast_argparent35'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl29'(B, C), !.
'bindArgs.ast_argparent35'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl29'(B, C), !.
'bindArgs.ast_argparent35'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl29'(B, C), !.
'bindArgs.ast_argparent35'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl29'(C, D), !.
'bindArgs.ast_argparent35'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl29'(B, C), !.
'bindArgs.ast_argparent35'([A|B], [A|C]) :-
	'bindArgs.ast_argencl29'(B, C).

% 'bindArgs.ast_argencl29'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl29'([], []) :- !.
'bindArgs.ast_argencl29'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argtype7'(B, C).
'bindArgs.ast_argencl29'([null|A], [null|B]) :-
	'bindArgs.ast_argtype7'(A, B), !.
'bindArgs.ast_argencl29'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argtype7'(C, D), !.
'bindArgs.ast_argencl29'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT, fieldDefT])),
	'bindArgs.ast_argtype7'(B, C), !.
'bindArgs.ast_argencl29'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argtype7'(B, C), !.
'bindArgs.ast_argencl29'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argtype7'(B, C), !.
'bindArgs.ast_argencl29'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argtype7'(C, D), !.
'bindArgs.ast_argencl29'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argtype7'(B, C), !.
'bindArgs.ast_argencl29'([A|B], [A|C]) :-
	'bindArgs.ast_argtype7'(B, C).

% 'bindArgs.ast_argtype7'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argtype7'([], []) :- !.
'bindArgs.ast_argtype7'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argexpr4'(B, C).
'bindArgs.ast_argtype7'([A|C], [B|D]) :-
	member(typeTermType, [typeTermType]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argexpr4'(C, D), !.
'bindArgs.ast_argtype7'([A|B], [A|C]) :-
	'bindArgs.ast_argexpr4'(B, C), !.
'bindArgs.ast_argtype7'([A|B], [A|C]) :-
	'bindArgs.ast_argexpr4'(B, C).

% 'bindArgs.ast_argid39'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [typeTestT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid39'([], []) :- !.
'bindArgs.ast_argid39'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent36'(B, C).
'bindArgs.ast_argid39'([null|A], [null|B]) :-
	'bindArgs.ast_argparent36'(A, B), !.
'bindArgs.ast_argid39'([A|C], [B|D]) :-
	member(typeTermType, [typeTestT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent36'(C, D), !.
'bindArgs.ast_argid39'([A|B], [A|C]) :-
	not(member(classDefT, [typeTestT])),
	'bindArgs.ast_argparent36'(B, C), !.
'bindArgs.ast_argid39'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent36'(B, C), !.
'bindArgs.ast_argid39'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent36'(B, C), !.
'bindArgs.ast_argid39'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent36'(C, D), !.
'bindArgs.ast_argid39'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent36'(B, C), !.
'bindArgs.ast_argid39'([A|B], [A|C]) :-
	'bindArgs.ast_argparent36'(B, C).

% 'bindArgs.ast_argparent36'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argparent36'([], []) :- !.
'bindArgs.ast_argparent36'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argencl30'(B, C).
'bindArgs.ast_argparent36'([null|A], [null|B]) :-
	'bindArgs.ast_argencl30'(A, B), !.
'bindArgs.ast_argparent36'([A|C], [B|D]) :-
	member(typeTermType, [id]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argencl30'(C, D), !.
'bindArgs.ast_argparent36'([A|B], [A|C]) :-
	not(member(classDefT, [id])),
	'bindArgs.ast_argencl30'(B, C), !.
'bindArgs.ast_argparent36'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argencl30'(B, C), !.
'bindArgs.ast_argparent36'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argencl30'(B, C), !.
'bindArgs.ast_argparent36'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argencl30'(C, D), !.
'bindArgs.ast_argparent36'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argencl30'(B, C), !.
'bindArgs.ast_argparent36'([A|B], [A|C]) :-
	'bindArgs.ast_argencl30'(B, C).

% 'bindArgs.ast_argencl30'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argencl30'([], []) :- !.
'bindArgs.ast_argencl30'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argtype7'(B, C).
'bindArgs.ast_argencl30'([null|A], [null|B]) :-
	'bindArgs.ast_argtype7'(A, B), !.
'bindArgs.ast_argencl30'([A|C], [B|D]) :-
	member(typeTermType, [methodDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argtype7'(C, D), !.
'bindArgs.ast_argencl30'([A|B], [A|C]) :-
	not(member(classDefT, [methodDefT])),
	'bindArgs.ast_argtype7'(B, C), !.
'bindArgs.ast_argencl30'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argtype7'(B, C), !.
'bindArgs.ast_argencl30'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argtype7'(B, C), !.
'bindArgs.ast_argencl30'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argtype7'(C, D), !.
'bindArgs.ast_argencl30'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argtype7'(B, C), !.
'bindArgs.ast_argencl30'([A|B], [A|C]) :-
	'bindArgs.ast_argtype7'(B, C).

% 'bindArgs.ast_argid40'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [whileLoopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid40'([], []) :- !.
'bindArgs.ast_argid40'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argparent13'(B, C).
'bindArgs.ast_argid40'([null|A], [null|B]) :-
	'bindArgs.ast_argparent13'(A, B), !.
'bindArgs.ast_argid40'([A|C], [B|D]) :-
	member(typeTermType, [whileLoopT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argparent13'(C, D), !.
'bindArgs.ast_argid40'([A|B], [A|C]) :-
	not(member(classDefT, [whileLoopT])),
	'bindArgs.ast_argparent13'(B, C), !.
'bindArgs.ast_argid40'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argparent13'(B, C), !.
'bindArgs.ast_argid40'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argparent13'(B, C), !.
'bindArgs.ast_argid40'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argparent13'(C, D), !.
'bindArgs.ast_argid40'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argparent13'(B, C), !.
'bindArgs.ast_argid40'([A|B], [A|C]) :-
	'bindArgs.ast_argparent13'(B, C).

% 'bindArgs.ast_argsub1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(sub, mult(1, 1, no), id, [classDefT]), ast_arg(super, mult(1, 1, no), id, [classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argsub1'([], []) :- !.
'bindArgs.ast_argsub1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argsuper1'(B, C).
'bindArgs.ast_argsub1'([null|A], [null|B]) :-
	'bindArgs.ast_argsuper1'(A, B), !.
'bindArgs.ast_argsub1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argsuper1'(C, D), !.
'bindArgs.ast_argsub1'([A|C], [B|D]) :-
	member(typeTermType, [classDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argsuper1'(C, D), !.
'bindArgs.ast_argsub1'([A|B], [A|C]) :-
	not(member(classDefT, [classDefT])),
	'bindArgs.ast_argsuper1'(B, C), !.
'bindArgs.ast_argsub1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argsuper1'(B, C), !.
'bindArgs.ast_argsub1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argsuper1'(B, C), !.
'bindArgs.ast_argsub1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argsuper1'(C, D), !.
'bindArgs.ast_argsub1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argsuper1'(B, C), !.
'bindArgs.ast_argsub1'([A|B], [A|C]) :-
	'bindArgs.ast_argsuper1'(B, C).

% 'bindArgs.ast_argsuper1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(super, mult(1, 1, no), id, [classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argsuper1'([], []) :- !.
'bindArgs.ast_argsuper1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argsuper1'([null], [null]) :- !.
'bindArgs.ast_argsuper1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argsuper1'([A|C], [B|D]) :-
	member(typeTermType, [classDefT]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argsuper1'([A|B], [A|C]) :-
	not(member(classDefT, [classDefT])),
	B=[],
	C=[], !.
'bindArgs.ast_argsuper1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argsuper1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argsuper1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argsuper1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argsuper1'([A], [A]).

% 'bindArgs.ast_argid41'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [classDefT, methodDefT, fieldDefT]), ast_arg(modifier, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid41'([], []) :- !.
'bindArgs.ast_argid41'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_argmodifier1'(B, C).
'bindArgs.ast_argid41'([null|A], [null|B]) :-
	'bindArgs.ast_argmodifier1'(A, B), !.
'bindArgs.ast_argid41'([A|C], [B|D]) :-
	member(typeTermType, [classDefT, methodDefT, fieldDefT]), !,
	map_type_term1(A, B),
	'bindArgs.ast_argmodifier1'(C, D), !.
'bindArgs.ast_argid41'([A|B], [A|C]) :-
	not(member(classDefT, [classDefT, methodDefT, fieldDefT])),
	'bindArgs.ast_argmodifier1'(B, C), !.
'bindArgs.ast_argid41'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_argmodifier1'(B, C), !.
'bindArgs.ast_argid41'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_argmodifier1'(B, C), !.
'bindArgs.ast_argid41'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_argmodifier1'(C, D), !.
'bindArgs.ast_argid41'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_argmodifier1'(B, C), !.
'bindArgs.ast_argid41'([A|B], [A|C]) :-
	'bindArgs.ast_argmodifier1'(B, C).

% 'bindArgs.ast_argmodifier1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(modifier, mult(1, 1, no), attr, [atom])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argmodifier1'([], []) :- !.
'bindArgs.ast_argmodifier1'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argmodifier1'([A|C], [B|D]) :-
	member(typeTermType, [atom]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argmodifier1'([A], [A]) :- !.
'bindArgs.ast_argmodifier1'([A], [A]).

% 'bindArgs.ast_argid42'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg(id, mult(1, 1, no), id, [classDefT])], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_argid42'([], []) :- !.
'bindArgs.ast_argid42'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_argid42'([null], [null]) :- !.
'bindArgs.ast_argid42'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argid42'([A|C], [B|D]) :-
	member(typeTermType, [classDefT]), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argid42'([A|B], [A|C]) :-
	not(member(classDefT, [classDefT])),
	B=[],
	C=[], !.
'bindArgs.ast_argid42'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argid42'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_argid42'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_argid42'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_argid42'([A], [A]).

% 'bindArgs.ast_arg1'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg('$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)), ast_arg('$VAR'(6), '$VAR'(7), '$VAR'(8), '$VAR'(9)), ast_arg('$VAR'(10), '$VAR'(11), '$VAR'(12), '$VAR'(13)), ast_arg('$VAR'(14), '$VAR'(15), '$VAR'(16), '$VAR'(17))], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_arg1'([], []) :- !.
'bindArgs.ast_arg1'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_arg2'(B, C).
'bindArgs.ast_arg1'([A|C], [B|D]) :-
	member(classDefT, _), !,
	replaceFQNsWithClassIds1(A, B),
	'bindArgs.ast_arg2'(C, D), !.
'bindArgs.ast_arg1'([null|A], [null|B]) :-
	'bindArgs.ast_arg2'(A, B), !.
'bindArgs.ast_arg1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arg2'(C, D), !.
'bindArgs.ast_arg1'([A|C], [B|D]) :-
	member(typeTermType, _), !,
	map_type_term1(A, B),
	'bindArgs.ast_arg2'(C, D), !.
'bindArgs.ast_arg1'([A|B], [A|C]) :-
	'bindArgs.ast_arg2'(B, C), !.
'bindArgs.ast_arg1'([A|B], [A|C]) :-
	not(member(classDefT, _)),
	'bindArgs.ast_arg2'(B, C), !.
'bindArgs.ast_arg1'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_arg2'(B, C), !.
'bindArgs.ast_arg1'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_arg2'(B, C), !.
'bindArgs.ast_arg1'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arg2'(C, D), !.
'bindArgs.ast_arg1'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_arg2'(B, C), !.
'bindArgs.ast_arg1'([A|B], [A|C]) :-
	'bindArgs.ast_arg2'(B, C).

% 'bindArgs.ast_arg2'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg('$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)), ast_arg('$VAR'(6), '$VAR'(7), '$VAR'(8), '$VAR'(9)), ast_arg('$VAR'(10), '$VAR'(11), '$VAR'(12), '$VAR'(13))], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_arg2'([], []) :- !.
'bindArgs.ast_arg2'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_arg3'(B, C).
'bindArgs.ast_arg2'([A|C], [B|D]) :-
	member(classDefT, _), !,
	replaceFQNsWithClassIds1(A, B),
	'bindArgs.ast_arg3'(C, D), !.
'bindArgs.ast_arg2'([null|A], [null|B]) :-
	'bindArgs.ast_arg3'(A, B), !.
'bindArgs.ast_arg2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arg3'(C, D), !.
'bindArgs.ast_arg2'([A|C], [B|D]) :-
	member(typeTermType, _), !,
	map_type_term1(A, B),
	'bindArgs.ast_arg3'(C, D), !.
'bindArgs.ast_arg2'([A|B], [A|C]) :-
	'bindArgs.ast_arg3'(B, C), !.
'bindArgs.ast_arg2'([A|B], [A|C]) :-
	not(member(classDefT, _)),
	'bindArgs.ast_arg3'(B, C), !.
'bindArgs.ast_arg2'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_arg3'(B, C), !.
'bindArgs.ast_arg2'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_arg3'(B, C), !.
'bindArgs.ast_arg2'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arg3'(C, D), !.
'bindArgs.ast_arg2'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_arg3'(B, C), !.
'bindArgs.ast_arg2'([A|B], [A|C]) :-
	'bindArgs.ast_arg3'(B, C).

% 'bindArgs.ast_arg3'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg('$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)), ast_arg('$VAR'(6), '$VAR'(7), '$VAR'(8), '$VAR'(9))], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_arg3'([], []) :- !.
'bindArgs.ast_arg3'([A|B], [_|C]) :-
	var(A), !,
	'bindArgs.ast_arg4'(B, C).
'bindArgs.ast_arg3'([A|C], [B|D]) :-
	member(classDefT, _), !,
	replaceFQNsWithClassIds1(A, B),
	'bindArgs.ast_arg4'(C, D), !.
'bindArgs.ast_arg3'([null|A], [null|B]) :-
	'bindArgs.ast_arg4'(A, B), !.
'bindArgs.ast_arg3'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arg4'(C, D), !.
'bindArgs.ast_arg3'([A|C], [B|D]) :-
	member(typeTermType, _), !,
	map_type_term1(A, B),
	'bindArgs.ast_arg4'(C, D), !.
'bindArgs.ast_arg3'([A|B], [A|C]) :-
	'bindArgs.ast_arg4'(B, C), !.
'bindArgs.ast_arg3'([A|B], [A|C]) :-
	not(member(classDefT, _)),
	'bindArgs.ast_arg4'(B, C), !.
'bindArgs.ast_arg3'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	'bindArgs.ast_arg4'(B, C), !.
'bindArgs.ast_arg3'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	'bindArgs.ast_arg4'(B, C), !.
'bindArgs.ast_arg3'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	'bindArgs.ast_arg4'(C, D), !.
'bindArgs.ast_arg3'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	'bindArgs.ast_arg4'(B, C), !.
'bindArgs.ast_arg3'([A|B], [A|C]) :-
	'bindArgs.ast_arg4'(B, C).

% 'bindArgs.ast_arg4'('$VAR'(0), '$VAR'(1)):-bindArgs([ast_arg('$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5))], '$VAR'(0), '$VAR'(1))
'bindArgs.ast_arg4'([], []) :- !.
'bindArgs.ast_arg4'([A|B], [_|C]) :-
	var(A), !,
	B=[],
	C=[].
'bindArgs.ast_arg4'([A|C], [B|D]) :-
	member(classDefT, _), !,
	replaceFQNsWithClassIds1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_arg4'([null], [null]) :- !.
'bindArgs.ast_arg4'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_arg4'([A|C], [B|D]) :-
	member(typeTermType, _), !,
	map_type_term1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_arg4'([A], [A]) :- !.
'bindArgs.ast_arg4'([A|B], [A|C]) :-
	not(member(classDefT, _)),
	B=[],
	C=[], !.
'bindArgs.ast_arg4'([A|B], [A|C]) :-
	methodDefT(A, _, _, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_arg4'([A|B], [A|C]) :-
	fieldDefT(A, _, _, _, _),
	B=[],
	C=[], !.
'bindArgs.ast_arg4'([A|C], [B|D]) :-
	fullQualifiedName1(A, B),
	C=[],
	D=[], !.
'bindArgs.ast_arg4'([_|B], [A|C]) :-
	'\\+number1'(A),
	A\=null,
	format('~nwarning: (bindArgs) probably not an ID: ~w~n', [A]),
	B=[],
	C=[], !.
'bindArgs.ast_arg4'([A], [A]).
%Warning: Unbound variable found as a goal.
%         Potentially all original code is needed.

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_term('Java', '$VAR'(1), '$VAR'(0))
get_ast_node_termJava1(B, A) :-
	packageT(A, C), !,
	B=packageT(A, C).
get_ast_node_termJava1(B, A) :-
	classDefT(A, C, D, E), !,
	B=classDefT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	methodDefT(A, C, D, E, F, G, H), !,
	B=methodDefT(A, C, D, E, F, G, H).
get_ast_node_termJava1(B, A) :-
	fieldDefT(A, C, D, E, F), !,
	B=fieldDefT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	paramDefT(A, C, D, E), !,
	B=paramDefT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	applyT(A, C, D, E, F, G, H), !,
	B=applyT(A, C, D, E, F, G, H).
get_ast_node_termJava1(B, A) :-
	assertT(A, C, D, E, F), !,
	B=assertT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	assignT(A, C, D, E, F), !,
	B=assignT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	assignopT(A, C, D, E, F, G), !,
	B=assignopT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	blockT(A, C, D, E), !,
	B=blockT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	breakT(A, C, D, E, F), !,
	B=breakT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	caseT(A, C, D, E), !,
	B=caseT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	conditionalT(A, C, D, E, F, G), !,
	B=conditionalT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	continueT(A, C, D, E, F), !,
	B=continueT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	doLoopT(A, C, D, E, F), !,
	B=doLoopT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	execT(A, C, D, E), !,
	B=execT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	catchT(A, C, D, E, F), !,
	B=catchT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	forLoopT(A, C, D, E, F, G, H), !,
	B=forLoopT(A, C, D, E, F, G, H).
get_ast_node_termJava1(B, A) :-
	getFieldT(A, C, D, E, F, G), !,
	B=getFieldT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	ifT(A, C, D, E, F, G), !,
	B=ifT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	importT(A, C, D), !,
	B=importT(A, C, D).
get_ast_node_termJava1(B, A) :-
	indexedT(A, C, D, E, F), !,
	B=indexedT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	labelT(A, C, D, E, F), !,
	B=labelT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	literalT(A, C, D, E, F), !,
	B=literalT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	localDefT(A, C, D, E, F, G), !,
	B=localDefT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	newArrayT(A, C, D, E, F, G), !,
	B=newArrayT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	newClassT(A, C, D, E, F, G, H, I), !,
	B=newClassT(A, C, D, E, F, G, H, I).
get_ast_node_termJava1(B, A) :-
	nopT(A, C, D), !,
	B=nopT(A, C, D).
get_ast_node_termJava1(B, A) :-
	operationT(A, C, D, E, F, G), !,
	B=operationT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	precedenceT(A, C, D, E), !,
	B=precedenceT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	returnT(A, C, D, E), !,
	B=returnT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	selectT(A, C, D, E, F, G), !,
	B=selectT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	identT(A, C, D, E, F), !,
	B=identT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	switchT(A, C, D, E, F), !,
	B=switchT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	synchronizedT(A, C, D, E, F), !,
	B=synchronizedT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	throwT(A, C, D, E), !,
	B=throwT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	toplevelT(A, C, D, E), !,
	B=toplevelT(A, C, D, E).
get_ast_node_termJava1(B, A) :-
	tryT(A, C, D, E, F, G), !,
	B=tryT(A, C, D, E, F, G).
get_ast_node_termJava1(B, A) :-
	typeCastT(A, C, D, E, F), !,
	B=typeCastT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	typeTestT(A, C, D, E, F), !,
	B=typeTestT(A, C, D, E, F).
get_ast_node_termJava1(B, A) :-
	whileLoopT(A, C, D, E, F), !,
	B=whileLoopT(A, C, D, E, F).

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', classDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava1(A, B, C, D) :-
	get_ast_node_termJava1(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava1(_, _, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), classDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava1(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(B, D, F, H, A) :-
	classDefT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava1(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-markEnclAsDirty('Java', methodDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
markEnclAsDirtyJava1(A, B, C, D, E, F, G) :-
	get_ast_node_termJava1(A, B, C, D, E, F, G, H),
	'\\+checkIfTopLevelJava1'(H),
	(   get_ast_node_enclosingJava1(H, I),
	    '\\+=1'(I),
	    '\\+checkIfTopLevelJava1'(I),
	    assert1T(dirty_tree('Java', I)), !
	;   assert1T(dirty_tree('Java', H)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-get_ast_node_term('Java', '$VAR'(7), methodDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(B, D, F, H, J, L, N, A) :-
	methodDefT(A, C, E, G, I, K, M), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L,
	M=N.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', fieldDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava1(A, B, C, D, E) :-
	get_ast_node_termJava1(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), fieldDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava1(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(B, D, F, H, J, A) :-
	fieldDefT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', paramDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava2(A, B, C, D) :-
	get_ast_node_termJava2(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava2(_, _, _, _).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), paramDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava2(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(B, D, F, H, A) :-
	paramDefT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava2(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-markEnclAsDirty('Java', applyT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
markEnclAsDirtyJava2(A, B, C, D, E, F, G) :-
	get_ast_node_termJava2(A, B, C, D, E, F, G, H),
	'\\+checkIfTopLevelJava1'(H),
	(   get_ast_node_enclosingJava1(H, I),
	    '\\+=1'(I),
	    '\\+checkIfTopLevelJava1'(I),
	    assert1T(dirty_tree('Java', I)), !
	;   assert1T(dirty_tree('Java', H)), !
	).
markEnclAsDirtyJava2(_, _, _, _, _, _, _).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-get_ast_node_term('Java', '$VAR'(7), applyT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(B, D, F, H, J, L, N, A) :-
	applyT(A, C, E, G, I, K, M), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L,
	M=N.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', assertT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava2(A, B, C, D, E) :-
	get_ast_node_termJava2(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava2(_, _, _, _, _).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), assertT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava2(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(B, D, F, H, J, A) :-
	assertT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', assignT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava3(A, B, C, D, E) :-
	get_ast_node_termJava3(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava3(_, _, _, _, _).

% get_ast_node_termJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), assignT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava3(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(B, D, F, H, J, A) :-
	assignT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', assignopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava1(A, B, C, D, E, F) :-
	get_ast_node_termJava1(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), assignopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(B, D, F, H, J, L, A) :-
	assignopT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', blockT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava3(A, B, C, D) :-
	get_ast_node_termJava3(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava3(_, _, _, _).

% get_ast_node_termJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), blockT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava3(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(B, D, F, H, A) :-
	blockT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava3(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', breakT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava4(A, B, C, D, E) :-
	get_ast_node_termJava4(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava4(_, _, _, _, _).

% get_ast_node_termJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), breakT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava4(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(B, D, F, H, J, A) :-
	breakT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', caseT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava4(A, B, C, D) :-
	get_ast_node_termJava4(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava4(_, _, _, _).

% get_ast_node_termJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), caseT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava4(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(B, D, F, H, A) :-
	caseT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava4(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', conditionalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava2(A, B, C, D, E, F) :-
	get_ast_node_termJava2(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava2(_, _, _, _, _, _).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), conditionalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(B, D, F, H, J, L, A) :-
	conditionalT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', continueT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava5(A, B, C, D, E) :-
	get_ast_node_termJava5(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava5(_, _, _, _, _).

% get_ast_node_termJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), continueT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava5(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(B, D, F, H, J, A) :-
	continueT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', doLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava6(A, B, C, D, E) :-
	get_ast_node_termJava6(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava6(_, _, _, _, _).

% get_ast_node_termJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), doLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava6(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(B, D, F, H, J, A) :-
	doLoopT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', execT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava5(A, B, C, D) :-
	get_ast_node_termJava5(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava5(_, _, _, _).

% get_ast_node_termJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), execT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava5(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(B, D, F, H, A) :-
	execT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava5(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', catchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava7(A, B, C, D, E) :-
	get_ast_node_termJava7(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava7(_, _, _, _, _).

% get_ast_node_termJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), catchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava7(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(B, D, F, H, J, A) :-
	catchT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-markEnclAsDirty('Java', forLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
markEnclAsDirtyJava3(A, B, C, D, E, F, G) :-
	get_ast_node_termJava3(A, B, C, D, E, F, G, H),
	'\\+checkIfTopLevelJava1'(H),
	(   get_ast_node_enclosingJava1(H, I),
	    '\\+=1'(I),
	    '\\+checkIfTopLevelJava1'(I),
	    assert1T(dirty_tree('Java', I)), !
	;   assert1T(dirty_tree('Java', H)), !
	).
markEnclAsDirtyJava3(_, _, _, _, _, _, _).

% get_ast_node_termJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-get_ast_node_term('Java', '$VAR'(7), forLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(B, D, F, H, J, L, N, A) :-
	forLoopT(A, C, E, G, I, K, M), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L,
	M=N.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', getFieldT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava3(A, B, C, D, E, F) :-
	get_ast_node_termJava3(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava3(_, _, _, _, _, _).

% get_ast_node_termJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), getFieldT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(B, D, F, H, J, L, A) :-
	getFieldT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', ifT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava4(A, B, C, D, E, F) :-
	get_ast_node_termJava4(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava4(_, _, _, _, _, _).

% get_ast_node_termJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), ifT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(B, D, F, H, J, L, A) :-
	ifT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-markEnclAsDirty('Java', importT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
markEnclAsDirtyJava1(A, B, C) :-
	get_ast_node_termJava1(A, B, C, D),
	'\\+checkIfTopLevelJava1'(D),
	(   get_ast_node_enclosingJava1(D, E),
	    '\\+=1'(E),
	    '\\+checkIfTopLevelJava1'(E),
	    assert1T(dirty_tree('Java', E)), !
	;   assert1T(dirty_tree('Java', D)), !
	).
markEnclAsDirtyJava1(_, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-get_ast_node_term('Java', '$VAR'(3), importT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
get_ast_node_termJava1(_, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(B, D, F, A) :-
	importT(A, C, E), !,
	A=B,
	C=D,
	E=F.
get_ast_node_termJava1(_, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', indexedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava8(A, B, C, D, E) :-
	get_ast_node_termJava8(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava8(_, _, _, _, _).

% get_ast_node_termJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), indexedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava8(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava8(B, D, F, H, J, A) :-
	indexedT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', labelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava9(A, B, C, D, E) :-
	get_ast_node_termJava9(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava9(_, _, _, _, _).

% get_ast_node_termJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), labelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava9(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(B, D, F, H, J, A) :-
	labelT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava10('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', literalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava10(A, B, C, D, E) :-
	get_ast_node_termJava10(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava10(_, _, _, _, _).

% get_ast_node_termJava10('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), literalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava10(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(B, D, F, H, J, A) :-
	literalT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', localDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava5(A, B, C, D, E, F) :-
	get_ast_node_termJava5(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava5(_, _, _, _, _, _).

% get_ast_node_termJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), localDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(B, D, F, H, J, L, A) :-
	localDefT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', newArrayT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava6(A, B, C, D, E, F) :-
	get_ast_node_termJava6(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava6(_, _, _, _, _, _).

% get_ast_node_termJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), newArrayT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(B, D, F, H, J, L, A) :-
	newArrayT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-markEnclAsDirty('Java', newClassT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)))
markEnclAsDirtyJava1(A, B, C, D, E, F, G, H) :-
	get_ast_node_termJava1(A, B, C, D, E, F, G, H, I),
	'\\+checkIfTopLevelJava1'(I),
	(   get_ast_node_enclosingJava1(I, J),
	    '\\+=1'(J),
	    '\\+checkIfTopLevelJava1'(J),
	    assert1T(dirty_tree('Java', J)), !
	;   assert1T(dirty_tree('Java', I)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _, _, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7), '$VAR'(8)):-get_ast_node_term('Java', '$VAR'(8), newClassT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)))
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(B, D, F, H, J, L, N, P, A) :-
	newClassT(A, C, E, G, I, K, M, O), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L,
	M=N,
	O=P.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2)):-markEnclAsDirty('Java', nopT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
markEnclAsDirtyJava2(A, B, C) :-
	get_ast_node_termJava2(A, B, C, D),
	'\\+checkIfTopLevelJava1'(D),
	(   get_ast_node_enclosingJava1(D, E),
	    '\\+=1'(E),
	    '\\+checkIfTopLevelJava1'(E),
	    assert1T(dirty_tree('Java', E)), !
	;   assert1T(dirty_tree('Java', D)), !
	).
markEnclAsDirtyJava2(_, _, _).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-get_ast_node_term('Java', '$VAR'(3), nopT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
get_ast_node_termJava2(_, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(B, D, F, A) :-
	nopT(A, C, E), !,
	A=B,
	C=D,
	E=F.
get_ast_node_termJava2(_, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', operationT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava7(A, B, C, D, E, F) :-
	get_ast_node_termJava7(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava7(_, _, _, _, _, _).

% get_ast_node_termJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), operationT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava7(B, D, F, H, J, L, A) :-
	operationT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', precedenceT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava6(A, B, C, D) :-
	get_ast_node_termJava6(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava6(_, _, _, _).

% get_ast_node_termJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), precedenceT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava6(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(B, D, F, H, A) :-
	precedenceT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava6(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', returnT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava7(A, B, C, D) :-
	get_ast_node_termJava7(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava7(_, _, _, _).

% get_ast_node_termJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), returnT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava7(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(B, D, F, H, A) :-
	returnT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava7(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', selectT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava8(A, B, C, D, E, F) :-
	get_ast_node_termJava8(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava8(_, _, _, _, _, _).

% get_ast_node_termJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), selectT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(B, D, F, H, J, L, A) :-
	selectT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava11('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', identT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava11(A, B, C, D, E) :-
	get_ast_node_termJava11(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava11(_, _, _, _, _).

% get_ast_node_termJava11('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), identT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava11(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(B, D, F, H, J, A) :-
	identT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava12('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', switchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava12(A, B, C, D, E) :-
	get_ast_node_termJava12(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava12(_, _, _, _, _).

% get_ast_node_termJava12('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), switchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava12(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(B, D, F, H, J, A) :-
	switchT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava13('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', synchronizedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava13(A, B, C, D, E) :-
	get_ast_node_termJava13(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava13(_, _, _, _, _).

% get_ast_node_termJava13('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), synchronizedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava13(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(B, D, F, H, J, A) :-
	synchronizedT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', throwT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava8(A, B, C, D) :-
	get_ast_node_termJava8(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava8(_, _, _, _).

% get_ast_node_termJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), throwT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava8(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(B, D, F, H, A) :-
	throwT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava8(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', toplevelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava9(A, B, C, D) :-
	get_ast_node_termJava9(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava9(_, _, _, _).

% get_ast_node_termJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), toplevelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava9(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(B, D, F, H, A) :-
	toplevelT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava9(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', tryT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava9(A, B, C, D, E, F) :-
	get_ast_node_termJava9(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava9(_, _, _, _, _, _).

% get_ast_node_termJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), tryT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(B, D, F, H, J, L, A) :-
	tryT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava14('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', typeCastT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava14(A, B, C, D, E) :-
	get_ast_node_termJava14(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava14(_, _, _, _, _).

% get_ast_node_termJava14('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), typeCastT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava14(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(B, D, F, H, J, A) :-
	typeCastT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava15('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', typeTestT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava15(A, B, C, D, E) :-
	get_ast_node_termJava15(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava15(_, _, _, _, _).

% get_ast_node_termJava15('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), typeTestT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava15(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(B, D, F, H, J, A) :-
	typeTestT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava16('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', whileLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava16(A, B, C, D, E) :-
	get_ast_node_termJava16(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava16(_, _, _, _, _).

% get_ast_node_termJava16('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), whileLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava16(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(B, D, F, H, J, A) :-
	whileLoopT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
