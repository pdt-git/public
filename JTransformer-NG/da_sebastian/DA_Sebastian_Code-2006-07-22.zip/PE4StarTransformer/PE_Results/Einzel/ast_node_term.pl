ast_node_term('Java', A) :-
	ast_node_termJava1(A).

% ast_node_termJava1('$VAR'(0)):-ast_node_term('Java', '$VAR'(0))
ast_node_termJava1(A) :-
	nonvar(A), !,
	functor(A, B, C),
	(   B=packageT,
	    C=2
	;   B=classDefT,
	    hackTreeSignatureclassDefT1(C)
	;   B=methodDefT,
	    hackTreeSignaturemethodDefT1(C)
	;   B=fieldDefT,
	    hackTreeSignaturefieldDefT1(C)
	;   B=paramDefT,
	    hackTreeSignatureparamDefT1(C)
	;   B=applyT,
	    C=7
	;   B=assertT,
	    C=5
	;   B=assignT,
	    C=5
	;   B=assignopT,
	    C=6
	;   B=blockT,
	    C=4
	;   B=breakT,
	    C=5
	;   B=caseT,
	    C=4
	;   B=conditionalT,
	    C=6
	;   B=continueT,
	    C=5
	;   B=doLoopT,
	    C=5
	;   B=execT,
	    C=4
	;   B=catchT,
	    C=5
	;   B=forLoopT,
	    C=7
	;   B=getFieldT,
	    C=6
	;   B=ifT,
	    C=6
	;   B=importT,
	    C=3
	;   B=indexedT,
	    C=5
	;   B=labelT,
	    C=5
	;   B=literalT,
	    C=5
	;   B=localDefT,
	    C=6
	;   B=newArrayT,
	    C=6
	;   B=newClassT,
	    C=8
	;   B=nopT,
	    C=3
	;   B=operationT,
	    C=6
	;   B=precedenceT,
	    C=4
	;   B=returnT,
	    C=4
	;   B=selectT,
	    C=6
	;   B=identT,
	    C=5
	;   B=switchT,
	    C=5
	;   B=synchronizedT,
	    C=5
	;   B=throwT,
	    C=4
	;   B=toplevelT,
	    C=4
	;   B=tryT,
	    C=6
	;   B=typeCastT,
	    C=5
	;   B=typeTestT,
	    C=5
	;   B=whileLoopT,
	    C=5
	).
ast_node_termJava1(A) :-
	var(A),
	(   A=packageT(_, _)
	;   A=classDefT(_, _, _, _)
	;   A=methodDefT(_, _, _, _, _, _, _)
	;   A=fieldDefT(_, _, _, _, _)
	;   A=paramDefT(_, _, _, _)
	;   A=applyT(_, _, _, _, _, _, _)
	;   A=assertT(_, _, _, _, _)
	;   A=assignT(_, _, _, _, _)
	;   A=assignopT(_, _, _, _, _, _)
	;   A=blockT(_, _, _, _)
	;   A=breakT(_, _, _, _, _)
	;   A=caseT(_, _, _, _)
	;   A=conditionalT(_, _, _, _, _, _)
	;   A=continueT(_, _, _, _, _)
	;   A=doLoopT(_, _, _, _, _)
	;   A=execT(_, _, _, _)
	;   A=catchT(_, _, _, _, _)
	;   A=forLoopT(_, _, _, _, _, _, _)
	;   A=getFieldT(_, _, _, _, _, _)
	;   A=ifT(_, _, _, _, _, _)
	;   A=importT(_, _, _)
	;   A=indexedT(_, _, _, _, _)
	;   A=labelT(_, _, _, _, _)
	;   A=literalT(_, _, _, _, _)
	;   A=localDefT(_, _, _, _, _, _)
	;   A=newArrayT(_, _, _, _, _, _)
	;   A=newClassT(_, _, _, _, _, _, _, _)
	;   A=nopT(_, _, _)
	;   A=operationT(_, _, _, _, _, _)
	;   A=precedenceT(_, _, _, _)
	;   A=returnT(_, _, _, _)
	;   A=selectT(_, _, _, _, _, _)
	;   A=identT(_, _, _, _, _)
	;   A=switchT(_, _, _, _, _)
	;   A=synchronizedT(_, _, _, _, _)
	;   A=throwT(_, _, _, _)
	;   A=toplevelT(_, _, _, _)
	;   A=tryT(_, _, _, _, _, _)
	;   A=typeCastT(_, _, _, _, _)
	;   A=typeTestT(_, _, _, _, _)
	;   A=whileLoopT(_, _, _, _, _)
	).

% hackTreeSignatureclassDefT1('$VAR'(0)):-hackTreeSignature(classDefT, 9, '$VAR'(0))
hackTreeSignatureclassDefT1(4) :- !.
hackTreeSignatureclassDefT1(9).

% hackTreeSignaturemethodDefT1('$VAR'(0)):-hackTreeSignature(methodDefT, 8, '$VAR'(0))
hackTreeSignaturemethodDefT1(7) :- !.
hackTreeSignaturemethodDefT1(8).

% hackTreeSignaturefieldDefT1('$VAR'(0)):-hackTreeSignature(fieldDefT, 6, '$VAR'(0))
hackTreeSignaturefieldDefT1(5) :- !.
hackTreeSignaturefieldDefT1(6).

% hackTreeSignatureparamDefT1('$VAR'(0)):-hackTreeSignature(paramDefT, 5, '$VAR'(0))
hackTreeSignatureparamDefT1(4) :- !.
hackTreeSignatureparamDefT1(5).
