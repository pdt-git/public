deleteSubElements('Java', A, B, C) :-
	deleteSubElementsJava1(A, B, C).

% deleteSubElementsJava1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-deleteSubElements('Java', '$VAR'(0), '$VAR'(1), '$VAR'(2))
deleteSubElementsJava1(B, C, E) :-
	counter(0),
	findall(A, (get_ast_node_parent(A, B), get_ast_node_label(A, C), incCounter(D), D=<E, deepDeleteJava1(A)), _).

% deepDeleteJava1('$VAR'(0)):-deepDelete('Java', '$VAR'(0))
deepDeleteJava1([]).
deepDeleteJava1([A|F]) :-
	sub_trees1(A, B),
	deepDeleteJava1(B),
	deleteTreeJava1(A),
	forall((ast_node_signature('JavaAttributes', C, D), functor(E, C, D), E=..[C, A|_]), removeTagKind(delete, E)),
	deepDeleteJava1(F).
deepDeleteJava1(A) :-
	tree(A, _, _), !,
	deepDeleteJava1([A]).

% sub_trees1('$VAR'(0), '$VAR'(1)):-sub_trees('$VAR'(0), '$VAR'(1))
sub_trees1(A, B) :-
	blockT(A, _, _, B), !.
sub_trees1(A, C) :-
	packageT(A, _), !,
	findall(B, (classDefT(B, A, _, _);toplevelT(B, A, _, _)), C).
sub_trees1(A, [B]) :-
	precedenceT(A, _, _, B), !.
sub_trees1(A, B) :-
	toplevelT(A, _, _, B), !.
sub_trees1(A, B) :-
	classDefT(A, _, _, B), !.
sub_trees1(A, D) :-
	methodDefT(A, _, _, C, _, _, B), !,
	(   B=null,
	    append([], C, D)
	;   append(B, C, D)
	).
sub_trees1(A, C) :-
	fieldDefT(A, _, _, _, B), !,
	(   B=null,
	    C=[]
	;   C=B
	).
sub_trees1(A, []) :-
	paramDefT(A, _, _, _), !.
sub_trees1(A, C) :-
	localDefT(A, _, _, _, _, B), !,
	(   B=null,
	    C=[]
	;   C=B
	).
sub_trees1(A, [B, C]) :-
	doLoopT(A, _, _, B, C), !.
sub_trees1(A, [B, C]) :-
	whileLoopT(A, _, _, B, C), !.
sub_trees1(A, [B|G]) :-
	forLoopT(A, _, _, D, C, E, B), !,
	(   C=null,
	    append(D, E, F),
	    append([], F, G)
	;   append(D, E, H),
	    append(C, H, G)
	).
sub_trees1(A, [B]) :-
	labelT(A, _, _, B, _), !.
sub_trees1(A, [B|C]) :-
	switchT(A, _, _, B, C), !.
sub_trees1(A, C) :-
	caseT(A, _, _, B), !,
	(   B=null,
	    C=[]
	;   C=B
	).
sub_trees1(A, [B, C]) :-
	synchronizedT(A, _, _, B, C), !.
sub_trees1(A, [B|E]) :-
	tryT(A, _, _, B, C, D), !,
	(   C=null,
	    D=null,
	    append([], [], E)
	;   C=null,
	    append([], [D], E)
	;   D=null,
	    append([C], [], E)
	;   append([C], [D], E)
	).
sub_trees1(A, [B, C]) :-
	catchT(A, _, _, B, C), !.
sub_trees1(A, [B, C]) :-
	assertT(A, _, _, B, C), !.
sub_trees1(A, [B|E]) :-
	ifT(A, _, _, B, D, C), !,
	(   C=null,
	    append([D], [], E)
	;   append([D], C, E)
	).
sub_trees1(A, [B, C, D]) :-
	conditionalT(A, _, _, B, C, D), !.
sub_trees1(A, [B]) :-
	execT(A, _, _, B), !.
sub_trees1(A, C) :-
	returnT(A, _, _, B), !,
	(   B=null,
	    C=[]
	;   C=B
	).
sub_trees1(A, []) :-
	breakT(A, _, _, _, _), !.
sub_trees1(A, []) :-
	continueT(A, _, _, _, _), !.
sub_trees1(A, [B]) :-
	throwT(A, _, _, B), !.
sub_trees1(A, D) :-
	applyT(A, _, _, B, _, C, _), !,
	(   B=null,
	    append([], C, D)
	;   append(B, C, D)
	).
sub_trees1(A, [B|G]) :-
	newClassT(A, _, _, _, F, B, D, C), !,
	(   C=null,
	    D=null,
	    append([], [], E),
	    append(E, F, G)
	;   C=null,
	    append([], D, H),
	    append(H, F, G)
	;   D=null,
	    append(C, [], I),
	    append(I, F, G)
	;   append(C, D, J),
	    append(J, F, G)
	).
sub_trees1(A, D) :-
	newArrayT(A, _, _, B, C, _), !,
	(   B=null,
	    C=null,
	    append([], [], D)
	;   B=null,
	    append([], [C], D)
	;   C=null,
	    append([B], [], D)
	;   append([B], [C], D)
	).
sub_trees1(A, [B, C]) :-
	assignT(A, _, _, B, C), !.
sub_trees1(A, [B, C]) :-
	assignopT(A, _, _, B, _, C), !.
sub_trees1(A, B) :-
	operationT(A, _, _, B, _, _), !.
sub_trees1(A, [B]) :-
	typeCastT(A, _, _, _, B), !.
sub_trees1(A, [B]) :-
	typeTestT(A, _, _, _, B), !.
sub_trees1(A, [B, C]) :-
	indexedT(A, _, _, B, C), !.
sub_trees1(A, [B]) :-
	selectT(A, _, _, _, B, _), !.
sub_trees1(A, C) :-
	getFieldT(A, _, _, B, _, _), !,
	(   B==null
	->  C=[]
	;   C=[B]
	).
sub_trees1(A, []) :-
	importT(A, _, _), !.
sub_trees1(A, []) :-
	literalT(A, _, _, _, _), !.
sub_trees1(A, []) :-
	identT(A, _, _, _, _), !.
sub_trees1(A, []) :-
	nopT(A, _, _), !.
sub_trees1(A, []) :-
	tree(A, B, C), !,
	format('ERROR: sub_trees: ~a, ~a, ~a~n', [A, B, C]).
sub_trees1(A, null) :-
	not(tree(A, _, _)), !.

% original definition
:- dynamic blockT/4.

% original definition
:- dynamic packageT/2.
packageT(null, '').

% original definition
:- dynamic classDefT/4.

% original definition
:- dynamic toplevelT/4.

% original definition
:- dynamic precedenceT/4.

% original definition
:- dynamic methodDefT/7.

% original definition
:- dynamic fieldDefT/5.

% original definition
:- dynamic paramDefT/4.

% original definition
:- dynamic localDefT/6.

% original definition
:- dynamic doLoopT/5.

% original definition
:- dynamic whileLoopT/5.

% original definition
:- dynamic forLoopT/7.

% original definition
:- dynamic labelT/5.

% original definition
:- dynamic switchT/5.

% original definition
:- dynamic caseT/4.

% original definition
:- dynamic synchronizedT/5.

% original definition
:- dynamic tryT/6.

% original definition
:- dynamic catchT/5.

% original definition
:- dynamic assertT/5.

% original definition
:- dynamic ifT/6.

% original definition
:- dynamic conditionalT/6.

% original definition
:- dynamic execT/4.

% original definition
:- dynamic returnT/4.

% original definition
:- dynamic breakT/5.

% original definition
:- dynamic continueT/5.

% original definition
:- dynamic throwT/4.

% original definition
:- dynamic applyT/7.

% original definition
:- dynamic newClassT/8.

% original definition
:- dynamic newArrayT/6.

% original definition
:- dynamic assignT/5.

% original definition
:- dynamic assignopT/6.

% original definition
:- dynamic operationT/6.

% original definition
:- dynamic typeCastT/5.

% original definition
:- dynamic typeTestT/5.

% original definition
:- dynamic indexedT/5.

% original definition
:- dynamic selectT/6.

% original definition
:- dynamic getFieldT/6.

% original definition
:- dynamic importT/3.

% original definition
:- dynamic literalT/5.

% original definition
:- dynamic identT/5.

% original definition
:- dynamic nopT/3.

% deleteTreeJava1('$VAR'(0)):-deleteTree('Java', '$VAR'(0))
deleteTreeJava1(A) :-
	packageT(A, B), !,
	retract(packageT(A, B)),
	markEnclAsDirtyJava1(A, B),
	asserta(rollback(assert(packageT(A, B)))).
deleteTreeJava1(A) :-
	classDefT(A, B, C, D), !,
	retract(classDefT(A, B, C, D)),
	markEnclAsDirtyJava1(A, B, C, D),
	asserta(rollback(assert(classDefT(A, B, C, D)))).
deleteTreeJava1(A) :-
	methodDefT(A, B, C, D, E, F, G), !,
	retract(methodDefT(A, B, C, D, E, F, G)),
	markEnclAsDirtyJava1(A, B, C, D, E, F, G),
	asserta(rollback(assert(methodDefT(A, B, C, D, E, F, G)))).
deleteTreeJava1(A) :-
	fieldDefT(A, B, C, D, E), !,
	retract(fieldDefT(A, B, C, D, E)),
	markEnclAsDirtyJava1(A, B, C, D, E),
	asserta(rollback(assert(fieldDefT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	paramDefT(A, B, C, D), !,
	retract(paramDefT(A, B, C, D)),
	markEnclAsDirtyJava2(A, B, C, D),
	asserta(rollback(assert(paramDefT(A, B, C, D)))).
deleteTreeJava1(A) :-
	applyT(A, B, C, D, E, F, G), !,
	retract(applyT(A, B, C, D, E, F, G)),
	markEnclAsDirtyJava2(A, B, C, D, E, F, G),
	asserta(rollback(assert(applyT(A, B, C, D, E, F, G)))).
deleteTreeJava1(A) :-
	assertT(A, B, C, D, E), !,
	retract(assertT(A, B, C, D, E)),
	markEnclAsDirtyJava2(A, B, C, D, E),
	asserta(rollback(assert(assertT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	assignT(A, B, C, D, E), !,
	retract(assignT(A, B, C, D, E)),
	markEnclAsDirtyJava3(A, B, C, D, E),
	asserta(rollback(assert(assignT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	assignopT(A, B, C, D, E, F), !,
	retract(assignopT(A, B, C, D, E, F)),
	markEnclAsDirtyJava1(A, B, C, D, E, F),
	asserta(rollback(assert(assignopT(A, B, C, D, E, F)))).
deleteTreeJava1(A) :-
	blockT(A, B, C, D), !,
	retract(blockT(A, B, C, D)),
	markEnclAsDirtyJava3(A, B, C, D),
	asserta(rollback(assert(blockT(A, B, C, D)))).
deleteTreeJava1(A) :-
	breakT(A, B, C, D, E), !,
	retract(breakT(A, B, C, D, E)),
	markEnclAsDirtyJava4(A, B, C, D, E),
	asserta(rollback(assert(breakT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	caseT(A, B, C, D), !,
	retract(caseT(A, B, C, D)),
	markEnclAsDirtyJava4(A, B, C, D),
	asserta(rollback(assert(caseT(A, B, C, D)))).
deleteTreeJava1(A) :-
	conditionalT(A, B, C, D, E, F), !,
	retract(conditionalT(A, B, C, D, E, F)),
	markEnclAsDirtyJava2(A, B, C, D, E, F),
	asserta(rollback(assert(conditionalT(A, B, C, D, E, F)))).
deleteTreeJava1(A) :-
	continueT(A, B, C, D, E), !,
	retract(continueT(A, B, C, D, E)),
	markEnclAsDirtyJava5(A, B, C, D, E),
	asserta(rollback(assert(continueT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	doLoopT(A, B, C, D, E), !,
	retract(doLoopT(A, B, C, D, E)),
	markEnclAsDirtyJava6(A, B, C, D, E),
	asserta(rollback(assert(doLoopT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	execT(A, B, C, D), !,
	retract(execT(A, B, C, D)),
	markEnclAsDirtyJava5(A, B, C, D),
	asserta(rollback(assert(execT(A, B, C, D)))).
deleteTreeJava1(A) :-
	catchT(A, B, C, D, E), !,
	retract(catchT(A, B, C, D, E)),
	markEnclAsDirtyJava7(A, B, C, D, E),
	asserta(rollback(assert(catchT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	forLoopT(A, B, C, D, E, F, G), !,
	retract(forLoopT(A, B, C, D, E, F, G)),
	markEnclAsDirtyJava3(A, B, C, D, E, F, G),
	asserta(rollback(assert(forLoopT(A, B, C, D, E, F, G)))).
deleteTreeJava1(A) :-
	getFieldT(A, B, C, D, E, F), !,
	retract(getFieldT(A, B, C, D, E, F)),
	markEnclAsDirtyJava3(A, B, C, D, E, F),
	asserta(rollback(assert(getFieldT(A, B, C, D, E, F)))).
deleteTreeJava1(A) :-
	ifT(A, B, C, D, E, F), !,
	retract(ifT(A, B, C, D, E, F)),
	markEnclAsDirtyJava4(A, B, C, D, E, F),
	asserta(rollback(assert(ifT(A, B, C, D, E, F)))).
deleteTreeJava1(A) :-
	importT(A, B, C), !,
	retract(importT(A, B, C)),
	markEnclAsDirtyJava1(A, B, C),
	asserta(rollback(assert(importT(A, B, C)))).
deleteTreeJava1(A) :-
	indexedT(A, B, C, D, E), !,
	retract(indexedT(A, B, C, D, E)),
	markEnclAsDirtyJava8(A, B, C, D, E),
	asserta(rollback(assert(indexedT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	labelT(A, B, C, D, E), !,
	retract(labelT(A, B, C, D, E)),
	markEnclAsDirtyJava9(A, B, C, D, E),
	asserta(rollback(assert(labelT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	literalT(A, B, C, D, E), !,
	retract(literalT(A, B, C, D, E)),
	markEnclAsDirtyJava10(A, B, C, D, E),
	asserta(rollback(assert(literalT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	localDefT(A, B, C, D, E, F), !,
	retract(localDefT(A, B, C, D, E, F)),
	markEnclAsDirtyJava5(A, B, C, D, E, F),
	asserta(rollback(assert(localDefT(A, B, C, D, E, F)))).
deleteTreeJava1(A) :-
	newArrayT(A, B, C, D, E, F), !,
	retract(newArrayT(A, B, C, D, E, F)),
	markEnclAsDirtyJava6(A, B, C, D, E, F),
	asserta(rollback(assert(newArrayT(A, B, C, D, E, F)))).
deleteTreeJava1(A) :-
	newClassT(A, B, C, D, E, F, G, H), !,
	retract(newClassT(A, B, C, D, E, F, G, H)),
	markEnclAsDirtyJava1(A, B, C, D, E, F, G, H),
	asserta(rollback(assert(newClassT(A, B, C, D, E, F, G, H)))).
deleteTreeJava1(A) :-
	nopT(A, B, C), !,
	retract(nopT(A, B, C)),
	markEnclAsDirtyJava2(A, B, C),
	asserta(rollback(assert(nopT(A, B, C)))).
deleteTreeJava1(A) :-
	operationT(A, B, C, D, E, F), !,
	retract(operationT(A, B, C, D, E, F)),
	markEnclAsDirtyJava7(A, B, C, D, E, F),
	asserta(rollback(assert(operationT(A, B, C, D, E, F)))).
deleteTreeJava1(A) :-
	precedenceT(A, B, C, D), !,
	retract(precedenceT(A, B, C, D)),
	markEnclAsDirtyJava6(A, B, C, D),
	asserta(rollback(assert(precedenceT(A, B, C, D)))).
deleteTreeJava1(A) :-
	returnT(A, B, C, D), !,
	retract(returnT(A, B, C, D)),
	markEnclAsDirtyJava7(A, B, C, D),
	asserta(rollback(assert(returnT(A, B, C, D)))).
deleteTreeJava1(A) :-
	selectT(A, B, C, D, E, F), !,
	retract(selectT(A, B, C, D, E, F)),
	markEnclAsDirtyJava8(A, B, C, D, E, F),
	asserta(rollback(assert(selectT(A, B, C, D, E, F)))).
deleteTreeJava1(A) :-
	identT(A, B, C, D, E), !,
	retract(identT(A, B, C, D, E)),
	markEnclAsDirtyJava11(A, B, C, D, E),
	asserta(rollback(assert(identT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	switchT(A, B, C, D, E), !,
	retract(switchT(A, B, C, D, E)),
	markEnclAsDirtyJava12(A, B, C, D, E),
	asserta(rollback(assert(switchT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	synchronizedT(A, B, C, D, E), !,
	retract(synchronizedT(A, B, C, D, E)),
	markEnclAsDirtyJava13(A, B, C, D, E),
	asserta(rollback(assert(synchronizedT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	throwT(A, B, C, D), !,
	retract(throwT(A, B, C, D)),
	markEnclAsDirtyJava8(A, B, C, D),
	asserta(rollback(assert(throwT(A, B, C, D)))).
deleteTreeJava1(A) :-
	toplevelT(A, B, C, D), !,
	retract(toplevelT(A, B, C, D)),
	markEnclAsDirtyJava9(A, B, C, D),
	asserta(rollback(assert(toplevelT(A, B, C, D)))).
deleteTreeJava1(A) :-
	tryT(A, B, C, D, E, F), !,
	retract(tryT(A, B, C, D, E, F)),
	markEnclAsDirtyJava9(A, B, C, D, E, F),
	asserta(rollback(assert(tryT(A, B, C, D, E, F)))).
deleteTreeJava1(A) :-
	typeCastT(A, B, C, D, E), !,
	retract(typeCastT(A, B, C, D, E)),
	markEnclAsDirtyJava14(A, B, C, D, E),
	asserta(rollback(assert(typeCastT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	typeTestT(A, B, C, D, E), !,
	retract(typeTestT(A, B, C, D, E)),
	markEnclAsDirtyJava15(A, B, C, D, E),
	asserta(rollback(assert(typeTestT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	whileLoopT(A, B, C, D, E), !,
	retract(whileLoopT(A, B, C, D, E)),
	markEnclAsDirtyJava16(A, B, C, D, E),
	asserta(rollback(assert(whileLoopT(A, B, C, D, E)))).
deleteTreeJava1(A) :-
	nopT(A, B, C), !,
	retract(nopT(A, B, C)),
	markEnclAsDirtyJava2(A, B, C),
	asserta(rollback(assert(nopT(A, B, C)))).
deleteTreeJava1(A) :-
	not(tree(A, _, _)),
	format('could not retract id: ~a~n', [A]), !.

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1)):-markEnclAsDirty('Java', packageT('$VAR'(0), '$VAR'(1)))
markEnclAsDirtyJava1(A, B) :-
	get_ast_node_termJava1(A, B, C),
	'\\+checkIfTopLevelJava1'(C),
	(   get_ast_node_enclosingJava1(C, D),
	    '\\+=1'(D),
	    '\\+checkIfTopLevelJava1'(D),
	    assert1T(dirty_tree('Java', D)), !
	;   assert1T(dirty_tree('Java', C)), !
	).
markEnclAsDirtyJava1(_, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-get_ast_node_term('Java', '$VAR'(2), packageT('$VAR'(0), '$VAR'(1)))
get_ast_node_termJava1(B, D, A) :-
	packageT(A, C), !,
	A=B,
	C=D.
get_ast_node_termJava1(_, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% '\\+checkIfTopLevelJava1'('$VAR'(0)):- \+checkIfTopLevel('Java', '$VAR'(0))
'\\+checkIfTopLevelJava1'(A) :-
	checkIfTopLevelJava1(A), !,
	fail.
'\\+checkIfTopLevelJava1'(_).

% checkIfTopLevelJava1('$VAR'(0)):-checkIfTopLevel('Java', '$VAR'(0))
checkIfTopLevelJava1(A) :-
	classDefT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	paramDefT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assertT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assignT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	blockT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	breakT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	caseT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	continueT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	execT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	catchT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	importT(A, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	indexedT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	labelT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	literalT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	nopT(A, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	precedenceT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	returnT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	identT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	switchT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	throwT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	toplevelT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	packageT(A, _), !,
	fail.
checkIfTopLevelJava1(_).

% get_ast_node_enclosingJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_enclosing('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_enclosingJava1(A, B) :-
	applyT(A, _, B, _, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	assertT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	assignT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	assignopT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	blockT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	breakT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	caseT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	conditionalT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	continueT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	doLoopT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	execT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	catchT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	forLoopT(A, _, B, _, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	getFieldT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	ifT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	indexedT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	labelT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	literalT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	localDefT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	newArrayT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	newClassT(A, _, B, _, _, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	nopT(A, _, B).
get_ast_node_enclosingJava1(A, B) :-
	operationT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	precedenceT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	returnT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	selectT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	identT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	switchT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	synchronizedT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	throwT(A, _, B, _).
get_ast_node_enclosingJava1(A, B) :-
	tryT(A, _, B, _, _, _).
get_ast_node_enclosingJava1(A, B) :-
	typeCastT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	typeTestT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, B) :-
	whileLoopT(A, _, B, _, _).
get_ast_node_enclosingJava1(A, A) :-
	packageT(A, _), !.
get_ast_node_enclosingJava1(A, B) :-
	classDefT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	paramDefT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	fieldDefT(A, B, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	methodDefT(A, B, _, _, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	toplevelT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	importT(A, _, B), !.

% '\\+=1'('$VAR'(0)):- \+'$VAR'(0)=null
'\\+=1'(null) :- !,
	fail.
'\\+=1'(_).

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', classDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava1(A, B, C, D) :-
	get_ast_node_termJava1(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava1(_, _, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), classDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava1(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(B, D, F, H, A) :-
	classDefT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava1(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-markEnclAsDirty('Java', methodDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
markEnclAsDirtyJava1(A, B, C, D, E, F, G) :-
	get_ast_node_termJava1(A, B, C, D, E, F, G, H),
	'\\+checkIfTopLevelJava1'(H),
	(   get_ast_node_enclosingJava1(H, I),
	    '\\+=1'(I),
	    '\\+checkIfTopLevelJava1'(I),
	    assert1T(dirty_tree('Java', I)), !
	;   assert1T(dirty_tree('Java', H)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-get_ast_node_term('Java', '$VAR'(7), methodDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(B, D, F, H, J, L, N, A) :-
	methodDefT(A, C, E, G, I, K, M), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L,
	M=N.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', fieldDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava1(A, B, C, D, E) :-
	get_ast_node_termJava1(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), fieldDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava1(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(B, D, F, H, J, A) :-
	fieldDefT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', paramDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava2(A, B, C, D) :-
	get_ast_node_termJava2(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava2(_, _, _, _).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), paramDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava2(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(B, D, F, H, A) :-
	paramDefT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava2(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-markEnclAsDirty('Java', applyT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
markEnclAsDirtyJava2(A, B, C, D, E, F, G) :-
	get_ast_node_termJava2(A, B, C, D, E, F, G, H),
	'\\+checkIfTopLevelJava1'(H),
	(   get_ast_node_enclosingJava1(H, I),
	    '\\+=1'(I),
	    '\\+checkIfTopLevelJava1'(I),
	    assert1T(dirty_tree('Java', I)), !
	;   assert1T(dirty_tree('Java', H)), !
	).
markEnclAsDirtyJava2(_, _, _, _, _, _, _).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-get_ast_node_term('Java', '$VAR'(7), applyT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(B, D, F, H, J, L, N, A) :-
	applyT(A, C, E, G, I, K, M), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L,
	M=N.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', assertT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava2(A, B, C, D, E) :-
	get_ast_node_termJava2(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava2(_, _, _, _, _).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), assertT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava2(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(B, D, F, H, J, A) :-
	assertT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', assignT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava3(A, B, C, D, E) :-
	get_ast_node_termJava3(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava3(_, _, _, _, _).

% get_ast_node_termJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), assignT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava3(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(B, D, F, H, J, A) :-
	assignT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', assignopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava1(A, B, C, D, E, F) :-
	get_ast_node_termJava1(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), assignopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(B, D, F, H, J, L, A) :-
	assignopT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', blockT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava3(A, B, C, D) :-
	get_ast_node_termJava3(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava3(_, _, _, _).

% get_ast_node_termJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), blockT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava3(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(B, D, F, H, A) :-
	blockT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava3(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', breakT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava4(A, B, C, D, E) :-
	get_ast_node_termJava4(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava4(_, _, _, _, _).

% get_ast_node_termJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), breakT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava4(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(B, D, F, H, J, A) :-
	breakT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', caseT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava4(A, B, C, D) :-
	get_ast_node_termJava4(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava4(_, _, _, _).

% get_ast_node_termJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), caseT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava4(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(B, D, F, H, A) :-
	caseT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava4(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', conditionalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava2(A, B, C, D, E, F) :-
	get_ast_node_termJava2(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava2(_, _, _, _, _, _).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), conditionalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(B, D, F, H, J, L, A) :-
	conditionalT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', continueT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava5(A, B, C, D, E) :-
	get_ast_node_termJava5(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava5(_, _, _, _, _).

% get_ast_node_termJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), continueT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava5(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(B, D, F, H, J, A) :-
	continueT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', doLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava6(A, B, C, D, E) :-
	get_ast_node_termJava6(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava6(_, _, _, _, _).

% get_ast_node_termJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), doLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava6(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(B, D, F, H, J, A) :-
	doLoopT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', execT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava5(A, B, C, D) :-
	get_ast_node_termJava5(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava5(_, _, _, _).

% get_ast_node_termJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), execT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava5(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(B, D, F, H, A) :-
	execT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava5(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', catchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava7(A, B, C, D, E) :-
	get_ast_node_termJava7(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava7(_, _, _, _, _).

% get_ast_node_termJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), catchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava7(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(B, D, F, H, J, A) :-
	catchT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-markEnclAsDirty('Java', forLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
markEnclAsDirtyJava3(A, B, C, D, E, F, G) :-
	get_ast_node_termJava3(A, B, C, D, E, F, G, H),
	'\\+checkIfTopLevelJava1'(H),
	(   get_ast_node_enclosingJava1(H, I),
	    '\\+=1'(I),
	    '\\+checkIfTopLevelJava1'(I),
	    assert1T(dirty_tree('Java', I)), !
	;   assert1T(dirty_tree('Java', H)), !
	).
markEnclAsDirtyJava3(_, _, _, _, _, _, _).

% get_ast_node_termJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-get_ast_node_term('Java', '$VAR'(7), forLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(B, D, F, H, J, L, N, A) :-
	forLoopT(A, C, E, G, I, K, M), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L,
	M=N.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', getFieldT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava3(A, B, C, D, E, F) :-
	get_ast_node_termJava3(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava3(_, _, _, _, _, _).

% get_ast_node_termJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), getFieldT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(B, D, F, H, J, L, A) :-
	getFieldT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava3(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', ifT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava4(A, B, C, D, E, F) :-
	get_ast_node_termJava4(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava4(_, _, _, _, _, _).

% get_ast_node_termJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), ifT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(B, D, F, H, J, L, A) :-
	ifT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava4(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-markEnclAsDirty('Java', importT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
markEnclAsDirtyJava1(A, B, C) :-
	get_ast_node_termJava1(A, B, C, D),
	'\\+checkIfTopLevelJava1'(D),
	(   get_ast_node_enclosingJava1(D, E),
	    '\\+=1'(E),
	    '\\+checkIfTopLevelJava1'(E),
	    assert1T(dirty_tree('Java', E)), !
	;   assert1T(dirty_tree('Java', D)), !
	).
markEnclAsDirtyJava1(_, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-get_ast_node_term('Java', '$VAR'(3), importT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
get_ast_node_termJava1(_, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(B, D, F, A) :-
	importT(A, C, E), !,
	A=B,
	C=D,
	E=F.
get_ast_node_termJava1(_, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', indexedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava8(A, B, C, D, E) :-
	get_ast_node_termJava8(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava8(_, _, _, _, _).

% get_ast_node_termJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), indexedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava8(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava8(B, D, F, H, J, A) :-
	indexedT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', labelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava9(A, B, C, D, E) :-
	get_ast_node_termJava9(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava9(_, _, _, _, _).

% get_ast_node_termJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), labelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava9(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(B, D, F, H, J, A) :-
	labelT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava10('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', literalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava10(A, B, C, D, E) :-
	get_ast_node_termJava10(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava10(_, _, _, _, _).

% get_ast_node_termJava10('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), literalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava10(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(B, D, F, H, J, A) :-
	literalT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava10(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', localDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava5(A, B, C, D, E, F) :-
	get_ast_node_termJava5(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava5(_, _, _, _, _, _).

% get_ast_node_termJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), localDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(B, D, F, H, J, L, A) :-
	localDefT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava5(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', newArrayT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava6(A, B, C, D, E, F) :-
	get_ast_node_termJava6(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava6(_, _, _, _, _, _).

% get_ast_node_termJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), newArrayT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(B, D, F, H, J, L, A) :-
	newArrayT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-markEnclAsDirty('Java', newClassT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)))
markEnclAsDirtyJava1(A, B, C, D, E, F, G, H) :-
	get_ast_node_termJava1(A, B, C, D, E, F, G, H, I),
	'\\+checkIfTopLevelJava1'(I),
	(   get_ast_node_enclosingJava1(I, J),
	    '\\+=1'(J),
	    '\\+checkIfTopLevelJava1'(J),
	    assert1T(dirty_tree('Java', J)), !
	;   assert1T(dirty_tree('Java', I)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _, _, _, _).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7), '$VAR'(8)):-get_ast_node_term('Java', '$VAR'(8), newClassT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)))
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(B, D, F, H, J, L, N, P, A) :-
	newClassT(A, C, E, G, I, K, M, O), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L,
	M=N,
	O=P.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava1(_, _, _, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2)):-markEnclAsDirty('Java', nopT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
markEnclAsDirtyJava2(A, B, C) :-
	get_ast_node_termJava2(A, B, C, D),
	'\\+checkIfTopLevelJava1'(D),
	(   get_ast_node_enclosingJava1(D, E),
	    '\\+=1'(E),
	    '\\+checkIfTopLevelJava1'(E),
	    assert1T(dirty_tree('Java', E)), !
	;   assert1T(dirty_tree('Java', D)), !
	).
markEnclAsDirtyJava2(_, _, _).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-get_ast_node_term('Java', '$VAR'(3), nopT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
get_ast_node_termJava2(_, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(B, D, F, A) :-
	nopT(A, C, E), !,
	A=B,
	C=D,
	E=F.
get_ast_node_termJava2(_, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava2(_, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', operationT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava7(A, B, C, D, E, F) :-
	get_ast_node_termJava7(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava7(_, _, _, _, _, _).

% get_ast_node_termJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), operationT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava7(B, D, F, H, J, L, A) :-
	operationT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', precedenceT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava6(A, B, C, D) :-
	get_ast_node_termJava6(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava6(_, _, _, _).

% get_ast_node_termJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), precedenceT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava6(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(B, D, F, H, A) :-
	precedenceT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava6(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava6(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', returnT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava7(A, B, C, D) :-
	get_ast_node_termJava7(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava7(_, _, _, _).

% get_ast_node_termJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), returnT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava7(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(B, D, F, H, A) :-
	returnT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava7(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava7(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', selectT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava8(A, B, C, D, E, F) :-
	get_ast_node_termJava8(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava8(_, _, _, _, _, _).

% get_ast_node_termJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), selectT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(B, D, F, H, J, L, A) :-
	selectT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava11('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', identT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava11(A, B, C, D, E) :-
	get_ast_node_termJava11(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava11(_, _, _, _, _).

% get_ast_node_termJava11('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), identT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava11(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(B, D, F, H, J, A) :-
	identT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava11(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava12('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', switchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava12(A, B, C, D, E) :-
	get_ast_node_termJava12(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava12(_, _, _, _, _).

% get_ast_node_termJava12('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), switchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava12(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(B, D, F, H, J, A) :-
	switchT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava12(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava13('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', synchronizedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava13(A, B, C, D, E) :-
	get_ast_node_termJava13(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava13(_, _, _, _, _).

% get_ast_node_termJava13('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), synchronizedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava13(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(B, D, F, H, J, A) :-
	synchronizedT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava13(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', throwT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava8(A, B, C, D) :-
	get_ast_node_termJava8(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava8(_, _, _, _).

% get_ast_node_termJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), throwT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava8(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(B, D, F, H, A) :-
	throwT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava8(_, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava8(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', toplevelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava9(A, B, C, D) :-
	get_ast_node_termJava9(A, B, C, D, E),
	'\\+checkIfTopLevelJava1'(E),
	(   get_ast_node_enclosingJava1(E, F),
	    '\\+=1'(F),
	    '\\+checkIfTopLevelJava1'(F),
	    assert1T(dirty_tree('Java', F)), !
	;   assert1T(dirty_tree('Java', E)), !
	).
markEnclAsDirtyJava9(_, _, _, _).

% get_ast_node_termJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-get_ast_node_term('Java', '$VAR'(4), toplevelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
get_ast_node_termJava9(_, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(B, D, F, H, A) :-
	toplevelT(A, C, E, G), !,
	A=B,
	C=D,
	E=F,
	G=H.
get_ast_node_termJava9(_, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', tryT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava9(A, B, C, D, E, F) :-
	get_ast_node_termJava9(A, B, C, D, E, F, G),
	'\\+checkIfTopLevelJava1'(G),
	(   get_ast_node_enclosingJava1(G, H),
	    '\\+=1'(H),
	    '\\+checkIfTopLevelJava1'(H),
	    assert1T(dirty_tree('Java', H)), !
	;   assert1T(dirty_tree('Java', G)), !
	).
markEnclAsDirtyJava9(_, _, _, _, _, _).

% get_ast_node_termJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-get_ast_node_term('Java', '$VAR'(6), tryT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava9(B, D, F, H, J, L, A) :-
	tryT(A, C, E, G, I, K), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J,
	K=L.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava9(_, _, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava14('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', typeCastT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava14(A, B, C, D, E) :-
	get_ast_node_termJava14(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava14(_, _, _, _, _).

% get_ast_node_termJava14('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), typeCastT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava14(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava14(B, D, F, H, J, A) :-
	typeCastT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava14(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava15('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', typeTestT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava15(A, B, C, D, E) :-
	get_ast_node_termJava15(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava15(_, _, _, _, _).

% get_ast_node_termJava15('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), typeTestT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava15(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava15(B, D, F, H, J, A) :-
	typeTestT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
get_ast_node_termJava15(_, _, _, _, _, A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.

% markEnclAsDirtyJava16('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', whileLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava16(A, B, C, D, E) :-
	get_ast_node_termJava16(A, B, C, D, E, F),
	'\\+checkIfTopLevelJava1'(F),
	(   get_ast_node_enclosingJava1(F, G),
	    '\\+=1'(G),
	    '\\+checkIfTopLevelJava1'(G),
	    assert1T(dirty_tree('Java', G)), !
	;   assert1T(dirty_tree('Java', F)), !
	).
markEnclAsDirtyJava16(_, _, _, _, _).

% get_ast_node_termJava16('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-get_ast_node_term('Java', '$VAR'(5), whileLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
get_ast_node_termJava16(_, _, _, _, _, A) :-
	packageT(A, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	classDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	paramDefT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	assertT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	assignT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	blockT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	breakT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	caseT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	continueT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	execT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	catchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	importT(A, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	indexedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	labelT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	literalT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	nopT(A, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	precedenceT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	returnT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	identT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	switchT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	throwT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	toplevelT(A, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(_, _, _, _, _, A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
get_ast_node_termJava16(B, D, F, H, J, A) :-
	whileLoopT(A, C, E, G, I), !,
	A=B,
	C=D,
	E=F,
	G=H,
	I=J.
