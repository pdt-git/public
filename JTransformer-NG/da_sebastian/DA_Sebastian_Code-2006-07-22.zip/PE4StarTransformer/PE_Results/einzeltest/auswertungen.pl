ast_node_signature('Java', A, B) :-
	ast_node_signatureJava1(A, B).

% ast_node_signatureJava1('$VAR'(0), '$VAR'(1)):-ast_node_signature('Java', '$VAR'(0), '$VAR'(1))
ast_node_signatureJava1(packageT, 2).
ast_node_signatureJava1(classDefT, A) :-
	hackTreeSignatureclassDefT1(A).
ast_node_signatureJava1(methodDefT, A) :-
	hackTreeSignaturemethodDefT1(A).
ast_node_signatureJava1(fieldDefT, A) :-
	hackTreeSignaturefieldDefT1(A).
ast_node_signatureJava1(paramDefT, A) :-
	hackTreeSignatureparamDefT1(A).
ast_node_signatureJava1(applyT, 7).
ast_node_signatureJava1(assertT, 5).
ast_node_signatureJava1(assignT, 5).
ast_node_signatureJava1(assignopT, 6).
ast_node_signatureJava1(blockT, 4).
ast_node_signatureJava1(breakT, 5).
ast_node_signatureJava1(caseT, 4).
ast_node_signatureJava1(conditionalT, 6).
ast_node_signatureJava1(continueT, 5).
ast_node_signatureJava1(doLoopT, 5).
ast_node_signatureJava1(execT, 4).
ast_node_signatureJava1(catchT, 5).
ast_node_signatureJava1(forLoopT, 7).
ast_node_signatureJava1(getFieldT, 6).
ast_node_signatureJava1(ifT, 6).
ast_node_signatureJava1(importT, 3).
ast_node_signatureJava1(indexedT, 5).
ast_node_signatureJava1(labelT, 5).
ast_node_signatureJava1(literalT, 5).
ast_node_signatureJava1(localDefT, A) :-
	hackTreeSignaturelocalDefT1(A).
ast_node_signatureJava1(newArrayT, 6).
ast_node_signatureJava1(newClassT, 8).
ast_node_signatureJava1(nopT, 3).
ast_node_signatureJava1(operationT, 6).
ast_node_signatureJava1(precedenceT, 4).
ast_node_signatureJava1(returnT, 4).
ast_node_signatureJava1(selectT, 6).
ast_node_signatureJava1(identT, 5).
ast_node_signatureJava1(switchT, 5).
ast_node_signatureJava1(synchronizedT, 5).
ast_node_signatureJava1(throwT, 4).
ast_node_signatureJava1(toplevelT, 4).
ast_node_signatureJava1(tryT, 6).
ast_node_signatureJava1(typeCastT, 5).
ast_node_signatureJava1(typeTestT, 5).
ast_node_signatureJava1(whileLoopT, 5).

% hackTreeSignatureclassDefT1('$VAR'(0)):-hackTreeSignature(classDefT, 9, '$VAR'(0))
hackTreeSignatureclassDefT1(4) :- !.
hackTreeSignatureclassDefT1(9).

% hackTreeSignaturemethodDefT1('$VAR'(0)):-hackTreeSignature(methodDefT, 8, '$VAR'(0))
hackTreeSignaturemethodDefT1(7) :- !.
hackTreeSignaturemethodDefT1(8).

% hackTreeSignaturefieldDefT1('$VAR'(0)):-hackTreeSignature(fieldDefT, 6, '$VAR'(0))
hackTreeSignaturefieldDefT1(5) :- !.
hackTreeSignaturefieldDefT1(6).

% hackTreeSignatureparamDefT1('$VAR'(0)):-hackTreeSignature(paramDefT, 5, '$VAR'(0))
hackTreeSignatureparamDefT1(4) :- !.
hackTreeSignatureparamDefT1(5).

% hackTreeSignaturelocalDefT1('$VAR'(0)):-hackTreeSignature(localDefT, 7, '$VAR'(0))
hackTreeSignaturelocalDefT1(6) :- !.
hackTreeSignaturelocalDefT1(7).
ast_node_signature('JavaAttributes', A, B) :-
	ast_node_signatureJavaAttributes1(A, B).

% ast_node_signatureJavaAttributes1('$VAR'(0), '$VAR'(1)):-ast_node_signature('JavaAttributes', '$VAR'(0), '$VAR'(1))
ast_node_signatureJavaAttributes1(extendsT, 2).
ast_node_signatureJavaAttributes1(modifierT, 2).
ast_node_signatureJavaAttributes1(implementsT, 2).
ast_node_signatureJavaAttributes1(externT, 1).
ast_node_signatureJavaAttributes1(interfaceT, 1).
ast_node_signatureJavaAttributes1(sourceLocation, 4).
ast_node_signatureJavaAttributes1(projectLocationT, 3).
ast_node_signatureJavaAttributes1(slT, 3).
get_ast_node_argument('Java', A, B, C) :-
	get_ast_node_argumentJava1(A, B, C).

% get_ast_node_argumentJava1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-get_ast_node_argument('Java', '$VAR'(0), '$VAR'(1), '$VAR'(2))
get_ast_node_argumentJava1(A, B, C) :-
	get_ast_node_argumentJava5(A, B, C).

% get_ast_node_argumentJava5('$VAR'(0), '$VAR'(1), '$VAR'(2)):-get_ast_node_argument('Java', '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(0), '$VAR'(6), '$VAR'(7), '$VAR'(1), '$VAR'(8), '$VAR'(9), '$VAR'(10), '$VAR'(2))
get_ast_node_argumentJava5(A, id, A) :-
	packageT(A, _).
get_ast_node_argumentJava5(A, name, B) :-
	packageT(A, B).
get_ast_node_argumentJava5(A, id, A) :-
	classDefT(A, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	classDefT(A, B, _, _).
get_ast_node_argumentJava5(A, name, B) :-
	classDefT(A, _, B, _).
get_ast_node_argumentJava5(A, defs, B) :-
	classDefT(A, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	methodDefT(A, _, _, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	methodDefT(A, B, _, _, _, _, _).
get_ast_node_argumentJava5(A, name, B) :-
	methodDefT(A, _, B, _, _, _, _).
get_ast_node_argumentJava5(A, params, B) :-
	methodDefT(A, _, _, B, _, _, _).
get_ast_node_argumentJava5(A, type, B) :-
	methodDefT(A, _, _, _, B, _, _).
get_ast_node_argumentJava5(A, excepts, B) :-
	methodDefT(A, _, _, _, _, B, _).
get_ast_node_argumentJava5(A, body, B) :-
	methodDefT(A, _, _, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	fieldDefT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	fieldDefT(A, B, _, _, _).
get_ast_node_argumentJava5(A, type, B) :-
	fieldDefT(A, _, B, _, _).
get_ast_node_argumentJava5(A, name, B) :-
	fieldDefT(A, _, _, B, _).
get_ast_node_argumentJava5(A, expr, B) :-
	fieldDefT(A, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	paramDefT(A, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	paramDefT(A, B, _, _).
get_ast_node_argumentJava5(A, type, B) :-
	paramDefT(A, _, B, _).
get_ast_node_argumentJava5(A, name, B) :-
	paramDefT(A, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	applyT(A, _, _, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	applyT(A, B, _, _, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	applyT(A, _, B, _, _, _, _).
get_ast_node_argumentJava5(A, expr, B) :-
	applyT(A, _, _, B, _, _, _).
get_ast_node_argumentJava5(A, name, B) :-
	applyT(A, _, _, _, B, _, _).
get_ast_node_argumentJava5(A, args, B) :-
	applyT(A, _, _, _, _, B, _).
get_ast_node_argumentJava5(A, ref, B) :-
	applyT(A, _, _, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	assertT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	assertT(A, B, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	assertT(A, _, B, _, _).
get_ast_node_argumentJava5(A, expr, B) :-
	assertT(A, _, _, B, _).
get_ast_node_argumentJava5(A, msg, B) :-
	assertT(A, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	assignT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	assignT(A, B, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	assignT(A, _, B, _, _).
get_ast_node_argumentJava5(A, lhs, B) :-
	assignT(A, _, _, B, _).
get_ast_node_argumentJava5(A, expr, B) :-
	assignT(A, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	assignopT(A, _, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	assignopT(A, B, _, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	assignopT(A, _, B, _, _, _).
get_ast_node_argumentJava5(A, lhs, B) :-
	assignopT(A, _, _, B, _, _).
get_ast_node_argumentJava5(A, operator, B) :-
	assignopT(A, _, _, _, B, _).
get_ast_node_argumentJava5(A, expr, B) :-
	assignopT(A, _, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	blockT(A, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	blockT(A, B, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	blockT(A, _, B, _).
get_ast_node_argumentJava5(A, stmts, B) :-
	blockT(A, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	breakT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	breakT(A, B, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	breakT(A, _, B, _, _).
get_ast_node_argumentJava5(A, label, B) :-
	breakT(A, _, _, B, _).
get_ast_node_argumentJava5(A, target, B) :-
	breakT(A, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	caseT(A, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	caseT(A, B, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	caseT(A, _, B, _).
get_ast_node_argumentJava5(A, expr, B) :-
	caseT(A, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	conditionalT(A, _, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	conditionalT(A, B, _, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	conditionalT(A, _, B, _, _, _).
get_ast_node_argumentJava5(A, cond, B) :-
	conditionalT(A, _, _, B, _, _).
get_ast_node_argumentJava5(A, thenexpr, B) :-
	conditionalT(A, _, _, _, B, _).
get_ast_node_argumentJava5(A, elseexpr, B) :-
	conditionalT(A, _, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	continueT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	continueT(A, B, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	continueT(A, _, B, _, _).
get_ast_node_argumentJava5(A, label, B) :-
	continueT(A, _, _, B, _).
get_ast_node_argumentJava5(A, target, B) :-
	continueT(A, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	doLoopT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	doLoopT(A, B, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	doLoopT(A, _, B, _, _).
get_ast_node_argumentJava5(A, cond, B) :-
	doLoopT(A, _, _, B, _).
get_ast_node_argumentJava5(A, body, B) :-
	doLoopT(A, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	execT(A, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	execT(A, B, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	execT(A, _, B, _).
get_ast_node_argumentJava5(A, expr, B) :-
	execT(A, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	catchT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	catchT(A, B, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	catchT(A, _, B, _, _).
get_ast_node_argumentJava5(A, param, B) :-
	catchT(A, _, _, B, _).
get_ast_node_argumentJava5(A, body, B) :-
	catchT(A, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	forLoopT(A, _, _, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	forLoopT(A, B, _, _, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	forLoopT(A, _, B, _, _, _, _).
get_ast_node_argumentJava5(A, inits, B) :-
	forLoopT(A, _, _, B, _, _, _).
get_ast_node_argumentJava5(A, cond, B) :-
	forLoopT(A, _, _, _, B, _, _).
get_ast_node_argumentJava5(A, updaters, B) :-
	forLoopT(A, _, _, _, _, B, _).
get_ast_node_argumentJava5(A, body, B) :-
	forLoopT(A, _, _, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	getFieldT(A, _, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	getFieldT(A, B, _, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	getFieldT(A, _, B, _, _, _).
get_ast_node_argumentJava5(A, expr, B) :-
	getFieldT(A, _, _, B, _, _).
get_ast_node_argumentJava5(A, name, B) :-
	getFieldT(A, _, _, _, B, _).
get_ast_node_argumentJava5(A, field, B) :-
	getFieldT(A, _, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	ifT(A, _, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	ifT(A, B, _, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	ifT(A, _, B, _, _, _).
get_ast_node_argumentJava5(A, cond, B) :-
	ifT(A, _, _, B, _, _).
get_ast_node_argumentJava5(A, then, B) :-
	ifT(A, _, _, _, B, _).
get_ast_node_argumentJava5(A, else, B) :-
	ifT(A, _, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	importT(A, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	importT(A, B, _).
get_ast_node_argumentJava5(A, import, B) :-
	importT(A, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	indexedT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	indexedT(A, B, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	indexedT(A, _, B, _, _).
get_ast_node_argumentJava5(A, index, B) :-
	indexedT(A, _, _, B, _).
get_ast_node_argumentJava5(A, indexed, B) :-
	indexedT(A, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	labelT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	labelT(A, B, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	labelT(A, _, B, _, _).
get_ast_node_argumentJava5(A, body, B) :-
	labelT(A, _, _, B, _).
get_ast_node_argumentJava5(A, label, B) :-
	labelT(A, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	literalT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	literalT(A, B, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	literalT(A, _, B, _, _).
get_ast_node_argumentJava5(A, type, B) :-
	literalT(A, _, _, B, _).
get_ast_node_argumentJava5(A, value, B) :-
	literalT(A, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	localDefT(A, _, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	localDefT(A, B, _, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	localDefT(A, _, B, _, _, _).
get_ast_node_argumentJava5(A, type, B) :-
	localDefT(A, _, _, B, _, _).
get_ast_node_argumentJava5(A, name, B) :-
	localDefT(A, _, _, _, B, _).
get_ast_node_argumentJava5(A, expr, B) :-
	localDefT(A, _, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	newArrayT(A, _, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	newArrayT(A, B, _, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	newArrayT(A, _, B, _, _, _).
get_ast_node_argumentJava5(A, dims, B) :-
	newArrayT(A, _, _, B, _, _).
get_ast_node_argumentJava5(A, elems, B) :-
	newArrayT(A, _, _, _, B, _).
get_ast_node_argumentJava5(A, type, B) :-
	newArrayT(A, _, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	newClassT(A, _, _, _, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	newClassT(A, B, _, _, _, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	newClassT(A, _, B, _, _, _, _, _).
get_ast_node_argumentJava5(A, constr, B) :-
	newClassT(A, _, _, B, _, _, _, _).
get_ast_node_argumentJava5(A, args, B) :-
	newClassT(A, _, _, _, B, _, _, _).
get_ast_node_argumentJava5(A, clident, B) :-
	newClassT(A, _, _, _, _, B, _, _).
get_ast_node_argumentJava5(A, def, B) :-
	newClassT(A, _, _, _, _, _, B, _).
get_ast_node_argumentJava5(A, encltype, B) :-
	newClassT(A, _, _, _, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	nopT(A, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	nopT(A, B, _).
get_ast_node_argumentJava5(A, encl, B) :-
	nopT(A, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	operationT(A, _, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	operationT(A, B, _, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	operationT(A, _, B, _, _, _).
get_ast_node_argumentJava5(A, args, B) :-
	operationT(A, _, _, B, _, _).
get_ast_node_argumentJava5(A, op, B) :-
	operationT(A, _, _, _, B, _).
get_ast_node_argumentJava5(A, pos, B) :-
	operationT(A, _, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	precedenceT(A, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	precedenceT(A, B, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	precedenceT(A, _, B, _).
get_ast_node_argumentJava5(A, expr, B) :-
	precedenceT(A, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	returnT(A, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	returnT(A, B, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	returnT(A, _, B, _).
get_ast_node_argumentJava5(A, expr, B) :-
	returnT(A, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	selectT(A, _, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	selectT(A, B, _, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	selectT(A, _, B, _, _, _).
get_ast_node_argumentJava5(A, name, B) :-
	selectT(A, _, _, B, _, _).
get_ast_node_argumentJava5(A, selected, B) :-
	selectT(A, _, _, _, B, _).
get_ast_node_argumentJava5(A, ref, B) :-
	selectT(A, _, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	identT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	identT(A, B, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	identT(A, _, B, _, _).
get_ast_node_argumentJava5(A, name, B) :-
	identT(A, _, _, B, _).
get_ast_node_argumentJava5(A, ref, B) :-
	identT(A, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	switchT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	switchT(A, B, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	switchT(A, _, B, _, _).
get_ast_node_argumentJava5(A, cond, B) :-
	switchT(A, _, _, B, _).
get_ast_node_argumentJava5(A, stmts, B) :-
	switchT(A, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	synchronizedT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	synchronizedT(A, B, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	synchronizedT(A, _, B, _, _).
get_ast_node_argumentJava5(A, lock, B) :-
	synchronizedT(A, _, _, B, _).
get_ast_node_argumentJava5(A, block, B) :-
	synchronizedT(A, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	throwT(A, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	throwT(A, B, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	throwT(A, _, B, _).
get_ast_node_argumentJava5(A, expr, B) :-
	throwT(A, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	toplevelT(A, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	toplevelT(A, B, _, _).
get_ast_node_argumentJava5(A, file, B) :-
	toplevelT(A, _, B, _).
get_ast_node_argumentJava5(A, defs, B) :-
	toplevelT(A, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	tryT(A, _, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	tryT(A, B, _, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	tryT(A, _, B, _, _, _).
get_ast_node_argumentJava5(A, block, B) :-
	tryT(A, _, _, B, _, _).
get_ast_node_argumentJava5(A, catchers, B) :-
	tryT(A, _, _, _, B, _).
get_ast_node_argumentJava5(A, finalize, B) :-
	tryT(A, _, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	typeCastT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	typeCastT(A, B, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	typeCastT(A, _, B, _, _).
get_ast_node_argumentJava5(A, type, B) :-
	typeCastT(A, _, _, B, _).
get_ast_node_argumentJava5(A, expr, B) :-
	typeCastT(A, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	typeTestT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	typeTestT(A, B, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	typeTestT(A, _, B, _, _).
get_ast_node_argumentJava5(A, type, B) :-
	typeTestT(A, _, _, B, _).
get_ast_node_argumentJava5(A, expr, B) :-
	typeTestT(A, _, _, _, B).
get_ast_node_argumentJava5(A, id, A) :-
	whileLoopT(A, _, _, _, _).
get_ast_node_argumentJava5(A, parent, B) :-
	whileLoopT(A, B, _, _, _).
get_ast_node_argumentJava5(A, encl, B) :-
	whileLoopT(A, _, B, _, _).
get_ast_node_argumentJava5(A, cond, B) :-
	whileLoopT(A, _, _, B, _).
get_ast_node_argumentJava5(A, body, B) :-
	whileLoopT(A, _, _, _, B).

% original definition
:- dynamic packageT/2.
packageT(null, '').

% original definition
:- dynamic classDefT/4.

% original definition
:- dynamic methodDefT/7.

% original definition
:- dynamic fieldDefT/5.

% original definition
:- dynamic paramDefT/4.

% original definition
:- dynamic applyT/7.

% original definition
:- dynamic assertT/5.

% original definition
:- dynamic assignT/5.

% original definition
:- dynamic assignopT/6.

% original definition
:- dynamic blockT/4.

% original definition
:- dynamic breakT/5.

% original definition
:- dynamic caseT/4.

% original definition
:- dynamic conditionalT/6.

% original definition
:- dynamic continueT/5.

% original definition
:- dynamic doLoopT/5.

% original definition
:- dynamic execT/4.

% original definition
:- dynamic catchT/5.

% original definition
:- dynamic forLoopT/7.

% original definition
:- dynamic getFieldT/6.

% original definition
:- dynamic ifT/6.

% original definition
:- dynamic importT/3.

% original definition
:- dynamic indexedT/5.

% original definition
:- dynamic labelT/5.

% original definition
:- dynamic literalT/5.

% original definition
:- dynamic localDefT/6.

% original definition
:- dynamic newArrayT/6.

% original definition
:- dynamic newClassT/8.

% original definition
:- dynamic nopT/3.

% original definition
:- dynamic operationT/6.

% original definition
:- dynamic precedenceT/4.

% original definition
:- dynamic returnT/4.

% original definition
:- dynamic selectT/6.

% original definition
:- dynamic identT/5.

% original definition
:- dynamic switchT/5.

% original definition
:- dynamic synchronizedT/5.

% original definition
:- dynamic throwT/4.

% original definition
:- dynamic toplevelT/4.

% original definition
:- dynamic tryT/6.

% original definition
:- dynamic typeCastT/5.

% original definition
:- dynamic typeTestT/5.

% original definition
:- dynamic whileLoopT/5.
get_ast_node_edge('Java', A, B, C) :-
	get_ast_node_edgeJava1(A, B, C).

% get_ast_node_edgeJava1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-get_ast_node_edge('Java', '$VAR'(0), '$VAR'(1), '$VAR'(2))
get_ast_node_edgeJava1(A, B, C) :-
	get_ast_node_argumentJava2(A, B, C).

% get_ast_node_argumentJava2('$VAR'(0), '$VAR'(1), '$VAR'(2)):-get_ast_node_argument('Java', '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(0), '$VAR'(6), '$VAR'(7), '$VAR'(1), '$VAR'(8), id, '$VAR'(9), '$VAR'(2))
get_ast_node_argumentJava2(A, id, A) :-
	packageT(A, _).
get_ast_node_argumentJava2(A, id, A) :-
	classDefT(A, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	classDefT(A, B, _, _).
get_ast_node_argumentJava2(A, defs, B) :-
	classDefT(A, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	methodDefT(A, _, _, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	methodDefT(A, B, _, _, _, _, _).
get_ast_node_argumentJava2(A, params, B) :-
	methodDefT(A, _, _, B, _, _, _).
get_ast_node_argumentJava2(A, excepts, B) :-
	methodDefT(A, _, _, _, _, B, _).
get_ast_node_argumentJava2(A, body, B) :-
	methodDefT(A, _, _, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	fieldDefT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	fieldDefT(A, B, _, _, _).
get_ast_node_argumentJava2(A, expr, B) :-
	fieldDefT(A, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	paramDefT(A, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	paramDefT(A, B, _, _).
get_ast_node_argumentJava2(A, id, A) :-
	applyT(A, _, _, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	applyT(A, B, _, _, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	applyT(A, _, B, _, _, _, _).
get_ast_node_argumentJava2(A, expr, B) :-
	applyT(A, _, _, B, _, _, _).
get_ast_node_argumentJava2(A, args, B) :-
	applyT(A, _, _, _, _, B, _).
get_ast_node_argumentJava2(A, ref, B) :-
	applyT(A, _, _, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	assertT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	assertT(A, B, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	assertT(A, _, B, _, _).
get_ast_node_argumentJava2(A, expr, B) :-
	assertT(A, _, _, B, _).
get_ast_node_argumentJava2(A, msg, B) :-
	assertT(A, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	assignT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	assignT(A, B, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	assignT(A, _, B, _, _).
get_ast_node_argumentJava2(A, lhs, B) :-
	assignT(A, _, _, B, _).
get_ast_node_argumentJava2(A, expr, B) :-
	assignT(A, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	assignopT(A, _, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	assignopT(A, B, _, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	assignopT(A, _, B, _, _, _).
get_ast_node_argumentJava2(A, lhs, B) :-
	assignopT(A, _, _, B, _, _).
get_ast_node_argumentJava2(A, expr, B) :-
	assignopT(A, _, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	blockT(A, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	blockT(A, B, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	blockT(A, _, B, _).
get_ast_node_argumentJava2(A, stmts, B) :-
	blockT(A, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	breakT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	breakT(A, B, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	breakT(A, _, B, _, _).
get_ast_node_argumentJava2(A, target, B) :-
	breakT(A, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	caseT(A, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	caseT(A, B, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	caseT(A, _, B, _).
get_ast_node_argumentJava2(A, expr, B) :-
	caseT(A, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	conditionalT(A, _, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	conditionalT(A, B, _, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	conditionalT(A, _, B, _, _, _).
get_ast_node_argumentJava2(A, cond, B) :-
	conditionalT(A, _, _, B, _, _).
get_ast_node_argumentJava2(A, thenexpr, B) :-
	conditionalT(A, _, _, _, B, _).
get_ast_node_argumentJava2(A, elseexpr, B) :-
	conditionalT(A, _, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	continueT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	continueT(A, B, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	continueT(A, _, B, _, _).
get_ast_node_argumentJava2(A, target, B) :-
	continueT(A, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	doLoopT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	doLoopT(A, B, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	doLoopT(A, _, B, _, _).
get_ast_node_argumentJava2(A, cond, B) :-
	doLoopT(A, _, _, B, _).
get_ast_node_argumentJava2(A, body, B) :-
	doLoopT(A, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	execT(A, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	execT(A, B, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	execT(A, _, B, _).
get_ast_node_argumentJava2(A, expr, B) :-
	execT(A, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	catchT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	catchT(A, B, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	catchT(A, _, B, _, _).
get_ast_node_argumentJava2(A, param, B) :-
	catchT(A, _, _, B, _).
get_ast_node_argumentJava2(A, body, B) :-
	catchT(A, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	forLoopT(A, _, _, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	forLoopT(A, B, _, _, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	forLoopT(A, _, B, _, _, _, _).
get_ast_node_argumentJava2(A, inits, B) :-
	forLoopT(A, _, _, B, _, _, _).
get_ast_node_argumentJava2(A, cond, B) :-
	forLoopT(A, _, _, _, B, _, _).
get_ast_node_argumentJava2(A, updaters, B) :-
	forLoopT(A, _, _, _, _, B, _).
get_ast_node_argumentJava2(A, body, B) :-
	forLoopT(A, _, _, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	getFieldT(A, _, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	getFieldT(A, B, _, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	getFieldT(A, _, B, _, _, _).
get_ast_node_argumentJava2(A, expr, B) :-
	getFieldT(A, _, _, B, _, _).
get_ast_node_argumentJava2(A, field, B) :-
	getFieldT(A, _, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	ifT(A, _, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	ifT(A, B, _, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	ifT(A, _, B, _, _, _).
get_ast_node_argumentJava2(A, cond, B) :-
	ifT(A, _, _, B, _, _).
get_ast_node_argumentJava2(A, then, B) :-
	ifT(A, _, _, _, B, _).
get_ast_node_argumentJava2(A, else, B) :-
	ifT(A, _, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	importT(A, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	importT(A, B, _).
get_ast_node_argumentJava2(A, import, B) :-
	importT(A, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	indexedT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	indexedT(A, B, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	indexedT(A, _, B, _, _).
get_ast_node_argumentJava2(A, index, B) :-
	indexedT(A, _, _, B, _).
get_ast_node_argumentJava2(A, indexed, B) :-
	indexedT(A, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	labelT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	labelT(A, B, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	labelT(A, _, B, _, _).
get_ast_node_argumentJava2(A, body, B) :-
	labelT(A, _, _, B, _).
get_ast_node_argumentJava2(A, id, A) :-
	literalT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	literalT(A, B, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	literalT(A, _, B, _, _).
get_ast_node_argumentJava2(A, id, A) :-
	localDefT(A, _, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	localDefT(A, B, _, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	localDefT(A, _, B, _, _, _).
get_ast_node_argumentJava2(A, expr, B) :-
	localDefT(A, _, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	newArrayT(A, _, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	newArrayT(A, B, _, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	newArrayT(A, _, B, _, _, _).
get_ast_node_argumentJava2(A, dims, B) :-
	newArrayT(A, _, _, B, _, _).
get_ast_node_argumentJava2(A, elems, B) :-
	newArrayT(A, _, _, _, B, _).
get_ast_node_argumentJava2(A, id, A) :-
	newClassT(A, _, _, _, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	newClassT(A, B, _, _, _, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	newClassT(A, _, B, _, _, _, _, _).
get_ast_node_argumentJava2(A, constr, B) :-
	newClassT(A, _, _, B, _, _, _, _).
get_ast_node_argumentJava2(A, args, B) :-
	newClassT(A, _, _, _, B, _, _, _).
get_ast_node_argumentJava2(A, clident, B) :-
	newClassT(A, _, _, _, _, B, _, _).
get_ast_node_argumentJava2(A, def, B) :-
	newClassT(A, _, _, _, _, _, B, _).
get_ast_node_argumentJava2(A, encltype, B) :-
	newClassT(A, _, _, _, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	nopT(A, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	nopT(A, B, _).
get_ast_node_argumentJava2(A, encl, B) :-
	nopT(A, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	operationT(A, _, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	operationT(A, B, _, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	operationT(A, _, B, _, _, _).
get_ast_node_argumentJava2(A, args, B) :-
	operationT(A, _, _, B, _, _).
get_ast_node_argumentJava2(A, pos, B) :-
	operationT(A, _, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	precedenceT(A, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	precedenceT(A, B, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	precedenceT(A, _, B, _).
get_ast_node_argumentJava2(A, expr, B) :-
	precedenceT(A, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	returnT(A, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	returnT(A, B, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	returnT(A, _, B, _).
get_ast_node_argumentJava2(A, expr, B) :-
	returnT(A, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	selectT(A, _, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	selectT(A, B, _, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	selectT(A, _, B, _, _, _).
get_ast_node_argumentJava2(A, selected, B) :-
	selectT(A, _, _, _, B, _).
get_ast_node_argumentJava2(A, ref, B) :-
	selectT(A, _, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	identT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	identT(A, B, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	identT(A, _, B, _, _).
get_ast_node_argumentJava2(A, ref, B) :-
	identT(A, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	switchT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	switchT(A, B, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	switchT(A, _, B, _, _).
get_ast_node_argumentJava2(A, cond, B) :-
	switchT(A, _, _, B, _).
get_ast_node_argumentJava2(A, stmts, B) :-
	switchT(A, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	synchronizedT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	synchronizedT(A, B, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	synchronizedT(A, _, B, _, _).
get_ast_node_argumentJava2(A, lock, B) :-
	synchronizedT(A, _, _, B, _).
get_ast_node_argumentJava2(A, block, B) :-
	synchronizedT(A, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	throwT(A, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	throwT(A, B, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	throwT(A, _, B, _).
get_ast_node_argumentJava2(A, expr, B) :-
	throwT(A, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	toplevelT(A, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	toplevelT(A, B, _, _).
get_ast_node_argumentJava2(A, defs, B) :-
	toplevelT(A, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	tryT(A, _, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	tryT(A, B, _, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	tryT(A, _, B, _, _, _).
get_ast_node_argumentJava2(A, block, B) :-
	tryT(A, _, _, B, _, _).
get_ast_node_argumentJava2(A, catchers, B) :-
	tryT(A, _, _, _, B, _).
get_ast_node_argumentJava2(A, finalize, B) :-
	tryT(A, _, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	typeCastT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	typeCastT(A, B, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	typeCastT(A, _, B, _, _).
get_ast_node_argumentJava2(A, expr, B) :-
	typeCastT(A, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	typeTestT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	typeTestT(A, B, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	typeTestT(A, _, B, _, _).
get_ast_node_argumentJava2(A, expr, B) :-
	typeTestT(A, _, _, _, B).
get_ast_node_argumentJava2(A, id, A) :-
	whileLoopT(A, _, _, _, _).
get_ast_node_argumentJava2(A, parent, B) :-
	whileLoopT(A, B, _, _, _).
get_ast_node_argumentJava2(A, encl, B) :-
	whileLoopT(A, _, B, _, _).
get_ast_node_argumentJava2(A, cond, B) :-
	whileLoopT(A, _, _, B, _).
get_ast_node_argumentJava2(A, body, B) :-
	whileLoopT(A, _, _, _, B).
get_ast_node_attribute('Java', A, B, C) :-
	get_ast_node_attributeJava1(A, B, C).

% get_ast_node_attributeJava1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-get_ast_node_attribute('Java', '$VAR'(0), '$VAR'(1), '$VAR'(2))
get_ast_node_attributeJava1(A, name, B) :-
	packageT(A, B).
get_ast_node_attributeJava1(A, name, B) :-
	classDefT(A, _, B, _).
get_ast_node_attributeJava1(A, name, B) :-
	methodDefT(A, _, B, _, _, _, _).
get_ast_node_attributeJava1(A, type, B) :-
	methodDefT(A, _, _, _, B, _, _).
get_ast_node_attributeJava1(A, type, B) :-
	fieldDefT(A, _, B, _, _).
get_ast_node_attributeJava1(A, name, B) :-
	fieldDefT(A, _, _, B, _).
get_ast_node_attributeJava1(A, type, B) :-
	paramDefT(A, _, B, _).
get_ast_node_attributeJava1(A, name, B) :-
	paramDefT(A, _, _, B).
get_ast_node_attributeJava1(A, name, B) :-
	applyT(A, _, _, _, B, _, _).
get_ast_node_attributeJava1(A, operator, B) :-
	assignopT(A, _, _, _, B, _).
get_ast_node_attributeJava1(A, label, B) :-
	breakT(A, _, _, B, _).
get_ast_node_attributeJava1(A, label, B) :-
	continueT(A, _, _, B, _).
get_ast_node_attributeJava1(A, name, B) :-
	getFieldT(A, _, _, _, B, _).
get_ast_node_attributeJava1(A, label, B) :-
	labelT(A, _, _, _, B).
get_ast_node_attributeJava1(A, type, B) :-
	literalT(A, _, _, B, _).
get_ast_node_attributeJava1(A, value, B) :-
	literalT(A, _, _, _, B).
get_ast_node_attributeJava1(A, type, B) :-
	localDefT(A, _, _, B, _, _).
get_ast_node_attributeJava1(A, name, B) :-
	localDefT(A, _, _, _, B, _).
get_ast_node_attributeJava1(A, type, B) :-
	newArrayT(A, _, _, _, _, B).
get_ast_node_attributeJava1(A, op, B) :-
	operationT(A, _, _, _, B, _).
get_ast_node_attributeJava1(A, name, B) :-
	selectT(A, _, _, B, _, _).
get_ast_node_attributeJava1(A, name, B) :-
	identT(A, _, _, B, _).
get_ast_node_attributeJava1(A, file, B) :-
	toplevelT(A, _, B, _).
get_ast_node_attributeJava1(A, type, B) :-
	typeCastT(A, _, _, B, _).
get_ast_node_attributeJava1(A, type, B) :-
	typeTestT(A, _, _, B, _).
get_ast_node_parent('Java', A, B) :-
	get_ast_node_parentJava1(A, B).

% get_ast_node_parentJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_parent('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_parentJava1(A, B) :-
	classDefT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	methodDefT(A, B, _, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	fieldDefT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	paramDefT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	applyT(A, B, _, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	assertT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	assignT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	assignopT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	blockT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	breakT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	caseT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	conditionalT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	continueT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	doLoopT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	execT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	catchT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	forLoopT(A, B, _, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	getFieldT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	ifT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	importT(A, B, _).
get_ast_node_parentJava1(A, B) :-
	indexedT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	labelT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	literalT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	localDefT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	newArrayT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	newClassT(A, B, _, _, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	nopT(A, B, _).
get_ast_node_parentJava1(A, B) :-
	operationT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	precedenceT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	returnT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	selectT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	identT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	switchT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	synchronizedT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	throwT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	toplevelT(A, B, _, _).
get_ast_node_parentJava1(A, B) :-
	tryT(A, B, _, _, _, _).
get_ast_node_parentJava1(A, B) :-
	typeCastT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	typeTestT(A, B, _, _, _).
get_ast_node_parentJava1(A, B) :-
	whileLoopT(A, B, _, _, _).
get_ast_node_parentJava1(A, null) :-
	packageT(A, _).
get_ast_node_enclosing('Java', A, B) :-
	get_ast_node_enclosingJava1(A, B).

% get_ast_node_enclosingJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_enclosing('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_enclosingJava1(A, B) :-
	applyT(A, _, B, _, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	assertT(A, _, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	assignT(A, _, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	assignopT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	blockT(A, _, B, _), !.
get_ast_node_enclosingJava1(A, B) :-
	breakT(A, _, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	caseT(A, _, B, _), !.
get_ast_node_enclosingJava1(A, B) :-
	conditionalT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	continueT(A, _, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	doLoopT(A, _, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	execT(A, _, B, _), !.
get_ast_node_enclosingJava1(A, B) :-
	catchT(A, _, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	forLoopT(A, _, B, _, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	getFieldT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	ifT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	indexedT(A, _, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	labelT(A, _, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	literalT(A, _, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	localDefT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	newArrayT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	newClassT(A, _, B, _, _, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	nopT(A, _, B), !.
get_ast_node_enclosingJava1(A, B) :-
	operationT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	precedenceT(A, _, B, _), !.
get_ast_node_enclosingJava1(A, B) :-
	returnT(A, _, B, _), !.
get_ast_node_enclosingJava1(A, B) :-
	selectT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	identT(A, _, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	switchT(A, _, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	synchronizedT(A, _, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	throwT(A, _, B, _), !.
get_ast_node_enclosingJava1(A, B) :-
	tryT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	typeCastT(A, _, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	typeTestT(A, _, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	whileLoopT(A, _, B, _, _), !.
get_ast_node_enclosingJava1(A, A) :-
	packageT(A, _), !.
get_ast_node_enclosingJava1(A, B) :-
	classDefT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	paramDefT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	fieldDefT(A, B, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	methodDefT(A, B, _, _, _, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	toplevelT(A, B, _, _), !.
get_ast_node_enclosingJava1(A, B) :-
	importT(A, _, B), !.
get_ast_node_label('Java', A, B) :-
	get_ast_node_labelJava1(A, B).

% get_ast_node_labelJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_label('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_labelJava1(A, packageT) :-
	packageT(A, _), !.
get_ast_node_labelJava1(A, classDefT) :-
	classDefT(A, _, _, _), !.
get_ast_node_labelJava1(A, methodDefT) :-
	methodDefT(A, _, _, _, _, _, _), !.
get_ast_node_labelJava1(A, fieldDefT) :-
	fieldDefT(A, _, _, _, _), !.
get_ast_node_labelJava1(A, paramDefT) :-
	paramDefT(A, _, _, _), !.
get_ast_node_labelJava1(A, applyT) :-
	applyT(A, _, _, _, _, _, _), !.
get_ast_node_labelJava1(A, assertT) :-
	assertT(A, _, _, _, _), !.
get_ast_node_labelJava1(A, assignT) :-
	assignT(A, _, _, _, _), !.
get_ast_node_labelJava1(A, assignopT) :-
	assignopT(A, _, _, _, _, _), !.
get_ast_node_labelJava1(A, blockT) :-
	blockT(A, _, _, _), !.
get_ast_node_labelJava1(A, breakT) :-
	breakT(A, _, _, _, _), !.
get_ast_node_labelJava1(A, caseT) :-
	caseT(A, _, _, _), !.
get_ast_node_labelJava1(A, conditionalT) :-
	conditionalT(A, _, _, _, _, _), !.
get_ast_node_labelJava1(A, continueT) :-
	continueT(A, _, _, _, _), !.
get_ast_node_labelJava1(A, doLoopT) :-
	doLoopT(A, _, _, _, _), !.
get_ast_node_labelJava1(A, execT) :-
	execT(A, _, _, _), !.
get_ast_node_labelJava1(A, catchT) :-
	catchT(A, _, _, _, _), !.
get_ast_node_labelJava1(A, forLoopT) :-
	forLoopT(A, _, _, _, _, _, _), !.
get_ast_node_labelJava1(A, getFieldT) :-
	getFieldT(A, _, _, _, _, _), !.
get_ast_node_labelJava1(A, ifT) :-
	ifT(A, _, _, _, _, _), !.
get_ast_node_labelJava1(A, importT) :-
	importT(A, _, _), !.
get_ast_node_labelJava1(A, indexedT) :-
	indexedT(A, _, _, _, _), !.
get_ast_node_labelJava1(A, labelT) :-
	labelT(A, _, _, _, _), !.
get_ast_node_labelJava1(A, literalT) :-
	literalT(A, _, _, _, _), !.
get_ast_node_labelJava1(A, localDefT) :-
	localDefT(A, _, _, _, _, _), !.
get_ast_node_labelJava1(A, newArrayT) :-
	newArrayT(A, _, _, _, _, _), !.
get_ast_node_labelJava1(A, newClassT) :-
	newClassT(A, _, _, _, _, _, _, _), !.
get_ast_node_labelJava1(A, nopT) :-
	nopT(A, _, _), !.
get_ast_node_labelJava1(A, operationT) :-
	operationT(A, _, _, _, _, _), !.
get_ast_node_labelJava1(A, precedenceT) :-
	precedenceT(A, _, _, _), !.
get_ast_node_labelJava1(A, returnT) :-
	returnT(A, _, _, _), !.
get_ast_node_labelJava1(A, selectT) :-
	selectT(A, _, _, _, _, _), !.
get_ast_node_labelJava1(A, identT) :-
	identT(A, _, _, _, _), !.
get_ast_node_labelJava1(A, switchT) :-
	switchT(A, _, _, _, _), !.
get_ast_node_labelJava1(A, synchronizedT) :-
	synchronizedT(A, _, _, _, _), !.
get_ast_node_labelJava1(A, throwT) :-
	throwT(A, _, _, _), !.
get_ast_node_labelJava1(A, toplevelT) :-
	toplevelT(A, _, _, _), !.
get_ast_node_labelJava1(A, tryT) :-
	tryT(A, _, _, _, _, _), !.
get_ast_node_labelJava1(A, typeCastT) :-
	typeCastT(A, _, _, _, _), !.
get_ast_node_labelJava1(A, typeTestT) :-
	typeTestT(A, _, _, _, _), !.
get_ast_node_labelJava1(A, whileLoopT) :-
	whileLoopT(A, _, _, _, _), !.
get_ast_node_id('Java', A, B) :-
	get_ast_node_idJava1(A, B).

% get_ast_node_idJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_id('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_idJava1(A, B) :-
	nonvar(A),
	ast_node_dataJava1(A, C),
	A= (B=B),
	C=[D|E],
	(   D=ast_arg(_, _, id, _), !
	;   E=[ast_arg(_, _, id, _)|_], !
	).

% ast_node_dataJava1('$VAR'(0), '$VAR'(1)):-ast_node_data('Java', '$VAR'(0), '$VAR'(2), '$VAR'(3), '$VAR'(1), '$VAR'(4))
ast_node_dataJava1(A, C) :-
	nonvar(A),
	A= (\+B), !,
	ast_node_dataJava1(B, C).
ast_node_dataJava1(A, B) :-
	nonvar(A), !,
	B=[ast_arg(id, mult(1, 1, no), id, [D]), ast_arg(E, mult(F, 1, no), G, [H|I])|J],
	functor(A, C, _),
	(   C=packageT,
	    D=id,
	    E=name,
	    F=1,
	    G=attr,
	    H=atom,
	    I=[],
	    J=[]
	;   C=classDefT,
	    D=classDefT,
	    E=parent,
	    F=1,
	    G=id,
	    H=execT,
	    I=[packageT, classDefT, newClassT, blockT],
	    J=[ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])]
	;   C=methodDefT,
	    D=methodDefT,
	    E=parent,
	    F=1,
	    G=id,
	    H=classDefT,
	    I=[],
	    J=[ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   C=fieldDefT,
	    D=fieldDefT,
	    E=parent,
	    F=1,
	    G=id,
	    H=classDefT,
	    I=[],
	    J=[ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   C=paramDefT,
	    D=paramDefT,
	    E=parent,
	    F=1,
	    G=id,
	    H=methodDefT,
	    I=[catchT],
	    J=[ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   C=applyT,
	    D=applyT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])]
	;   C=assertT,
	    D=assertT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(msg, mult(0, 1, no), id, [expressionType])]
	;   C=assignT,
	    D=assignT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=assignopT,
	    D=assignopT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=blockT,
	    D=blockT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(stmts, mult(0, *, ord), id, [statementType])]
	;   C=breakT,
	    D=breakT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])]
	;   C=caseT,
	    D=caseT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType])]
	;   C=conditionalT,
	    D=conditionalT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])]
	;   C=continueT,
	    D=continueT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])]
	;   C=doLoopT,
	    D=doLoopT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])]
	;   C=execT,
	    D=execT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=catchT,
	    D=catchT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(param, mult(1, 1, no), id, [paramDefT]), ast_arg(body, mult(1, 1, no), id, [blockT])]
	;   C=forLoopT,
	    D=forLoopT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(inits, mult(0, *, ord), id, [[expressionType, localDefT]]), ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])]
	;   C=getFieldT,
	    D=getFieldT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])]
	;   C=ifT,
	    D=ifT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])]
	;   C=importT,
	    D=importT,
	    E=parent,
	    F=1,
	    G=id,
	    H=toplevelT,
	    I=[],
	    J=[ast_arg(import, mult(1, 1, no), id, [packageT, classDefT])]
	;   C=indexedT,
	    D=indexedT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(index, mult(1, 1, no), id, [expressionType]), ast_arg(indexed, mult(1, 1, no), id, [expressionType])]
	;   C=labelT,
	    D=labelT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(body, mult(1, 1, no), id, [statementType]), ast_arg(label, mult(1, 1, no), attr, [atom])]
	;   C=literalT,
	    D=literalT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(value, mult(1, 1, no), attr, [atom])]
	;   C=localDefT,
	    D=localDefT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   C=newArrayT,
	    D=newArrayT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(dims, mult(1, *, ord), id, [expressionType]), ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])]
	;   C=newClassT,
	    D=newClassT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(constr, mult(0, 1, no), id, [methodDefT]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])]
	;   C=nopT,
	    D=nopT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT])]
	;   C=operationT,
	    D=operationT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(args, mult(1, 1, ord), id, [expressionType]), ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])]
	;   C=precedenceT,
	    D=precedenceT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=returnT,
	    D=execT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=selectT,
	    D=selectT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])]
	;   C=identT,
	    D=identT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT, localDefT])]
	;   C=switchT,
	    D=switchT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(stmts, mult(1, 1, no), id, [statementType])]
	;   C=synchronizedT,
	    D=synchronizedT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(lock, mult(1, 1, no), id, [expressionType]), ast_arg(block, mult(1, 1, no), id, [blockT])]
	;   C=throwT,
	    D=throwT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=toplevelT,
	    D=toplevelT,
	    E=parent,
	    F=0,
	    G=id,
	    H=packageT,
	    I=[],
	    J=[ast_arg(file, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])]
	;   C=tryT,
	    D=tryT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(block, mult(1, 1, no), id, [blockT]), ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])]
	;   C=typeCastT,
	    D=typeCastT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=typeTestT,
	    D=typeTestT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=whileLoopT,
	    D=whileLoopT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])]
	).
ast_node_dataJava1(A, B) :-
	var(A),
	B=[ast_arg(id, mult(1, 1, no), id, [C]), ast_arg(D, mult(E, 1, no), F, [G|H])|I],
	(   A=packageT(_, _),
	    C=id,
	    D=name,
	    E=1,
	    F=attr,
	    G=atom,
	    H=[],
	    I=[]
	;   A=classDefT(_, _, _, _),
	    C=classDefT,
	    D=parent,
	    E=1,
	    F=id,
	    G=execT,
	    H=[packageT, classDefT, newClassT, blockT],
	    I=[ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])]
	;   A=methodDefT(_, _, _, _, _, _, _),
	    C=methodDefT,
	    D=parent,
	    E=1,
	    F=id,
	    G=classDefT,
	    H=[],
	    I=[ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   A=fieldDefT(_, _, _, _, _),
	    C=fieldDefT,
	    D=parent,
	    E=1,
	    F=id,
	    G=classDefT,
	    H=[],
	    I=[ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   A=paramDefT(_, _, _, _),
	    C=paramDefT,
	    D=parent,
	    E=1,
	    F=id,
	    G=methodDefT,
	    H=[catchT],
	    I=[ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   A=applyT(_, _, _, _, _, _, _),
	    C=applyT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])]
	;   A=assertT(_, _, _, _, _),
	    C=assertT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(msg, mult(0, 1, no), id, [expressionType])]
	;   A=assignT(_, _, _, _, _),
	    C=assignT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   A=assignopT(_, _, _, _, _, _),
	    C=assignopT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   A=blockT(_, _, _, _),
	    C=blockT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(stmts, mult(0, *, ord), id, [statementType])]
	;   A=breakT(_, _, _, _, _),
	    C=breakT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])]
	;   A=caseT(_, _, _, _),
	    C=caseT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType])]
	;   A=conditionalT(_, _, _, _, _, _),
	    C=conditionalT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])]
	;   A=continueT(_, _, _, _, _),
	    C=continueT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])]
	;   A=doLoopT(_, _, _, _, _),
	    C=doLoopT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])]
	;   A=execT(_, _, _, _),
	    C=execT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   A=catchT(_, _, _, _, _),
	    C=catchT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(param, mult(1, 1, no), id, [paramDefT]), ast_arg(body, mult(1, 1, no), id, [blockT])]
	;   A=forLoopT(_, _, _, _, _, _, _),
	    C=forLoopT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(inits, mult(0, *, ord), id, [[expressionType, localDefT]]), ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])]
	;   A=getFieldT(_, _, _, _, _, _),
	    C=getFieldT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])]
	;   A=ifT(_, _, _, _, _, _),
	    C=ifT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])]
	;   A=importT(_, _, _),
	    C=importT,
	    D=parent,
	    E=1,
	    F=id,
	    G=toplevelT,
	    H=[],
	    I=[ast_arg(import, mult(1, 1, no), id, [packageT, classDefT])]
	;   A=indexedT(_, _, _, _, _),
	    C=indexedT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(index, mult(1, 1, no), id, [expressionType]), ast_arg(indexed, mult(1, 1, no), id, [expressionType])]
	;   A=labelT(_, _, _, _, _),
	    C=labelT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(body, mult(1, 1, no), id, [statementType]), ast_arg(label, mult(1, 1, no), attr, [atom])]
	;   A=literalT(_, _, _, _, _),
	    C=literalT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(value, mult(1, 1, no), attr, [atom])]
	;   A=localDefT(_, _, _, _, _, _),
	    C=localDefT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   A=newArrayT(_, _, _, _, _, _),
	    C=newArrayT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(dims, mult(1, *, ord), id, [expressionType]), ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])]
	;   A=newClassT(_, _, _, _, _, _, _, _),
	    C=newClassT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(constr, mult(0, 1, no), id, [methodDefT]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])]
	;   A=nopT(_, _, _),
	    C=nopT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT])]
	;   A=operationT(_, _, _, _, _, _),
	    C=operationT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(args, mult(1, 1, ord), id, [expressionType]), ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])]
	;   A=precedenceT(_, _, _, _),
	    C=precedenceT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   A=returnT(_, _, _, _),
	    C=execT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   A=selectT(_, _, _, _, _, _),
	    C=selectT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])]
	;   A=identT(_, _, _, _, _),
	    C=identT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT, localDefT])]
	;   A=switchT(_, _, _, _, _),
	    C=switchT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(stmts, mult(1, 1, no), id, [statementType])]
	;   A=synchronizedT(_, _, _, _, _),
	    C=synchronizedT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(lock, mult(1, 1, no), id, [expressionType]), ast_arg(block, mult(1, 1, no), id, [blockT])]
	;   A=throwT(_, _, _, _),
	    C=throwT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   A=toplevelT(_, _, _, _),
	    C=toplevelT,
	    D=parent,
	    E=0,
	    F=id,
	    G=packageT,
	    H=[],
	    I=[ast_arg(file, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])]
	;   A=tryT(_, _, _, _, _, _),
	    C=tryT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(block, mult(1, 1, no), id, [blockT]), ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])]
	;   A=typeCastT(_, _, _, _, _),
	    C=typeCastT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   A=typeTestT(_, _, _, _, _),
	    C=typeTestT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   A=whileLoopT(_, _, _, _, _),
	    C=whileLoopT,
	    D=parent,
	    E=1,
	    F=id,
	    G=id,
	    H=[],
	    I=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])]
	).
get_ast_node_sub_trees('Java', A, B) :-
	get_ast_node_sub_treesJava1(A, B).

% get_ast_node_sub_treesJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_sub_trees('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_sub_treesJava1(A, D) :-
	methodDefT(A, _, _, C, _, _, B), !,
	(   B=null,
	    append([], C, D)
	;   append([B], C, D)
	).
get_ast_node_sub_treesJava1(A, C) :-
	packageT(A, _), !,
	findall(B, (classDefT(B, A, _, _);toplevelT(B, A, _, _)), C).
get_ast_node_sub_treesJava1(A, E) :-
	findall(B, (get_ast_node_argumentJava1(A, D, C, B), member(C, D)), E).

% get_ast_node_argumentJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-get_ast_node_argument('Java', '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(0), '$VAR'(7), '$VAR'(1), '$VAR'(2), '$VAR'(8), id, '$VAR'(9), '$VAR'(3))
get_ast_node_argumentJava1(A, [], id, A) :-
	packageT(A, _).
get_ast_node_argumentJava1(A, [defs], id, A) :-
	classDefT(A, _, _, _).
get_ast_node_argumentJava1(A, [defs], parent, B) :-
	classDefT(A, B, _, _).
get_ast_node_argumentJava1(A, [defs], defs, B) :-
	classDefT(A, _, _, B).
get_ast_node_argumentJava1(A, [params, body], id, A) :-
	methodDefT(A, _, _, _, _, _, _).
get_ast_node_argumentJava1(A, [params, body], parent, B) :-
	methodDefT(A, B, _, _, _, _, _).
get_ast_node_argumentJava1(A, [params, body], params, B) :-
	methodDefT(A, _, _, B, _, _, _).
get_ast_node_argumentJava1(A, [params, body], excepts, B) :-
	methodDefT(A, _, _, _, _, B, _).
get_ast_node_argumentJava1(A, [params, body], body, B) :-
	methodDefT(A, _, _, _, _, _, B).
get_ast_node_argumentJava1(A, [expr], id, A) :-
	fieldDefT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [expr], parent, B) :-
	fieldDefT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [expr], expr, B) :-
	fieldDefT(A, _, _, _, B).
get_ast_node_argumentJava1(A, [], id, A) :-
	paramDefT(A, _, _, _).
get_ast_node_argumentJava1(A, [], parent, B) :-
	paramDefT(A, B, _, _).
get_ast_node_argumentJava1(A, [expr, args], id, A) :-
	applyT(A, _, _, _, _, _, _).
get_ast_node_argumentJava1(A, [expr, args], parent, B) :-
	applyT(A, B, _, _, _, _, _).
get_ast_node_argumentJava1(A, [expr, args], encl, B) :-
	applyT(A, _, B, _, _, _, _).
get_ast_node_argumentJava1(A, [expr, args], expr, B) :-
	applyT(A, _, _, B, _, _, _).
get_ast_node_argumentJava1(A, [expr, args], args, B) :-
	applyT(A, _, _, _, _, B, _).
get_ast_node_argumentJava1(A, [expr, args], ref, B) :-
	applyT(A, _, _, _, _, _, B).
get_ast_node_argumentJava1(A, [expr, msg], id, A) :-
	assertT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [expr, msg], parent, B) :-
	assertT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [expr, msg], encl, B) :-
	assertT(A, _, B, _, _).
get_ast_node_argumentJava1(A, [expr, msg], expr, B) :-
	assertT(A, _, _, B, _).
get_ast_node_argumentJava1(A, [expr, msg], msg, B) :-
	assertT(A, _, _, _, B).
get_ast_node_argumentJava1(A, [lhs, expr], id, A) :-
	assignT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [lhs, expr], parent, B) :-
	assignT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [lhs, expr], encl, B) :-
	assignT(A, _, B, _, _).
get_ast_node_argumentJava1(A, [lhs, expr], lhs, B) :-
	assignT(A, _, _, B, _).
get_ast_node_argumentJava1(A, [lhs, expr], expr, B) :-
	assignT(A, _, _, _, B).
get_ast_node_argumentJava1(A, [lhs, expr], id, A) :-
	assignopT(A, _, _, _, _, _).
get_ast_node_argumentJava1(A, [lhs, expr], parent, B) :-
	assignopT(A, B, _, _, _, _).
get_ast_node_argumentJava1(A, [lhs, expr], encl, B) :-
	assignopT(A, _, B, _, _, _).
get_ast_node_argumentJava1(A, [lhs, expr], lhs, B) :-
	assignopT(A, _, _, B, _, _).
get_ast_node_argumentJava1(A, [lhs, expr], expr, B) :-
	assignopT(A, _, _, _, _, B).
get_ast_node_argumentJava1(A, [stmts], id, A) :-
	blockT(A, _, _, _).
get_ast_node_argumentJava1(A, [stmts], parent, B) :-
	blockT(A, B, _, _).
get_ast_node_argumentJava1(A, [stmts], encl, B) :-
	blockT(A, _, B, _).
get_ast_node_argumentJava1(A, [stmts], stmts, B) :-
	blockT(A, _, _, B).
get_ast_node_argumentJava1(A, [], id, A) :-
	breakT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [], parent, B) :-
	breakT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [], encl, B) :-
	breakT(A, _, B, _, _).
get_ast_node_argumentJava1(A, [], target, B) :-
	breakT(A, _, _, _, B).
get_ast_node_argumentJava1(A, [expr], id, A) :-
	caseT(A, _, _, _).
get_ast_node_argumentJava1(A, [expr], parent, B) :-
	caseT(A, B, _, _).
get_ast_node_argumentJava1(A, [expr], encl, B) :-
	caseT(A, _, B, _).
get_ast_node_argumentJava1(A, [expr], expr, B) :-
	caseT(A, _, _, B).
get_ast_node_argumentJava1(A, [cond, thenexpr, elseexpr], id, A) :-
	conditionalT(A, _, _, _, _, _).
get_ast_node_argumentJava1(A, [cond, thenexpr, elseexpr], parent, B) :-
	conditionalT(A, B, _, _, _, _).
get_ast_node_argumentJava1(A, [cond, thenexpr, elseexpr], encl, B) :-
	conditionalT(A, _, B, _, _, _).
get_ast_node_argumentJava1(A, [cond, thenexpr, elseexpr], cond, B) :-
	conditionalT(A, _, _, B, _, _).
get_ast_node_argumentJava1(A, [cond, thenexpr, elseexpr], thenexpr, B) :-
	conditionalT(A, _, _, _, B, _).
get_ast_node_argumentJava1(A, [cond, thenexpr, elseexpr], elseexpr, B) :-
	conditionalT(A, _, _, _, _, B).
get_ast_node_argumentJava1(A, [], id, A) :-
	continueT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [], parent, B) :-
	continueT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [], encl, B) :-
	continueT(A, _, B, _, _).
get_ast_node_argumentJava1(A, [], target, B) :-
	continueT(A, _, _, _, B).
get_ast_node_argumentJava1(A, [cond, body], id, A) :-
	doLoopT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [cond, body], parent, B) :-
	doLoopT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [cond, body], encl, B) :-
	doLoopT(A, _, B, _, _).
get_ast_node_argumentJava1(A, [cond, body], cond, B) :-
	doLoopT(A, _, _, B, _).
get_ast_node_argumentJava1(A, [cond, body], body, B) :-
	doLoopT(A, _, _, _, B).
get_ast_node_argumentJava1(A, [expr], id, A) :-
	execT(A, _, _, _).
get_ast_node_argumentJava1(A, [expr], parent, B) :-
	execT(A, B, _, _).
get_ast_node_argumentJava1(A, [expr], encl, B) :-
	execT(A, _, B, _).
get_ast_node_argumentJava1(A, [expr], expr, B) :-
	execT(A, _, _, B).
get_ast_node_argumentJava1(A, [param, body], id, A) :-
	catchT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [param, body], parent, B) :-
	catchT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [param, body], encl, B) :-
	catchT(A, _, B, _, _).
get_ast_node_argumentJava1(A, [param, body], param, B) :-
	catchT(A, _, _, B, _).
get_ast_node_argumentJava1(A, [param, body], body, B) :-
	catchT(A, _, _, _, B).
get_ast_node_argumentJava1(A, [inits, cond, updaters, body], id, A) :-
	forLoopT(A, _, _, _, _, _, _).
get_ast_node_argumentJava1(A, [inits, cond, updaters, body], parent, B) :-
	forLoopT(A, B, _, _, _, _, _).
get_ast_node_argumentJava1(A, [inits, cond, updaters, body], encl, B) :-
	forLoopT(A, _, B, _, _, _, _).
get_ast_node_argumentJava1(A, [inits, cond, updaters, body], inits, B) :-
	forLoopT(A, _, _, B, _, _, _).
get_ast_node_argumentJava1(A, [inits, cond, updaters, body], cond, B) :-
	forLoopT(A, _, _, _, B, _, _).
get_ast_node_argumentJava1(A, [inits, cond, updaters, body], updaters, B) :-
	forLoopT(A, _, _, _, _, B, _).
get_ast_node_argumentJava1(A, [inits, cond, updaters, body], body, B) :-
	forLoopT(A, _, _, _, _, _, B).
get_ast_node_argumentJava1(A, [expr], id, A) :-
	getFieldT(A, _, _, _, _, _).
get_ast_node_argumentJava1(A, [expr], parent, B) :-
	getFieldT(A, B, _, _, _, _).
get_ast_node_argumentJava1(A, [expr], encl, B) :-
	getFieldT(A, _, B, _, _, _).
get_ast_node_argumentJava1(A, [expr], expr, B) :-
	getFieldT(A, _, _, B, _, _).
get_ast_node_argumentJava1(A, [expr], field, B) :-
	getFieldT(A, _, _, _, _, B).
get_ast_node_argumentJava1(A, [cond, then, else], id, A) :-
	ifT(A, _, _, _, _, _).
get_ast_node_argumentJava1(A, [cond, then, else], parent, B) :-
	ifT(A, B, _, _, _, _).
get_ast_node_argumentJava1(A, [cond, then, else], encl, B) :-
	ifT(A, _, B, _, _, _).
get_ast_node_argumentJava1(A, [cond, then, else], cond, B) :-
	ifT(A, _, _, B, _, _).
get_ast_node_argumentJava1(A, [cond, then, else], then, B) :-
	ifT(A, _, _, _, B, _).
get_ast_node_argumentJava1(A, [cond, then, else], else, B) :-
	ifT(A, _, _, _, _, B).
get_ast_node_argumentJava1(A, [], id, A) :-
	importT(A, _, _).
get_ast_node_argumentJava1(A, [], parent, B) :-
	importT(A, B, _).
get_ast_node_argumentJava1(A, [], import, B) :-
	importT(A, _, B).
get_ast_node_argumentJava1(A, [index, indexed], id, A) :-
	indexedT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [index, indexed], parent, B) :-
	indexedT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [index, indexed], encl, B) :-
	indexedT(A, _, B, _, _).
get_ast_node_argumentJava1(A, [index, indexed], index, B) :-
	indexedT(A, _, _, B, _).
get_ast_node_argumentJava1(A, [index, indexed], indexed, B) :-
	indexedT(A, _, _, _, B).
get_ast_node_argumentJava1(A, [body], id, A) :-
	labelT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [body], parent, B) :-
	labelT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [body], encl, B) :-
	labelT(A, _, B, _, _).
get_ast_node_argumentJava1(A, [body], body, B) :-
	labelT(A, _, _, B, _).
get_ast_node_argumentJava1(A, [], id, A) :-
	literalT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [], parent, B) :-
	literalT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [], encl, B) :-
	literalT(A, _, B, _, _).
get_ast_node_argumentJava1(A, [expr], id, A) :-
	localDefT(A, _, _, _, _, _).
get_ast_node_argumentJava1(A, [expr], parent, B) :-
	localDefT(A, B, _, _, _, _).
get_ast_node_argumentJava1(A, [expr], encl, B) :-
	localDefT(A, _, B, _, _, _).
get_ast_node_argumentJava1(A, [expr], expr, B) :-
	localDefT(A, _, _, _, _, B).
get_ast_node_argumentJava1(A, [dims, elems], id, A) :-
	newArrayT(A, _, _, _, _, _).
get_ast_node_argumentJava1(A, [dims, elems], parent, B) :-
	newArrayT(A, B, _, _, _, _).
get_ast_node_argumentJava1(A, [dims, elems], encl, B) :-
	newArrayT(A, _, B, _, _, _).
get_ast_node_argumentJava1(A, [dims, elems], dims, B) :-
	newArrayT(A, _, _, B, _, _).
get_ast_node_argumentJava1(A, [dims, elems], elems, B) :-
	newArrayT(A, _, _, _, B, _).
get_ast_node_argumentJava1(A, [args, clident, def, encltype], id, A) :-
	newClassT(A, _, _, _, _, _, _, _).
get_ast_node_argumentJava1(A, [args, clident, def, encltype], parent, B) :-
	newClassT(A, B, _, _, _, _, _, _).
get_ast_node_argumentJava1(A, [args, clident, def, encltype], encl, B) :-
	newClassT(A, _, B, _, _, _, _, _).
get_ast_node_argumentJava1(A, [args, clident, def, encltype], constr, B) :-
	newClassT(A, _, _, B, _, _, _, _).
get_ast_node_argumentJava1(A, [args, clident, def, encltype], args, B) :-
	newClassT(A, _, _, _, B, _, _, _).
get_ast_node_argumentJava1(A, [args, clident, def, encltype], clident, B) :-
	newClassT(A, _, _, _, _, B, _, _).
get_ast_node_argumentJava1(A, [args, clident, def, encltype], def, B) :-
	newClassT(A, _, _, _, _, _, B, _).
get_ast_node_argumentJava1(A, [args, clident, def, encltype], encltype, B) :-
	newClassT(A, _, _, _, _, _, _, B).
get_ast_node_argumentJava1(A, [], id, A) :-
	nopT(A, _, _).
get_ast_node_argumentJava1(A, [], parent, B) :-
	nopT(A, B, _).
get_ast_node_argumentJava1(A, [], encl, B) :-
	nopT(A, _, B).
get_ast_node_argumentJava1(A, [args], id, A) :-
	operationT(A, _, _, _, _, _).
get_ast_node_argumentJava1(A, [args], parent, B) :-
	operationT(A, B, _, _, _, _).
get_ast_node_argumentJava1(A, [args], encl, B) :-
	operationT(A, _, B, _, _, _).
get_ast_node_argumentJava1(A, [args], args, B) :-
	operationT(A, _, _, B, _, _).
get_ast_node_argumentJava1(A, [args], pos, B) :-
	operationT(A, _, _, _, _, B).
get_ast_node_argumentJava1(A, [expr], id, A) :-
	precedenceT(A, _, _, _).
get_ast_node_argumentJava1(A, [expr], parent, B) :-
	precedenceT(A, B, _, _).
get_ast_node_argumentJava1(A, [expr], encl, B) :-
	precedenceT(A, _, B, _).
get_ast_node_argumentJava1(A, [expr], expr, B) :-
	precedenceT(A, _, _, B).
get_ast_node_argumentJava1(A, [expr], id, A) :-
	returnT(A, _, _, _).
get_ast_node_argumentJava1(A, [expr], parent, B) :-
	returnT(A, B, _, _).
get_ast_node_argumentJava1(A, [expr], encl, B) :-
	returnT(A, _, B, _).
get_ast_node_argumentJava1(A, [expr], expr, B) :-
	returnT(A, _, _, B).
get_ast_node_argumentJava1(A, [selected], id, A) :-
	selectT(A, _, _, _, _, _).
get_ast_node_argumentJava1(A, [selected], parent, B) :-
	selectT(A, B, _, _, _, _).
get_ast_node_argumentJava1(A, [selected], encl, B) :-
	selectT(A, _, B, _, _, _).
get_ast_node_argumentJava1(A, [selected], selected, B) :-
	selectT(A, _, _, _, B, _).
get_ast_node_argumentJava1(A, [selected], ref, B) :-
	selectT(A, _, _, _, _, B).
get_ast_node_argumentJava1(A, [], id, A) :-
	identT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [], parent, B) :-
	identT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [], encl, B) :-
	identT(A, _, B, _, _).
get_ast_node_argumentJava1(A, [], ref, B) :-
	identT(A, _, _, _, B).
get_ast_node_argumentJava1(A, [cond, stmts], id, A) :-
	switchT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [cond, stmts], parent, B) :-
	switchT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [cond, stmts], encl, B) :-
	switchT(A, _, B, _, _).
get_ast_node_argumentJava1(A, [cond, stmts], cond, B) :-
	switchT(A, _, _, B, _).
get_ast_node_argumentJava1(A, [cond, stmts], stmts, B) :-
	switchT(A, _, _, _, B).
get_ast_node_argumentJava1(A, [lock, block], id, A) :-
	synchronizedT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [lock, block], parent, B) :-
	synchronizedT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [lock, block], encl, B) :-
	synchronizedT(A, _, B, _, _).
get_ast_node_argumentJava1(A, [lock, block], lock, B) :-
	synchronizedT(A, _, _, B, _).
get_ast_node_argumentJava1(A, [lock, block], block, B) :-
	synchronizedT(A, _, _, _, B).
get_ast_node_argumentJava1(A, [expr], id, A) :-
	throwT(A, _, _, _).
get_ast_node_argumentJava1(A, [expr], parent, B) :-
	throwT(A, B, _, _).
get_ast_node_argumentJava1(A, [expr], encl, B) :-
	throwT(A, _, B, _).
get_ast_node_argumentJava1(A, [expr], expr, B) :-
	throwT(A, _, _, B).
get_ast_node_argumentJava1(A, [defs], id, A) :-
	toplevelT(A, _, _, _).
get_ast_node_argumentJava1(A, [defs], parent, B) :-
	toplevelT(A, B, _, _).
get_ast_node_argumentJava1(A, [defs], defs, B) :-
	toplevelT(A, _, _, B).
get_ast_node_argumentJava1(A, [block, catchers, finalize], id, A) :-
	tryT(A, _, _, _, _, _).
get_ast_node_argumentJava1(A, [block, catchers, finalize], parent, B) :-
	tryT(A, B, _, _, _, _).
get_ast_node_argumentJava1(A, [block, catchers, finalize], encl, B) :-
	tryT(A, _, B, _, _, _).
get_ast_node_argumentJava1(A, [block, catchers, finalize], block, B) :-
	tryT(A, _, _, B, _, _).
get_ast_node_argumentJava1(A, [block, catchers, finalize], catchers, B) :-
	tryT(A, _, _, _, B, _).
get_ast_node_argumentJava1(A, [block, catchers, finalize], finalize, B) :-
	tryT(A, _, _, _, _, B).
get_ast_node_argumentJava1(A, [expr], id, A) :-
	typeCastT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [expr], parent, B) :-
	typeCastT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [expr], encl, B) :-
	typeCastT(A, _, B, _, _).
get_ast_node_argumentJava1(A, [expr], expr, B) :-
	typeCastT(A, _, _, _, B).
get_ast_node_argumentJava1(A, [expr], id, A) :-
	typeTestT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [expr], parent, B) :-
	typeTestT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [expr], encl, B) :-
	typeTestT(A, _, B, _, _).
get_ast_node_argumentJava1(A, [expr], expr, B) :-
	typeTestT(A, _, _, _, B).
get_ast_node_argumentJava1(A, [cond, body], id, A) :-
	whileLoopT(A, _, _, _, _).
get_ast_node_argumentJava1(A, [cond, body], parent, B) :-
	whileLoopT(A, B, _, _, _).
get_ast_node_argumentJava1(A, [cond, body], encl, B) :-
	whileLoopT(A, _, B, _, _).
get_ast_node_argumentJava1(A, [cond, body], cond, B) :-
	whileLoopT(A, _, _, B, _).
get_ast_node_argumentJava1(A, [cond, body], body, B) :-
	whileLoopT(A, _, _, _, B).
set_ast_node_argument('Java', A, B, C, D, E, F, G, H) :-
	set_ast_node_argumentJava1(A, B, C, D, E, F, G, H).

% set_ast_node_argumentJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-set_ast_node_argument('Java', '$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7))
set_ast_node_argumentJava1(A, B, C, I, J, K, L, M) :-
	ast_node_dataJava1(A, B, D),
	A= (C=C),
	D=[E|H],
	(   E=ast_arg(id, F, id, G),
	    'setArgValue.ast_argid1'(F, G, H, C, I, J, K, L, M, N),
	    O=..[B|N],
	    retract(C=C),
	    markEnclAsDirtyJava1(C),
	    asserta(rollback(assert(C=C))),
	    addJava1(O)
	;   H=[ast_arg(id, P, id, Q)|R],
	    'setArgValue.1'(E, P, Q, R, C, I, J, K, L, M, S),
	    T=..[B|S],
	    retract(C=C),
	    markEnclAsDirtyJava1(C),
	    asserta(rollback(assert(C=C))),
	    addJava1(T)
	).

% ast_node_dataJava1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-ast_node_data('Java', '$VAR'(0), '$VAR'(1), '$VAR'(3), '$VAR'(2), '$VAR'(4))
ast_node_dataJava1(A, C, D) :-
	nonvar(A),
	A= (\+B), !,
	ast_node_dataJava1(B, C, D).
ast_node_dataJava1(A, C, B) :-
	nonvar(A), !,
	B=[ast_arg(id, mult(1, 1, no), id, [D]), ast_arg(E, mult(F, 1, no), G, [H|I])|J],
	functor(A, C, _),
	(   C=packageT,
	    D=id,
	    E=name,
	    F=1,
	    G=attr,
	    H=atom,
	    I=[],
	    J=[]
	;   C=classDefT,
	    D=classDefT,
	    E=parent,
	    F=1,
	    G=id,
	    H=execT,
	    I=[packageT, classDefT, newClassT, blockT],
	    J=[ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])]
	;   C=methodDefT,
	    D=methodDefT,
	    E=parent,
	    F=1,
	    G=id,
	    H=classDefT,
	    I=[],
	    J=[ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   C=fieldDefT,
	    D=fieldDefT,
	    E=parent,
	    F=1,
	    G=id,
	    H=classDefT,
	    I=[],
	    J=[ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   C=paramDefT,
	    D=paramDefT,
	    E=parent,
	    F=1,
	    G=id,
	    H=methodDefT,
	    I=[catchT],
	    J=[ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   C=applyT,
	    D=applyT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])]
	;   C=assertT,
	    D=assertT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(msg, mult(0, 1, no), id, [expressionType])]
	;   C=assignT,
	    D=assignT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=assignopT,
	    D=assignopT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=blockT,
	    D=blockT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(stmts, mult(0, *, ord), id, [statementType])]
	;   C=breakT,
	    D=breakT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])]
	;   C=caseT,
	    D=caseT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType])]
	;   C=conditionalT,
	    D=conditionalT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])]
	;   C=continueT,
	    D=continueT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])]
	;   C=doLoopT,
	    D=doLoopT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])]
	;   C=execT,
	    D=execT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=catchT,
	    D=catchT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(param, mult(1, 1, no), id, [paramDefT]), ast_arg(body, mult(1, 1, no), id, [blockT])]
	;   C=forLoopT,
	    D=forLoopT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(inits, mult(0, *, ord), id, [[expressionType, localDefT]]), ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])]
	;   C=getFieldT,
	    D=getFieldT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])]
	;   C=ifT,
	    D=ifT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])]
	;   C=importT,
	    D=importT,
	    E=parent,
	    F=1,
	    G=id,
	    H=toplevelT,
	    I=[],
	    J=[ast_arg(import, mult(1, 1, no), id, [packageT, classDefT])]
	;   C=indexedT,
	    D=indexedT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(index, mult(1, 1, no), id, [expressionType]), ast_arg(indexed, mult(1, 1, no), id, [expressionType])]
	;   C=labelT,
	    D=labelT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(body, mult(1, 1, no), id, [statementType]), ast_arg(label, mult(1, 1, no), attr, [atom])]
	;   C=literalT,
	    D=literalT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(value, mult(1, 1, no), attr, [atom])]
	;   C=localDefT,
	    D=localDefT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   C=newArrayT,
	    D=newArrayT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(dims, mult(1, *, ord), id, [expressionType]), ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])]
	;   C=newClassT,
	    D=newClassT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(constr, mult(0, 1, no), id, [methodDefT]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])]
	;   C=nopT,
	    D=nopT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT])]
	;   C=operationT,
	    D=operationT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(args, mult(1, 1, ord), id, [expressionType]), ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])]
	;   C=precedenceT,
	    D=precedenceT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=returnT,
	    D=execT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=selectT,
	    D=selectT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])]
	;   C=identT,
	    D=identT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT, localDefT])]
	;   C=switchT,
	    D=switchT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(stmts, mult(1, 1, no), id, [statementType])]
	;   C=synchronizedT,
	    D=synchronizedT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(lock, mult(1, 1, no), id, [expressionType]), ast_arg(block, mult(1, 1, no), id, [blockT])]
	;   C=throwT,
	    D=throwT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=toplevelT,
	    D=toplevelT,
	    E=parent,
	    F=0,
	    G=id,
	    H=packageT,
	    I=[],
	    J=[ast_arg(file, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])]
	;   C=tryT,
	    D=tryT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(block, mult(1, 1, no), id, [blockT]), ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])]
	;   C=typeCastT,
	    D=typeCastT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=typeTestT,
	    D=typeTestT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=whileLoopT,
	    D=whileLoopT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])]
	).
ast_node_dataJava1(A, C, B) :-
	var(A),
	B=[ast_arg(id, mult(1, 1, no), id, [D]), ast_arg(E, mult(F, 1, no), G, [H|I])|J],
	(   C=packageT,
	    A=packageT(_, _),
	    D=id,
	    E=name,
	    F=1,
	    G=attr,
	    H=atom,
	    I=[],
	    J=[]
	;   C=classDefT,
	    A=classDefT(_, _, _, _),
	    D=classDefT,
	    E=parent,
	    F=1,
	    G=id,
	    H=execT,
	    I=[packageT, classDefT, newClassT, blockT],
	    J=[ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])]
	;   C=methodDefT,
	    A=methodDefT(_, _, _, _, _, _, _),
	    D=methodDefT,
	    E=parent,
	    F=1,
	    G=id,
	    H=classDefT,
	    I=[],
	    J=[ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   C=fieldDefT,
	    A=fieldDefT(_, _, _, _, _),
	    D=fieldDefT,
	    E=parent,
	    F=1,
	    G=id,
	    H=classDefT,
	    I=[],
	    J=[ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   C=paramDefT,
	    A=paramDefT(_, _, _, _),
	    D=paramDefT,
	    E=parent,
	    F=1,
	    G=id,
	    H=methodDefT,
	    I=[catchT],
	    J=[ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   C=applyT,
	    A=applyT(_, _, _, _, _, _, _),
	    D=applyT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])]
	;   C=assertT,
	    A=assertT(_, _, _, _, _),
	    D=assertT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(msg, mult(0, 1, no), id, [expressionType])]
	;   C=assignT,
	    A=assignT(_, _, _, _, _),
	    D=assignT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=assignopT,
	    A=assignopT(_, _, _, _, _, _),
	    D=assignopT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=blockT,
	    A=blockT(_, _, _, _),
	    D=blockT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(stmts, mult(0, *, ord), id, [statementType])]
	;   C=breakT,
	    A=breakT(_, _, _, _, _),
	    D=breakT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])]
	;   C=caseT,
	    A=caseT(_, _, _, _),
	    D=caseT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType])]
	;   C=conditionalT,
	    A=conditionalT(_, _, _, _, _, _),
	    D=conditionalT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])]
	;   C=continueT,
	    A=continueT(_, _, _, _, _),
	    D=continueT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])]
	;   C=doLoopT,
	    A=doLoopT(_, _, _, _, _),
	    D=doLoopT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])]
	;   C=execT,
	    A=execT(_, _, _, _),
	    D=execT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=catchT,
	    A=catchT(_, _, _, _, _),
	    D=catchT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(param, mult(1, 1, no), id, [paramDefT]), ast_arg(body, mult(1, 1, no), id, [blockT])]
	;   C=forLoopT,
	    A=forLoopT(_, _, _, _, _, _, _),
	    D=forLoopT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(inits, mult(0, *, ord), id, [[expressionType, localDefT]]), ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])]
	;   C=getFieldT,
	    A=getFieldT(_, _, _, _, _, _),
	    D=getFieldT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])]
	;   C=ifT,
	    A=ifT(_, _, _, _, _, _),
	    D=ifT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])]
	;   C=importT,
	    A=importT(_, _, _),
	    D=importT,
	    E=parent,
	    F=1,
	    G=id,
	    H=toplevelT,
	    I=[],
	    J=[ast_arg(import, mult(1, 1, no), id, [packageT, classDefT])]
	;   C=indexedT,
	    A=indexedT(_, _, _, _, _),
	    D=indexedT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(index, mult(1, 1, no), id, [expressionType]), ast_arg(indexed, mult(1, 1, no), id, [expressionType])]
	;   C=labelT,
	    A=labelT(_, _, _, _, _),
	    D=labelT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(body, mult(1, 1, no), id, [statementType]), ast_arg(label, mult(1, 1, no), attr, [atom])]
	;   C=literalT,
	    A=literalT(_, _, _, _, _),
	    D=literalT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(value, mult(1, 1, no), attr, [atom])]
	;   C=localDefT,
	    A=localDefT(_, _, _, _, _, _),
	    D=localDefT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])]
	;   C=newArrayT,
	    A=newArrayT(_, _, _, _, _, _),
	    D=newArrayT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(dims, mult(1, *, ord), id, [expressionType]), ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])]
	;   C=newClassT,
	    A=newClassT(_, _, _, _, _, _, _, _),
	    D=newClassT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(constr, mult(0, 1, no), id, [methodDefT]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])]
	;   C=nopT,
	    A=nopT(_, _, _),
	    D=nopT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT])]
	;   C=operationT,
	    A=operationT(_, _, _, _, _, _),
	    D=operationT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(args, mult(1, 1, ord), id, [expressionType]), ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])]
	;   C=precedenceT,
	    A=precedenceT(_, _, _, _),
	    D=precedenceT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=returnT,
	    A=returnT(_, _, _, _),
	    D=execT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=selectT,
	    A=selectT(_, _, _, _, _, _),
	    D=selectT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])]
	;   C=identT,
	    A=identT(_, _, _, _, _),
	    D=identT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT, localDefT])]
	;   C=switchT,
	    A=switchT(_, _, _, _, _),
	    D=switchT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(stmts, mult(1, 1, no), id, [statementType])]
	;   C=synchronizedT,
	    A=synchronizedT(_, _, _, _, _),
	    D=synchronizedT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(lock, mult(1, 1, no), id, [expressionType]), ast_arg(block, mult(1, 1, no), id, [blockT])]
	;   C=throwT,
	    A=throwT(_, _, _, _),
	    D=throwT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=toplevelT,
	    A=toplevelT(_, _, _, _),
	    D=toplevelT,
	    E=parent,
	    F=0,
	    G=id,
	    H=packageT,
	    I=[],
	    J=[ast_arg(file, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])]
	;   C=tryT,
	    A=tryT(_, _, _, _, _, _),
	    D=tryT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(block, mult(1, 1, no), id, [blockT]), ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])]
	;   C=typeCastT,
	    A=typeCastT(_, _, _, _, _),
	    D=typeCastT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=typeTestT,
	    A=typeTestT(_, _, _, _, _),
	    D=typeTestT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])]
	;   C=whileLoopT,
	    A=whileLoopT(_, _, _, _, _),
	    D=whileLoopT,
	    E=parent,
	    F=1,
	    G=id,
	    H=id,
	    I=[],
	    J=[ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])]
	).

% 'setArgValue.ast_argid1'('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7), '$VAR'(8), '$VAR'(9)):-setArgValue([ast_arg(id, '$VAR'(0), id, '$VAR'(1))|'$VAR'(2)], ['$VAR'(3), '$VAR'(3)], '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7), '$VAR'(8), '$VAR'(9))
'setArgValue.ast_argid1'(A, B, D, E, id, A, id, B, C, [C|F]) :-
	setArgValue1(D, E, A, B, C, F), !.
'setArgValue.ast_argid1'(_, _, [ast_arg(A, B, C, D)|_], E, A, B, C, D, F, [E, F]) :- !.
'setArgValue.ast_argid1'(_, _, [_|_], A, _, _, _, _, _, [A, A]).

% setArgValue1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-setArgValue('$VAR'(0), ['$VAR'(1)], ast_arg(id, '$VAR'(2), id, '$VAR'(3)), '$VAR'(4), '$VAR'(5))
setArgValue1([ast_arg(id, A, id, B)|_], _, A, B, C, [C]) :- !.
setArgValue1([_|_], A, _, _, _, [A]).

% markEnclAsDirtyJava1('$VAR'(0)):-markEnclAsDirty('Java', '$VAR'(0)='$VAR'(0))
markEnclAsDirtyJava1(A) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava1(_).

% get_ast_node_labelJava1('$VAR'(0)):-get_ast_node_label('Java', '$VAR'(0), packageT)
get_ast_node_labelJava1(A) :-
	packageT(A, _), !.

% get_ast_node_enclosingJava2('$VAR'(0), '$VAR'(1)):-get_ast_node_enclosing('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_enclosingJava2(A, B) :-
	applyT(A, _, B, _, _, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	assertT(A, _, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	assignT(A, _, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	assignopT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	blockT(A, _, B, _), !.
get_ast_node_enclosingJava2(A, B) :-
	breakT(A, _, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	caseT(A, _, B, _), !.
get_ast_node_enclosingJava2(A, B) :-
	conditionalT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	continueT(A, _, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	doLoopT(A, _, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	execT(A, _, B, _), !.
get_ast_node_enclosingJava2(A, B) :-
	catchT(A, _, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	forLoopT(A, _, B, _, _, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	getFieldT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	ifT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	indexedT(A, _, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	labelT(A, _, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	literalT(A, _, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	localDefT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	newArrayT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	newClassT(A, _, B, _, _, _, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	nopT(A, _, B), !.
get_ast_node_enclosingJava2(A, B) :-
	operationT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	precedenceT(A, _, B, _), !.
get_ast_node_enclosingJava2(A, B) :-
	returnT(A, _, B, _), !.
get_ast_node_enclosingJava2(A, B) :-
	selectT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	identT(A, _, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	switchT(A, _, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	synchronizedT(A, _, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	throwT(A, _, B, _), !.
get_ast_node_enclosingJava2(A, B) :-
	tryT(A, _, B, _, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	typeCastT(A, _, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	typeTestT(A, _, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	whileLoopT(A, _, B, _, _), !.
get_ast_node_enclosingJava2(A, A) :-
	packageT(A, _), !.
get_ast_node_enclosingJava2(A, B) :-
	classDefT(A, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	paramDefT(A, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	fieldDefT(A, B, _, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	methodDefT(A, B, _, _, _, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	toplevelT(A, B, _, _), !.
get_ast_node_enclosingJava2(A, B) :-
	importT(A, _, B), !.

% '\\+=1'('$VAR'(0)):- \+'$VAR'(0)=null
'\\+=1'(null) :- !,
	fail.
'\\+=1'(_).

% '\\+get_ast_node_labelJava1'('$VAR'(0)):- \+get_ast_node_label('Java', '$VAR'(0), packageT)
'\\+get_ast_node_labelJava1'(A) :-
	get_ast_node_labelJava1(A), !,
	fail.
'\\+get_ast_node_labelJava1'(_).

% addJava1('$VAR'(0)):-add('Java', '$VAR'(0))
addJava1(java_fq(A)) :- !,
	java_fq_to_pef1(A, B),
	addJava1(B).
addJava1(A) :-
	nonvar(A),
	call(A), !,
	format('~nWARNING: element: already exists: ~w~n.', [A]).
addJava1(A) :-
	nonvar(A),
	assert(A),
	asserta(rollback(retract(A))),
	(   arg(1, A, B),
	    get_ast_node_labelJava1(B),
	    (   get_ast_node_enclosingJava2(B, C),
		'\\+=1'(C),
		'\\+get_ast_node_labelJava1'(C),
		assert1T(dirty_tree('Java', C)), !
	    ;   assert1T(dirty_tree('Java', B)), !
	    )
	;   true
	).

% java_fq_to_pef1('$VAR'(0), '$VAR'(1)):-java_fq_to_pef('$VAR'(0), '$VAR'(1))
java_fq_to_pef1(A, E) :-
	'\\+ground1'(A),
	sformat(B, 'compiler error, term not ground: ~w', [A]),
	t_i_based_error_handling(B),
	A=..[C|D],
	(   C=packageT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [id]), ast_arg(name, mult(1, 1, no), attr, [atom])], D, F),
	    E=..[packageT|F]
	;   C=classDefT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [classDefT]), ast_arg(parent, mult(1, 1, no), id, [execT, packageT, classDefT, newClassT, blockT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], D, G),
	    E=..[classDefT|G]
	;   C=methodDefT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [methodDefT]), ast_arg(parent, mult(1, 1, no), id, [classDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], D, H),
	    E=..[methodDefT|H]
	;   C=fieldDefT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [fieldDefT]), ast_arg(parent, mult(1, 1, no), id, [classDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], D, I),
	    E=..[fieldDefT|I]
	;   C=paramDefT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [paramDefT]), ast_arg(parent, mult(1, 1, no), id, [methodDefT, catchT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], D, J),
	    E=..[paramDefT|J]
	;   C=applyT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [applyT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], D, K),
	    E=..[applyT|K]
	;   C=assertT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [assertT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(msg, mult(0, 1, no), id, [expressionType])], D, L),
	    E=..[assertT|L]
	;   C=assignT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [assignT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], D, M),
	    E=..[assignT|M]
	;   C=assignopT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [assignopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], D, N),
	    E=..[assignopT|N]
	;   C=blockT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [blockT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(stmts, mult(0, *, ord), id, [statementType])], D, O),
	    E=..[blockT|O]
	;   C=breakT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [breakT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])], D, P),
	    E=..[breakT|P]
	;   C=caseT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [caseT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], D, Q),
	    E=..[caseT|Q]
	;   C=conditionalT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [conditionalT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])], D, R),
	    E=..[conditionalT|R]
	;   C=continueT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [continueT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])], D, S),
	    E=..[continueT|S]
	;   C=doLoopT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [doLoopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], D, T),
	    E=..[doLoopT|T]
	;   C=execT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [execT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], D, U),
	    E=..[execT|U]
	;   C=catchT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [catchT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(param, mult(1, 1, no), id, [paramDefT]), ast_arg(body, mult(1, 1, no), id, [blockT])], D, V),
	    E=..[catchT|V]
	;   C=forLoopT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [forLoopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(inits, mult(0, *, ord), id, [[expressionType, localDefT]]), ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])], D, W),
	    E=..[forLoopT|W]
	;   C=getFieldT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [getFieldT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])], D, X),
	    E=..[getFieldT|X]
	;   C=ifT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [ifT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])], D, Y),
	    E=..[ifT|Y]
	;   C=importT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [importT]), ast_arg(parent, mult(1, 1, no), id, [toplevelT]), ast_arg(import, mult(1, 1, no), id, [packageT, classDefT])], D, Z),
	    E=..[importT|Z]
	;   C=indexedT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [indexedT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(index, mult(1, 1, no), id, [expressionType]), ast_arg(indexed, mult(1, 1, no), id, [expressionType])], D, A1),
	    E=..[indexedT|A1]
	;   C=labelT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [labelT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(body, mult(1, 1, no), id, [statementType]), ast_arg(label, mult(1, 1, no), attr, [atom])], D, B1),
	    E=..[labelT|B1]
	;   C=literalT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [literalT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(value, mult(1, 1, no), attr, [atom])], D, C1),
	    E=..[literalT|C1]
	;   C=localDefT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [localDefT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], D, D1),
	    E=..[localDefT|D1]
	;   C=newArrayT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [newArrayT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(dims, mult(1, *, ord), id, [expressionType]), ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])], D, E1),
	    E=..[newArrayT|E1]
	;   C=newClassT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [newClassT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(constr, mult(0, 1, no), id, [methodDefT]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], D, F1),
	    E=..[newClassT|F1]
	;   C=nopT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [nopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT])], D, G1),
	    E=..[nopT|G1]
	;   C=operationT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [operationT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(args, mult(1, 1, ord), id, [expressionType]), ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])], D, H1),
	    E=..[operationT|H1]
	;   C=precedenceT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [precedenceT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], D, I1),
	    E=..[precedenceT|I1]
	;   C=returnT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [execT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], D, J1),
	    E=..[returnT|J1]
	;   C=selectT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [selectT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], D, K1),
	    E=..[selectT|K1]
	;   C=identT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [identT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT, localDefT])], D, L1),
	    E=..[identT|L1]
	;   C=switchT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [switchT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(stmts, mult(1, 1, no), id, [statementType])], D, M1),
	    E=..[switchT|M1]
	;   C=synchronizedT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [synchronizedT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(lock, mult(1, 1, no), id, [expressionType]), ast_arg(block, mult(1, 1, no), id, [blockT])], D, N1),
	    E=..[synchronizedT|N1]
	;   C=throwT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [throwT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], D, O1),
	    E=..[throwT|O1]
	;   C=toplevelT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [toplevelT]), ast_arg(parent, mult(0, 1, no), id, [packageT]), ast_arg(file, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])], D, P1),
	    E=..[toplevelT|P1]
	;   C=tryT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [tryT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(block, mult(1, 1, no), id, [blockT]), ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])], D, Q1),
	    E=..[tryT|Q1]
	;   C=typeCastT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [typeCastT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], D, R1),
	    E=..[typeCastT|R1]
	;   C=typeTestT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [typeTestT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], D, S1),
	    E=..[typeTestT|S1]
	;   C=whileLoopT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [whileLoopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], D, T1),
	    E=..[whileLoopT|T1]
	).
java_fq_to_pef1(A, D) :-
	A=..[B|C],
	(   B=packageT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [id]), ast_arg(name, mult(1, 1, no), attr, [atom])], C, E),
	    D=..[packageT|E]
	;   B=classDefT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [classDefT]), ast_arg(parent, mult(1, 1, no), id, [execT, packageT, classDefT, newClassT, blockT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [methodDefT, fieldDefT, classDefT]), ast_arg(extends, mult(1, 1, no), id, [classDefT]), ast_arg(implems, mult(0, *, no), id, [classDefT]), ast_arg(hasModif, mult(0, *, no), attr, [atom]), ast_arg(isInterf, mult(0, 1, no), flag, []), ast_arg(isExtern, mult(0, 1, no), flag, [])], C, F),
	    D=..[classDefT|F]
	;   B=methodDefT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [methodDefT]), ast_arg(parent, mult(1, 1, no), id, [classDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(params, mult(0, *, ord), id, [paramDefT]), ast_arg(type, mult(0, 1, no), attr, [typeTermType, nullType]), ast_arg(excepts, mult(0, *, ord), id, [classDefT]), ast_arg(body, mult(0, 1, no), id, [blockT]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], C, G),
	    D=..[methodDefT|G]
	;   B=fieldDefT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [fieldDefT]), ast_arg(parent, mult(1, 1, no), id, [classDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], C, H),
	    D=..[fieldDefT|H]
	;   B=paramDefT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [paramDefT]), ast_arg(parent, mult(1, 1, no), id, [methodDefT, catchT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], C, I),
	    D=..[paramDefT|I]
	;   B=applyT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [applyT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(ref, mult(1, 1, no), id, [methodDefT])], C, J),
	    D=..[applyT|J]
	;   B=assertT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [assertT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(msg, mult(0, 1, no), id, [expressionType])], C, K),
	    D=..[assertT|K]
	;   B=assignT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [assignT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], C, L),
	    D=..[assignT|L]
	;   B=assignopT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [assignopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(lhs, mult(1, 1, no), id, [getFieldT, identT, indexedT]), ast_arg(operator, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], C, M),
	    D=..[assignopT|M]
	;   B=blockT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [blockT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(stmts, mult(0, *, ord), id, [statementType])], C, N),
	    D=..[blockT|N]
	;   B=breakT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [breakT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])], C, O),
	    D=..[breakT|O]
	;   B=caseT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [caseT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType])], C, P),
	    D=..[caseT|P]
	;   B=conditionalT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [conditionalT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(thenexpr, mult(1, 1, no), id, [expressionType]), ast_arg(elseexpr, mult(0, 1, no), id, [expressionType])], C, Q),
	    D=..[conditionalT|Q]
	;   B=continueT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [continueT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(label, mult(1, 1, no), attr, [atom]), ast_arg(target, mult(0, 1, no), id, [statementType])], C, R),
	    D=..[continueT|R]
	;   B=doLoopT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [doLoopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], C, S),
	    D=..[doLoopT|S]
	;   B=execT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [execT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], C, T),
	    D=..[execT|T]
	;   B=catchT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [catchT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(param, mult(1, 1, no), id, [paramDefT]), ast_arg(body, mult(1, 1, no), id, [blockT])], C, U),
	    D=..[catchT|U]
	;   B=forLoopT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [forLoopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(inits, mult(0, *, ord), id, [[expressionType, localDefT]]), ast_arg(cond, mult(0, 1, no), id, [[expressionType]]), ast_arg(updaters, mult(0, *, ord), id, [[expressionType]]), ast_arg(body, mult(1, 1, no), id, [blockT])], C, V),
	    D=..[forLoopT|V]
	;   B=getFieldT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [getFieldT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(name, mult(0, 1, no), attr, [atom]), ast_arg(field, mult(1, 1, no), id, [fieldDefT])], C, W),
	    D=..[getFieldT|W]
	;   B=ifT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [ifT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(then, mult(1, 1, no), id, [blockT, statementType]), ast_arg(else, mult(0, 1, no), id, [blockT, statementType])], C, X),
	    D=..[ifT|X]
	;   B=importT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [importT]), ast_arg(parent, mult(1, 1, no), id, [toplevelT]), ast_arg(import, mult(1, 1, no), id, [packageT, classDefT])], C, Y),
	    D=..[importT|Y]
	;   B=indexedT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [indexedT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(index, mult(1, 1, no), id, [expressionType]), ast_arg(indexed, mult(1, 1, no), id, [expressionType])], C, Z),
	    D=..[indexedT|Z]
	;   B=labelT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [labelT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(body, mult(1, 1, no), id, [statementType]), ast_arg(label, mult(1, 1, no), attr, [atom])], C, A1),
	    D=..[labelT|A1]
	;   B=literalT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [literalT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(value, mult(1, 1, no), attr, [atom])], C, B1),
	    D=..[literalT|B1]
	;   B=localDefT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [localDefT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(expr, mult(0, 1, no), id, [expressionType]), ast_arg(hasModif, mult(0, *, no), attr, [atom])], C, C1),
	    D=..[localDefT|C1]
	;   B=newArrayT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [newArrayT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(dims, mult(1, *, ord), id, [expressionType]), ast_arg(elems, mult(0, *, ord), id, [expressionType]), ast_arg(type, mult(1, 1, no), attr, [typeTermType])], C, D1),
	    D=..[newArrayT|D1]
	;   B=newClassT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [newClassT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(constr, mult(0, 1, no), id, [methodDefT]), ast_arg(args, mult(0, *, ord), id, [expressionType]), ast_arg(clident, mult(0, 1, no), id, [identT, selectT]), ast_arg(def, mult(0, 1, no), id, [classDefT]), ast_arg(encltype, mult(0, 1, no), id, [classDefT])], C, E1),
	    D=..[newClassT|E1]
	;   B=nopT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [nopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT])], C, F1),
	    D=..[nopT|F1]
	;   B=operationT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [operationT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(args, mult(1, 1, ord), id, [expressionType]), ast_arg(op, mult(1, 1, no), attr, [atom]), ast_arg(pos, mult(1, 1, no), id, [number])], C, G1),
	    D=..[operationT|G1]
	;   B=precedenceT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [precedenceT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], C, H1),
	    D=..[precedenceT|H1]
	;   B=returnT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [execT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], C, I1),
	    D=..[returnT|I1]
	;   B=selectT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [selectT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(selected, mult(1, 1, no), id, [selectT, identT]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT])], C, J1),
	    D=..[selectT|J1]
	;   B=identT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [identT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(name, mult(1, 1, no), attr, [atom]), ast_arg(ref, mult(1, 1, no), id, [classDefT, packageT, localDefT])], C, K1),
	    D=..[identT|K1]
	;   B=switchT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [switchT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(stmts, mult(1, 1, no), id, [statementType])], C, L1),
	    D=..[switchT|L1]
	;   B=synchronizedT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [synchronizedT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(lock, mult(1, 1, no), id, [expressionType]), ast_arg(block, mult(1, 1, no), id, [blockT])], C, M1),
	    D=..[synchronizedT|M1]
	;   B=throwT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [throwT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], C, N1),
	    D=..[throwT|N1]
	;   B=toplevelT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [toplevelT]), ast_arg(parent, mult(0, 1, no), id, [packageT]), ast_arg(file, mult(1, 1, no), attr, [atom]), ast_arg(defs, mult(0, *, ord), id, [importT, classDefT])], C, O1),
	    D=..[toplevelT|O1]
	;   B=tryT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [tryT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(block, mult(1, 1, no), id, [blockT]), ast_arg(catchers, mult(1, *, ord), id, [catchT]), ast_arg(finalize, mult(0, 1, no), id, [blockT])], C, P1),
	    D=..[tryT|P1]
	;   B=typeCastT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [typeCastT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT, fieldDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], C, Q1),
	    D=..[typeCastT|Q1]
	;   B=typeTestT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [typeTestT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(type, mult(1, 1, no), attr, [typeTermType]), ast_arg(expr, mult(1, 1, no), id, [expressionType])], C, R1),
	    D=..[typeTestT|R1]
	;   B=whileLoopT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [whileLoopT]), ast_arg(parent, mult(1, 1, no), id, [id]), ast_arg(encl, mult(1, 1, no), id, [methodDefT]), ast_arg(cond, mult(1, 1, no), id, [expressionType]), ast_arg(body, mult(1, 1, no), id, [statementType])], C, S1),
	    D=..[whileLoopT|S1]
	).
java_fq_to_pef1(A, D) :-
	A=..[B|C],
	(   B=extendsT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [classDefT]), ast_arg(super, mult(1, 1, no), id, [classDefT])], C, E),
	    D=..[extendsT|E]
	;   B=modifierT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [classDefT, methodDefT, fieldDefT]), ast_arg(modifier, mult(1, 1, no), attr, [atom])], C, F),
	    D=..[modifierT|F]
	;   B=implementsT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [classDefT]), ast_arg(super, mult(1, 1, no), id, [classDefT])], C, G),
	    D=..[implementsT|G]
	;   B=externT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [classDefT])], C, H),
	    D=..[externT|H]
	;   B=interfaceT, !,
	    bindArgs([ast_arg(id, mult(1, 1, no), id, [classDefT])], C, I),
	    D=..[interfaceT|I]
	;   B=sourceLocation, !,
	    bindArgs([ast_arg(_, _, _, _), ast_arg(_, _, _, _), ast_arg(_, _, _, _), ast_arg(_, _, _, _)], C, J),
	    D=..[sourceLocation|J]
	;   B=projectLocationT, !,
	    bindArgs([ast_arg(_, _, _, _), ast_arg(_, _, _, _), ast_arg(_, _, _, _)], C, K),
	    D=..[projectLocationT|K]
	;   B=slT,
	    bindArgs([ast_arg(_, _, _, _), ast_arg(_, _, _, _), ast_arg(_, _, _, _)], C, L),
	    D=..[slT|L]
	).

% '\\+ground1'('$VAR'(0)):- \+ground('$VAR'(0))
'\\+ground1'(A) :-
	ground(A), !,
	fail.
'\\+ground1'(_).
%Warning: Unbound variable found as a goal.
%         Potentially all original code is needed.

% 'setArgValue.1'('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7), '$VAR'(8), '$VAR'(9), '$VAR'(10)):-setArgValue(['$VAR'(0), ast_arg(id, '$VAR'(1), id, '$VAR'(2))|'$VAR'(3)], ['$VAR'(4), '$VAR'(4)], '$VAR'(5), '$VAR'(6), '$VAR'(7), '$VAR'(8), '$VAR'(9), '$VAR'(10))
'setArgValue.1'(ast_arg(A, B, C, D), F, G, H, I, A, B, C, D, E, [E|J]) :-
	'setArgValue.ast_argid2'(F, G, H, I, A, B, C, D, E, J), !.
'setArgValue.1'(_, B, C, D, A, E, F, G, H, I, [A|J]) :-
	'setArgValue.ast_argid2'(B, C, D, A, E, F, G, H, I, J).

% 'setArgValue.ast_argid2'('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7), '$VAR'(8), '$VAR'(9)):-setArgValue([ast_arg(id, '$VAR'(0), id, '$VAR'(1))|'$VAR'(2)], ['$VAR'(3)], ast_arg('$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)), '$VAR'(8), '$VAR'(9))
'setArgValue.ast_argid2'(A, B, _, _, id, A, id, B, C, [C]) :- !.
'setArgValue.ast_argid2'(_, _, _, A, _, _, _, _, _, [A]).
set_ast_node_parent('Java', A, B) :-
	set_ast_node_parentJava1(A, B).

% set_ast_node_parentJava1('$VAR'(0), '$VAR'(1)):-set_ast_node_parent('Java', '$VAR'(0), '$VAR'(1))
set_ast_node_parentJava1(A, _) :-
	packageT(A, B),
	retract(packageT(A, B)),
	markEnclAsDirtyJava1(A, B),
	asserta(rollback(assert(packageT(A, B)))),
	addJava1(A, B).
set_ast_node_parentJava1(A, E) :-
	classDefT(A, B, C, D),
	retract(classDefT(A, B, C, D)),
	markEnclAsDirtyJava1(A, B, C, D),
	asserta(rollback(assert(classDefT(A, B, C, D)))),
	addJava1(A, E, C, D).
set_ast_node_parentJava1(A, H) :-
	methodDefT(A, B, C, D, E, F, G),
	retract(methodDefT(A, B, C, D, E, F, G)),
	markEnclAsDirtyJava1(A, B, C, D, E, F, G),
	asserta(rollback(assert(methodDefT(A, B, C, D, E, F, G)))),
	addJava1(A, H, C, D, E, F, G).
set_ast_node_parentJava1(A, F) :-
	fieldDefT(A, B, C, D, E),
	retract(fieldDefT(A, B, C, D, E)),
	markEnclAsDirtyJava1(A, B, C, D, E),
	asserta(rollback(assert(fieldDefT(A, B, C, D, E)))),
	addJava1(A, F, C, D, E).
set_ast_node_parentJava1(A, E) :-
	paramDefT(A, B, C, D),
	retract(paramDefT(A, B, C, D)),
	markEnclAsDirtyJava2(A, B, C, D),
	asserta(rollback(assert(paramDefT(A, B, C, D)))),
	addJava2(A, E, C, D).
set_ast_node_parentJava1(A, H) :-
	applyT(A, B, C, D, E, F, G),
	retract(applyT(A, B, C, D, E, F, G)),
	markEnclAsDirtyJava2(A, B, C, D, E, F, G),
	asserta(rollback(assert(applyT(A, B, C, D, E, F, G)))),
	addJava2(A, H, C, D, E, F, G).
set_ast_node_parentJava1(A, F) :-
	assertT(A, B, C, D, E),
	retract(assertT(A, B, C, D, E)),
	markEnclAsDirtyJava2(A, B, C, D, E),
	asserta(rollback(assert(assertT(A, B, C, D, E)))),
	addJava2(A, F, C, D, E).
set_ast_node_parentJava1(A, F) :-
	assignT(A, B, C, D, E),
	retract(assignT(A, B, C, D, E)),
	markEnclAsDirtyJava3(A, B, C, D, E),
	asserta(rollback(assert(assignT(A, B, C, D, E)))),
	addJava3(A, F, C, D, E).
set_ast_node_parentJava1(A, G) :-
	assignopT(A, B, C, D, E, F),
	retract(assignopT(A, B, C, D, E, F)),
	markEnclAsDirtyJava1(A, B, C, D, E, F),
	asserta(rollback(assert(assignopT(A, B, C, D, E, F)))),
	addJava1(A, G, C, D, E, F).
set_ast_node_parentJava1(A, E) :-
	blockT(A, B, C, D),
	retract(blockT(A, B, C, D)),
	markEnclAsDirtyJava3(A, B, C, D),
	asserta(rollback(assert(blockT(A, B, C, D)))),
	addJava3(A, E, C, D).
set_ast_node_parentJava1(A, F) :-
	breakT(A, B, C, D, E),
	retract(breakT(A, B, C, D, E)),
	markEnclAsDirtyJava4(A, B, C, D, E),
	asserta(rollback(assert(breakT(A, B, C, D, E)))),
	addJava4(A, F, C, D, E).
set_ast_node_parentJava1(A, E) :-
	caseT(A, B, C, D),
	retract(caseT(A, B, C, D)),
	markEnclAsDirtyJava4(A, B, C, D),
	asserta(rollback(assert(caseT(A, B, C, D)))),
	addJava4(A, E, C, D).
set_ast_node_parentJava1(A, G) :-
	conditionalT(A, B, C, D, E, F),
	retract(conditionalT(A, B, C, D, E, F)),
	markEnclAsDirtyJava2(A, B, C, D, E, F),
	asserta(rollback(assert(conditionalT(A, B, C, D, E, F)))),
	addJava2(A, G, C, D, E, F).
set_ast_node_parentJava1(A, F) :-
	continueT(A, B, C, D, E),
	retract(continueT(A, B, C, D, E)),
	markEnclAsDirtyJava5(A, B, C, D, E),
	asserta(rollback(assert(continueT(A, B, C, D, E)))),
	addJava5(A, F, C, D, E).
set_ast_node_parentJava1(A, F) :-
	doLoopT(A, B, C, D, E),
	retract(doLoopT(A, B, C, D, E)),
	markEnclAsDirtyJava6(A, B, C, D, E),
	asserta(rollback(assert(doLoopT(A, B, C, D, E)))),
	addJava6(A, F, C, D, E).
set_ast_node_parentJava1(A, E) :-
	execT(A, B, C, D),
	retract(execT(A, B, C, D)),
	markEnclAsDirtyJava5(A, B, C, D),
	asserta(rollback(assert(execT(A, B, C, D)))),
	addJava5(A, E, C, D).
set_ast_node_parentJava1(A, F) :-
	catchT(A, B, C, D, E),
	retract(catchT(A, B, C, D, E)),
	markEnclAsDirtyJava7(A, B, C, D, E),
	asserta(rollback(assert(catchT(A, B, C, D, E)))),
	addJava7(A, F, C, D, E).
set_ast_node_parentJava1(A, H) :-
	forLoopT(A, B, C, D, E, F, G),
	retract(forLoopT(A, B, C, D, E, F, G)),
	markEnclAsDirtyJava3(A, B, C, D, E, F, G),
	asserta(rollback(assert(forLoopT(A, B, C, D, E, F, G)))),
	addJava3(A, H, C, D, E, F, G).
set_ast_node_parentJava1(A, G) :-
	getFieldT(A, B, C, D, E, F),
	retract(getFieldT(A, B, C, D, E, F)),
	markEnclAsDirtyJava3(A, B, C, D, E, F),
	asserta(rollback(assert(getFieldT(A, B, C, D, E, F)))),
	addJava3(A, G, C, D, E, F).
set_ast_node_parentJava1(A, G) :-
	ifT(A, B, C, D, E, F),
	retract(ifT(A, B, C, D, E, F)),
	markEnclAsDirtyJava4(A, B, C, D, E, F),
	asserta(rollback(assert(ifT(A, B, C, D, E, F)))),
	addJava4(A, G, C, D, E, F).
set_ast_node_parentJava1(A, D) :-
	importT(A, B, C),
	retract(importT(A, B, C)),
	markEnclAsDirtyJava1(A, B, C),
	asserta(rollback(assert(importT(A, B, C)))),
	addJava1(A, D, C).
set_ast_node_parentJava1(A, F) :-
	indexedT(A, B, C, D, E),
	retract(indexedT(A, B, C, D, E)),
	markEnclAsDirtyJava8(A, B, C, D, E),
	asserta(rollback(assert(indexedT(A, B, C, D, E)))),
	addJava8(A, F, C, D, E).
set_ast_node_parentJava1(A, F) :-
	labelT(A, B, C, D, E),
	retract(labelT(A, B, C, D, E)),
	markEnclAsDirtyJava9(A, B, C, D, E),
	asserta(rollback(assert(labelT(A, B, C, D, E)))),
	addJava9(A, F, C, D, E).
set_ast_node_parentJava1(A, F) :-
	literalT(A, B, C, D, E),
	retract(literalT(A, B, C, D, E)),
	markEnclAsDirtyJava10(A, B, C, D, E),
	asserta(rollback(assert(literalT(A, B, C, D, E)))),
	addJava10(A, F, C, D, E).
set_ast_node_parentJava1(A, G) :-
	localDefT(A, B, C, D, E, F),
	retract(localDefT(A, B, C, D, E, F)),
	markEnclAsDirtyJava5(A, B, C, D, E, F),
	asserta(rollback(assert(localDefT(A, B, C, D, E, F)))),
	addJava5(A, G, C, D, E, F).
set_ast_node_parentJava1(A, G) :-
	newArrayT(A, B, C, D, E, F),
	retract(newArrayT(A, B, C, D, E, F)),
	markEnclAsDirtyJava6(A, B, C, D, E, F),
	asserta(rollback(assert(newArrayT(A, B, C, D, E, F)))),
	addJava6(A, G, C, D, E, F).
set_ast_node_parentJava1(A, I) :-
	newClassT(A, B, C, D, E, F, G, H),
	retract(newClassT(A, B, C, D, E, F, G, H)),
	markEnclAsDirtyJava1(A, B, C, D, E, F, G, H),
	asserta(rollback(assert(newClassT(A, B, C, D, E, F, G, H)))),
	addJava1(A, I, C, D, E, F, G, H).
set_ast_node_parentJava1(A, D) :-
	nopT(A, B, C),
	retract(nopT(A, B, C)),
	markEnclAsDirtyJava2(A, B, C),
	asserta(rollback(assert(nopT(A, B, C)))),
	addJava2(A, D, C).
set_ast_node_parentJava1(A, G) :-
	operationT(A, B, C, D, E, F),
	retract(operationT(A, B, C, D, E, F)),
	markEnclAsDirtyJava7(A, B, C, D, E, F),
	asserta(rollback(assert(operationT(A, B, C, D, E, F)))),
	addJava7(A, G, C, D, E, F).
set_ast_node_parentJava1(A, E) :-
	precedenceT(A, B, C, D),
	retract(precedenceT(A, B, C, D)),
	markEnclAsDirtyJava6(A, B, C, D),
	asserta(rollback(assert(precedenceT(A, B, C, D)))),
	addJava6(A, E, C, D).
set_ast_node_parentJava1(A, E) :-
	returnT(A, B, C, D),
	retract(returnT(A, B, C, D)),
	markEnclAsDirtyJava7(A, B, C, D),
	asserta(rollback(assert(returnT(A, B, C, D)))),
	addJava7(A, E, C, D).
set_ast_node_parentJava1(A, G) :-
	selectT(A, B, C, D, E, F),
	retract(selectT(A, B, C, D, E, F)),
	markEnclAsDirtyJava8(A, B, C, D, E, F),
	asserta(rollback(assert(selectT(A, B, C, D, E, F)))),
	addJava8(A, G, C, D, E, F).
set_ast_node_parentJava1(A, F) :-
	identT(A, B, C, D, E),
	retract(identT(A, B, C, D, E)),
	markEnclAsDirtyJava11(A, B, C, D, E),
	asserta(rollback(assert(identT(A, B, C, D, E)))),
	addJava11(A, F, C, D, E).
set_ast_node_parentJava1(A, F) :-
	switchT(A, B, C, D, E),
	retract(switchT(A, B, C, D, E)),
	markEnclAsDirtyJava12(A, B, C, D, E),
	asserta(rollback(assert(switchT(A, B, C, D, E)))),
	addJava12(A, F, C, D, E).
set_ast_node_parentJava1(A, F) :-
	synchronizedT(A, B, C, D, E),
	retract(synchronizedT(A, B, C, D, E)),
	markEnclAsDirtyJava13(A, B, C, D, E),
	asserta(rollback(assert(synchronizedT(A, B, C, D, E)))),
	addJava13(A, F, C, D, E).
set_ast_node_parentJava1(A, E) :-
	throwT(A, B, C, D),
	retract(throwT(A, B, C, D)),
	markEnclAsDirtyJava8(A, B, C, D),
	asserta(rollback(assert(throwT(A, B, C, D)))),
	addJava8(A, E, C, D).
set_ast_node_parentJava1(A, E) :-
	toplevelT(A, B, C, D),
	retract(toplevelT(A, B, C, D)),
	markEnclAsDirtyJava9(A, B, C, D),
	asserta(rollback(assert(toplevelT(A, B, C, D)))),
	addJava9(A, E, C, D).
set_ast_node_parentJava1(A, G) :-
	tryT(A, B, C, D, E, F),
	retract(tryT(A, B, C, D, E, F)),
	markEnclAsDirtyJava9(A, B, C, D, E, F),
	asserta(rollback(assert(tryT(A, B, C, D, E, F)))),
	addJava9(A, G, C, D, E, F).
set_ast_node_parentJava1(A, F) :-
	typeCastT(A, B, C, D, E),
	retract(typeCastT(A, B, C, D, E)),
	markEnclAsDirtyJava14(A, B, C, D, E),
	asserta(rollback(assert(typeCastT(A, B, C, D, E)))),
	addJava14(A, F, C, D, E).
set_ast_node_parentJava1(A, F) :-
	typeTestT(A, B, C, D, E),
	retract(typeTestT(A, B, C, D, E)),
	markEnclAsDirtyJava15(A, B, C, D, E),
	asserta(rollback(assert(typeTestT(A, B, C, D, E)))),
	addJava15(A, F, C, D, E).
set_ast_node_parentJava1(A, F) :-
	whileLoopT(A, B, C, D, E),
	retract(whileLoopT(A, B, C, D, E)),
	markEnclAsDirtyJava16(A, B, C, D, E),
	asserta(rollback(assert(whileLoopT(A, B, C, D, E)))),
	addJava16(A, F, C, D, E).

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1)):-markEnclAsDirty('Java', packageT('$VAR'(0), '$VAR'(1)))
markEnclAsDirtyJava1(A, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava1(_, _).

% addJava1('$VAR'(0), '$VAR'(1)):-add('Java', packageT('$VAR'(0), '$VAR'(1)))
addJava1(A, B) :-
	packageT(A, B), !,
	format('~nWARNING: element: already exists: ~w~n.', [packageT(A, B)]).
addJava1(A, B) :-
	assert(packageT(A, B)),
	asserta(rollback(retract(packageT(A, B)))),
	markEnclAsDirtyJava1(A, B).

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', classDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava1(A, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava1(_, _, _, _).

% addJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', classDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava1(A, B, C, D) :-
	classDefT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [classDefT(A, B, C, D)]).
addJava1(A, B, C, D) :-
	assert(classDefT(A, B, C, D)),
	asserta(rollback(retract(classDefT(A, B, C, D)))),
	markEnclAsDirtyJava1(A, B, C, D).

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-markEnclAsDirty('Java', methodDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
markEnclAsDirtyJava1(A, _, _, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _, _, _).

% addJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-add('Java', methodDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
addJava1(A, B, C, D, E, F, G) :-
	methodDefT(A, B, C, D, E, F, G), !,
	format('~nWARNING: element: already exists: ~w~n.', [methodDefT(A, B, C, D, E, F, G)]).
addJava1(A, B, C, D, E, F, G) :-
	assert(methodDefT(A, B, C, D, E, F, G)),
	asserta(rollback(retract(methodDefT(A, B, C, D, E, F, G)))),
	markEnclAsDirtyJava1(A, B, C, D, E, F, G).

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', fieldDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava1(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _).

% addJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', fieldDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava1(A, B, C, D, E) :-
	fieldDefT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [fieldDefT(A, B, C, D, E)]).
addJava1(A, B, C, D, E) :-
	assert(fieldDefT(A, B, C, D, E)),
	asserta(rollback(retract(fieldDefT(A, B, C, D, E)))),
	markEnclAsDirtyJava1(A, B, C, D, E).

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', paramDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava2(A, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava2(_, _, _, _).

% addJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', paramDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava2(A, B, C, D) :-
	paramDefT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [paramDefT(A, B, C, D)]).
addJava2(A, B, C, D) :-
	assert(paramDefT(A, B, C, D)),
	asserta(rollback(retract(paramDefT(A, B, C, D)))),
	markEnclAsDirtyJava2(A, B, C, D).

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-markEnclAsDirty('Java', applyT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
markEnclAsDirtyJava2(A, _, _, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava2(_, _, _, _, _, _, _).

% addJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-add('Java', applyT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
addJava2(A, B, C, D, E, F, G) :-
	applyT(A, B, C, D, E, F, G), !,
	format('~nWARNING: element: already exists: ~w~n.', [applyT(A, B, C, D, E, F, G)]).
addJava2(A, B, C, D, E, F, G) :-
	assert(applyT(A, B, C, D, E, F, G)),
	asserta(rollback(retract(applyT(A, B, C, D, E, F, G)))),
	markEnclAsDirtyJava2(A, B, C, D, E, F, G).

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', assertT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava2(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava2(_, _, _, _, _).

% addJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', assertT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava2(A, B, C, D, E) :-
	assertT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [assertT(A, B, C, D, E)]).
addJava2(A, B, C, D, E) :-
	assert(assertT(A, B, C, D, E)),
	asserta(rollback(retract(assertT(A, B, C, D, E)))),
	markEnclAsDirtyJava2(A, B, C, D, E).

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', assignT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava3(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava3(_, _, _, _, _).

% addJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', assignT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava3(A, B, C, D, E) :-
	assignT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [assignT(A, B, C, D, E)]).
addJava3(A, B, C, D, E) :-
	assert(assignT(A, B, C, D, E)),
	asserta(rollback(retract(assignT(A, B, C, D, E)))),
	markEnclAsDirtyJava3(A, B, C, D, E).

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', assignopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava1(A, _, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _, _).

% addJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', assignopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava1(A, B, C, D, E, F) :-
	assignopT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [assignopT(A, B, C, D, E, F)]).
addJava1(A, B, C, D, E, F) :-
	assert(assignopT(A, B, C, D, E, F)),
	asserta(rollback(retract(assignopT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava1(A, B, C, D, E, F).

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', blockT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava3(A, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava3(_, _, _, _).

% addJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', blockT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava3(A, B, C, D) :-
	blockT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [blockT(A, B, C, D)]).
addJava3(A, B, C, D) :-
	assert(blockT(A, B, C, D)),
	asserta(rollback(retract(blockT(A, B, C, D)))),
	markEnclAsDirtyJava3(A, B, C, D).

% markEnclAsDirtyJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', breakT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava4(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava4(_, _, _, _, _).

% addJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', breakT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava4(A, B, C, D, E) :-
	breakT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [breakT(A, B, C, D, E)]).
addJava4(A, B, C, D, E) :-
	assert(breakT(A, B, C, D, E)),
	asserta(rollback(retract(breakT(A, B, C, D, E)))),
	markEnclAsDirtyJava4(A, B, C, D, E).

% markEnclAsDirtyJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', caseT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava4(A, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava4(_, _, _, _).

% addJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', caseT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava4(A, B, C, D) :-
	caseT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [caseT(A, B, C, D)]).
addJava4(A, B, C, D) :-
	assert(caseT(A, B, C, D)),
	asserta(rollback(retract(caseT(A, B, C, D)))),
	markEnclAsDirtyJava4(A, B, C, D).

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', conditionalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava2(A, _, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava2(_, _, _, _, _, _).

% addJava2('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', conditionalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava2(A, B, C, D, E, F) :-
	conditionalT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [conditionalT(A, B, C, D, E, F)]).
addJava2(A, B, C, D, E, F) :-
	assert(conditionalT(A, B, C, D, E, F)),
	asserta(rollback(retract(conditionalT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava2(A, B, C, D, E, F).

% markEnclAsDirtyJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', continueT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava5(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava5(_, _, _, _, _).

% addJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', continueT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava5(A, B, C, D, E) :-
	continueT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [continueT(A, B, C, D, E)]).
addJava5(A, B, C, D, E) :-
	assert(continueT(A, B, C, D, E)),
	asserta(rollback(retract(continueT(A, B, C, D, E)))),
	markEnclAsDirtyJava5(A, B, C, D, E).

% markEnclAsDirtyJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', doLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava6(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava6(_, _, _, _, _).

% addJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', doLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava6(A, B, C, D, E) :-
	doLoopT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [doLoopT(A, B, C, D, E)]).
addJava6(A, B, C, D, E) :-
	assert(doLoopT(A, B, C, D, E)),
	asserta(rollback(retract(doLoopT(A, B, C, D, E)))),
	markEnclAsDirtyJava6(A, B, C, D, E).

% markEnclAsDirtyJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', execT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava5(A, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava5(_, _, _, _).

% addJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', execT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava5(A, B, C, D) :-
	execT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [execT(A, B, C, D)]).
addJava5(A, B, C, D) :-
	assert(execT(A, B, C, D)),
	asserta(rollback(retract(execT(A, B, C, D)))),
	markEnclAsDirtyJava5(A, B, C, D).

% markEnclAsDirtyJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', catchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava7(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava7(_, _, _, _, _).

% addJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', catchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava7(A, B, C, D, E) :-
	catchT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [catchT(A, B, C, D, E)]).
addJava7(A, B, C, D, E) :-
	assert(catchT(A, B, C, D, E)),
	asserta(rollback(retract(catchT(A, B, C, D, E)))),
	markEnclAsDirtyJava7(A, B, C, D, E).

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-markEnclAsDirty('Java', forLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
markEnclAsDirtyJava3(A, _, _, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava3(_, _, _, _, _, _, _).

% addJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)):-add('Java', forLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6)))
addJava3(A, B, C, D, E, F, G) :-
	forLoopT(A, B, C, D, E, F, G), !,
	format('~nWARNING: element: already exists: ~w~n.', [forLoopT(A, B, C, D, E, F, G)]).
addJava3(A, B, C, D, E, F, G) :-
	assert(forLoopT(A, B, C, D, E, F, G)),
	asserta(rollback(retract(forLoopT(A, B, C, D, E, F, G)))),
	markEnclAsDirtyJava3(A, B, C, D, E, F, G).

% markEnclAsDirtyJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', getFieldT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava3(A, _, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava3(_, _, _, _, _, _).

% addJava3('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', getFieldT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava3(A, B, C, D, E, F) :-
	getFieldT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [getFieldT(A, B, C, D, E, F)]).
addJava3(A, B, C, D, E, F) :-
	assert(getFieldT(A, B, C, D, E, F)),
	asserta(rollback(retract(getFieldT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava3(A, B, C, D, E, F).

% markEnclAsDirtyJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', ifT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava4(A, _, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava4(_, _, _, _, _, _).

% addJava4('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', ifT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava4(A, B, C, D, E, F) :-
	ifT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [ifT(A, B, C, D, E, F)]).
addJava4(A, B, C, D, E, F) :-
	assert(ifT(A, B, C, D, E, F)),
	asserta(rollback(retract(ifT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava4(A, B, C, D, E, F).

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-markEnclAsDirty('Java', importT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
markEnclAsDirtyJava1(A, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava1(_, _, _).

% addJava1('$VAR'(0), '$VAR'(1), '$VAR'(2)):-add('Java', importT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
addJava1(A, B, C) :-
	importT(A, B, C), !,
	format('~nWARNING: element: already exists: ~w~n.', [importT(A, B, C)]).
addJava1(A, B, C) :-
	assert(importT(A, B, C)),
	asserta(rollback(retract(importT(A, B, C)))),
	markEnclAsDirtyJava1(A, B, C).

% markEnclAsDirtyJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', indexedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava8(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava8(_, _, _, _, _).

% addJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', indexedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava8(A, B, C, D, E) :-
	indexedT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [indexedT(A, B, C, D, E)]).
addJava8(A, B, C, D, E) :-
	assert(indexedT(A, B, C, D, E)),
	asserta(rollback(retract(indexedT(A, B, C, D, E)))),
	markEnclAsDirtyJava8(A, B, C, D, E).

% markEnclAsDirtyJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', labelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava9(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava9(_, _, _, _, _).

% addJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', labelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava9(A, B, C, D, E) :-
	labelT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [labelT(A, B, C, D, E)]).
addJava9(A, B, C, D, E) :-
	assert(labelT(A, B, C, D, E)),
	asserta(rollback(retract(labelT(A, B, C, D, E)))),
	markEnclAsDirtyJava9(A, B, C, D, E).

% markEnclAsDirtyJava10('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', literalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava10(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava10(_, _, _, _, _).

% addJava10('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', literalT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava10(A, B, C, D, E) :-
	literalT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [literalT(A, B, C, D, E)]).
addJava10(A, B, C, D, E) :-
	assert(literalT(A, B, C, D, E)),
	asserta(rollback(retract(literalT(A, B, C, D, E)))),
	markEnclAsDirtyJava10(A, B, C, D, E).

% markEnclAsDirtyJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', localDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava5(A, _, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava5(_, _, _, _, _, _).

% addJava5('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', localDefT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava5(A, B, C, D, E, F) :-
	localDefT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [localDefT(A, B, C, D, E, F)]).
addJava5(A, B, C, D, E, F) :-
	assert(localDefT(A, B, C, D, E, F)),
	asserta(rollback(retract(localDefT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava5(A, B, C, D, E, F).

% markEnclAsDirtyJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', newArrayT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava6(A, _, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava6(_, _, _, _, _, _).

% addJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', newArrayT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava6(A, B, C, D, E, F) :-
	newArrayT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [newArrayT(A, B, C, D, E, F)]).
addJava6(A, B, C, D, E, F) :-
	assert(newArrayT(A, B, C, D, E, F)),
	asserta(rollback(retract(newArrayT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava6(A, B, C, D, E, F).

% markEnclAsDirtyJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-markEnclAsDirty('Java', newClassT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)))
markEnclAsDirtyJava1(A, _, _, _, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava1(_, _, _, _, _, _, _, _).

% addJava1('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)):-add('Java', newClassT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5), '$VAR'(6), '$VAR'(7)))
addJava1(A, B, C, D, E, F, G, H) :-
	newClassT(A, B, C, D, E, F, G, H), !,
	format('~nWARNING: element: already exists: ~w~n.', [newClassT(A, B, C, D, E, F, G, H)]).
addJava1(A, B, C, D, E, F, G, H) :-
	assert(newClassT(A, B, C, D, E, F, G, H)),
	asserta(rollback(retract(newClassT(A, B, C, D, E, F, G, H)))),
	markEnclAsDirtyJava1(A, B, C, D, E, F, G, H).

% markEnclAsDirtyJava2('$VAR'(0), '$VAR'(1), '$VAR'(2)):-markEnclAsDirty('Java', nopT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
markEnclAsDirtyJava2(A, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava2(_, _, _).

% addJava2('$VAR'(0), '$VAR'(1), '$VAR'(2)):-add('Java', nopT('$VAR'(0), '$VAR'(1), '$VAR'(2)))
addJava2(A, B, C) :-
	nopT(A, B, C), !,
	format('~nWARNING: element: already exists: ~w~n.', [nopT(A, B, C)]).
addJava2(A, B, C) :-
	assert(nopT(A, B, C)),
	asserta(rollback(retract(nopT(A, B, C)))),
	markEnclAsDirtyJava2(A, B, C).

% markEnclAsDirtyJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', operationT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava7(A, _, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava7(_, _, _, _, _, _).

% addJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', operationT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava7(A, B, C, D, E, F) :-
	operationT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [operationT(A, B, C, D, E, F)]).
addJava7(A, B, C, D, E, F) :-
	assert(operationT(A, B, C, D, E, F)),
	asserta(rollback(retract(operationT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava7(A, B, C, D, E, F).

% markEnclAsDirtyJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', precedenceT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava6(A, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava6(_, _, _, _).

% addJava6('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', precedenceT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava6(A, B, C, D) :-
	precedenceT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [precedenceT(A, B, C, D)]).
addJava6(A, B, C, D) :-
	assert(precedenceT(A, B, C, D)),
	asserta(rollback(retract(precedenceT(A, B, C, D)))),
	markEnclAsDirtyJava6(A, B, C, D).

% markEnclAsDirtyJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', returnT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava7(A, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava7(_, _, _, _).

% addJava7('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', returnT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava7(A, B, C, D) :-
	returnT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [returnT(A, B, C, D)]).
addJava7(A, B, C, D) :-
	assert(returnT(A, B, C, D)),
	asserta(rollback(retract(returnT(A, B, C, D)))),
	markEnclAsDirtyJava7(A, B, C, D).

% markEnclAsDirtyJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', selectT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava8(A, _, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava8(_, _, _, _, _, _).

% addJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', selectT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava8(A, B, C, D, E, F) :-
	selectT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [selectT(A, B, C, D, E, F)]).
addJava8(A, B, C, D, E, F) :-
	assert(selectT(A, B, C, D, E, F)),
	asserta(rollback(retract(selectT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava8(A, B, C, D, E, F).

% markEnclAsDirtyJava11('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', identT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava11(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava11(_, _, _, _, _).

% addJava11('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', identT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava11(A, B, C, D, E) :-
	identT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [identT(A, B, C, D, E)]).
addJava11(A, B, C, D, E) :-
	assert(identT(A, B, C, D, E)),
	asserta(rollback(retract(identT(A, B, C, D, E)))),
	markEnclAsDirtyJava11(A, B, C, D, E).

% markEnclAsDirtyJava12('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', switchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava12(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava12(_, _, _, _, _).

% addJava12('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', switchT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava12(A, B, C, D, E) :-
	switchT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [switchT(A, B, C, D, E)]).
addJava12(A, B, C, D, E) :-
	assert(switchT(A, B, C, D, E)),
	asserta(rollback(retract(switchT(A, B, C, D, E)))),
	markEnclAsDirtyJava12(A, B, C, D, E).

% markEnclAsDirtyJava13('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', synchronizedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava13(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava13(_, _, _, _, _).

% addJava13('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', synchronizedT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava13(A, B, C, D, E) :-
	synchronizedT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [synchronizedT(A, B, C, D, E)]).
addJava13(A, B, C, D, E) :-
	assert(synchronizedT(A, B, C, D, E)),
	asserta(rollback(retract(synchronizedT(A, B, C, D, E)))),
	markEnclAsDirtyJava13(A, B, C, D, E).

% markEnclAsDirtyJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', throwT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava8(A, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava8(_, _, _, _).

% addJava8('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', throwT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava8(A, B, C, D) :-
	throwT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [throwT(A, B, C, D)]).
addJava8(A, B, C, D) :-
	assert(throwT(A, B, C, D)),
	asserta(rollback(retract(throwT(A, B, C, D)))),
	markEnclAsDirtyJava8(A, B, C, D).

% markEnclAsDirtyJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-markEnclAsDirty('Java', toplevelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
markEnclAsDirtyJava9(A, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava9(_, _, _, _).

% addJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)):-add('Java', toplevelT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3)))
addJava9(A, B, C, D) :-
	toplevelT(A, B, C, D), !,
	format('~nWARNING: element: already exists: ~w~n.', [toplevelT(A, B, C, D)]).
addJava9(A, B, C, D) :-
	assert(toplevelT(A, B, C, D)),
	asserta(rollback(retract(toplevelT(A, B, C, D)))),
	markEnclAsDirtyJava9(A, B, C, D).

% markEnclAsDirtyJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-markEnclAsDirty('Java', tryT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
markEnclAsDirtyJava9(A, _, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava9(_, _, _, _, _, _).

% addJava9('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)):-add('Java', tryT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4), '$VAR'(5)))
addJava9(A, B, C, D, E, F) :-
	tryT(A, B, C, D, E, F), !,
	format('~nWARNING: element: already exists: ~w~n.', [tryT(A, B, C, D, E, F)]).
addJava9(A, B, C, D, E, F) :-
	assert(tryT(A, B, C, D, E, F)),
	asserta(rollback(retract(tryT(A, B, C, D, E, F)))),
	markEnclAsDirtyJava9(A, B, C, D, E, F).

% markEnclAsDirtyJava14('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', typeCastT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava14(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava14(_, _, _, _, _).

% addJava14('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', typeCastT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava14(A, B, C, D, E) :-
	typeCastT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [typeCastT(A, B, C, D, E)]).
addJava14(A, B, C, D, E) :-
	assert(typeCastT(A, B, C, D, E)),
	asserta(rollback(retract(typeCastT(A, B, C, D, E)))),
	markEnclAsDirtyJava14(A, B, C, D, E).

% markEnclAsDirtyJava15('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', typeTestT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava15(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava15(_, _, _, _, _).

% addJava15('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', typeTestT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava15(A, B, C, D, E) :-
	typeTestT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [typeTestT(A, B, C, D, E)]).
addJava15(A, B, C, D, E) :-
	assert(typeTestT(A, B, C, D, E)),
	asserta(rollback(retract(typeTestT(A, B, C, D, E)))),
	markEnclAsDirtyJava15(A, B, C, D, E).

% markEnclAsDirtyJava16('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-markEnclAsDirty('Java', whileLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
markEnclAsDirtyJava16(A, _, _, _, _) :-
	get_ast_node_labelJava1(A),
	(   get_ast_node_enclosingJava2(A, B),
	    '\\+=1'(B),
	    '\\+get_ast_node_labelJava1'(B),
	    assert1T(dirty_tree('Java', B)), !
	;   assert1T(dirty_tree('Java', A)), !
	).
markEnclAsDirtyJava16(_, _, _, _, _).

% addJava16('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)):-add('Java', whileLoopT('$VAR'(0), '$VAR'(1), '$VAR'(2), '$VAR'(3), '$VAR'(4)))
addJava16(A, B, C, D, E) :-
	whileLoopT(A, B, C, D, E), !,
	format('~nWARNING: element: already exists: ~w~n.', [whileLoopT(A, B, C, D, E)]).
addJava16(A, B, C, D, E) :-
	assert(whileLoopT(A, B, C, D, E)),
	asserta(rollback(retract(whileLoopT(A, B, C, D, E)))),
	markEnclAsDirtyJava16(A, B, C, D, E).
set_ast_node_enclosing('Java', A, B) :-
	set_ast_node_enclosingJava1(A, B).

% set_ast_node_enclosingJava1('$VAR'(0), '$VAR'(1)):-set_ast_node_enclosing('Java', '$VAR'(0), '$VAR'(1))
set_ast_node_enclosingJava1(A, _) :-
	packageT(A, B),
	retract(packageT(A, B)),
	markEnclAsDirtyJava1(A, B),
	asserta(rollback(assert(packageT(A, B)))),
	addJava1(A, B).
set_ast_node_enclosingJava1(A, _) :-
	classDefT(A, B, C, D),
	retract(classDefT(A, B, C, D)),
	markEnclAsDirtyJava1(A, B, C, D),
	asserta(rollback(assert(classDefT(A, B, C, D)))),
	addJava1(A, B, C, D).
set_ast_node_enclosingJava1(A, _) :-
	methodDefT(A, B, C, D, E, F, G),
	retract(methodDefT(A, B, C, D, E, F, G)),
	markEnclAsDirtyJava1(A, B, C, D, E, F, G),
	asserta(rollback(assert(methodDefT(A, B, C, D, E, F, G)))),
	addJava1(A, B, C, D, E, F, G).
set_ast_node_enclosingJava1(A, _) :-
	fieldDefT(A, B, C, D, E),
	retract(fieldDefT(A, B, C, D, E)),
	markEnclAsDirtyJava1(A, B, C, D, E),
	asserta(rollback(assert(fieldDefT(A, B, C, D, E)))),
	addJava1(A, B, C, D, E).
set_ast_node_enclosingJava1(A, _) :-
	paramDefT(A, B, C, D),
	retract(paramDefT(A, B, C, D)),
	markEnclAsDirtyJava2(A, B, C, D),
	asserta(rollback(assert(paramDefT(A, B, C, D)))),
	addJava2(A, B, C, D).
set_ast_node_enclosingJava1(A, H) :-
	applyT(A, B, C, D, E, F, G),
	retract(applyT(A, B, C, D, E, F, G)),
	markEnclAsDirtyJava2(A, B, C, D, E, F, G),
	asserta(rollback(assert(applyT(A, B, C, D, E, F, G)))),
	addJava2(A, B, H, D, E, F, G).
set_ast_node_enclosingJava1(A, F) :-
	assertT(A, B, C, D, E),
	retract(assertT(A, B, C, D, E)),
	markEnclAsDirtyJava2(A, B, C, D, E),
	asserta(rollback(assert(assertT(A, B, C, D, E)))),
	addJava2(A, B, F, D, E).
set_ast_node_enclosingJava1(A, F) :-
	assignT(A, B, C, D, E),
	retract(assignT(A, B, C, D, E)),
	markEnclAsDirtyJava3(A, B, C, D, E),
	asserta(rollback(assert(assignT(A, B, C, D, E)))),
	addJava3(A, B, F, D, E).
set_ast_node_enclosingJava1(A, G) :-
	assignopT(A, B, C, D, E, F),
	retract(assignopT(A, B, C, D, E, F)),
	markEnclAsDirtyJava1(A, B, C, D, E, F),
	asserta(rollback(assert(assignopT(A, B, C, D, E, F)))),
	addJava1(A, B, G, D, E, F).
set_ast_node_enclosingJava1(A, E) :-
	blockT(A, B, C, D),
	retract(blockT(A, B, C, D)),
	markEnclAsDirtyJava3(A, B, C, D),
	asserta(rollback(assert(blockT(A, B, C, D)))),
	addJava3(A, B, E, D).
set_ast_node_enclosingJava1(A, F) :-
	breakT(A, B, C, D, E),
	retract(breakT(A, B, C, D, E)),
	markEnclAsDirtyJava4(A, B, C, D, E),
	asserta(rollback(assert(breakT(A, B, C, D, E)))),
	addJava4(A, B, F, D, E).
set_ast_node_enclosingJava1(A, E) :-
	caseT(A, B, C, D),
	retract(caseT(A, B, C, D)),
	markEnclAsDirtyJava4(A, B, C, D),
	asserta(rollback(assert(caseT(A, B, C, D)))),
	addJava4(A, B, E, D).
set_ast_node_enclosingJava1(A, G) :-
	conditionalT(A, B, C, D, E, F),
	retract(conditionalT(A, B, C, D, E, F)),
	markEnclAsDirtyJava2(A, B, C, D, E, F),
	asserta(rollback(assert(conditionalT(A, B, C, D, E, F)))),
	addJava2(A, B, G, D, E, F).
set_ast_node_enclosingJava1(A, F) :-
	continueT(A, B, C, D, E),
	retract(continueT(A, B, C, D, E)),
	markEnclAsDirtyJava5(A, B, C, D, E),
	asserta(rollback(assert(continueT(A, B, C, D, E)))),
	addJava5(A, B, F, D, E).
set_ast_node_enclosingJava1(A, F) :-
	doLoopT(A, B, C, D, E),
	retract(doLoopT(A, B, C, D, E)),
	markEnclAsDirtyJava6(A, B, C, D, E),
	asserta(rollback(assert(doLoopT(A, B, C, D, E)))),
	addJava6(A, B, F, D, E).
set_ast_node_enclosingJava1(A, E) :-
	execT(A, B, C, D),
	retract(execT(A, B, C, D)),
	markEnclAsDirtyJava5(A, B, C, D),
	asserta(rollback(assert(execT(A, B, C, D)))),
	addJava5(A, B, E, D).
set_ast_node_enclosingJava1(A, F) :-
	catchT(A, B, C, D, E),
	retract(catchT(A, B, C, D, E)),
	markEnclAsDirtyJava7(A, B, C, D, E),
	asserta(rollback(assert(catchT(A, B, C, D, E)))),
	addJava7(A, B, F, D, E).
set_ast_node_enclosingJava1(A, H) :-
	forLoopT(A, B, C, D, E, F, G),
	retract(forLoopT(A, B, C, D, E, F, G)),
	markEnclAsDirtyJava3(A, B, C, D, E, F, G),
	asserta(rollback(assert(forLoopT(A, B, C, D, E, F, G)))),
	addJava3(A, B, H, D, E, F, G).
set_ast_node_enclosingJava1(A, G) :-
	getFieldT(A, B, C, D, E, F),
	retract(getFieldT(A, B, C, D, E, F)),
	markEnclAsDirtyJava3(A, B, C, D, E, F),
	asserta(rollback(assert(getFieldT(A, B, C, D, E, F)))),
	addJava3(A, B, G, D, E, F).
set_ast_node_enclosingJava1(A, G) :-
	ifT(A, B, C, D, E, F),
	retract(ifT(A, B, C, D, E, F)),
	markEnclAsDirtyJava4(A, B, C, D, E, F),
	asserta(rollback(assert(ifT(A, B, C, D, E, F)))),
	addJava4(A, B, G, D, E, F).
set_ast_node_enclosingJava1(A, _) :-
	importT(A, B, C),
	retract(importT(A, B, C)),
	markEnclAsDirtyJava1(A, B, C),
	asserta(rollback(assert(importT(A, B, C)))),
	addJava1(A, B, C).
set_ast_node_enclosingJava1(A, F) :-
	indexedT(A, B, C, D, E),
	retract(indexedT(A, B, C, D, E)),
	markEnclAsDirtyJava8(A, B, C, D, E),
	asserta(rollback(assert(indexedT(A, B, C, D, E)))),
	addJava8(A, B, F, D, E).
set_ast_node_enclosingJava1(A, F) :-
	labelT(A, B, C, D, E),
	retract(labelT(A, B, C, D, E)),
	markEnclAsDirtyJava9(A, B, C, D, E),
	asserta(rollback(assert(labelT(A, B, C, D, E)))),
	addJava9(A, B, F, D, E).
set_ast_node_enclosingJava1(A, F) :-
	literalT(A, B, C, D, E),
	retract(literalT(A, B, C, D, E)),
	markEnclAsDirtyJava10(A, B, C, D, E),
	asserta(rollback(assert(literalT(A, B, C, D, E)))),
	addJava10(A, B, F, D, E).
set_ast_node_enclosingJava1(A, G) :-
	localDefT(A, B, C, D, E, F),
	retract(localDefT(A, B, C, D, E, F)),
	markEnclAsDirtyJava5(A, B, C, D, E, F),
	asserta(rollback(assert(localDefT(A, B, C, D, E, F)))),
	addJava5(A, B, G, D, E, F).
set_ast_node_enclosingJava1(A, G) :-
	newArrayT(A, B, C, D, E, F),
	retract(newArrayT(A, B, C, D, E, F)),
	markEnclAsDirtyJava6(A, B, C, D, E, F),
	asserta(rollback(assert(newArrayT(A, B, C, D, E, F)))),
	addJava6(A, B, G, D, E, F).
set_ast_node_enclosingJava1(A, I) :-
	newClassT(A, B, C, D, E, F, G, H),
	retract(newClassT(A, B, C, D, E, F, G, H)),
	markEnclAsDirtyJava1(A, B, C, D, E, F, G, H),
	asserta(rollback(assert(newClassT(A, B, C, D, E, F, G, H)))),
	addJava1(A, B, I, D, E, F, G, H).
set_ast_node_enclosingJava1(A, D) :-
	nopT(A, B, C),
	retract(nopT(A, B, C)),
	markEnclAsDirtyJava2(A, B, C),
	asserta(rollback(assert(nopT(A, B, C)))),
	addJava2(A, B, D).
set_ast_node_enclosingJava1(A, G) :-
	operationT(A, B, C, D, E, F),
	retract(operationT(A, B, C, D, E, F)),
	markEnclAsDirtyJava7(A, B, C, D, E, F),
	asserta(rollback(assert(operationT(A, B, C, D, E, F)))),
	addJava7(A, B, G, D, E, F).
set_ast_node_enclosingJava1(A, E) :-
	precedenceT(A, B, C, D),
	retract(precedenceT(A, B, C, D)),
	markEnclAsDirtyJava6(A, B, C, D),
	asserta(rollback(assert(precedenceT(A, B, C, D)))),
	addJava6(A, B, E, D).
set_ast_node_enclosingJava1(A, E) :-
	returnT(A, B, C, D),
	retract(returnT(A, B, C, D)),
	markEnclAsDirtyJava7(A, B, C, D),
	asserta(rollback(assert(returnT(A, B, C, D)))),
	addJava7(A, B, E, D).
set_ast_node_enclosingJava1(A, G) :-
	selectT(A, B, C, D, E, F),
	retract(selectT(A, B, C, D, E, F)),
	markEnclAsDirtyJava8(A, B, C, D, E, F),
	asserta(rollback(assert(selectT(A, B, C, D, E, F)))),
	addJava8(A, B, G, D, E, F).
set_ast_node_enclosingJava1(A, F) :-
	identT(A, B, C, D, E),
	retract(identT(A, B, C, D, E)),
	markEnclAsDirtyJava11(A, B, C, D, E),
	asserta(rollback(assert(identT(A, B, C, D, E)))),
	addJava11(A, B, F, D, E).
set_ast_node_enclosingJava1(A, F) :-
	switchT(A, B, C, D, E),
	retract(switchT(A, B, C, D, E)),
	markEnclAsDirtyJava12(A, B, C, D, E),
	asserta(rollback(assert(switchT(A, B, C, D, E)))),
	addJava12(A, B, F, D, E).
set_ast_node_enclosingJava1(A, F) :-
	synchronizedT(A, B, C, D, E),
	retract(synchronizedT(A, B, C, D, E)),
	markEnclAsDirtyJava13(A, B, C, D, E),
	asserta(rollback(assert(synchronizedT(A, B, C, D, E)))),
	addJava13(A, B, F, D, E).
set_ast_node_enclosingJava1(A, E) :-
	throwT(A, B, C, D),
	retract(throwT(A, B, C, D)),
	markEnclAsDirtyJava8(A, B, C, D),
	asserta(rollback(assert(throwT(A, B, C, D)))),
	addJava8(A, B, E, D).
set_ast_node_enclosingJava1(A, _) :-
	toplevelT(A, B, C, D),
	retract(toplevelT(A, B, C, D)),
	markEnclAsDirtyJava9(A, B, C, D),
	asserta(rollback(assert(toplevelT(A, B, C, D)))),
	addJava9(A, B, C, D).
set_ast_node_enclosingJava1(A, G) :-
	tryT(A, B, C, D, E, F),
	retract(tryT(A, B, C, D, E, F)),
	markEnclAsDirtyJava9(A, B, C, D, E, F),
	asserta(rollback(assert(tryT(A, B, C, D, E, F)))),
	addJava9(A, B, G, D, E, F).
set_ast_node_enclosingJava1(A, F) :-
	typeCastT(A, B, C, D, E),
	retract(typeCastT(A, B, C, D, E)),
	markEnclAsDirtyJava14(A, B, C, D, E),
	asserta(rollback(assert(typeCastT(A, B, C, D, E)))),
	addJava14(A, B, F, D, E).
set_ast_node_enclosingJava1(A, F) :-
	typeTestT(A, B, C, D, E),
	retract(typeTestT(A, B, C, D, E)),
	markEnclAsDirtyJava15(A, B, C, D, E),
	asserta(rollback(assert(typeTestT(A, B, C, D, E)))),
	addJava15(A, B, F, D, E).
set_ast_node_enclosingJava1(A, F) :-
	whileLoopT(A, B, C, D, E),
	retract(whileLoopT(A, B, C, D, E)),
	markEnclAsDirtyJava16(A, B, C, D, E),
	asserta(rollback(assert(whileLoopT(A, B, C, D, E)))),
	addJava16(A, B, F, D, E).
set_ast_node_enclosingJava1(A, E) :-
	paramDefT(A, B, C, D), !,
	retract(paramDefT(A, B, C, D)),
	markEnclAsDirtyJava2(A, B, C, D),
	asserta(rollback(assert(paramDefT(A, B, C, D)))),
	addJava2(A, E, C, D).
checkIfTopLevel('Java', A) :-
	checkIfTopLevelJava1(A).

% checkIfTopLevelJava1('$VAR'(0)):-checkIfTopLevel('Java', '$VAR'(0))
checkIfTopLevelJava1(A) :-
	classDefT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	methodDefT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	fieldDefT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	paramDefT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	applyT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assertT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assignT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	assignopT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	blockT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	breakT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	caseT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	conditionalT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	continueT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	doLoopT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	execT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	catchT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	forLoopT(A, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	getFieldT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	ifT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	importT(A, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	indexedT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	labelT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	literalT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	localDefT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	newArrayT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	newClassT(A, _, _, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	nopT(A, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	operationT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	precedenceT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	returnT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	selectT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	identT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	switchT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	synchronizedT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	throwT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	toplevelT(A, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	tryT(A, _, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	typeCastT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	typeTestT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	whileLoopT(A, _, _, _, _), !,
	fail.
checkIfTopLevelJava1(A) :-
	packageT(A, _), !,
	fail.
checkIfTopLevelJava1(_).
delete_ast_node('Java', A) :-
	delete_ast_nodeJava1(A).

% delete_ast_nodeJava1('$VAR'(0)):-delete_ast_node('Java', '$VAR'(0))
delete_ast_nodeJava1(A) :-
	get_ast_node_termJava1(A, B),
	deleteJava1(B), !.
delete_ast_nodeJava1(A) :-
	nopT(A, B, C), !,
	retract(nopT(A, B, C)),
	markEnclAsDirtyJava2(A, B, C),
	asserta(rollback(assert(nopT(A, B, C)))).
delete_ast_nodeJava1(A) :-
	get_ast_node_termJava1(A), !,
	fail.
delete_ast_nodeJava1(A) :-
	format('could not retract id: ~a~n', [A]).

% get_ast_node_termJava1('$VAR'(0), '$VAR'(1)):-get_ast_node_term('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_termJava1(A, packageT(A, B)) :-
	packageT(A, B), !.
get_ast_node_termJava1(A, classDefT(A, B, C, D)) :-
	classDefT(A, B, C, D), !.
get_ast_node_termJava1(A, methodDefT(A, B, C, D, E, F, G)) :-
	methodDefT(A, B, C, D, E, F, G), !.
get_ast_node_termJava1(A, fieldDefT(A, B, C, D, E)) :-
	fieldDefT(A, B, C, D, E), !.
get_ast_node_termJava1(A, paramDefT(A, B, C, D)) :-
	paramDefT(A, B, C, D), !.
get_ast_node_termJava1(A, applyT(A, B, C, D, E, F, G)) :-
	applyT(A, B, C, D, E, F, G), !.
get_ast_node_termJava1(A, assertT(A, B, C, D, E)) :-
	assertT(A, B, C, D, E), !.
get_ast_node_termJava1(A, assignT(A, B, C, D, E)) :-
	assignT(A, B, C, D, E), !.
get_ast_node_termJava1(A, assignopT(A, B, C, D, E, F)) :-
	assignopT(A, B, C, D, E, F), !.
get_ast_node_termJava1(A, blockT(A, B, C, D)) :-
	blockT(A, B, C, D), !.
get_ast_node_termJava1(A, breakT(A, B, C, D, E)) :-
	breakT(A, B, C, D, E), !.
get_ast_node_termJava1(A, caseT(A, B, C, D)) :-
	caseT(A, B, C, D), !.
get_ast_node_termJava1(A, conditionalT(A, B, C, D, E, F)) :-
	conditionalT(A, B, C, D, E, F), !.
get_ast_node_termJava1(A, continueT(A, B, C, D, E)) :-
	continueT(A, B, C, D, E), !.
get_ast_node_termJava1(A, doLoopT(A, B, C, D, E)) :-
	doLoopT(A, B, C, D, E), !.
get_ast_node_termJava1(A, execT(A, B, C, D)) :-
	execT(A, B, C, D), !.
get_ast_node_termJava1(A, catchT(A, B, C, D, E)) :-
	catchT(A, B, C, D, E), !.
get_ast_node_termJava1(A, forLoopT(A, B, C, D, E, F, G)) :-
	forLoopT(A, B, C, D, E, F, G), !.
get_ast_node_termJava1(A, getFieldT(A, B, C, D, E, F)) :-
	getFieldT(A, B, C, D, E, F), !.
get_ast_node_termJava1(A, ifT(A, B, C, D, E, F)) :-
	ifT(A, B, C, D, E, F), !.
get_ast_node_termJava1(A, importT(A, B, C)) :-
	importT(A, B, C), !.
get_ast_node_termJava1(A, indexedT(A, B, C, D, E)) :-
	indexedT(A, B, C, D, E), !.
get_ast_node_termJava1(A, labelT(A, B, C, D, E)) :-
	labelT(A, B, C, D, E), !.
get_ast_node_termJava1(A, literalT(A, B, C, D, E)) :-
	literalT(A, B, C, D, E), !.
get_ast_node_termJava1(A, localDefT(A, B, C, D, E, F)) :-
	localDefT(A, B, C, D, E, F), !.
get_ast_node_termJava1(A, newArrayT(A, B, C, D, E, F)) :-
	newArrayT(A, B, C, D, E, F), !.
get_ast_node_termJava1(A, newClassT(A, B, C, D, E, F, G, H)) :-
	newClassT(A, B, C, D, E, F, G, H), !.
get_ast_node_termJava1(A, nopT(A, B, C)) :-
	nopT(A, B, C), !.
get_ast_node_termJava1(A, operationT(A, B, C, D, E, F)) :-
	operationT(A, B, C, D, E, F), !.
get_ast_node_termJava1(A, precedenceT(A, B, C, D)) :-
	precedenceT(A, B, C, D), !.
get_ast_node_termJava1(A, returnT(A, B, C, D)) :-
	returnT(A, B, C, D), !.
get_ast_node_termJava1(A, selectT(A, B, C, D, E, F)) :-
	selectT(A, B, C, D, E, F), !.
get_ast_node_termJava1(A, identT(A, B, C, D, E)) :-
	identT(A, B, C, D, E), !.
get_ast_node_termJava1(A, switchT(A, B, C, D, E)) :-
	switchT(A, B, C, D, E), !.
get_ast_node_termJava1(A, synchronizedT(A, B, C, D, E)) :-
	synchronizedT(A, B, C, D, E), !.
get_ast_node_termJava1(A, throwT(A, B, C, D)) :-
	throwT(A, B, C, D), !.
get_ast_node_termJava1(A, toplevelT(A, B, C, D)) :-
	toplevelT(A, B, C, D), !.
get_ast_node_termJava1(A, tryT(A, B, C, D, E, F)) :-
	tryT(A, B, C, D, E, F), !.
get_ast_node_termJava1(A, typeCastT(A, B, C, D, E)) :-
	typeCastT(A, B, C, D, E), !.
get_ast_node_termJava1(A, typeTestT(A, B, C, D, E)) :-
	typeTestT(A, B, C, D, E), !.
get_ast_node_termJava1(A, whileLoopT(A, B, C, D, E)) :-
	whileLoopT(A, B, C, D, E), !.

% deleteJava1('$VAR'(0)):-delete('Java', '$VAR'(0))
deleteJava1(java_fq(A)) :- !,
	java_fq_to_pef1(A, B),
	deleteJava1(B).
deleteJava1(A) :-
	nonvar(A),
	retract(A),
	markEnclAsDirtyJava2(A),
	asserta(rollback(assert(A))).
%Warning: Unbound variable found as a goal.
%         Potentially all original code is needed.

% markEnclAsDirtyJava2('$VAR'(0)):-markEnclAsDirty('Java', '$VAR'(0))
markEnclAsDirtyJava2(A) :-
	arg(1, A, B),
	get_ast_node_labelJava1(B),
	(   get_ast_node_enclosingJava2(B, C),
	    '\\+=1'(C),
	    '\\+get_ast_node_labelJava1'(C),
	    assert1T(dirty_tree('Java', C)), !
	;   assert1T(dirty_tree('Java', B)), !
	).
markEnclAsDirtyJava2(_).

% get_ast_node_termJava1('$VAR'(0)):-get_ast_node_term('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_termJava1(A) :-
	packageT(A, _), !.
get_ast_node_termJava1(A) :-
	classDefT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	methodDefT(A, _, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	fieldDefT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	paramDefT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	applyT(A, _, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	assertT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	assignT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	assignopT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	blockT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	breakT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	caseT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	conditionalT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	continueT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	doLoopT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	execT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	catchT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	forLoopT(A, _, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	getFieldT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	ifT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	importT(A, _, _), !.
get_ast_node_termJava1(A) :-
	indexedT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	labelT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	literalT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	localDefT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	newArrayT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	newClassT(A, _, _, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	nopT(A, _, _), !.
get_ast_node_termJava1(A) :-
	operationT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	precedenceT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	returnT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	selectT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	identT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	switchT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	synchronizedT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	throwT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	toplevelT(A, _, _, _), !.
get_ast_node_termJava1(A) :-
	tryT(A, _, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	typeCastT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	typeTestT(A, _, _, _, _), !.
get_ast_node_termJava1(A) :-
	whileLoopT(A, _, _, _, _), !.
retract_ast_node('Java', A) :-
	retract_ast_nodeJava1(A).

% retract_ast_nodeJava1('$VAR'(0)):-retract_ast_node('Java', '$VAR'(0))
retract_ast_nodeJava1(A) :-
	get_ast_node_termJava1(A, B),
	retract(B), !.
retract_ast_nodeJava1(A) :-
	nopT(A, B, C), !,
	retract(nopT(A, B, C)).
retract_ast_nodeJava1(A) :-
	get_ast_node_termJava1(A), !,
	fail.
retract_ast_nodeJava1(A) :-
	format('could not retract id: ~a~n', [A]).
%Warning: Unbound variable found as a goal.
%         Potentially all original code is needed.
get_ast_node_term('Java', A, B) :-
	get_ast_node_termJava2(A, B).

% get_ast_node_termJava2('$VAR'(0), '$VAR'(1)):-get_ast_node_term('Java', '$VAR'(0), '$VAR'(1))
get_ast_node_termJava2(A, packageT(A, B)) :-
	packageT(A, B), !.
get_ast_node_termJava2(A, classDefT(A, B, C, D)) :-
	classDefT(A, B, C, D), !.
get_ast_node_termJava2(A, methodDefT(A, B, C, D, E, F, G)) :-
	methodDefT(A, B, C, D, E, F, G), !.
get_ast_node_termJava2(A, fieldDefT(A, B, C, D, E)) :-
	fieldDefT(A, B, C, D, E), !.
get_ast_node_termJava2(A, paramDefT(A, B, C, D)) :-
	paramDefT(A, B, C, D), !.
get_ast_node_termJava2(A, applyT(A, B, C, D, E, F, G)) :-
	applyT(A, B, C, D, E, F, G), !.
get_ast_node_termJava2(A, assertT(A, B, C, D, E)) :-
	assertT(A, B, C, D, E), !.
get_ast_node_termJava2(A, assignT(A, B, C, D, E)) :-
	assignT(A, B, C, D, E), !.
get_ast_node_termJava2(A, assignopT(A, B, C, D, E, F)) :-
	assignopT(A, B, C, D, E, F), !.
get_ast_node_termJava2(A, blockT(A, B, C, D)) :-
	blockT(A, B, C, D), !.
get_ast_node_termJava2(A, breakT(A, B, C, D, E)) :-
	breakT(A, B, C, D, E), !.
get_ast_node_termJava2(A, caseT(A, B, C, D)) :-
	caseT(A, B, C, D), !.
get_ast_node_termJava2(A, conditionalT(A, B, C, D, E, F)) :-
	conditionalT(A, B, C, D, E, F), !.
get_ast_node_termJava2(A, continueT(A, B, C, D, E)) :-
	continueT(A, B, C, D, E), !.
get_ast_node_termJava2(A, doLoopT(A, B, C, D, E)) :-
	doLoopT(A, B, C, D, E), !.
get_ast_node_termJava2(A, execT(A, B, C, D)) :-
	execT(A, B, C, D), !.
get_ast_node_termJava2(A, catchT(A, B, C, D, E)) :-
	catchT(A, B, C, D, E), !.
get_ast_node_termJava2(A, forLoopT(A, B, C, D, E, F, G)) :-
	forLoopT(A, B, C, D, E, F, G), !.
get_ast_node_termJava2(A, getFieldT(A, B, C, D, E, F)) :-
	getFieldT(A, B, C, D, E, F), !.
get_ast_node_termJava2(A, ifT(A, B, C, D, E, F)) :-
	ifT(A, B, C, D, E, F), !.
get_ast_node_termJava2(A, importT(A, B, C)) :-
	importT(A, B, C), !.
get_ast_node_termJava2(A, indexedT(A, B, C, D, E)) :-
	indexedT(A, B, C, D, E), !.
get_ast_node_termJava2(A, labelT(A, B, C, D, E)) :-
	labelT(A, B, C, D, E), !.
get_ast_node_termJava2(A, literalT(A, B, C, D, E)) :-
	literalT(A, B, C, D, E), !.
get_ast_node_termJava2(A, localDefT(A, B, C, D, E, F)) :-
	localDefT(A, B, C, D, E, F), !.
get_ast_node_termJava2(A, newArrayT(A, B, C, D, E, F)) :-
	newArrayT(A, B, C, D, E, F), !.
get_ast_node_termJava2(A, newClassT(A, B, C, D, E, F, G, H)) :-
	newClassT(A, B, C, D, E, F, G, H), !.
get_ast_node_termJava2(A, nopT(A, B, C)) :-
	nopT(A, B, C), !.
get_ast_node_termJava2(A, operationT(A, B, C, D, E, F)) :-
	operationT(A, B, C, D, E, F), !.
get_ast_node_termJava2(A, precedenceT(A, B, C, D)) :-
	precedenceT(A, B, C, D), !.
get_ast_node_termJava2(A, returnT(A, B, C, D)) :-
	returnT(A, B, C, D), !.
get_ast_node_termJava2(A, selectT(A, B, C, D, E, F)) :-
	selectT(A, B, C, D, E, F), !.
get_ast_node_termJava2(A, identT(A, B, C, D, E)) :-
	identT(A, B, C, D, E), !.
get_ast_node_termJava2(A, switchT(A, B, C, D, E)) :-
	switchT(A, B, C, D, E), !.
get_ast_node_termJava2(A, synchronizedT(A, B, C, D, E)) :-
	synchronizedT(A, B, C, D, E), !.
get_ast_node_termJava2(A, throwT(A, B, C, D)) :-
	throwT(A, B, C, D), !.
get_ast_node_termJava2(A, toplevelT(A, B, C, D)) :-
	toplevelT(A, B, C, D), !.
get_ast_node_termJava2(A, tryT(A, B, C, D, E, F)) :-
	tryT(A, B, C, D, E, F), !.
get_ast_node_termJava2(A, typeCastT(A, B, C, D, E)) :-
	typeCastT(A, B, C, D, E), !.
get_ast_node_termJava2(A, typeTestT(A, B, C, D, E)) :-
	typeTestT(A, B, C, D, E), !.
get_ast_node_termJava2(A, whileLoopT(A, B, C, D, E)) :-
	whileLoopT(A, B, C, D, E), !.
