% Author: Sebastian Lorenz
% Date: 7/20/2006

:- consult(conf_paths).

%F�r Test von JTransformer
:- consult('g:/da/work/jtransformer/main').
%Alte, urspr�ngliche JT-Pr�dikate f�r Vergleiche laden:
:- consult(jtransformer('changed_predicates')).
:- consult(jtransformer('removed_predicates')).


%F�r Test von StarTransformer
%:- consult(pe_environment).

%F�r Test von StarTransformer-Java
%:- consult('d:/petest/main').

%Dagmars CTs
:- consult('g:/da/work/testmaterial/analysispredicatesforjava/load').
:- consult('g:/da/work/testmaterial/refactoringsascts/load').


test :-
    consult(home('FactBaseExportVonJHOTDraw')),
    consult(home('encapsulateField')),
    time(encapsulateField(_,_,_,_,_)).
    
    
%delete ALL classes
cvb :-
    classDefT(ClassID, _, ClassName, _),
    methodDefT(_MethodID, ClassID, MethodName, _ParameterIDs, _, _, _),
    concat('pre_',MethodName,NewMethodName),
    time(apply_ct(renameMethod(ClassName, MethodName, _Parameters, NewMethodName))),
    fail.
cvb.
/*
    consult(home('FactBaseExportVonJHOTDraw')),
    time(apply_ct(deleteClass('TriangleFigure'))).
*/

   /* classDefT(_, _, ClassName, _),
    time(apply_ct(deleteClass(ClassName))),
    fail.*/



