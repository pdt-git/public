% Author: Sebastian, G�nter
% Date: 2/9/2006

/*************************************************************************
Pfade und Aliase

Konvention: Alle JTransformer bestreffenden Pfade tragen das Pr�fix "jt_"
            F�r die Ergebnispfade gelten die gleichen Namen wie f�r JTrans-
            former, nur da� das Pr�fix hier "pe_results_" lautet
Diese Konvention wird in folgenden Dateien genutzt: [zu erg�nzen]
**************************************************************************/

store_search_path(Alias, Env, PostFix) :-
   dummy_getenv( Env, Path),
   %getenv( Env, Path),
   concat(Path, PostFix, FullPath),
   assert( file_search_path(Alias, FullPath)).

% Enter your path here if working with the SWI-Prolog-Editor for Windows:').
%dummy_getenv('WORK_HOME', 'G:/DA/PEForStarTransformer/').
dummy_getenv('WORK_HOME', 'L:/Work/gk/gk/data/forschungEigene/code/optima/code-v2-final/PE4StarTransformer').

%home
:- store_search_path(home,'WORK_HOME','').

%Mixtus
:- store_search_path( mixtus, 'WORK_HOME', '/Mixtus' ).


/*------------- JTransformer NG aus CVS ----------------------------------*/
/*
%JTransformer Kern
:- store_search_path(jtransformer, 'WORK_HOME', '/JTransformer').
:- store_search_path(jt_engine, 'WORK_HOME', '/JTransformer/engine').
%JTransformer Java-Daten (ausgelagert)
:- store_search_path(jt_java, 'WORK_HOME', '/JTransformer/st.java/pl').
*/

%StarTransformer Verzeichnis
:- store_search_path(st_dir, 'WORK_HOME', '/StarTransformer').
%StarTransformer Kern
:- store_search_path(st_engine, 'WORK_HOME', '/StarTransformer/engine').
%StarTransformer Java-Daten (ausgelagert)
:- store_search_path(st_java, 'WORK_HOME', '/StarTransformer/st.java/pl').


%Verzeichnisse f�r Ergebnisse der partiellen Auswertung
:- store_search_path(pe_results,'WORK_HOME','/PE_Results').
:- store_search_path(pe_results_engine, 'WORK_HOME', '/PE_Results/engine').
:- store_search_path(pe_results_java, 'WORK_HOME', '/PE_Results/st.java/pl').

delete_stored_paths :- 
    retractall(file_search_path(home, _)),
    retractall(file_search_path(mixtus, _)),
    
    retractall(file_search_path(st_dir, _)),
    retractall(file_search_path(st_engine, _)),
    retractall(file_search_path(st_java, _)),
    
    retractall(file_search_path(pe_results, _)),
    retractall(file_search_path(pe_results_engine, _)),
    retractall(file_search_path(pe_results_java, _)),
    true.


