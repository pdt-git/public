% Author:
% Date: 2/22/2006

%In dieser Datei werden alle Zeittests f�r JTransformer get�tigt

%:- consult(conf_paths).
%:- consult(conf_jtransformer).

allSols(Pred) :- Pred, fail.

timeTest(Pred) :-
            time(Pred).

/*
%von ast_node_def/3 abh�ngige Pr�dikate:
:- timeTest(ast_node_term('Java',_)).
%:- timeTest(consistent('Java')).
:- timeTest(ast_node_signature('Java',_,_)).
:- timeTest(ast_reference_type('Java',_)).
:- timeTest(ast_node_subtype('Java', _,_)).
*/
:- timeTest(ast_node_subtype('Java',_,_)).
:- timeTest(ast_node_subtypeJava1(_,_)).
