% Author: Sebastian Lorenz
% Date: 2/22/2006

/*Enth�lt alle StarTransformer spezifischen Ladevorg�nge. Das komplette ST wird
  sowohl in Prolog (mit "consult") als auch in Mixtus (mit "pconsult") geladen.
*/


/*************************************************************************
StarTransformer laden
Dies ist die verallgemeinerte JTransformer-Version, also die eigentliche
Baustelle.
**************************************************************************/

:- consult(st_engine('main')).
:- consult(st_java('main.stj')).
:- consult(st_engine('compatiblitySWI.pl')).


%wird ben�tigt in apply_all_post/1, aus util/term_operations.pl

comma2list(_member, [_member]) :-
    _member \= ','(_,_),
    !.
comma2list(_member, [_member|_T]) :-
    nonvar(_T),
    _T = [],
    !.
comma2list(','(_member,_t), [_member|_T]) :-
    comma2list(_t, _T),
    !.
comma2list(_, []).


/*************************************************************************
StarTransformer in Mixtus laden
**************************************************************************/

/***************
Engine
****************/

%/apply
:- pconsult(st_engine('/apply/garbage_collect.pl')).
:- pconsult(st_engine('/apply/transaction.pl')).
:- pconsult(st_engine('/apply/ct_apply.pl')).
%/ast
:- pconsult(st_engine('/ast/languageIndependentSyntax.pl')).
:- pconsult(st_engine('/ast/languageIndependentSemantics.pl')).
:- pconsult(st_engine('/ast/languageAbstractions.pl')).
:- pconsult(st_engine('/ast/languageIndependentAccessLayer.pl')).
%/ast/java..
:- pconsult(st_engine('/ast/java/fq_api.pl')).
:- pconsult(st_engine('/ast/java/fq_api_tests.pl')).
:- pconsult(st_engine('/ast/java/javaAstOperations/clone.pl')).
:- pconsult(st_engine('/ast/java/javaAstOperations/tree_modifications.pl')).
:- pconsult(st_engine('/ast/java/javaAstOperations/tree_queries.pl')).
:- pconsult(st_engine('/ast/java/javaAstOperations/visitor.pl')).
:- pconsult(st_engine('/ast/java/src_file_handling.pl')).
:- pconsult(st_engine('/ast/java/src_file_handling_test.pl')).
%/check
:- pconsult(st_engine('/check/treechecks.pl')).
%/debug
:- pconsult(st_engine('/debug/tree_spy.pl')).
%/linker
:- pconsult(st_engine('/linker/javaFactFileLinking.pl')).
%/persistence
:- pconsult(st_engine('/persistence/treefactwriter.pl')).

/***************
Java-spezifisch
****************/

:- pconsult(st_java('/org/cs3/java/writer/java_writer.pl')).
:- pconsult(st_java('/org/cs3/java/writer/type_name.pl')).
:- pconsult(st_java('/org/cs3/java/astSpec/javaFactbase.pl')).
:- pconsult(st_java('/org/cs3/java/astSpec/javaSyntax.pl')).
:- pconsult(st_java('/org/cs3/java/ctSpec/high_level_api.pl')).
:- pconsult(st_java('/org/cs3/java/ctSpec/high_level_api_test.pl')).
:- pconsult(st_java('/org/cs3/java/ctSpec/java_lang_init.pl')).

