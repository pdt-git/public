% Dan Sahlin, Copyright SICS 1991
frozen0(X,F) :-
	handle_freeze ->
		isp_frozen(X,F);
		F=true.


isp_frozen(X,F) :- frozen(X,F), !.
isp_frozen(_,true).
