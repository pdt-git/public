%Kompatibil�tspr�dikate
%false :- fail.

%Laden von Mixtus
:- consult([anti_unify,bagof8c,breakout8,builtin2,can_fold8c,cl,cleanup_conj2,cyclic,delayoutput,erase8,evaluable8c,evaluableg8,executable,gs1,instance2,loop8a,may_cut9,new_literal,ok_determ,p8f,pclause3,pconsult4,propagate2,remove_last7,reset_all8a,residue,save8c,set,solsand2,state8c,to_disj4,transform8d,vars8,varstructs,write8c,isp]).

/*************************************************************
MIXTUS EINSTELLUNGEN
**************************************************************/
:- set(maxnondeterm,100).   %If a predicate generated has more than maxnondeterm clauses, it will not be unfolded.

/*************************************************************
Dateien, in denen die auszuwertenden Pr�dikate stehen
**************************************************************/
%:- pconsult('1test2.pl').
%:- pconsult('1test3.pl').
%:- pconsult(['javaSyntax.pl','languageIndependentSyntax.pl']).
:- pconsult('c:/Studium/Diplomarbeit/CTC/ctc1.0.2/ctc/load.pl').
:- pconsult('c:/Studium/Diplomarbeit/CTC/ctc1.0.2/ctc/interpreter/ctc_interpreter.pl').
:- pconsult('c:/Studium/Diplomarbeit/CTC/ctc1.0.2/ctc/interpreter/ctc_converter.pl').
:- pconsult('c:/Studium/Diplomarbeit/CTC/ctc1.0.2/ctc/interpreter/ddb.pl').
:- pconsult('c:/Studium/Diplomarbeit/CTC/ctc1.0.2/ctc/interpreter/shared_vars.pl').
:- pconsult('c:/Studium/Diplomarbeit/CTC/ctc1.0.2/ctc/test/ctc_testrunner-datadriven.pl').
:- pconsult('c:/Studium/Diplomarbeit/CTC/ctc1.0.2/ctc/test/interpreter/paperExample/cts.pl').
:- pconsult('c:/Studium/Diplomarbeit/CTC/ctc1.0.2/ctc/test/interpreter/paperExample/ast/BpubField.pl').

%:- pconsult('languageIndependentSyntax.pl').
%:- pconsult('javaSyntax.pl').
%:- pe_all.

/*************************************************************
Pr�dikate, die nicht zur expansion anderer Pr�dikate genutzt werden sollen
**************************************************************/
%:- assert(st_pred_expansion(ast_node_signature_REAL(_,_,_))).

%:- pe(ast_node_signature('Java', NodeType, Arity)).
%:- pe(ast_node_term('Java',A)).



listAsserted :- listing(pclause_consult/3),   %pconsult4: 9 matches
                listing(pdynamic/2),          %pconsult4: 6 matches, write8c: 2 matches
                listing(p_op/4),              %pconsult4: 5 matches, write8c: 1 match
                listing(pmultifile/2),        %pconsult4: 4 matches
                listing(static_struct/1),     %pconsult4: 4 matches, loop8a: 1 match
                listing(pblock_consult/2),    %pconsult4: 7 matches
                listing(mixtus_term_expansion/3).      %pconsult4: 5 matches

/* Tools
 */
                
startStopwatch :-
     statistics(runtime, _CPU),    % Start new CPU timer
     statistics(real_time, _Real). % Start new real timer

reportRuntime(ForWhat) :-
     statistics(runtime,    [_CPUMilisSinceStart, CPUMilisSinceLast]),
     statistics(real_time,  [_RealSecsSinceStart, RealSecsSinceLast]),
     format('~n~k: CPU = ~a milliseconds, real time ca. ~a seconds~n',
            [ForWhat,CPUMilisSinceLast,RealSecsSinceLast]).

            /**
 * Quick comparison of two versions of a predicate
 * that are supposed to give the same result. Call
 * regressionTest/2 and look for ' --  fail ' strings in
 * the output in order to detect mismatches of the results.
 *
 * Assumption: Defensive programming, that is creation of a
 * new version of a predicate instead of overwriting the old
 * version. You can still overwrite the old version after
 * successful run of your regression test.
 *
 * Example:
 * regressionTest( newTreeSignature(F, Arity), treeSignature(F, Arity) ).
 */

regressionTest(Old,New) :- equiv( Old, New ).
regressionTest(_ld,_ew) :- nl, fail.
regressionTest(Old,New) :- equiv( New, Old ).
regressionTest(_ld,_ew) :- nl.

equiv(P,Q) :-
   call(P),
   ( (write(P), write(' -- '))
   ; (write(' fail '), nl, fail)
   ),
   call(Q),
   write(Q),
   fail.

