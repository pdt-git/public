% Dan Sahlin, Copyright SICS 1991
:- multifile executable/1.
:- dynamic executable/1.
% Here you can define (user-defined) predicates that can safely be
% executed instead of being partially evaluated. The main advantage is a
% considerable speed-up compared to partial evaluation.
% Sufficient conditions on the predicate to generate a correct program are:
% 1. the predicate must be logical
% 2. an exhaustive search must terminate (finite number of solutions and
%    no infinite loops).
% The predicate may well be non-mixtus_deterministic.

executable(member(A,B)) :- nonvar(A),nonvar(B).

:- multifile classify_goal/3.
:- dynamic classify_goal/3.
% Here you may define the number of solutions and the "purity" of a
% predicate.
% for manual classification of possibly external goals
% usage  classify_goal(G,Class,Sols)
%    G = the goal (the arguments must not become instantiated in this call)
%    Class = a member of [side,sensitive,logical]
%    Sols = a subset (or rather a sublist) of [0,1,2]

% S.L. 18.1.06 Erg�nzung
% Stopliste f�r Pr�dikate, die nicht zu Expansionzwecken genutzt werden sollen
:- multifile st_pred_expansion/1.
:- dynamic st_pred_expansion/1.

:- multifile lock_evaluation/1.
:- dynamic lock_evaluation/1.
