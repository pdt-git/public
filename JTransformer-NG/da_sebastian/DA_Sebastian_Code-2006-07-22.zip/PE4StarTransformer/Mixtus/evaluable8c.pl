% Dan Sahlin, Copyright SICS 1991
peval_builtin(A,State) :-
	normalize_ivars(State,Ivarsl,State2),
	peval_builtin2(A,Ivarsl,State2).

peval_builtin2(A,Ivarsl,State) :-
	(evaluable(A);
	 evaluablel(A,Ivarsl)), !,
	(mixtus_deterministic(A) -> true; not_last(State)),
	(cyclic -> copy_newvars(A,A2), call(A2), p((A=A2),State);
	% assumption: no cyclic structures can be created unless there
	% is a multiple occurrence of a variable in the goal
		   call(A), p_next(State)).

peval_builtin2(A,Ivarsl,State) :-
	(builtin2(A,Glist);
	 builtin3(A,Ivarsl,Glist);
	 normalize_svars(State,Svarsl),
	 builtin4(A,Svarsl,Glist)
	),!,
	 member_last((A2 :- B),Glist,Last),
	 comp_last(State,Last),
	 (cyclic, nonvar(A2) ->
		 unify_cyclic(A,A2,U),
		 cons_conj(U,B,UB),
		 entergoal(UB,State); % cyclic unification & reevaluation!
	  B = true ->
		 A=A2,
		 p_next(State); % slight execution optimization
		 entergoal(B,State)
	 ).

peval_builtin2(A,_Ivars,State) :-
	entergoal(A,State).

unification(X,Y,Cyclicunifs) :-
	(cyclic ->
		  (\+ neq(X,Y) ->
% does not work:  (verify(X=Y) ->
			unify_cyclic(X,Y,Cyclicunifs)
		;       fail
		)
	;       X=Y,
		Cyclicunifs=true
	).

builtin2(X=Y,G) :- !,
	(unification(X,Y,Rest) ->
		G = [(_ :- Rest)]
	;       G = []
	).

builtin2(X =\= Y,G) :-
	simplifyexpr(X,X2), simplifyexpr(Y,Y2),
	(number(X2), number(Y2) ->  (X2=Y2 -> G=[]; G=[(_ :- true)]);
		       X2 == Y2 -> G=[];
				    G = [(_ :- X2 =\= Y2)]).

builtin2(X < Y,G) :- simplifyexpr(X,X2), simplifyexpr(Y,Y2),
	(number(X2),number(Y2) -> (X2<Y2 -> G=[(_ :- true)]; G=[]);
			X2==Y2 -> G = [];
				  G = [(_ :- X2 < Y2)]).

builtin2(X > Y,G) :- builtin2(Y < X,G).

builtin2(X =< Y,G) :- simplifyexpr(X,X2), simplifyexpr(Y,Y2),
	(number(X2),number(Y2)  -> (X2=<Y2 -> G=[(_ :- true)]; G=[]);
			X2==Y2 -> G = [(_ :- true)];
				  G = [(_ :- X2 =< Y2)]).

builtin2(X >= Y,G) :- builtin2(Y =< X,G).

builtin2(clause(H0,B),G2) :-
	isp, remove_user_module(H0,H),!,
	builtin2(clause(H,B),G),
	add_user_module(G,G2).
builtin2(clause(H,B),G) :- !,
	(
	nonvar(H),
	has_clauses(H),
	 \+is_dynamic(H),
	 \+is_multifile(H) ->
		clauselist_heads(H,G);
		G = [(_ :- clause(H,B))]).

builtin2(predicate_property(A0,P),G) :- !,
	remove_user_module(A0,A),
	(nonvar(A) ->
		findall((predicate_property(A,P1):-true),
			(P1=built_in, predicate_property(A,P1);
			 has_clauses(A), P1=interpreted;
			 is_dynamic(A), P1=(dynamic)),G);
		G = [(_ :- predicate_property(A,P))]
	).

clauselist_heads(H,G) :-
	clauselist_data(H,G0),
	to_clauseheads(G0,G).

to_clauseheads([],[]).
to_clauseheads([(Goal:-Body)|R],[(clause(Goal,Body):-true)|R2]) :-
	to_clauseheads(R,R2).

add_user_module([],[]).
add_user_module([(clause(Goal,Body):-true)|Rest],
	[(clause(user:Goal,Body):-true)|Rest2]):-
	add_user_module(Rest,Rest2).

% simplifyexpr sometimes returns an integer where a correct evaluation
% would have been a float. For example: 0*1.2 is simplified to 0 instead of 0.0

:- dynamic arithopt/0.

arithopt. % when set X*0 becomes 0 although 1.2*0 is 0.0 etc., see below
% ??? more thourough handling of aritopt needed
% a simplified type analysis (int/float) could help

simplifyexpr(X,X) :- var(X),!.

simplifyexpr(X+Y,V) :- !,
	simplifyexpr(X,X2), simplifyexpr(Y,Y2),
	(number(X2), number(Y2) -> V is X2+Y2;
	 arithopt, X2==0 -> V = Y2;
	 arithopt, Y2==0 -> V = X2;
	 X2==0.0 -> V = Y2;
	 Y2==0.0 -> V = X2;
		 V = X2+Y2).

simplifyexpr(X-Y,V) :- !,
	simplifyexpr(X,X2), simplifyexpr(Y,Y2),
	(number(X2), number(Y2) -> V is X2-Y2;
	 X2==Y2 ->
		(arithopt, var(X2) ->
			V = X2-Y2;
		 integer(X2) ->
			V = 0;
			V = 0.0);
	 arithopt, Y2==0 ->
		V = X2;
	 Y2==0.0 ->
		V = X2;
		V = X2-Y2).

simplifyexpr(X*Y,V) :- !,
	simplifyexpr(X,X2), simplifyexpr(Y,Y2),
	(number(X2), number(Y2) -> V is X2*Y2;
	 arithopt, (X2 == 0; Y2 == 0) -> V =0;
	 (X2 == 0.0; Y2 == 0.0) -> V =0.0;
	 X2 == 1 -> V = Y2;
	 Y2 == 1 -> V = X2;
	 (arithopt; float(Y2)), X2 == 1.0 -> V = Y2;
	 (arithopt; float(X2)), Y2 == 1.0 -> V = X2;
		    V = X2*Y2).

simplifyexpr(X/Y,V) :- !,
	simplifyexpr(X,X2), simplifyexpr(Y,Y2),
	(X2 == 0, Y2 \== 0 -> V = 0.0;
	 number(X2), number(Y2) -> V is X2/Y2;
	 X2 == Y2 -> V = 1.0;
	 Y2 == 1 -> V = X2;
		   V = X2/Y2).

simplifyexpr(X//Y,V) :- !,
	simplifyexpr(X,X2), simplifyexpr(Y,Y2),
	(X2 == 0, Y2 \== 0 -> V = 0;
	 number(X2), number(Y2) -> V is X2//Y2;
	 X2 == Y2 -> V = 1;
	 Y2 == 1 -> V = X2;
		   V = X2//Y2).

simplifyexpr(X mod Y,V) :- !,
	simplifyexpr(X,X2), simplifyexpr(Y,Y2),
	(X2 == 0, Y2 \== 0 -> V = 0;
	 number(X2), number(Y2) -> V is X2 mod Y2;
	 X2 == Y2 -> V = 0;
	 Y2 == 1 -> V = 0;
		   V = X2 mod Y2).

simplifyexpr(-X,V) :- !,
	simplifyexpr(X,X2),
	(number(X2) -> V is -X2;
		       V = -X2).

simplifyexpr(integer(X),V) :- !,
	simplifyexpr(X,X2),
	(number(X2) -> V is integer(X2);
		       V = integer(X2)).

simplifyexpr(float(X),V) :- !,
	simplifyexpr(X,X2),
	(number(X2) -> V is float(X2);
		       V = float(X2)).

simplifyexpr(X/\Y,V) :- !,
	simplifyexpr(X,X2), simplifyexpr(Y,Y2),
	(X2 == 0 -> V = 0;
	 Y2 == 0 -> V = 0;
	 number(X2), number(Y2) -> V is X2/\Y2;
	 X2 == Y2 -> V = X2;
		   V = X2/\Y2).

simplifyexpr(X\/Y,V) :- !,
	simplifyexpr(X,X2), simplifyexpr(Y,Y2),
	(number(X2), number(Y2) -> V is X2\/Y2;
	 X2 == 0 -> V = Y2;
	 Y2 == 0 -> V = X2;
	 X2 == Y2 -> V = X2;
		   V = X2\/Y2).

% ??? exclusive or
simplifyexpr(X^Y,V) :- !,
	simplifyexpr(X,X2), simplifyexpr(Y,Y2),
	(number(X2), number(Y2) ->
		E= X2^Y2, V is E  % E introduced to make Quintus not to complain
	;X2 == Y2 ->
		V = X2
	;       V = X2^Y2).

simplifyexpr(\(X),V) :- !,
	simplifyexpr(X,X2),
	(number(X2) -> V is \(X2);
		       V = \(X2)).

simplifyexpr(X<<Y,V) :- !,
	simplifyexpr(X,X2), simplifyexpr(Y,Y2),
	(number(X2), number(Y2) -> V is X2<<Y2;
	 X2 == Y2 -> V = X2;
		   V = X2<<Y2).

simplifyexpr(X>>Y,V) :- !,
	simplifyexpr(X,X2), simplifyexpr(Y,Y2),
	(number(X2), number(Y2) -> V is X2>>Y2;
	 X2 == Y2 -> V = X2;
		   V = X2>>Y2).

simplifyexpr([X|Xr],V) :-
	Xr == [], !,
	simplifyexpr(X,V).

simplifyexpr(X,V) :- is_ground(X), !, V is X.

simplifyexpr(X,X). % all the other cases


%builtin3(X == Y,Ivars,Newgoallist) :- !,

builtin3(X @> Y,Ivars,Newgoallist) :- !,
	builtin3(Y @< X,Ivars,Newgoallist).
builtin3(X @>= Y,Ivars,Newgoallist) :- !,
	builtin3(Y @=< X,Ivars,Newgoallist).
builtin3(X @=< Y,Ivars,Newgoallist) :- !,
	p_compare(true,X,Y,Ivars,Newgoallist).
builtin3(X @< Y,Ivars,Newgoallist) :- !,
	p_compare(fail,X,Y,Ivars,Newgoallist).
builtin3(compare(Op,X,Y),Ivars,Newgoallist) :- !,
	(var(Op) ->
		peval_compare(X,Y,Ivars,Xlist-[],Ylist-[],(=)-Tout),
		(Xlist=[] ->
			Newgoallist = [(compare(Tout,_,_):- true)]
		;       (Tout=(<) -> Xapp=[1], Yapp=[2];
			 Tout=(>) -> Xapp=[2], Yapp=[1];
				       Xapp=[], Yapp=[]),
			append(Xlist,Xapp,Xlist2),
			append(Ylist,Yapp,Ylist2),
			list2term(Xlist2,Xterm),
			list2term(Ylist2,Yterm),
			Newgoallist = [(_ :- compare(Op,Xterm,Yterm))]
		)
	;Op = '=' -> builtin3(X==Y,Ivars,Newgoallist)
	;Op = '<' -> builtin3(X@<Y,Ivars,Newgoallist)
	;Op = '>' -> builtin3(X@>Y,Ivars,Newgoallist)
	;        Newgoallist = []
	).


builtin3(X==Y,Ivars,Newgoallist) :- !,
	peval_compare(X,Y,Ivars,Xlist-[],Ylist-[],(=)-Tout),
	((Tout=(<); Tout=(>)) ->
		Newgoallist = [];
	 Xlist=[] ->
		Newgoallist = [(_ :- true)];
		list2term(Xlist,Xterm),
		list2term(Ylist,Yterm),
		Newgoallist = [(_ :- Xterm == Yterm)]
	).
builtin3(X\==Y,Ivars,Newgoallist) :- !,
	builtin3(X==Y,Ivars,Newgoallist2),
	(Newgoallist2=[] -> Newgoallist=[(_ :- true)];
	 Newgoallist2=[(_ :- true)] -> Newgoallist=[];
	 Newgoallist2=[(_ :- Xterm==Yterm)],
	 Newgoallist=[(_ :- Xterm\==Yterm)]).

/*******
builtin3(copy_term_nofail(A,B),Ivars,Newgoallist) :- !, % hack
	builtin3(copy_term(A,B),Ivars,Newgoallist2),
	(Newgoallist2 = [(_ :- copy_term(AIterm,BIterm))] ->
		Newgoallist = [(_ :- copy_term_nofail(AIterm,BIterm))];
		Newgoallist = Newgoallist2).
******/

builtin3(copy_term(A,B),Ivars,Newgoallist) :- !,
	vars_in_common(A,Ivars,AI),
      % ??? cyclic structures are not treated properly below
	(copy_term(t(A,AI),t(B,BI)) ->
		(AI==BI -> % was AI=[]
			Newgoallist = [(_ :- true)]
		 ;      list2term(AI,AIterm),
			list2term(BI,BIterm),
			(
			/****
			 all_new_vars(BI,Ivars) ->
			     Newgoallist = [(_ :- copy_term_nofail(AIterm,BIterm))]
			;
			****/
			     Newgoallist = [(_ :- copy_term(AIterm,BIterm))]
			)
		)
	;       Newgoallist = []).

builtin3(numbervars(T,N,M),Ivars,Newgoallist) :-
	rename_VAR,
	!,
	extract_vars_ordered(T,T2),
	(integer(N) ->
		number_ivars(T2,N,Ivars,N2,T2rest),
		(T2rest=[] ->
			Newgoallist=[(numbervars(_,_,N2):-true)]
		;       list2term(T2rest,T2term),
			Newgoallist=[(numbervars(T,N,M) :-
				      numbervars(T2term,N2,M))]
		)
	;       list2term(T2,T2term),
		Newgoallist=[(numbervars(T,N,M):-
			      numbervars(T2term,N,M))]
	).

number_ivars([V|R],N,Ivars,M,Rest) :-
	\+ varmember(V,Ivars), !, % unbound var
	V='$VAR'(N), N1 is N+1,
	number_ivars(R,N1,Ivars,M,Rest).
number_ivars(T,N,_Ivars,N,T).


builtin4(clause(H,B,Ref),Svarsl,G) :- !,
	(voidvar(Ref,Svarsl) ->
		builtin2(clause(H,B),G0),
		change_heads(G0,G);
		G = [(_ :- clause(H,B,Ref))]).

builtin4(X is Y,Svarsl,G) :- !,
	(voidvar(X,Svarsl) ->
		G = [(_ :- true)]
	;       simplifyexpr(Y,Y2),
		(number(Y2) ->
			(verify(X=Y2) ->
				X=Y2, G=[(_ :- true)]
			;       G=[]
			)
		;       G = [(_ :- X is Y2)]
		)
	).

builtin4(X =:= Y,_Svarsl,G) :- !,
 /**    (voidvar(X,Svarsl);voidvar(Y,Svarsl)) -> G = [(_ :- true)]; **/
	simplifyexpr(X,X2), simplifyexpr(Y,Y2),
	(number(X2), number(Y2) ->
		(X2=Y2 ->
			G = [(_ :- true)]
		;       G = []
		)
	;       (X2 == Y2 ->
			G = [(_ :- true)]
		;       G = [(_ :- X2 =:= Y2)]
		)
	).

change_heads([],[]).
change_heads([(clause(X,Y):-B)|R1],
	     [(clause(X,Y,_):-B)|R2]) :- change_heads(R1,R2).

comparable(X,Y,Ivars,Tout) :-
	Xlist=[],
	peval_compare(X,Y,Ivars,Xlist-[],_Ylist-[],(=)-Tout).

p_compare(Equal,X,Y,Ivars,Newgoallist) :- !,
	peval_compare(X,Y,Ivars,Xlist-[],Ylist-[],(=)-Tout),
	(Xlist=[] ->
		((Tout=(<); Tout=(=), Equal=true) ->
			Newgoallist=[(_ :- true)]
		;       Newgoallist=[]
		)
	;       list2term(Xlist,Xterm),
		list2term(Ylist,Yterm),
		((Tout=(<); Tout=(=), Equal=true) ->
			Newgoallist = [(_ :- Xterm@=<Yterm)]
		;       Newgoallist = [(_ :- Xterm@<Yterm)]
		)
	).

peval_compare(_,_,_,_-[], _-[], T-T) :- (T=(<); T=(>)), !.
peval_compare(X,Y,_Ivars,Xs-Xs, Ys-Ys,T-T) :- X==Y, !.
peval_compare(X,Y,Ivars,Xlistin-Xlistout, Ylistin-Ylistout,_Tin-Tout) :-
	(unboundvar(X,Ivars); unboundvar(Y,Ivars)), !,
	 Xlistin=Xlistout, Ylistin=Ylistout, compare(Tout,X,Y).
peval_compare(X,Y,_Ivars,Xlistin-Xlistout, Ylistin-Ylistout,Tin-Tout) :-
% a var in Ivar may be bound to anything but a structure containing a nonIvar
%       (varmember(X,Ivars); varmember(Y,Ivars)),!,
	(var(X); var(Y)), !,
	 Xlistin=[X|Xlistout], Ylistin=[Y|Ylistout], Tout=Tin.
peval_compare(X,Y,Ivars,Xlistin-Xlistout,Ylistin-Ylistout,Tin-Tout) :-
	functor(X,XF,XN), functor(Y,YF,YN),
	XN>0, YN>0,!,
	(XF=YF, XN=YN ->
		peval_compare_arg(1,XN,X,Y,Ivars,Xlistin-Xlistout,Ylistin-Ylistout,Tin-Tout);
	 compare(Tout,X,Y),
	 Xlistin=Xlistout, Ylistin=Ylistout
%         X @< Y ->
%                Xlistin=Xlistout, Ylistin=Ylistout, Tout=(<);
%                Xlistin=Xlistout, Ylistin=Ylistout, Tout=(>)
	).
peval_compare(X,Y,_Ivars,Xlist-Xlist,Ylist-Ylist,_Tin-Tout) :-
	compare(Tout,X,Y).
%        X == Y -> Tout=Tin;
%        X @< Y -> Tout=(<);
%                  Tout=(>).

peval_compare_arg(I,N,_,_,_,Xlist-Xlist,Ylist-Ylist,T-T) :- I>N.
peval_compare_arg(I,N,X,Y,Ivars,Xlistin-Xlistout,Ylistin-Ylistout,Tin-Tout) :-
	arg(I,X,XI), arg(I,Y,YI),
	peval_compare(XI,YI,Ivars,Xlistin-Xlist2,Ylistin-Ylist2,Tin-T2),
	I1 is I+1,
	peval_compare_arg(I1,N,X,Y,Ivars,Xlist2-Xlistout,Ylist2-Ylistout,T2-Tout).

list2term([Xterm],Xterm) :- !.
list2term(Xlist,Xterm) :- Xterm=..[t|Xlist].

add_ivars(G,Ivars,(G,Ivars)).

% special variant of \+(X=Y) used by dif above
% the dynamic predicate "truth" is used so that it is guaranteed
% that it will not be removed, even if neq is partially evalualuated
neq(X,Y) :- X=Y, truth, % dont remove "true", it is needed to invoked tests
		% on "dif" variables before cut is performed
	    !, fail.
neq(_,_).

:- dynamic truth/0.

truth.

consmember(G,G1) :- G==G1.
consmember(G,(A,_)) :- G==A.
consmember(G,(_,B)) :- consmember(G,B).

all_new_vars(BI,Ivars) :-
	uniq_varlist(BI),
	\+ (member(X,BI), \+ unboundvar(X,Ivars)).

voidvar(X,Svarsl) :- var(X), \+ varmember(X,Svarsl).

% copy_newvars works like copy_term, but a new unique variable is created
% for each occurrence of a variable in the source-term

copy_newvars(X,_) :- var(X),!.
copy_newvars(X,X) :- atomic(X),!.
copy_newvars(X,Y) :- functor(X,F,N), functor(Y,F,N),
		copy_newvars_args(N,X,Y).

copy_newvars_args(0,_X,_Y) :- !.
copy_newvars_args(N,X,Y) :- arg(N,X,XI), arg(N,Y,YI), copy_newvars(XI,YI),
	N1 is N-1, copy_newvars_args(N1,X,Y).

