% Dan Sahlin, Copyright SICS 1991
pclause_builtin(\+X, (X,!,fail)).
pclause_builtin(\+_, true).
pclause_builtin(call(X),X). % not used???
pclause_builtin('C'([A|B],A,B),true).
pclause_builtin(freeze(_,G),call(G)). % having a wait-declaration
pclause_builtin(phrase(A,B),phrase(A,B,[])).
% phrase below cannot handle cut, maybe dcg_translate_dcg in SICStus
% should be used or the definition below extended to cope with cut
pclause_builtin(phrase({G},A,A),(!, G)).
pclause_builtin(phrase((G1,G2),A,C),(phrase(G1,A,B), phrase(G2,B,C))).
pclause_builtin(phrase((G1;Else),A,C),(
		 (nonvar(G1), G1=(Test->Then)), !,
		  (phrase(Test,A,B)->phrase(Then,B,C);
				      phrase(Else,A,C)))).
pclause_builtin(phrase((G1;G2),A,B),( !, (phrase(G1,A,B); phrase(G2,A,B)))).
pclause_builtin(phrase(G,A,B),('PHRASE ISLIST'(G), !, 'PHRASE APPEND'(G,B,A))).
pclause_builtin(phrase(\+G,A,B),(!, \+phrase(G,A,B))).
pclause_builtin(phrase((G1->G2),A,C),(!, (phrase(G1,A,B)->phrase(G2,B,C)))).
pclause_builtin( phrase(if(Test,Then,Else),A,C),(!,
	   if(phrase(Test,A,B),phrase(Then,B,C),phrase(Else,A,C)))).
pclause_builtin(phrase(G,A,B),(G=..Glist, 'PHRASE_APPEND'(Glist,[A,B],G2list),
	      G2=..G2list, G2)).
% not needed as expansion has already happened
% phrase(G,A,B) :- (G ---> Body), phrase(Body,A,B).

% help predicates for phrase (will hopefully not be confuse with other
% user-defined predicates)
pclause_builtin('PHRASE ISLIST'(X),
	(X==[]; functor(X,F,2), F='.', arg(2,X,X2), 'PHRASE ISLIST'(X2))).
pclause_builtin('PHRASE APPEND'([], L, L),true).
pclause_builtin('PHRASE APPEND'([H|T], L, [H|R]),'PHRASE APPEND'(T, L, R)).

%% internal goal used by findall, bagof and setof
%pclause_builtin('PSEUDO ASSERT'(X),true).
