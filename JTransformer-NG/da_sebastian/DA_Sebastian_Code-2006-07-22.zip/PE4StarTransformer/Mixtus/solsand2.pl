% Dan Sahlin, Copyright SICS 1991
sols_and0(pair(0,nocut),P,Q) :-
	pair(0,nocut) mem P;
	pair(1,nocut)^pair(2,nocut) mem P, pair(0,nocut) mem Q.
sols_and0(pair(a,nocut),P,Q) :-
	pair(a,nocut) mem P;
	pair(1,_)^pair(a1,_)^pair(2,_)^pair(a2,_) mem P, pair(a,nocut) mem Q;
	pair(a1,nocut)^pair(a2,nocut) mem P, pair(0,nocut) mem Q.
sols_and0(pair(1,nocut),P,Q) :-
	pair(1,nocut) mem P, pair(1,nocut) mem Q;
	pair(2,nocut) mem P, pair(0,nocut) mem Q, pair(1,nocut) mem Q.
sols_and0(pair(a1,nocut),P,Q) :-
	pair(1,_)^pair(a1,_)^pair(2,_)^pair(a2,_) mem P, pair(a1,nocut) mem Q;
	pair(a1,nocut) mem P, pair(1,nocut) mem Q;
	pair(a2,nocut) mem P, pair(1,nocut) mem Q, pair(0,nocut) mem Q;
	pair(2,_)^pair(a2,_) mem P, pair(1,nocut) mem Q, pair(a,nocut) mem Q.
sols_and0(pair(2,nocut),P,Q) :-
	pair(2,nocut) mem P, pair(1,nocut) mem Q;
	pair(1,nocut)^pair(2,nocut) mem P, pair(2,nocut) mem Q.
sols_and0(pair(a2,nocut),P,Q) :-
	pair(1,_)^pair(a1,_)^pair(2,_)^pair(a2,_) mem P, pair(a2,nocut) mem Q;
	pair(a1,nocut)^pair(a2,nocut) mem P, pair(2,nocut) mem Q;
	pair(a2,nocut) mem P, pair(1,nocut) mem Q;
	pair(a2,nocut) mem P, pair(1,nocut)^pair(2,nocut) mem Q, pair(0,nocut) mem Q;
	pair(2,_) mem P, pair(1,nocut)^pair(2,nocut) mem Q, pair(a,nocut)^pair(a1,nocut)^pair(a2,nocut) mem Q.
sols_and0(pair(0,cut),P,Q) :-
	pair(0,cut) mem P;
	pair(1,nocut)^pair(2,nocut)^pair(a1,_)^pair(a2,_) mem P, pair(0,cut) mem Q;
	pair(1,cut)^pair(2,cut) mem P, pair(0,_) mem Q.
sols_and0(pair(a,cut),P,Q) :-
	pair(a,cut) mem P;
	pair(1,_)^pair(a1,_)^pair(2,_)^pair(a2,_) mem P, pair(a,cut) mem Q;
	pair(1,cut)^pair(a1,cut)^pair(2,cut)^pair(a2,cut) mem P, pair(a,nocut) mem Q;
	pair(a1,cut)^pair(a2,cut) mem P, pair(0,nocut) mem Q.
sols_and0(pair(1,cut),P,Q) :-
	pair(1,cut) mem P, pair(1,nocut) mem Q;
	pair(1,_)^pair(a1,_)^pair(2,_)^pair(a2,_) mem P, pair(1,cut) mem Q;
	pair(2,_)^pair(a2,_) mem P, pair(0,nocut) mem Q, pair(1,cut) mem Q;
	pair(2,cut) mem P, pair(0,nocut) mem Q, pair(1,nocut) mem Q.
sols_and0(pair(a1,cut),P,Q) :-
	pair(1,_)^pair(a1,_)^pair(2,_)^pair(a2,_) mem P, pair(a1,cut) mem Q;
	pair(1,cut)^pair(a1,cut)^pair(2,cut)^pair(a2,cut) mem P, pair(a1,_) mem Q;
	pair(a1,cut) mem P, pair(1,nocut) mem Q;
	pair(a2,cut) mem P, pair(1,nocut) mem Q, pair(0,nocut) mem Q;
	pair(2,_)^pair(a2,_) mem P, pair(1,nocut) mem Q, pair(a,cut) mem Q;
	pair(2,cut)^pair(a2,cut) mem P, pair(1,nocut) mem Q, pair(a,nocut) mem Q.
sols_and0(pair(2,cut),P,Q) :-
	pair(2,cut) mem P, pair(1,nocut) mem Q;
	pair(1,cut)^pair(2,cut) mem P, pair(2,nocut) mem Q;
	pair(1,_)^pair(a1,_)^pair(2,_)^pair(a2,_) mem P, pair(2,cut) mem Q.
sols_and0(pair(a2,cut),P,Q) :-
	pair(1,_)^pair(a1,_)^pair(2,_)^pair(a2,_) mem P, pair(a2,cut) mem Q;
	pair(1,cut)^pair(a1,cut)^pair(2,cut)^pair(a2,cut) mem P, pair(a2,nocut) mem Q;
	pair(a1,cut)^pair(a2,cut) mem P, pair(2,nocut) mem Q;
	pair(a2,cut) mem P, pair(1,nocut) mem Q;
	pair(2,cut) mem P, pair(1,nocut) mem Q, pair(a1,_) mem Q;
	pair(2,_) mem P, pair(1,nocut) mem Q, pair(a1,cut) mem Q;
	pair(a2,cut) mem P, pair(1,nocut)^pair(2,nocut) mem Q, pair(0,nocut) mem Q;
	pair(2,cut)^pair(a2,cut) mem P, pair(1,nocut)^pair(2,nocut) mem Q, pair(a,nocut) mem Q;
	pair(2,_)^pair(a2,_) mem P, pair(1,nocut)^pair(2,nocut) mem Q, pair(a,cut) mem Q.
