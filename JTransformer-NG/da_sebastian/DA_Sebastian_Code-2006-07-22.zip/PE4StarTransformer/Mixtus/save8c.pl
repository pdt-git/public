% Dan Sahlin, Copyright SICS 1991
:- dynamic saved_predicates/9, pblock_saved/1.

save_predicate(A,Anew,Cls,Sterms,Iterms,Block) :-
	vars_in_common(A,Iterms,Ivars),
	vars_in_common(A,Sterms,Svars),
	classify_cls(Cls,Anew,Ivars,Class,Sols,HasCut),
	save_predicate(A,Anew,Cls,Svars,Ivars,Class,Sols,HasCut),
	handle_block(Block,Class,Sols,Anew).

save_predicate(A,Anew,Cls,Svars,Ivars,Class,Sols,HasCut) :-
	stack_top(Num), Num1 is Num+1,
	trace_asserta(saved_predicates(A,Anew,Cls,Svars,Ivars,Class,Sols,HasCut,Num1)).

generated_pred(Anew,Class,Sols,HasCut) :-
	saved_predicates(_,Anew,_Cls,_Svars,_Ivars,Class,Sols,HasCut,_Num).

is_generated(Anew,A) :- saved_predicates(A,Anew,_Cls,_Svars,_Ivars,_Class,_Sols,_HasCut,_Num).

is_already_pevaled(A,state(C,_GS,H,Iterms,_Level,_Cut,_Break,_Last,_Reval,Rin,_Rout),Anew) :-
% trace_peval(A),
	functor(A,F,N), functor(Askel,F,N),
	vars_in_common(A,[H,Rin,C],Svars),
	saved_predicates(Askel,Anew,_Cls,Svars2,Ivars2,_Class,_Sols,_HasCut,_Num),
	is_goal_variant(A,Svars,[Iterms,Rin],Askel,Svars2,Ivars2).

is_goal_variant(A,Svars,Iterms,Askel,Svars2,Ivars2) :-
%        (A=replace(_,_,_,_),
%         saved_predicates(_Askel,_Anew,_Cls,_Svars2,_Ivars2,_Class,_Sols,_HasCut,Num),
%         Num>24 -> blah; true),
	variable_variants(A,Askel),    % 1. variants
	A=Askel,
%%%        extract_vars(Anew,Svars2),  % 2. the surrounding variables must
%       the variables in Anew and Svars may not be the same after a
%       generalized restart
	same_varlists(Svars,Svars2),   % be the same
	vars_in_common(A,Iterms,Ivars),% 3. the i-vars must be the same
	same_varlists(Ivars,Ivars2).

handle_block([],_,_,_) :- !.
handle_block(Block,Class,Sols,Anew) :-
	!,
	save_block_declarations(Block),
	is_generated(Anew,Aorig),
	wait_warnings(Class,Sols,Aorig).

save_block_declarations([]).
save_block_declarations([Blockitem|Block]) :-
	trace_assert(pblock_saved(Blockitem)),
	save_block_declarations(Block).

wait_warnings(side,_,A) :- !,
	wait_or_block_warning,
	write('-declared predicate may have side-effects: '), write(A), nl.
wait_warnings(nonlogical,_,A) :- !,
	wait_or_block_warning,
	write('-declared predicate may be nonlogical: '), write(A), nl.
wait_warnings(logical,Sols,A) :-
	member(2,Sols), !,
	wait_or_block_warning,
	write('-declared predicate being nonmixtus_deterministic: '), write(A), nl.
wait_warnings(_,_,_).

wait_or_block_warning :- isp, !, write('% block').
wait_or_block_warning :- write('% wait').

trace_assert(A) :-
/**
	(verify(A=used_names()) ->
		blah; true),
**/
%       print(A), nl,
	assert(A).

trace_asserta(A) :-
%       print(A), nl,
	asserta(A).


trace_findall(X,G,L) :-
	findall(X2,
		copy_call_wash_old_difs((print(X),nl,G),X,X2),
		L).

restart_difs([]).
restart_difs([_-A|B]) :- call(A), restart_difs(B).

restart_difs([],_).
restart_difs([_-(G1,G2)|B],Executed) :- !,
	restart_difs([_-G1,_-G2|B],Executed).
restart_difs([_-G|B],Executed) :-
	varmember(G,Executed), !, restart_difs(B,Executed).
restart_difs([_-G|B],Executed) :-
	call(G), restart_difs(B,[G|Executed]).


% restart_difs((Var-Difs)list, visible vars, handled difs)

restart_difs([],_,_).
restart_difs([_-(G1,G2)|B],VisibleVars,Executed) :- !,
	restart_difs([_-G1,_-G2|B],VisibleVars,Executed).
restart_difs([_-G|B],VisibleVars,Executed) :-
	varmember(G,Executed), !, restart_difs(B,VisibleVars,Executed).
restart_difs([_-G|B],VisibleVars,Executed) :-
	extract_vars(G,Gvars),
	vars_in_both(Gvars,VisibleVars,GvisVars),
	subtract_vars(Gvars,GvisVars,GInvisVars),
% if dif contains invisible variables then it can always be fulfilled and
% is not executed
	(GInvisVars=[] -> call(G); true),
	restart_difs(B,VisibleVars,[G|Executed]).


%       print(findall(A,B,C)), nl,
/**
	findall(A,(B,print(A),
		(verify(A=pair((instelephant2(_56983,_56983):-true),[_25140,[_24962,_1416,_51],_25141])) ->
			blah; true),
		nl),C).
**/
%       findall(A,B,C).

:- dynamic handle_freeze/0.
handle_freeze.


findall_freeze(X,G,L) :- handle_freeze, !,
	findall(X2,only_new_freeze(X,G,X2),L).
findall_freeze(X,G,L) :-
	findall(X,G,L).

only_new_freeze(X,G,X2) :-
	call_residue(G,Flist),
	call_residue(copy_term(t(X,G,Flist),t(X2,_G2,Flist2)),_),
	extract_vars(X2,X2vars), % not the vars in difs!
	restart_difs(Flist2,X2vars,[]).
