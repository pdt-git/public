% Dan Sahlin, Copyright SICS 1991

pe(A) :- pei(A,A,user_output).
pe(A,File) :- pei(A,A,File).
pei(A,Ivars) :- pei(A,Ivars,user_output).
pei(A,Ivars,File) :- write_init(File), pei_list(A,[],_W,Ivars,File).

pe_all :- pe_all(user_output).
pe_all(File) :- consulted_predlist(Preds), pe(Preds,File).

pei_list([],W,W,_Ivars,_File) :- /*retractall(st_pred_expansion(_)),*/!.
pei_list([H|T],W,W2,Ivars,File) :- !,
        pei_list(H,W,W1,Ivars,File),
        %assert(st_pred_expansion(H)),      %SL: mehrfache Auswertung verhindern!
        %assert(lock_evaluation(H)
        pei_list(T,W1,W2,Ivars,File).
%pei_list((deleteTree(_,_)),_,_,_,_) :- lockEvaluation,!.
pei_list(A,W,W1,Ivars,File) :- pei_item(A,W,W1,Ivars,File).

pei_item(A,W,W1,Ivars,File) :-
        check_clause(A),
        call_residue0(
                (peval_goal(A,[],A,Ivars,Anew,Cls,_IsRec,_HasCut,Block,_Break,_Restart),
                 write_program(A,Anew,Cls,W,W1,A,Ivars,Block,File)
                ),
                _Delayed_vars).

peval_goals(A,GS,Svars,Ivars,Cuttype,Level,Cls_or,CutDone,Break,Last) :-
        vars_in_common(A,Ivars,Ivarslist),
        new_literal(A,Svars,Ivarslist,Anew),
        peval_body_cut(A,GS,Ivarslist,Cuttype,Level,Anew,[],Cls,CutDone,Break,Last),
        retract(used_names(Anew)),
        to_disjunction(Cls,Anew,Cls_or).

/**
peval_goal(A,GS,Svars,Ivars0,Anew0,Cls,IsRec,HasCut,Wait,Break) :-
        varstructs(A,Atrim),
        (A \== Atrim -> write(varstructs(A,Atrim)), nl; true),
        peval_goal2(Atrim,GS,Svars,Ivars0,Anew0,Cls,IsRec,HasCut,Wait,Break),
        A=Atrim.
**/

peval_goal(A,GS,Svars,Ivars0,Anew0,Cls,IsRec,HasCut,Block,Break,Restart) :-
        (quickpe(2) ->
            make_skeleton(A,Askel),
            extract_vars(Askel,Allvars),
            peval_goal2(Askel,GS,Allvars,Allvars,Anew0,Cls,IsRec,HasCut,Block,Break,Restart),
            Askel=A;
            peval_goal2(A,GS,Svars,Ivars0,Anew0,Cls,IsRec,HasCut,Block,Break,Restart)).

peval_goal2(A,GS,Svars,Ivars0,Anew0,Cls,IsRec,HasCut,Block,Break,Restart) :-
        has_block(A,Block0),
        (Block0=[] -> Ivars=Ivars0; Ivars=Svars),
        vars_in_common(A,Ivars,Ivarslist),
        new_literal(A,Svars,Ivarslist,Anew),
        push_gs(GS,A,Anew,Ivarslist,IsRec,Restart,NewGS),
        init_level(Level),
        (block_uninst(Block0,A,Ivarslist) ->
                A_body = true, % the goal can never be trigged
                Block=[]
        ;       transform_block(Block0,Block,A,Anew),
                clause_disj(A,A_body)
        ),
        peval_body_cut(A_body,NewGS,Ivarslist,!,Level,Anew,[],Cls2,_CutDone,Break2,_Last),
        (break_restart(NewGS,Break2,NewGoal,NewSvars,NewIvarslist) ->
               % retract(used_names(Anew)),
                Restart=true,
                peval_goal(NewGoal,GS,NewSvars,NewIvarslist,Anew0,Cls,IsRec,HasCut,Block,Break,Restart),
                A=NewGoal;
                Anew0 = Anew, Break=Break2, Cls=Cls2,
                has_cut(Cls,HasCut)).

peval_body_cut(A,GS,Ivarslist,Cuttype,Level,Anew,Clsbefore,Cls3,CutDone,Break,Last) :-
        peval_body(A,GS,Ivarslist,Level,Anew,Cls,CutDone,Break,Last),  % Break, CutDone????
        append(Clsbefore,Cls,Cls2),
        (remove_last_cut_cls(Cls2,Cuttype,Clsbefore2,(Headlast:-Bodylast)) ->
                peval_body_cut((Anew=Headlast,Bodylast),GS,
                    Ivarslist,Cuttype,Level,Anew,Clsbefore2,Cls3,_CutDone,Break/*?*/,Last);
                Cls3=Cls2).

peval_body(A,GS,Ivarslist,Level,Anew,Cls2,CutDone,Break,Last) :-
        extract_isrecs(GS,IsRecs),
        findall_freeze(pair((Anew :- Residue),[CutDone,IsRecs,Break]),
                p_goals(A,GS,Anew,Ivarslist,Level,cut(CutDone,_),Break,Last,true,Residue),
                L),
        (extract2(L,Cls,CutDone0,[IsRecs,Break]) -> true; write(extract), nl),
        (length(L,1) -> CutDone=CutDone0; true),
        delay_output_unifs(Cls,Anew,Ivarslist,Cls2).

p_goals(A,GS,Anew,Ivars,Level,cut(CutDone,_),Break,Last,Rin,Rout) :-
        p(A,state(true,GS,Anew,Ivars,Level,cut(CutDone1,After),Break,Last,[],Rin,R2)),
        (nonvar(CutDone1), !,
         (CutDone1=! -> Cuttype=!; Cuttype=nocut),
        dec_intest(Level,Level2),
        peval_after(side,true,After,GS,Anew,Ivars,Cuttype,Level2,cut(CutDone2,_),Break,/*var:*/_Last,[],R2,R3),
        min_cut(CutDone1,CutDone2,CutDone)
        ;
        R3=R2,
        CutDone=CutDone1),
        cleanup_conj(R3,Rout).

% var(CutDone) is more than anything else in the max/min comparisons
min_cut(CutDone1,CutDone2,CutDone2) :- var(CutDone1),!.
%min_cut(CutDone1,CutDone2,CutDone2) :- nonvar(CutDone2), CutDone1>=CutDone2, !.
min_cut(CutDone1,_CutDone2,CutDone1).

extract2([],[],_,_).
extract2([pair(Cl,[CutDone|X])|R],[Cl|ClR],CutDone,X) :-
        extract2(R,ClR,CutDone,X).

p(A,State) :- var(A), !, entergoal(A,State).
p(A,State) :- isp, remove_user_module(A,A2), !, p(A2,State). % for ISP
% p(call(A),State) :- var(A), !, entergoal(call(A),State).
p(A,State) :- mixtus_executable(A), !, not_last(State), mixtus_call(A), p_next(State).
p(A,State) :- is_meta(A), !, peval_meta(A,State).
p(A,State) :- is_already_pevaled(A,State,Anew), !, entergoal(Anew,State).
p(A,State) :- has_clauses(A), \+ is_dynamic(A),/*S.L.18.1.06:*/ \+ st_pred_expansion(A) /*S.L.Ende*/, !, peval_pred(A,State).
% p(A,State) :- (builtin_data(A,_,_); A=copy_term_nofail(_,_)), !, peval_builtin(A,State).
p(A,State) :- builtin_data(A,_,_), !, peval_builtin(A,State).
p(A,State) :- is_generated(A,Aorig),!, p(Aorig,State).
p(A,State) :- peval_unknown(A,State).

is_meta((_,_)).
is_meta((_;_)).
is_meta(!).
is_meta('!if').
is_meta((_->_)).
is_meta(findall(_,_,_)).
is_meta(bagof(_,_,_)).
is_meta(setof(_,_,_)).
is_meta(_^_).
is_meta(freeze(_)).
is_meta(call(_)).
is_meta(call_residue(_,_)).
is_meta(undo(_)).
is_meta(if(_,_,_)).
is_meta('InTest').

%Conjunction
peval_meta((A,B),state(C,GS,Anew,Ivars,Level,Cut,Break,Last,Reval,Rin,Rout)) :- !,
        p(A,state((B,C),GS,Anew,Ivars,Level,Cut,Break,Last,Reval,Rin,Rout)).
        

peval_meta((A;Else),State) :-
        nonvar(A), A=(Test->Then), !,
        state(C,GS,H,Ivars,Level,Cut,Break,Last,_Reval,Rin,_Rout)=State,
        (if2cut, not_intest(Level), var(Last) ->
            p((Test,!,Then;Else),State);
            inc_level(Level,Nextlevel),
            %??? Nextlevel is Level+1,
            %???Cuttype='!if'(Nextlevel),
            Cuttype='!if',
            (ok_maxlevel(Nextlevel) ->
                    G = (('InTest',Test,Cuttype,Then,C);Else,C),
                    State2=state(true,GS,H,Ivars,Level,Cut,Break,Last,_Reval,Rin,_Rout);
                    G = (('InTest',Test,Cuttype,Then);Else),
                    State2=State),
            peval_goals(G,GS,[H,Rin,C],[Ivars,Rin],'!if',
                        Nextlevel,Ifthenelse,_IfthenelseCutDone,Break,Last),
            % cut information is not propagated from an if-then-else-construct
            (catch_break(GS,Break,Cut) +
            (retransform_if(Ifthenelse,Cls_or),
             (Cls_or=(_ -> _ ; _) ->
                entergoal(Cls_or,State2);
                p(Cls_or,State2)
            )))
        ).
        
peval_meta((A;B),State) :- !, (not_last(State), p(A,State); p(B,State)).
peval_meta((A->B),State) :- !, p((A->B;fail),State).

peval_meta(G,State) :-
        state(C,_GS,_Anew,Ivars,_Level,Cut,_Break,_Last,_Reval,Rin,Rout)=State,
        is_cut(G),
        may_cut(Ivars,Rin), !,
        (fail, is_last(State) -> Cut=cut(G,C), Rout=Rin;
                           do_cut(Cut,C,G,Rin,Rout)).
peval_meta(G,State) :- is_cut(G), !,
        dec_intest_state(State,State2),
        (fail, is_last(State) -> p_next(State2); entergoal(G,State2)).
peval_meta(findall(X,G,List),State) :- !,
        peval_findall(findall(X,G,List),State).
peval_meta(bagof(X,G,List),State) :- !,
        peval_bagof(bagof(X,G,List),State).
peval_meta(setof(X,G,List),State) :- !,
        peval_setof(setof(X,G,List),State).
peval_meta(_^G,State) :- p(G,State).
peval_meta(freeze(G),State) :- !,
        (is_ground(G) -> p(call(G),State);
            state(C,GS,H,Ivars,Level,Cut,Break,Last,Reval,Rin,Rout)=State,
            peval_goals(G,GS,[H,Rin,C],[H,Rin,C],!,Level,G_or,_CutDone,Break,Last),
            (catch_break(GS,Break,Cut) +
            (classify_goals(G_or,Class,Sols),
             (Class=side -> write('% potential sideeffect goal in freeze/1'), nl; true),
             ((member(2,Sols); member(a2,Sols)) ->
               write('% potential nonmixtus_deterministic goal in freeze/1'), nl; true),
             entergoal(freeze(G_or),
                     state(C,GS,H,Ivars,Level,Cut,Break,Last,Reval,Rin,Rout))
            ))
        ).
peval_meta(call(G),State) :- !, % ??? kan optimera Last
        state(C,GS,H,Ivars,Level,Cut,Break,Last,_Reval,Rin,_Rout)=State,
        peval_goals(G,GS,[H,Rin,C],[Ivars,Rin],!,Level,G_or,_CutDone,Break,Last),
        (catch_break(GS,Break,Cut) +
        (has_cut(G_or) -> entergoal(call(G_or),State);
                          p(G_or,State)
        )).
peval_meta(call_residue(G,R),State) :- !,
        state(C,GS,H,Ivars,Level,Cut,Break,Last,_Reval,Rin,_Rout)=State,
        peval_goals(G,GS,[H,Rin,C],[Ivars,Rin],!,Level,G_or,_CutDone,Break,Last),
        (catch_break(GS,Break,Cut) +
% possible improvement:
%    if dif or freeze have not been called in G_or then R=[]
        entergoal(call_residue(G_or,R),State)).
peval_meta(undo(G),State) :- !,
        state(C,GS,H,Ivars,Level,Cut,Break,Last,_Reval,Rin,_Rout)=State,
        peval_goals(G,GS,[H,Rin,C],[Ivars,Rin],!,Level,G_or,_CutDone,Break,Last),
        (catch_break(GS,Break,Cut) +
        entergoal(undo(G_or),State)).
peval_meta(if(Test,Then,Else),State) :- !,
        state(C,GS,H,Ivars,Level,Cut,Break,Last,_Reval,Rin,_Rout)=State,
        peval_goals(('InTest',Test),GS,[H,Rin,C],[Ivars,Rin],!,Level,Test_or,_CutDone,Break,Last),
        (catch_break(GS,Break,Cut) + (
      %  , (is_breakingout(GS,Break) -> Cut=cut(0,true);
           (success(Test_or) ->
                   p((Test_or,Then),State);
            failure(Test_or) ->
                   p((Test_or;Else),State);
                   peval_goals(Then,GS,[H,Rin,C,Test_or],[Ivars,Rin,Test_or],!,Level,Then_or,_CutDone,Break,Last),
                   (catch_break(GS,Break,Cut) +
                   (peval_goals(Else,GS,[H,Rin,C],[Ivars,Rin],!,Level,Else_or,_CutDone,Break,Last),
                    (catch_break(GS,Break,Cut) +
                    entergoal(if(Test_or,Then_or,Else_or),State)
                   )))
           ))).
peval_meta('InTest',state(C,GS,H,Ivars,Level,Cut,Break,Last,Reval,Rin,Rout)) :- !,
        inc_intest(Level,NextLevel),
        p_next(state(C,GS,H,Ivars,NextLevel,Cut,Break,Last,Reval,Rin,Rout)).



p_next(state(true,_GS,_Anew,_Ivars,_Level,_Cut,_Break,_Last,_Reval,Rin,Rin)) :- !.
p_next(state((A,C),GS,Anew,Ivars,Level,Cut,Break,Last,Reval,Rin,Rout)) :-
        p(A,state(C,GS,Anew,Ivars,Level,Cut,Break,Last,Reval,Rin,Rout)).

peval_pred(A,State) :- can_fold(A,State,true,Anew), !,
%%              write(can_fold(A,State,true,Anew)), nl,
        entergoal(Anew,State).
peval_pred(A,State) :-
        State=state(_C,GS,_Anew,_Ivars,_Level,Cut,Break,_Last,_Reval,_Rin,_Rout),
        loop_detection(A,GS,GR), !,
        (can_fold(A,State,fail,Anew) ->
%%              write(can_fold(A,State,fail,Anew)), nl,
                entergoal(Anew,State);
                breakout(GR,Break),
                Cut=cut(0,true)).
peval_pred(A,State) :-
        state(C,GS,H,Ivars,Level,Cut,Break,Last,_Reval,Rin,_Rout)=State,
        peval_goal(A,GS,[H,Rin,C],[Ivars,Rin],Anew,Cls,IsRec,HasCut,Block,Break,Restart),
        (catch_break(GS,Break,Cut) +
        ((IsRec\==true,
         (HasCut\==true;
          unfold_cut, not_intest(Level), var(Last);
          unfold_cut2,success_after_cut(Cls), success_before_cut(C,true)),
         ok_determ(Cls), Block==[], Restart\==true ->
               retract(used_names(Anew)),
               member_last((Anew :- B2), Cls, Last),
%              entergoal(B2,State)
%              p(B2,State)
               p((B2,B2=B2),State) % the strange goal B2=B2 just forces
                                   % the surrounding variables to be the same
                                   % at reevaluation to avoid looping
        ;
        save_predicate(A,Anew,Cls,[H,Rin,C],[Ivars,Rin],Block),
               entergoal(Anew,State)
        ))).

peval_unknown(A,state(C,GS,Anew,Ivars,Level,Cut,Break,Last,Reval,Rin,Rout)) :-
        Last=fail,
        (mixtus_classify_goal(A,Class,_Sols0), !; Class=side),
        peval_after(Class,A,C,GS,Anew,Ivars,nocut,Level,Cut,Break,Last,Reval,Rin,Rout).

entergoal(Goal,state(C,GS,Anew,Ivars,Level,Cut,Break,Last,Reval,Rin,Rout)) :-
(Rin\==true -> write(Rin), write('*******************************************'), nl; true),
        classify_goals(Goal,Class,Sols),
        update_last(Sols,Last),
%        (var(Last) -> Cuttype=!; Cuttype=nocut, Last2=Last),
        (nonvar(Goal), Goal=! -> Cuttype=!; Cuttype=nocut, Last2=Last),
         peval_after(Class,Goal,C,GS,Anew,Ivars,Cuttype,Level,Cut,Break,Last2,Reval,Rin,Rout).

peval_after(side,Goal,C,GS,H,Ivars,Cuttype,Level,Cut,Break,Last,_Reval,Rin,(Rin,Goal,Cls_or)) :-
%        Nextlevel is 7,
% Level+1,
        peval_goals(C,GS,[H,Rin,Goal],[Ivars,Rin,Goal],Cuttype,Level,Cls_or,CutDone2,Break,Last),
        (nonvar(CutDone2),
%%??        CutDone2 =< Level,
            (may_cut(Ivars,(Rin,Goal)); is_breakingout(GS,Break)) ->
                Cut=cut(CutDone2,true);
                true).

peval_after(sensitive,Goal,C,GS,Anew,Ivars,Cuttype,Level,Cut,Break,Last,Reval,Rin,(Rin,Goal,Cls_or)) :-
        peval_after(side,Goal,C,GS,Anew,Ivars,Cuttype,Level,Cut,Break,Last,Reval,Rin,(Rin,Goal,Cls_or)),
        Cls_or \== fail.

peval_after(logical,Goal,C,GS,Anew,Ivars,Cuttype,Level,Cut,Break,Last,Reval,Rin,Rout) :-
        peval_after(sensitive,Goal,C,GS,Anew,Ivars,Cuttype,Level,Cut,Break,Last,Reval,Rin,(Rin,Goal,Cls_or)),
        (propagate_left(Cls_or,Cls_rest,yes) ->
                (not_too_many_propagate_left(Goal,Reval,Reval2) ->
                       p(Goal,state((Cls_rest,true),GS,Anew,Ivars,Level,Cut,Break,Last,Reval2,Rin,Rout));
                       Rout = (Rin,Goal,Cls_rest)
                );
                Rout = (Rin,Goal,Cls_or)
        ).

is_cut(!).
is_cut('!if').



member_last(X,[X],_).
member_last(X,[X,_|_],fail).
member_last(X,[_,Y|R],Last) :- member_last(X,[Y|R],Last).

update_last(Sols,_Last) :- sols_mixtus_deterministic(Sols), !.
update_last(_Sols,fail).

:- dynamic unfold_cut/0, unfold_cut2/0.

unfold_cut. % unfold predicates with cut, if possible
% unfold_cut2. % ditto, variant two

:- dynamic if2cut/0.

init_level(level(0,0)).

inc_level(level(Nesting,InTest),level(NextNesting,InTest)) :-
        NextNesting is Nesting+1.

inc_intest(level(Nesting,InTest),level(Nesting,NextInTest)) :-
        NextInTest is InTest+1.
dec_intest(level(Nesting,InTest),level(Nesting,NextInTest)) :-
        NextInTest is InTest-1.
dec_intest_state(
        state(C,GS,Anew,Ivars,Level ,Cut,Break,Last,Reval,Rin,Rout),
        state(C,GS,Anew,Ivars,Level2,Cut,Break,Last,Reval,Rin,Rout)) :-
        dec_intest(Level,Level2).
not_intest(level(_,0)).

(catch_break(GS,Break,Cut) + G2) :-
        (is_breakingout(GS,Break) ->
                Cut=cut(0,true);
                call(G2)).

% A call is blocked forever if there is a blocked argument variable which
% does not occur at all in Ivarslist (actually in Svars)
block_uninst(Block,A,Ivarslist) :-
        functor(A,_,N), N>0,
        member(Blockitem,Block),
        block_uninst_item(N,Blockitem,A,Ivarslist).

block_uninst_item(I,Blockitem,A,Ivarslist) :-
        arg(I,Blockitem,'-'),
        arg(I,A,AI),
        var(AI),
        \+ varmember(AI,Ivarslist).

block_uninst_item(I,Blockitem,A,Ivarslist) :-
        I>1,
        I1 is I-1,
        block_uninst_item(I1,Blockitem,A,Ivarslist).

transform_block([],[],_A,_Anew) :- !.
transform_block([Blockitem0|Block0],[Blockitem|Block],A,Anew) :-
        transform_block_item(Blockitem0,Blockitem,A,Anew),
        transform_block(Block0,Block,A,Anew).

transform_block_item(Blockitem0,Blockitem,A,Anew) :-
        functor(Anew,AnewF,AnewN),
        functor(Blockitem,AnewF,AnewN),
        functor(A,_,N),
        block_var(N,Blockitem0,Blockitem,A,Anew),
        block_restvars(AnewN,Blockitem).

block_var(0,_,_,_,_) :- !.
block_var(I,Blockitem0,Blockitem,A,Anew) :-
        (arg(I,Blockitem0,'-') ->
                arg(I,A,Avar),
                functor(Anew,_,M),
                set_block_var(M,Avar,Blockitem,Anew)
        ;       true
        ),
        I1 is I-1,
        block_var(I1,Blockitem0,Blockitem,A,Anew).

set_block_var(0,_,_,_) :- !.
set_block_var(J,Avar,Blockitem,Anew) :-
        arg(J,Anew,AnewJ),
        (AnewJ==Avar ->
                arg(J,Blockitem,'-')
        ;       true),
        J1 is J-1,
        set_block_var(J1,Avar,Blockitem,Anew).

block_restvars(0,_) :- !.
block_restvars(I,Blockitem) :-
        (arg(I,Blockitem,'?') -> true; true),
        I1 is I-1,
        block_restvars(I1,Blockitem).

success_after_cut(Cls) :-
        \+ (member((_:-B),Cls),has_cut(B),may_fail_after_cut(B,true)).

% should really find the last cut to be optimal
may_fail_after_cut(B,_) :- var(B), !.
may_fail_after_cut(!,Gs) :- !, \+ success(Gs).
may_fail_after_cut((G1,G2),Gs) :- !,
        may_fail_after_cut(G1,(G2,Gs)).
may_fail_after_cut((G1;G2),Gs) :- !,
        may_fail_after_cut(G1,Gs);
        may_fail_after_cut(G2,Gs).
may_fail_after_cut(G,_) :- is_meta(G), !. % a bit coarse
may_fail_after_cut(_,Gs) :-
        may_fail_after_cut(Gs,true).

success_before_cut(G,_) :- var(G), !, fail.
success_before_cut((G1,G2),G) :- !,
        success_before_cut(G1,(G2,G)).
success_before_cut(true,_) :- !, fail.
success_before_cut(!,_) :- !.
success_before_cut(G,Gs) :- !,
        success(G),
        success_before_cut(Gs,true).
