% Dan Sahlin, Copyright SICS 1991

:- meta_predicate(call_residue0(:,-)).

call_residue0(X,L) :-
	handle_freeze -> call_residue(X,L);
			 L=[], call(X).

:- op(1150, fx, wait). % for compatibility with preisp, can be removed
