% Dan Sahlin, Copyright SICS 1991
reset_all :-
	retractall2(used_names(_)),            % in new_literal
	retractall2(saved_predicates(_,_,_,_,_,_,_,_,_)),
	retractall2(pblock_saved(_)).
