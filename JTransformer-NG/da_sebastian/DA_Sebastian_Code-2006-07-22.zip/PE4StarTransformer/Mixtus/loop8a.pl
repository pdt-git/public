% Dan Sahlin, Copyright SICS 1991
:- dynamic maxrec/1.
:- dynamic max_depth/1.

maxrec(2).      % must be at least 1
max_depth(4).  % ditto
% the above two flags are only used if quickpe(0) is true
% if quickpe(2) is true then loop_detection is never called

loop_detection(Goal,Acopy,GR) :-
	(quickpe(1) -> Max=1;
		maxrec(Max)),
	maxrec(Acopy,Goal,GR),
	length(GR,GN),
	GN > Max.

maxrec(Acopy,Goal,[GS_item|GR]) :-
	gs_goal(GS_item,Goal),
%       functor(Goal,F,N),
	depth(Acopy,Goal,GR).


depth([],_,[]).
depth([GS_item|Gs],Goal,[GS_item|GR]) :-
	gs_goal(GS_item,G1),
	max_depth(Maxl),
	(exact -> exact(G1,Goal); true),
%       \+ no_loop(Goal,G1,1,Maxl),
	(quickpe(1) ->
		same_functor(Goal,G1);
		\+ (min_no_loop(Goal,G1,1,Min), Min<Maxl)),
	!,
	depth(Gs,Goal,GR).
/***********
depth([GS_item|Gs],Goal,[GS_item|GR]) :-
	gs_orig_goal(GS_item,A),
	same_functor(A,Goal), % this must hold as the generlized restart
			      % will generate a variable goal otherwise
	is_subterm(A,Goal),
	write(is_subterm(A,Goal)),nl,
	!,
	depth(Gs,Goal,GR).
*********/
depth([_|Gs],Goal,GR) :-
	depth(Gs,Goal,GR).

% does not handle cyclic structures or difs

min_no_loop(Goal,G1,N,N1) :- var(Goal), !,
	(var(G1) -> maxinteger(N1); N1=N).
min_no_loop(_Goal,G1,_N,N1) :- var(G1), !, % nonvar(Goal)
	maxinteger(N1).
min_no_loop(Goal,G1,N,N1) :-
	structure_size(Goal,Goalsize),   % structure size smaller
	structure_size(G1,G1size),
	(Goalsize<G1size ->
		N1=N,!;
		\+ finite_struct(Goal),!,maxinteger(N1)
	).
min_no_loop(Goal,G1,N,N2) :-
	functor(Goal,FGoal,NGoal),
	functor(G1,FG1,NG1),
	 maxinteger(Maxint),
	(
%        is_list_functor(Goal),is_list_functor(G1),!, N2=Maxint;
	 \+ (FGoal=FG1, NGoal=NG1), N2=N,!;
%%       NGoal=0, !, N2=Maxint;
	 N1 is N+1,         % FGoal=FG1 and NGoal=NG1
	 min_no_loop_arg(NGoal,Goal,G1,Maxint,N1,N2)).

min_no_loop_arg(0,_Goal,_G1,Minimum,_N1,Minimum) :- !.
min_no_loop_arg(I,Goal,G1,Minimum,N1,N3) :-
	arg(I,Goal,GoalI), arg(I,G1,G1I),
	min_no_loop(GoalI,G1I,N1,N2),
	minimum(Minimum,N2,Minimum2),
	I1 is I-1,
	min_no_loop_arg(I1,Goal,G1,Minimum2,N1,N3).

is_list_functor([]).
is_list_functor([_|_]).

maxinteger(100000). % should be sufficient, max depth of terms

no_loop(Goal,G1,_N,_Maxl) :- var(Goal), !, nonvar(G1).
no_loop(Goal,G1,N,Maxl) :-
	(N>Maxl; \+ finite_struct(Goal)), !,
	structure_size(Goal,Goalsize),
	structure_size(G1,G1size),
	Goalsize<G1size.
no_loop(Goal,G1,N,Maxl) :- % N=<Maxl and finite_struct(Goal)
	functor(Goal,FGoal,NGoal),
	functor(G1,FG1,NG1),
	(\+ (FGoal=FG1,NGoal=NG1),!;
	N1 is N+1,         % FGoal=FG1 and NGoal=NG1
	no_loop_arg(NGoal,Goal,G1,N1,Maxl)).

no_loop_arg(0,_Goal,_G1,_N,_Maxl) :- !, fail.
no_loop_arg(I,Goal,G1,N,Maxl) :-
	arg(I,Goal,GoalI), arg(I,G1,G1I),
	no_loop(GoalI,G1I,N,Maxl).
no_loop_arg(I,Goal,G1,N,Maxl) :-
	I1 is I-1,
	no_loop_arg(I1,Goal,G1,N,Maxl).

structure_size(G,N) :- structure_size(G,0,N).

structure_size(G,N,N2) :- var(G), !, N2 is N+1.
structure_size(G,N,N2) :- functor(G,_,M), N1 is N+1,
			  structure_size_arg(M,G,N1,N2).

structure_size_arg(0,_,N,N):-!.
structure_size_arg(M,G,N,N2) :- arg(M,G,GM), structure_size(GM,N,N1),
				M1 is M-1, structure_size_arg(M1,G,N1,N2).

:- dynamic exact/0.

% exact.

exact(G1,G2) :- arg(1,G1,G11), \+ integer(G11), arg(1,G2,G21),
		is_ground(G11), is_ground(G21), !,
		G11=G21.
exact(_,_).

% is_subterm(A,Goal)
% very special loop test

is_subterm(A,B) :-
	functor(A,FA,NA), NA>0, functor(B,FB,NB),
	FA=FB, NA=NB,
	A =.. [_|AL], B=..[_|BL], subterm_args(AL,BL).
is_subterm(A,B) :- get_part(B,Bpart), A==Bpart.
is_subterm(A,B) :- var(B),get_part(A,Apart),Apart==B.

subterm_args([],[]).
subterm_args([A|AR],[B|BR]) :- is_subterm(A,B), subterm_args(AR,BR).

get_part(X,X).
get_part(X,Xpart) :- functor(X,_F,N), N>0,
	X =.. [_|XL], member(Xpart2,XL), get_part(Xpart2,Xpart).

same_functor(F,G) :-
	functor(F,Name,Arity),
	functor(G,GName,GArity),
	Name=GName, Arity=GArity.

:- dynamic maxfinite/1.

maxfinite(7).

finite_struct(X) :- static_struct(X).
finite_struct(X) :- integer(X), maxfinite(M),
		    (X>=0 -> X=<M; X>= -M).


:- dynamic quickpe/1.

quickpe(0).
