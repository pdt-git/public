% Dan Sahlin, Copyright SICS 1991
% sound but not complete(?)

isinstance_dif(X,Y) :-
	isinstance(X,Y),
	(handle_freeze ->
		\+ \+ (
		      extract_diflist(X,Xdifl,Xvars),
		      X=Y,
		      extract_diflist(X,Xdifl2,Xvars2),
		      Xvars=Xvars2,
		      same_diflists(Xdifl,Xdifl2)
		);
		true).

same_diflists([],[]).
same_diflists([E|R],Difs) :-
	delete_same(Difs,E,Difs2),
	same_diflists(R,Difs2).

delete_same([],_,[]).
delete_same([E1|R],E,Difs) :- E1==E,!, delete_same(R,E,Difs).
delete_same([E1|R],E,[E1|Difs]) :- delete_same(R,E,Difs).


extract_diflist(Y,Ydifl,Yvars) :-
	extract_vars_ordered(Y,Yvars), % {ven indirekta vars i diffar!
	extract_difs(Yvars,Ydifl).

extract_difs([],[]).
extract_difs([Y|R],DifsT) :-
	frozen(Y,DifsConj),
	conj_to_list(DifsConj,Difs),
	append(Difs,T,DifsT),
	extract_difs(R,T).

conj_to_list((A,B),Clist) :-
	conj_to_list(A,Alist),
	conj_to_list(B,Blist),
	append(Alist,Blist,Clist).
conj_to_list(G,[A=B]) :- difgoal(G,A,B).
conj_to_list(true,[]).



