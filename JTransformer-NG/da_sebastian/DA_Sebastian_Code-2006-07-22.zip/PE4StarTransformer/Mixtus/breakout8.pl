% Dan Sahlin, Copyright SICS 1991
:- dynamic tracebreakout/0.

%breakout(GR,GS_item) :- new_instancegoal(GR,GS_item), !,
%        (tracebreakout ->
%                write('instance breakout'), nl,
%                write(GR), nl; true).

breakout(GR,GS_item) :-
	get_last_two(GR,Goal1,Goal2,Depth1,Top1),
% write(anti_unify(Goal1,Goal2,NewGoal)),nl,
% get(X),
	anti_unify(Goal1,Goal2,NewGoal),
	(tracegoalstack ->
		[GR_item|GR2] = GR,
		gs_goal(GR_item,Goal),
		write_goalstack(Goal,GR2,'antiunify breakout');
		true),
	extract_vars(NewGoal,NewIvars),
	new_breakoutgoal(NewGoal,NewIvars,Depth1,Top1,GS_item);
	new_instancegoal(GR,GS_item).

is_breakingout(GS,GS_item) :-
	gs_depth(GS_item,RecursiveDepth),
	nonvar(RecursiveDepth),
	gs_new_depth(GS,Depth), Depth > RecursiveDepth.

% testing and restarting from a break
break_restart(NewGs,GS_item,
	NewGoal,NewSvars,NewIvars) :-
	gs(GS_item,NewGoal,NewSvars,NewIvars,_IsRec,Bdepth,Savetop,_A,_Info),
	% _A cannot be updated at a break_restart
	nonvar(Bdepth),
	gs_new_depth(NewGs,Depth), Depth is Bdepth+1,
	erase_to_top(Savetop).
