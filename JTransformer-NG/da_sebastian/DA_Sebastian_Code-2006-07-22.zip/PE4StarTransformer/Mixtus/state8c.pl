% Dan Sahlin, Copyright SICS 1991
normalize_ivars(state(C,GS,H,Ivars,Level,Cut,Break,Last,Reval,Rin,Rout),Ivarsl,
		state(C,GS,H,Ivars,Level,Cut,Break,Last,Reval,Rin,Rout)) :-
	extract_vars(Ivars,Ivarsl).

normalize_svars(state(C,_GS,H,_Ivars,_Level,_Cut,_Break,_Last,_Reval,Rin,_Rout),
		Svars) :-
	extract_vars([H,Rin,C],Svars).

comp_last(state(_C,_GS,_Anew,_Ivars,_Level,_Cut,_Break,Last,_Reval,_Rin,_Rout),Last).

not_last(State) :- comp_last(State,fail).
is_last(State) :- comp_last(State,Last), var(Last).



get_continuation(State,State2,C) :-
	State=state(C,GS,H,Ivars,Level,Cut,Break,Last,Reval,Rin,Rout),
	State2=state(true,GS,H,Ivars,Level,Cut,Break,Last,Reval,Rin,Rout).

