% Dan Sahlin, Copyright SICS 1991
:- dynamic maxpropleft/1.

maxpropleft(3).

% propagate_left: perform leading unifications if a disjunction is not found
propagate_left(X=Y,Cyclicunifs,yes) :- !, unification(X,Y,Cyclicunifs).
propagate_left((X=Y,Rest),Rest3,yes) :- !,
	unification(X,Y,Cyclicunifs),
	propagate_left(Rest,Rest2,_),
	cons_conj(Cyclicunifs,Rest2,Rest3).
propagate_left(Rest,Rest,no).

not_too_many_propagate_left(Goal,Reval,[Goalskel|Reval]) :-
	find_orig(Goal,Goalorig),
	functor(Goalorig,F,N),
	functor(Goalskel,F,N),
	count_same(Reval,Goalskel,1,M),
	maxpropleft(Mmax), M=<Mmax.

%not_too_many_propagate_left(Goal,Reval,[Goalorig|Reval]) :-
%        find_orig(Goal,Goalorig),
%        length(Reval,M),
%        maxpropleft(Mmax), M=<Mmax.

find_orig(A,Aorig) :- is_generated(A,A2), !, find_orig(A2,Aorig).
find_orig(A,A).

count_same([],_G,N,N) :- !.
count_same([G|Xs],G,N,N2) :- !, N1 is N+1, count_same(Xs,G,N1,N2).
count_same([_|Xs],G,N,N2) :- count_same(Xs,G,N,N2).
