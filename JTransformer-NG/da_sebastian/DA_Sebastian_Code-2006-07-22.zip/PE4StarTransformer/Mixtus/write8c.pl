% Dan Sahlin, Copyright SICS 1991
:- dynamic print_var_warnings/0.
print_var_warnings.

write_init(File) :-
	reset_all,
	on_file(File,write,(
		write_settings,
		write_ops
		)).

write_program(A,Anew,Cls,Svars,Ivars,Block,File) :-
	write_program(A,Anew,Cls,[],_W,Svars,Ivars,Block,File).

on_file(File,Mode,Call) :- % call Call with all output on File
	(File=user_output ->
		Stream=File;
	 File= +Filename ->
		open(Filename,append,Stream);
		open(File,Mode,Stream)),
	current_output(Previous_output),
	set_output(Stream),
		call(Call),
	flush_output(Stream),
	close(Stream),
	set_output(Previous_output).

write_program(A,Anew,Cls,W,W1,Svars,Ivars,Block,File) :-
    on_file(File,append,(
%       collect_simplepreds(Subst),
	Subst=[],
	save_predicate(A,Anew,Cls,Svars,Ivars,Block),
	write_block(A),
	(Cls = [] -> Anew2=fail; Anew2=Anew), % to avoid calls to a predicate
					      % without clauses
	(print_var_warnings -> true;
	   write((:- prolog_flag(single_var_warnings,_,off))), write('.'), nl),

	print_clauses([(A :- Anew2)],Subst,Cls2),
	write_clauses(Cls2,W,W1,Subst),
	(print_var_warnings -> true;
	   write((:- prolog_flag(single_var_warnings,_,on))), write('.'), nl)
     )). % end on file

write_program(A,Anew) :-
%       collect_simplepreds(Subst),
	Subst=[],
	write_block(A),
	print_clauses([(A :- Anew)],Subst,Cls),
	write_clauses(Cls,[],_Usedpreds,Subst).

collect_simplepreds(Subst) :-
	findall(Singlesubst,simplepred(Singlesubst),Subst).

simplepred(B/H) :-
	saved_predicates(_,_,[(H:-B)],_,_,_,_,_,_),
%        saved_predicates(_,_,out(HasCut,Class,Sols,Is_rec,G_lit,[(H :- B)])),
	only_vars(H),
%        \+ pdynamic(H,_),  % pclause
	only_vars(B),
	functor(B,BF,BN), functor(B2,BF,BN), \+ pred_parts(B2).

write_clauses([],W,W,_).
write_clauses([(_ :- B)|R],W,W2,S) :-
	write_predicates(B,W,W1,S), write_clauses(R,W1,W2,S).

write_predicates(G,W,W2,S) :-
	var(G), !,  % if unbound var is called, include all dynamic preds
		    % In interpreted SICStus all predicates are
		    % dynamic in contrast to Quintus where an explicit
		    % declaration is needed. Thus this method is only
		    % not correct for interpreted SICStus.
	warning_code_needed,
	L = [],
%        findall(H,pdynamic(H,_),L), % pclause ???
	write_clauses(L,W,W2,S).

write_predicates(G,W,W2,S) :-
	functor(G,F,N), functor(Gpat,F,N), pred_parts(Gpat), !,
	write_goals(1,N,G,Gpat,W,W2,S).

write_predicates(G,W,W2,S) :- % for generated preds
	functor(G,F,N1),
	functor(G2,F,N1),
	saved_predicates(Gorig,G2,Cls,Ivars,_,_,_,_,_),
%%       saved_predicates(_,Ivars,out(HasCut,Class,Sols,Is_rec,G2,Cls)),
	\+ (member(G2,W)), !,
	(comments -> (nl, write('% '), numbervars((G2 :- Gorig),0,_),
		      writeq((G2 :- Gorig)), nl, fail;true);true),
	(modes -> print_modes(G2,Ivars); true),
	write_block(G),
	print_clauses(Cls,S,Cls2),
	write_clauses(Cls2,[G2|W],W2,S).

write_predicates(G,W,W2,S) :- % for already defined preds
	functor(G,F,N1),
	functor(G3,F,N1),
	\+ (member(G3,W)),
	is_dynamic(G3), !,
%         pclause(G3,_),
	functor(G2,F,N1),
	clauselist_data(G2,Cls),
	(comments -> nl, write('% original definition'), nl; true),
	write(':- dynamic '), write(F/N1), write('.'), nl,
	write_block(G),
	print_clauses(Cls,S,Cls2),
	write_clauses(Cls2,[G2|W],W2,S).

write_predicates(G,W,W2,S) :- % for "clause(H,B)" %?? kan ers{ttas med pred_parts?
	functor(G,F,N1),
	F=clause, N1=2,!,
	G=clause(H,_),
	write_predicates(H,W,W2,S).

write_predicates(G,W,W2,S) :- % for "retract(X)"
	functor(G,F,N1),
	F=retract, N1=1,!,
	G=retract(H), (nonvar(H), H = (H2 :- _) -> true; H2=H),
	write_predicates(H2,W,W2,S).

write_predicates(_,W,W,_).

write_goals(I,N,_,_   ,W,W,_) :- I > N, !.
write_goals(I,N,G,Gpat,W,W2,S) :- arg(I,Gpat,Type), Type=n, !, % skip argument
	I1 is I+1, write_goals(I1,N,G,Gpat,W,W2,S).
write_goals(I,N,G,Gpat,W,W2,S) :- arg(I,G,IG), write_predicates(IG,W,W1,S),
	I1 is I+1, write_goals(I1,N,G,Gpat,W1,W2,S).

print_clauses(Cls,Subst,Cls2) :-
	replace_cls(Cls,Cls2,Subst),
	print_clauses(Cls2).

print_clauses([]).
print_clauses([Cl|R]) :-
	print_clause(Cl),
	print_clauses(R).

:- dynamic rename_VAR/0.

print_clause(Cl) :-
	(rename_VAR -> rename_VARS(Cl,Cl1);
		       Cl1=Cl),
	(handle_freeze -> reify_difs(Cl1,Cl2),
			  call_residue(copy_term(Cl2,Cl3),_);
			  Cl3=Cl1),
	portray_clause(Cl3).


% replace_cls(input-clause-list,output-clause-list,F1/F2)
% replace all predicates F2 with F1 keeping the variable connection
replace_cls([],[],_) :- !.
replace_cls([(H:-B)|R],[(H2:-B2)|R2],Subst) :-
	replace_cls2(H,H2,Subst), replace_cls2(B,B2,Subst),
	replace_cls(R,R2,Subst).

replace_cls2(G,G,_) :- var(G),!.
replace_cls2(G,G2,Subst) :-
	functor(G,F,N), functor(Gpat,F,N), pred_parts(Gpat),!,
	functor(G2,F,N), replace_cls3(N,G,Gpat,G2,Subst).
replace_cls2(G,G2,Subst) :- member(F1/F2,Subst), copy_term(F1/F2,G2/G),!.
replace_cls2(G,G,_).

replace_cls3(0,_,_,_,_) :- !.
replace_cls3(N,G,Gpat,G2,Subst) :-
	arg(N,Gpat,Type), Type=n, !, % skip argument
	arg(N,G,X), arg(N,G2,X),
	N1 is N-1, replace_cls3(N1,G,Gpat,G2,Subst).
replace_cls3(N,G,Gpat,G2,Subst) :-
	arg(N,G,GN), replace_cls2(GN,G2N,Subst), arg(N,G2,G2N),
	N1 is N-1, replace_cls3(N1,G,Gpat,G2,Subst).

warning_code_needed :-
	write('%Warning: Unbound variable found as a goal.'), nl,
	write('%         Potentially all original code is needed.'), nl.

:- dynamic comments/0.

comments.

:- dynamic modes/0.

% modes.

print_modes(H,Ivars) :-
	H =.. [F|Hargs],
	print_modes_args(Hargs,Ivars,ModeArgs),
	Mode =.. [F|ModeArgs],
	writeq((:- mode:Mode)), write('.'), nl.

print_modes_args([],_,[]).
print_modes_args([A|As],Ivars,[M|Ms]) :-
	((nonvar(A); varmember(A,Ivars)) -> M=arg; M=new),
	print_modes_args(As,Ivars,Ms).

write_block(P) :- has_block(P,Block),
	write_block_item(Block).

write_block_item([]).
write_block_item([Blockitem|Block]) :-
	(isp ->
		write(':- block '), write(Blockitem), write('.'), nl
	;is_wait_decl(Blockitem) ->
		functor(Blockitem,F,N),
		write(':- wait '), write(F/N), write('.'), nl
	 ;      write('% too old SICStus version: cannot handle block declarations!'), nl
	),
	write_block_item(Block).

% the first argument must be '-', the remaining, if any, must be '?'
is_wait_decl(Blockitem) :-
	functor(Blockitem,_,N),
	N>1,
	arg(1,Blockitem,'-'),
	is_wait_decl_args(N,Blockitem).

is_wait_decl_args(1,_) :- !.
is_wait_decl_args(I,Blockitem) :-
	arg(I,Blockitem,'?'),
	I1 is I-1,
	is_wait_decl_args(I1,Blockitem).

write_ops :-
	p_op(X,Y,Z,_File),
	write(':- '), write_canonical(op(X,Y,Z)), write('.'), nl, fail.
write_ops.

reify_difs((H :- B),(H :- B3)) :-
	extract_difs(H,[],Difvars,true,Difs), 
	reify_difs_goal(B,Difvars,_,B2),
	cons_conj(Difs,B2,B3).

reify_difs_goal(G,Difvars,Difvars2,G2) :- var(G), !,  % added for ISP as
	extract_difs(G,Difvars,Difvars2,true,Difs2),  % functor(_,_,_) does not fail
	cons_conj(Difs2,G,G2).
reify_difs_goal(G,Difvars,Difvars2,G3) :-
	functor(G,F,N), functor(Gpat,F,N), pred_parts(Gpat), !,
	functor(G2,F,N),
	reify_difs_goals(1,N,G,Gpat,Difvars,Difvars2,true,Difs,G2),
	cons_conj(Difs,G2,G3).
reify_difs_goal(G,Difvars,Difvars2,G2) :-
	extract_difs(G,Difvars,Difvars2,true,Difs2),
	cons_conj(Difs2,G,G2).

reify_difs_goals(I,N,_,_,Difvars,Difvars,Difs,Difs,_) :- I>N, !.
reify_difs_goals(I,N,G,Gpat,Difvars,Difvars2,Difs,Difs2,G2) :-
	arg(I,Gpat,Type), Type=n, !,
	arg(I,G,GI), arg(I,G2,GI),
	extract_difs(GI,Difvars,Difvars1,Difs,Difs1),
	I1 is I+1,
	reify_difs_goals(I1,N,G,Gpat,Difvars1,Difvars2,Difs1,Difs2,G2).
reify_difs_goals(I,N,G,Gpat,Difvars,Difvars2,Difs,Difs2,G2) :-
	arg(I,G,GI), arg(I,G2,G2I),
	reify_difs_goal(GI,Difvars,Difvars1,G2I),
	I1 is I+1,
	reify_difs_goals(I1,N,G,Gpat,Difvars1,Difvars2,Difs,Difs2,G2).

extract_difs(G,Difvars,Difvars2,Difs,Difs2) :-
	extract_vars(G,Gvars),
	extract_difvars(Gvars,Difvars,Difvars2,Difs,Difs2).

extract_difvars([],Difvars,Difvars,Difs,Difs).
extract_difvars([X|R],Difvars,Difvars2,Difs,Difs2) :-
	\+(varmember(X,Difvars)), frozen(X,Xdifs), Xdifs \== true, !,
%       Xdifs3=Xdifs,
	remove_already_encountered(Xdifs,Difvars,Xdifs2),
	remove_repetitions(Xdifs2,Xdifs3),
	cons_conj(Xdifs3,Difs,Difs1),
	extract_difvars(R,[X|Difvars],Difvars2,Difs1,Difs2).
extract_difvars([_|R],Difvars,Difvars2,Difs,Difs2) :-
	extract_difvars(R,Difvars,Difvars2,Difs,Difs2).

remove_already_encountered(A,Difvars,true) :-
	difgoal(A),
	extract_vars(A,Vars), % X and Y can be structures
	member(Var,Vars), varmember(Var,Difvars),!.
%       (varmember(X,Difvars); varmember(Y,Difvars)),!.
remove_already_encountered(true,_,true) :- !. % may happen in isp
remove_already_encountered(A,_,dif(X,Y)) :- difgoal(A,X,Y), !.
remove_already_encountered((A,B),Difvars,AB) :-
	remove_already_encountered(A,Difvars,A2),
	remove_already_encountered(B,Difvars,B2),
	cons_conj(A2,B2,AB).

remove_repetitions((A,B),C) :-
	difmember(A,B), !,
	remove_repetitions(B,C).
remove_repetitions((A,B),(A,C)) :- !,
	remove_repetitions(B,C).
remove_repetitions(A,A).

difmember(dif(A,B),dif(A2,B2)) :-
	A==A2, B==B2;
	A==B2, B==A2.
difmember(U,(V,W)) :-
	difmember(U,V);
	difmember(U,W).

% not used:
/*
add_frozen_vars(A,Difvars,Difvars2) :-
	difgoal(A,X,Y),
	!,
	add_if_var(X,Difvars,Difvars1),
	add_if_var(Y,Difvars1,Difvars2).

add_frozen_vars((A,B),Difvars,Difvars2) :-
	add_frozen_vars(A,Difvars,Difvars1),
	add_frozen_vars(B,Difvars1,Difvars2).
*/

:- dynamic print_settings/0.

write_settings :- print_settings, !,
		  write('/* '), nl,
		  settings,
		  write('*/'), nl.
write_settings.

rename_VARS(X,X) :- var(X), !.
rename_VARS('$VAR'(N),Constant) :-
	integer(N), !,
	name(N,Nstring),
	append(Nstring,")",NParstring),
	append("'$VAR'(",NParstring,String),
	name(Constant,String).
rename_VARS(X,Y) :-
	functor(X,XF,N),
	functor(Y,XF,N),
	rename_VARS_args(N,X,Y).

rename_VARS_args(0,_,_) :- !.
rename_VARS_args(I,X,Y) :-
	arg(I,X,XI), arg(I,Y,YI),
	rename_VARS(XI,YI),
	I1 is I-1,
	rename_VARS_args(I1,X,Y).

difgoal(A) :- difgoal(A,_,_).
