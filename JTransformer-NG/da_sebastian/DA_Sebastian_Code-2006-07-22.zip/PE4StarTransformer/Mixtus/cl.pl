% Dan Sahlin, Copyright SICS 1991
/*
classification of predicates

top-level predicates:
        classify_cls
        classify_goals/2
        classify_goals/3
        (has_cut, pred_parts)
*/

% added rules for "!(_)", treated as a cut as its scope will be the
% same as a cut whenever it is encountered, since it will be retransformed
% into a ( -> ; ) outside its scope

classify_cls([],_,_,logical,[0],_) :- !.
classify_cls(Cls,Anew,Ivars,Class,Sols,HasCut) :-
        pred_skel(Cls,Head),
        trans_to_disj(Cls,Anew,Ivars,Clsdisj),
        sols_start(Sols0),
        sols_goal_fix(Clsdisj,head(Head,Sols0),Sols0,Sols2,HasCut),
        class_goal0(Clsdisj,Sols2,Head,Class),
        trim_cut(Sols2,Sols).

sols_goal_fix(Clsdisj,Hskel,Sols0,Sols,HasCut) :-
        sols_goal(Clsdisj,Hskel,Sols1),
        merge_cut(Sols1,Sols2,HasCut0),
        (Sols0=Sols2 -> Sols=Sols2, HasCut=HasCut0;
                head(Hname/Harity,_) = Hskel,
                sols_goal_fix(Clsdisj,
                        head(Hname/Harity,Sols2),
                        Sols2,Sols,HasCut)
        ).

sols_remove(Sol,Head,Sols1,Clsdisj,Solstart,[Sol]) :-
        (member(Sol,Sols1);
         sols_goal_merge(Clsdisj,head(Head,Solstart),Sols2,_),
         member(Sol,Sols2)), !.
sols_remove(_Sol,_Head,_Sols1,_Clsdisj,_Solstart,[]).

sols_remove_a(Sol,Head,Clsdisj,Solstart,[Sol]) :-
         sols_goal_merge(Clsdisj,head(Head,Solstart),Sols2,_),
         member(Sol,Sols2), !.
sols_remove_a(_Sol,_Head,_Clsdisj,_Solstart,[]).

sols_goal_merge(Clsdisj,Hskel,Sols2,HasCut) :-
        sols_goal(Clsdisj,Hskel,Sols1),
        merge_cut(Sols1,Sols2,HasCut).


pred_skel([(H :- _)|_],Hname/Harity) :- !,
        functor(H,Hname,Harity).
pred_skel(_,_) :- write('************ pred_skel(_,_) anropad*********'),nl. %?????

%% alternative entrypoint for (conjuction/disjunction etc of) one or more goals

sols_goals(G,Sols,HasCut) :-
        sols_goal(G,dummy_nohead,Sols1),
        merge_cut(Sols1,Sols2,HasCut),
        trim_cut(Sols2,Sols).

classify_goals(G,Class2,Sols) :-
        sols_goals(G,Sols,HasCut),
        class_goal0(G,Sols,dummy_nohead,Class),
        % reclassification since class_goal treats ! as sensitive
        (HasCut == true -> Class2=side; Class2=Class).

classify_goals(G,Class) :-
        classify_goals(G,Class,_).

class_goal0(_G,Sols,_H,side) :-
        preserve_loops, has_loops(Sols), !.
class_goal0(G,_Sols,H,Class) :-
        class_goal(G,H,Class).

sols_goal(X,_,Sols) :- var(X), !,
        all_sols(Sols).

sols_goal(!,_,[pair(1,cut)]) :- !.
sols_goal(!(_),_,[pair(1,cut)]) :- !.

sols_goal(if(T,A,B),H,Sols) :- !,
        % T is inspected
        % Tcut must be "absurd"
        sols_goal(T,H,TSols),
        sols_goal(A,H,ASols),
        sols_goal(B,H,BSols),
        sols_ifb(TSols,ASols,BSols,Sols).

sols_goal((A,B),H,Sols) :- !,
        sols_goal(A,H,ASols),
        sols_goal(B,H,BSols),
        sols_and(ASols,BSols,Sols).

sols_goal((X;C),H,Sols) :-
        % ((A->B);C),
        nonvar(X), X= (A->B), !,
        sols_goal(A,H,ASols),
        sols_goal(B,H,BSols),
        sols_goal(C,H,CSols),
        sols_if(ASols,BSols,CSols,Sols).

sols_goal((A;B),H,Sols) :- !,
        % Noc = Anoc+Bnoc
        sols_goal(A,H,ASols),
        sols_goal(B,H,BSols),
        sols_or(ASols,BSols,Sols).
/****
sols_goal(call(G),H,Sols) :- !,
        sols_goal(G,H,Sols).
sols_goal(freeze(G),H,Sols) :- !,
        sols_goal(G,H,Sols2),
        (member(pair(1,nocut),Sols2) -> Sols=Sols2; Sols=[pair(1,nocut)|Sols2]).
sols_goal(freeze(_,G),H,Sols) :- !,
        sols_goal(freeze(G),H,Sols).
****/
sols_goal(A,H,Sols) :-
        ((mixtus_classify_goal(A,_Class,Sols0);
          builtin(A,_Class,Sols0);
          generated_pred(A,_Class,Sols0,_Is_recursive) %% ?? Is_recursive
         ),
         convert_sols(Sols0,Sols);
         head(Hname/Harity,Sols) = H, functor(A,Hname,Harity)
        ), !.

%??? not yet implemented:
%      incore, undo, setof, bagof, findall,

sols_goal(_,_,Sols) :- % otherwise, suspect the worst
        all_sols(Sols).

class_goal(G,_H,side) :- var(G), !.
class_goal(!,_H,sensitive) :- !. % normally cut is 'side' but its effect
                               % does not reach outside the predicate
class_goal(!(_),_H,sensitive) :- !.
class_goal(G,H,GClass) :-         % this clause must be before the next
        (mixtus_classify_goal(G,GClass,_Sols);
         builtin(G,GClass,GSols); % as findall must be handled here
         generated_pred(G,GClass,GSols,_Is_recursive); %%?? Is_recursive
         Hname/Harity = H, functor(G,Hname,Harity),
         GClass = logical % fake the recursive call as "logical" as it does not
                       % contribute to the "purity" of the predicate
        ),!.
class_goal(G,H,Class) :-
        functor(G,F,N), functor(Gpattern,F,N),
        pred_parts(Gpattern), !,
        class_goal2(G,H,Gpattern,N,Class).
class_goal(_G,_H,side).    % suspect the worst


class_goal2(_G,_H,_Gpat,0,logical) :- !.
class_goal2(G,H,Gpat,N,Class) :-
        arg(N,Gpat,Type), (Type=y;Type=nc), !,
        arg(N,G,GN),
        class_goal(GN,H,ClassGN),
        N1 is N-1,
        class_goal2(G,H,Gpat,N1,Class1),
        class_disj(ClassGN,Class1,Class).
class_goal2(G,H,Gpat,N,Class) :-
        N1 is N-1,
        class_goal2(G,H,Gpat,N1,Class).


class_disj(side,_,side) :- !.
class_disj(_,side,side) :- !.
class_disj(sensitive,_,sensitive) :- !.
class_disj(_,sensitive,sensitive) :- !.
class_disj(_,_,logical).



convert_sols([],[]).
convert_sols([N|R],[pair(N,nocut)|R2]) :- convert_sols(R,R2).

/***
convert_sols(0,[pair(0,nocut)]).
convert_sols(1,[pair(1,nocut)]).
convert_sols(many,[pair(2,nocut)]).
convert_sols(determ,[pair(0,nocut),pair(1,nocut)]).
convert_sols(nofail,[pair(1,nocut),pair(2,nocut)]).
convert_sols(varying,[pair(0,nocut),pair(1,nocut),pair(2,nocut)]).
********/

minimum(X,Y,X) :- X<Y,!.
minimum(_,Y,Y).

maximum(X,Y,X) :- X>Y,!.
maximum(_,Y,Y).

trans_to_disj([],_,_,fail) :- !.
trans_to_disj([(H :- B)],Anew,Ivars,B) :- % remove unification if it cannot fail
        verify((H=Anew, uniq_varlist(Ivars))), !.
trans_to_disj([(_H :- B)],_Anew,_Ivars,(headunify=_,B)) :- !. % create a fake unification
trans_to_disj([(H :- B)|R],Anew,Ivars,(B;R2)) :-
        verify((H=Anew, uniq_varlist(Ivars))), !, % remove unification if it cannot fail
        trans_to_disj(R,Anew,Ivars,R2).
trans_to_disj([(_H :- B)|R],Anew,Ivars, (headunify=_,B;R2)) :- % create a fake unification
        trans_to_disj(R,Anew,Ivars,R2).

sols(Asols+Bsols,Rsols) :- !, sols(Asols,Asols2), sols(Bsols,Bsols2),
                           sols_disj2(Asols2,Bsols2,Rsols).
sols(Asols*Bsols,Rsols) :- !, sols(Asols,Asols2), sols(Bsols,Bsols2),
                           sols_conj2(Asols2,Bsols2,Rsols).
sols(lub(Asols,Bsols),Rsols) :- !, sols(Asols,Asols2), sols(Bsols,Bsols2),
                           sols_lub(Asols2,Bsols2,Rsols).
sols(if(Asols,Bsols,Csols),Rsols) :- !, sols(Asols,Asols2), sols(Bsols,Bsols2),
                           sols(Csols,Csols2),
                           sols_if(Asols2,Bsols2,Csols2,Rsols).
sols(Asols,Asols).



has_cut(Cls,true) :- member((_:-B),Cls), has_cut(B),!.
has_cut(_Cls,fail).

has_cut(G) :- var(G),!.  % an unbound variable may become bound to cut
                         % or to (Test->Then)!
has_cut(!) :- !.
has_cut(!(_)) :- !.
has_cut(G) :- functor(G,F,N), functor(Gpat,F,N), pred_parts(Gpat), !,
        has_cutarg(N,G,Gpat).

has_cutarg(N,G,Gpat) :- N>0, arg(N,Gpat,Type), Type=y,
        arg(N,G,GN), has_cut(GN), !.
has_cutarg(N,G,Gpat) :- N>1, N1 is N-1, has_cutarg(N1,G,Gpat).


% pred_parts classifies a number of predefined predicates which
% may contain subgoals in their arguments.
%       y - position is a goal, and cut propagates outside
%       nc - position is a goal, but cut does not propagate outside
%            the predicate (or it may not contain a cut)
%       n - position is not a goal
pred_parts((y,y)).
pred_parts((y;y)).
pred_parts(if(nc,y,y)).
pred_parts((nc -> y)).
pred_parts((\+ nc)). % not needed as \+ is eliminated
pred_parts(freeze(nc)).
pred_parts(freeze(n,nc)).
pred_parts(frozen(n,n)). % same effect if this line is removed, just for comment
pred_parts(undo(nc)).
pred_parts(setof(n,nc,n)).
pred_parts(bagof(n,nc,n)).
pred_parts(findall(n,nc,n)).
pred_parts(n^y). % exist quantification in setof and bagof
pred_parts(call(nc)).
pred_parts(call_residue(nc,n)).
pred_parts(incore(nc)).
% pred_parts: the first arg of clause/2 gets special treatment in
%   write_predicates

/* new version
elements: a, 0, 1, a1, 2, a2
*/

:- op(700,xfx,mem).
X^Y mem L :- !, (member(X,L), !; Y mem L).
X mem L :- member(X,L), !.

sols_element(pair(X,Y)) :-
        member(X,[0,a,1,a1,2,a2]),
        member(Y,[nocut,cut]).

%sols_and(As,Bs,Zs) :- gen_sets0([Bs,As],and,Zs).
sols_and(P,Q,S) :- bagof(X,sols_and_element(P,Q,X),S).

sols_and_element(P,Q,X) :-
        sols_element(X),
        (sols_and0(X,P,Q) -> true; fail).
sols_or(As,Bs,Zs) :-  gen_sets0([Bs,As],or,Zs).
sols_if(As,Bs,Cs,Zs) :-  gen_sets0([Cs,Bs,As],if,Zs).
sols_ifb(As,Bs,Cs,Zs) :-  gen_sets0([Cs,Bs,As],ifb,Zs).

gen_sets0(Ass,Oper,Zs) :-
        gen_sets(Ass,Oper,[],[],Out), sort(Out,Zs).

gen_sets([],Oper,CBA,In,Out) :-
        sol_cut(Oper,CBA,Z), add_to_sols(In,Z,Out).

gen_sets([[]|_Ass],_Oper,_CBA,In,In).

gen_sets([[A|As]|Ass],Oper,CBA,In,Out) :-
        gen_sets(Ass,Oper,[A|CBA],In,Out2),
        gen_sets([As|Ass],Oper,CBA,Out2,Out).

add_to_sols(In,Z,In) :- member(Z,In),!.
add_to_sols(In,Z,[Z|In]).

sol_cut(and,[pair(A,ACut),pair(B,BCut)],pair(Z,ZCut)) :-
        (BCut=cut -> ((A=a;A=0) -> Z=A, ZCut=nocut;
                                   Z=B, ZCut=cut);
                     sol_and(A,B,Z),
                     ZCut=ACut).

sol_cut(or,[pair(A,ACut),pair(B,BCut)],pair(Z,ZCut)) :-
        (ACut=cut -> Z=A, ZCut=ACut;
                     sol_or(A,B,Z),
                     ZCut=BCut).

sol_cut(if,[pair(A,_ACut),pair(B,BCut),pair(C,CCut)],pair(Z,ZCut)) :-
        (A=a -> Z=A, ZCut=nocut; % no cuts in test are allowed
         A=0 -> Z=C, ZCut=CCut;
                Z=B, ZCut=BCut).

sol_cut(ifb,[pair(A,ACut),pair(B,BCut),pair(C,CCut)],pair(Z,ZCut)) :-
        (A=a -> Z=A, ZCut=nocut; % no cuts in test are allowed
         A=0 -> Z=C, ZCut=CCut;
                sol_cut(and,[pair(A,ACut),pair(B,BCut)],pair(Z,ZCut))).

% a partial evaluation of the below predicates will generate a flat database
sol_and(A,B,Z) :- sol_table(andtable,A,B,Z).
sol_or(A,B,Z) :- sol_table(ortable,A,B,Z).
sol_if(a,_Then,_Else,a).
sol_if(0,_Then,Else,Else).
sol_if(1,Then,_Else,Then).
sol_if(a1,Then,_Else,Then).
sol_if(2,Then,_Else,Then).
sol_if(a2,Then,_Else,Then).

sol_ifb(a,_Then,_Else,a).
sol_ifb(0,_Then,Else,Else).
sol_ifb(1,Then,_Else,Z) :- sol_and(1,Then,Z).
sol_ifb(a1,Then,_Else,Z) :- sol_and(a1,Then,Z).
sol_ifb(2,Then,_Else,Z) :- sol_and(2,Then,Z).
sol_ifb(a2,Then,_Else,Z) :- sol_and(a2,Then,Z).

sol_table(Table,A,B,Z) :-
        T =.. [Table,X], call(T), getelem(A,X,Row), getelem(B,Row,Z).

getelem(a, t(X,_,_,_,_,_),X).
getelem(0, t(_,X,_,_,_,_),X).
getelem(1, t(_,_,X,_,_,_),X).
getelem(a1,t(_,_,_,X,_,_),X).
getelem(2, t(_,_,_,_,X,_),X).
getelem(a2,t(_,_,_,_,_,X),X).

andtable(t(
        t(a, a, a, a, a, a), %a
        t(0, 0, 0, 0, 0, 0), %0
        t(a, 0, 1,a1, 2,a2), %1
        t(a, a,a1,a1,a2,a2), %a1
        t(a, 0, 2,a1, 2,a2), %2
        t(a, a,a2,a1,a2,a2))). %a2

ortable(t(
        t( a, a, a, a, a, a), %a
        t( a, 0, 1,a1, 2,a2), %0
        t(a1, 1, 2,a2, 2,a2), %1
        t(a1,a1,a1,a1,a1,a1), %a1
        t(a2, 2, 2,a2, 2,a2), %2
        t(a2,a2,a2,a2,a2,a2))). %a2

all_sols([pair(0,nocut),pair(1,nocut), pair(2,nocut),
          pair(a,nocut),pair(a1,nocut), pair(a2,nocut)]) :- preserve_loops, !.
                % except cut
all_sols([pair(0,nocut),pair(1,nocut), pair(2,nocut)]).
                % except cut and loop

sols_start([pair(a,nocut)]) :- fixpointiteration, !.
sols_start(X) :- all_sols(X).

merge_cut([],[],_).
merge_cut([pair(X,cut)|R],L,true) :- member(pair(X,_),R), !, merge_cut(R,L,_).
merge_cut([pair(X,Cut)|R],[pair(X,nocut)|L],HasCut) :- merge_cut(R,L,HasCut2),
        (Cut=cut -> HasCut=true; HasCut=HasCut2).

trim_cut(Sols,Out) :-
%        remove_loops(Sols,Sols2),  % not in cl5!
        Sols=Sols2,
        clear_cut(Sols2,Out).

% clear_cut removes the "pair" just keeping its first component

% remove_loops removes all loop values if "preserve_loops" is fail, i.e.
% "a1" and "a2" are replaced by "1" and "2" respectively and "a" is removed

:- dynamic preserve_loops/0.
% preserve_loops.

remove_loops(Sols,Sols) :- preserve_loops, !.
remove_loops(Sols1,Sols3) :- remove_loops2(Sols1,Sols2), sort(Sols2,Sols3).
                                 % sort removes the duplicates

remove_loops2([],[]).
remove_loops2([pair(a,_)|R],R2) :- remove_loops2(R,R2).
remove_loops2([pair(X,Cut)|R],[pair(X2,Cut)|R2]) :-
        rem_loop(X,X2), remove_loops2(R,R2).

rem_loop(a1,1).
rem_loop(a2,2).
rem_loop(X,X).

has_loops([pair(X,_)|_]) :- X=a; X=a1; X=a2.
has_loops([_|R]) :- has_loops(R).

clear_cut([],[]).
clear_cut([pair(X,_)|R],[X|Out]) :- !, clear_cut(R,Out).

%   success - the predicate always succeeds (for performing cuts)
%       -> at least one solution
success(Goals) :-
        sols_goals(Goals,Sols,_HasCut),
%        classify_goals(Goals,_Class,Sols),
        sols_success(Sols).

%   mixtus_deterministic - no choicepoints are created by predicate (for cut-elim).
%       -> at most one solution
mixtus_deterministic(Goals) :-
        sols_goals(Goals,Sols,_HasCut),
%        classify_goals(Goals,_Class,Sols),
        sols_mixtus_deterministic(Sols).

failure(Goals) :-
        sols_goals(Goals,Sols,_HasCut),
        sols_failure(Sols).

sols_failure(Sols) :- empty_intersection([1,2,a1,a2],Sols).

sols_mixtus_deterministic(Sols) :- empty_intersection([2,a2],Sols).

sols_success(Sols) :- empty_intersection([0],Sols).

empty_intersection(A,B) :- \+ (member(X,A), member(X,B)).

:- dynamic fixpointiteration/0.
fixpointiteration.

mixtus_classify_goal(G,Class,Sols) :- isp, !, user:classify_goal(G,Class,Sols).
mixtus_classify_goal(G,Class,Sols) :- classify_goal(G,Class,Sols).
