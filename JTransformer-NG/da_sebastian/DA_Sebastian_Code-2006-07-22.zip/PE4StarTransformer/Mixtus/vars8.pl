% Dan Sahlin, Copyright SICS 1991
% H is a functor whose all arguments are all different variables
only_vars(H) :- H =.. [_|FList],
                uniq_varlist(FList).

uniq_varlist([]).
uniq_varlist([V|Vs]) :- var(V),
        frozen0(V,true), % no difs on V
        \+((member(V1,Vs), V1==V)), uniq_varlist(Vs).

varmember(V,[H|_]) :- V==H,!.        %% ?? borde bytas mot varmember/3
varmember(V,[_|T]) :- varmember(V,T).

varmember(V,[H|T],T) :- V==H,!.
varmember(V,[H|T],[H|T2]) :- varmember(V,T,T2).

% variable_variants(A,B) :- verify((numbervars(A,0,N),numbervars(B,0,N),A=B)).
% note: this test assumes that A and B do not have any variables in common
variable_variants(A,B) :-
        verify((numbervars(A,0,N),numbervars(B,0,N),A=B)),
        isinstance_dif(A,B), isinstance_dif(B,A). % this line is actually a
                        % stronger test than verify above, but verify
                        % is kept as it fails much quicker.

%S.L. 2.07.06 --------------------------------------------------------
%:- redefine_system_predicate(flatten/2).
:- redefine_system_predicate(member/2).
:- redefine_system_predicate(append/3).
:- abolish(lists:append/3).
:- abolish(lists:member/2).
:- abolish(lists:flatten/2).
%End S.L.


member(X,[X|_]).
member(X,[_|Y]) :- member(X,Y).

member(X,[X|Xs],Xs).
member(X,[_|Y],Xs) :- member(X,Y,Xs).

% Quintus will complain about redefinition of append here:

append([], L, L).
append([H|T], L, [H|R]) :-
        append(T, L, R).


flatten([],[]).
flatten([H|T],L) :- flatten(T,T2), append(H,T2,L).

vars_in_both([],_,[]).
vars_in_both([H|T],SL,T3) :- varmember(H,SL,SL2), !,
                T3=[H|T2], vars_in_both(SL2,T,T2).
vars_in_both([_|T],SL,T2) :- vars_in_both(SL,T,T2).

vars_in_both_ordered([],_,[]).
vars_in_both_ordered([H|T],SL,T3) :- varmember(H,SL,SL2), !,
                T3=[H|T2], vars_in_both_ordered(T,SL2,T2).
vars_in_both_ordered([_|T],SL,T2) :- vars_in_both_ordered(T,SL,T2).


subtract_vars(G,[],G) :- !.
subtract_vars(G,[H|R],G2) :- varmember(H,G,G1), subtract_vars(G1,R,G2).

same_varlists(A,B) :- sort(A,AS), sort(B,BS), AS==BS.

extract_vars_ordered(X,Xvars) :-
        extract_vars_ordered(X,[],top,Xvars0), rev(Xvars0, Xvars).

extract_vars_ordered(X,L,_,L2) :- atomic(X), !, L=L2.
extract_vars_ordered(X,L,Top,L2) :- var(X),!,
        (varmember(X,L) -> L2=L;
                (Top=top ->
                        frozen0(X,Xfrozen),
                        extract_vars_ordered(Xfrozen,[X|L],lower,L2);
                        L2=[X|L])).
extract_vars_ordered(X,L,Top,L2) :-
        functor(X,_F,N), extract_vars_args_ordered(1,N,X,L,Top,L2).

extract_vars_args_ordered(N,M,_,L,_,L) :- N>M, !.
extract_vars_args_ordered(N,M,X,L,Top,L2) :- arg(N,X,XN),
        extract_vars_ordered(XN,L,Top,L1),
        N1 is N+1, extract_vars_args_ordered(N1,M,X,L1,Top,L2).

% extract_vars is used instead of extract_vars whenever
% unordered extraction of variables is possible as it is much more efficient
extract_vars(X,Xvars) :-
extract_vars(X,[],Xvars0), sort(Xvars0,Xvars).

extract_vars(X,L,L2) :- atomic(X), !, L=L2.
extract_vars(X,L,L2) :- var(X),!, L2=[X|L].
extract_vars([H|T],L,L2) :- !, extract_vars(H,L,L1), extract_vars(T,L1,L2).
extract_vars(X,L,L2) :- functor(X,_F,N), extract_vars_args(1,N,X,L,L2).

extract_vars_args(N,M,_,L,L) :- N>M, !.
extract_vars_args(N,M,X,L,L2) :- arg(N,X,XN), extract_vars(XN,L,L1),
                               N1 is N+1, extract_vars_args(N1,M,X,L1,L2).

rev(X,Xrev) :- rev(X,[],Xrev).

rev([],Acc,Acc).
rev([X|Xs],Acc,Xrev) :- rev(Xs,[X|Acc],Xrev).

%% borde kanske byta fil ???
% X is an instance of Y
isinstance(X,Y) :- verify((numbervars(X,1,_), X=Y)).

verify(X) :- \+ (\+ X).

vars_in_common(A,B,Cvars) :-
        extract_vars(A,Avars), extract_vars(B,Bvars),
        vars_in_both(Avars,Bvars,Cvars).

vars_in_common_ordered(A,B,Cvars) :-
% extract_vars_ordered must be used first below so the order of vars is preserved
        extract_vars_ordered(A,Avars), extract_vars(B,Bvars),
        vars_in_both_ordered(Avars,Bvars,Cvars).

% Outvars contains all the variables in Vars, but with the variables in
% Ivars put first (this will facilitate indexing in the code produced)
ivars_first(Vars,Ivars,Outvars) :-
        ivars_first(Vars,Ivars,Restvars-[],Outvars-Restvars).

ivars_first([],_Ivars,Restvars-Restvars,Outvars-Outvars).
ivars_first([H|T],Ivars,Restvars-Restvarstail,[H|Outvars]-Outvarstail) :-
        varmember(H,Ivars), !,
        ivars_first(T,Ivars,Restvars-Restvarstail,Outvars-Outvarstail).
ivars_first([H|T],Ivars,[H|Restvars]-Restvarstail,Outvars-Outvarstail) :-
        ivars_first(T,Ivars,Restvars-Restvarstail,Outvars-Outvarstail).
