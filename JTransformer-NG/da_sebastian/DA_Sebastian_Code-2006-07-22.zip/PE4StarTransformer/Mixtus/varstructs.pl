% Dan Sahlin, Copyright SICS 1991
:- dynamic maxvarstructs/1.
maxvarstructs(10).

% - recursively checks the deeper structures first. If they contain too
% many variables, they are replaced by a variable.
% - does not check if it is the same variable occurring many times
% in a structure
% - in the partial evaluator, knowledge about the structures is removed
% as this transformation works just as generalized restart. However, this
% is not the same thing, and it should be handled differently. Maybe
% the goal-stack should be extended with one more item as follows:
% Instead of having
%       A - original call
%       Anew - arguments are all vars in original call, the new call
% maybe there should be
%       A - original call
%       Anew - arguments are all vars in original call
%       Acall - some arguments may be structures, now this is the new call
% Main problem with this approach: what to do with variables occurring
% in several structures



varstructs(S,T) :- functor(S,F,N),
		   functor(T,F,N),
		   trim_varstructs_arg(N,S,T).

trim_varstructs(S,S) :- var(S), !.
trim_varstructs(S,Sout) :- functor(S,F,N),
			functor(T,F,N),
			trim_varstructs_arg(N,S,T),
			count_vars(T,0,Nvars),
			maxvarstructs(Maxvars),
			(Nvars > Maxvars ->
				true;
				Sout=T
			).

trim_varstructs_arg(0,_,_) :- !.
trim_varstructs_arg(N,S,T) :-
	arg(N,S,SN), arg(N,T,TN),
	trim_varstructs(SN,TN),
	N1 is N-1,
	trim_varstructs_arg(N1,S,T).

count_vars(X,I,I1) :- var(X),!,I1 is I+1.
count_vars(X,I,M) :- functor(X,_,N),!,
		     count_vars_args(N,X,I,M).

count_vars_args(0,_,I,I) :- !.
count_vars_args(N,X,I,M) :-
	arg(N,X,XN),
	count_vars(XN,I,I2),
	N1 is N-1,
	count_vars_args(N1,X,I2,M).


