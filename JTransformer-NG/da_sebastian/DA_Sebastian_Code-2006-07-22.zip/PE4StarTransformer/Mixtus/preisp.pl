% Dan Sahlin, Copyright SICS 1991
% This file exists in two versions:
%       preisp: version before Industrial SICStus Prolog (<= SICStus 0.7)
%       isp:     version for Industrial SICStus Prolog    (>= SICStus 2.0)


call_residue0(X,L) :-
	handle_freeze -> call_residue(X,L);
			 L=[], call(X).

:- op(1150, fx, block). % for compatibility with isp, can be removed

% :- consult(preisp2).

:- consult(files).

:- files(F), compile(F).

