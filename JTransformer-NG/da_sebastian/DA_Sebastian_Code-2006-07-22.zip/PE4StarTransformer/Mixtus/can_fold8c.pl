% Dan Sahlin, Copyright SICS 1991
:- dynamic tracefolding/0.

can_fold(A,state(C,GS,H,Ivars,_Level,_Cut,_Break,_Last,_Reval,Rin,_Rout),Stricttest,Anew) :-
	Surrounding=[H,Rin,C],
	gs_member(A2,Anew2,Ivars2list,Info,GS), % nonmixtus_deterministic choice in GS
	isinstance_dif(A,A2), % no cut here      % 1. instance
	(Stricttest=true,gs_info_init(Info) ->
		isinstance_dif(A2,A), Foldtype=variant;
		Foldtype=instance), % possibly also same Ivars?
	extract_vars(A2,A2vars),
	extract_vars(Anew2,Svars2),
	subtract_vars(A2vars,Svars2,NonSvars2),
	subtract_vars(A2vars,Ivars2list,NonIvars2),
	copy_term(t(A2,Anew2,NonSvars2,NonIvars2),
		  t(A,Anew,NonSvars,NonIvars)),
	uniq_varlist(NonIvars),            % 2. All NonIvars still unbound
%%        uniq_varlist(NonSvars),            % 2. All NonSvars still unbound
			     % unnecessary to check since subsumed by test 2.
	vars_in_common(NonIvars,Ivars,[]), % 3. No NonIvars cannot become bound
	vars_in_common(NonSvars,Surrounding,[]), % 3. No NonSvars cannot become bound
% extra villkor, problem med terminering
	(modes ->
		extract_vars(A,Avars),
		vars_in_common(Avars,Ivars,Ivarslist),
		subtract_vars(Avars,Ivarslist,NonIvars0),
		same_varlists(NonIvars0,NonIvars);
		true),
	(tracegoalstack,tracefolding ->
		(Foldtype=variant ->
			write_goalstack(A,GS,'folded variant');
			write_goalstack(A,GS,'folded instance'));
		true).
