% Dan Sahlin, Copyright SICS 1991
remove_last_cut_cls(Cls,Cuttype,Clsbefore,(H :- B2)) :-
	(Cuttype=!),
%       Cuttype='!if'),
	append(Clsbefore,[(H :- B)],Cls),
	remove_last_cut_goals(B,Cuttype,B2,Removed),
	Removed==true.

remove_last_cut_goals(X,_,X,_) :- var(X), !.
remove_last_cut_goals(G,Cuttype,true,true) :- is_cut(G,Cuttype), !. % "true" removed by cleanup_conj if possible
remove_last_cut_goals((G,G2),_Cuttype,G3,_) :- var(G), !,
	cons_conj(G,G2,G3).
remove_last_cut_goals((G,G1),Cuttype,G2,true) :- is_cut(G,Cuttype), !, remove_last_cut_goals(G1,Cuttype,G2,_).
remove_last_cut_goals(if(A,B,C),Cuttype,if(A,B3,C3),Removed) :- !,
	remove_last_cut_goals(B,Cuttype,B2,Removed), remove_last_cut_goals(C,Cuttype,C2,Removed),
	cleanup_conj(B2,B3), cleanup_conj(C2,C3).
remove_last_cut_goals((G,G2),Cuttype,G4,Removed) :- mixtus_deterministic(G), !,
	remove_last_cut_goals(G2,Cuttype,G3,Removed),
	cons_conj(G,G3,G4).
remove_last_cut_goals((G;G2),Cuttype,((A->B3);G4),Removed) :- nonvar(G), G=(A->B),!,
	remove_last_cut_goals(B,Cuttype,B2,Removed),
	remove_last_cut_goals(G2,Cuttype,G3,Removed),
	cleanup_conj(B2,B3), cleanup_conj(G3,G4).
remove_last_cut_goals((G;G2),Cuttype,(G;G4),Removed) :- !,
	remove_last_cut_goals(G2,Cuttype,G3,Removed),
	cleanup_conj(G3,G4).
remove_last_cut_goals(G,_Cuttype,G,_).

is_cut(Cuttype,Cuttype).  % Cuttype is either ! or '!if'
