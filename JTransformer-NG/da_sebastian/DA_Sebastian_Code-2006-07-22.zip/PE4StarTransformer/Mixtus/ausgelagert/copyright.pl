#!/bin/sh
ftparea=$1
shift
for i in $*
do
	(echo "% Dan Sahlin, Copyright SICS 1991"; cat $i) >$ftparea/$i
done











