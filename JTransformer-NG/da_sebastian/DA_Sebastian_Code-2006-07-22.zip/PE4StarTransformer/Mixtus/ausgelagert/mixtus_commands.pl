#!/bin/sh
version=$1
shift
sicstusversion=$1
shift
executable=$1
echo "version('Mixtus" $version"').";

# possibly native code:
echo "write('Ignore warnings below as native code is only available on some machines.')."
echo "prolog_flag(compiling,_,fastcode)."
echo "consult('"$sicstusversion"')."
echo "consult('"$executable"')."
echo $nofreeze
echo "save_program(mixtus)."

