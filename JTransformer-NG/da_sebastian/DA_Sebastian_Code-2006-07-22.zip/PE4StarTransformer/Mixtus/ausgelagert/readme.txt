This directory contains the source for Mixtus 0.3.6
Mixtus is an automatic partial evaluator for full Prolog.
Mixtus is Copyright SICS 1991

INSTALLATION

    To install "mixtus" in /usr/local/bin, and the manual page in
    /usr/local/man/man1 do
	    make install
    Note that if SICStus is reinstalled, Mixtus also has to be reinstalled.

    For a sample run see the file SAMPLE.RUN. The manual page also
    contains valuable information.

COMPATIBLE PROLOG SYSTEMS

    The two recommended versions of SICStus to run Mixtus under are SICStus
    0.7 #3 and SICStus 2.1 #3. It is also possible to run Mixtus under other
    Prolog systems, e.g.  Quintus.  Under Quintus, some warnings are given
    when the system is loaded. The Prolog system used can be changed by
    changing the variable PROLOG in the Makefile.

    Mixtus 0.3.5 runs best under SICStus 2.1 #3 or later.  Earlier versions of
    SICStus (before 0.7 #3) and other Prolog systems can be used but the
    capability of handling freeze etc is lost as the command
	    unset(handle_freeze).
    is automatically run when Mixtus is loaded.

    I have not yet worked out the interaction with the module system, so
    bagof, setof and findall are not expanded as they should.

    SICStus Prolog version 1.8 and later is not quite compatible with Mixtus
    mainly as Mixtus does not yet fully support modules.
    However, if modules are not used most will work well.
    Due to a bug in SICStus 1.8-2.1, "unset(handle_freeze)" must be set.
    The bug was fixed in SICStus 2.1 #2.
    Another bug was fixed in SICStus 2.1 #3 which otherwise printed out the
    name of modules when programs were printed by portray_clause.
    Please get the latest version of SICStus to run Mixtus. Contact
    sicstus-request@sics.se for licencing information.

Warning: don't try to read the Mixtus code.  It is poorly documented and
contains a lot of dead code.  I will try to clean it up at some time...
However, I don't know of any major bugs, so if you do find one, please let
me know.

My thesis named "An Automatic Partial Evaluator for Full Prolog" which
describes the system can be ordered free of charge from me.

A summary of my thesis can be found in "The Mixtus Approach to Automatic
Partial Evaluation of Full Prolog", In proceedings of the North American
Conference on Logic Programming 1990, MIT Press.

All comments are most welcome, in particular bug-reports and interesting
applications. I still lack a substantial example where Mixtus has
been used outside SICS, so please contact me if you are working with
such an example. I may also be able to help you if you get stuck using
Mixtus.

	/Dan Sahlin
email: dan@sics.se
