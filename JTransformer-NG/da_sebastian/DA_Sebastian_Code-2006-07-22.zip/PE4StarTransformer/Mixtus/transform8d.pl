% Dan Sahlin, Copyright SICS 1991
:- dynamic maxlevel/1.

maxlevel(0).
ok_maxlevel(level(Level,InTest)) :- InTest=0, maxlevel(Max), Level=<Max.

retransform_if(Thenpart,Cls_or2) :-
	cleanup_conj(Thenpart,Cls_or),
	collect_tests(Cls_or,Tests,[]),
	change_last_if(Tests,Cls_or2).

collect_tests((A;B),[(A;B)|TR],TR) :- A = (_->_), !.
collect_tests((A;B),T1,T3) :- !,
	collect_tests(A,T1,T2),
	collect_tests(B,T2,T3).
collect_tests(A,[Test|TR],TR) :- !,
	collect_test0(A,Test).

collect_test0(A,Test) :-
	collect_test(A,[],Cases,Test0),
	(Cases=[] -> Test=Test0;
	 Cases=[Place-G] ->
		Place=true,
		cleanup_test(Test0,Test1),
		Test=(Test1->G)
	;       make_cases(Cases,1,_X,Ifthencases),
		Test=(Test0->Ifthencases)
	).

make_cases([(X=N)-G],N,X,(X=N->G;true)) :- !.
make_cases([(X=N)-G|R],N,X,((X=N->G);Ifthen)) :-
	N1 is N+1,
	make_cases(R,N1,X,Ifthen).

extend_cases([],X-G,[X-G]):-!.
extend_cases([X0-G0|Cases],X-G,[X0-G0|Cases]):- G==G0,!,X=X0.
extend_cases([E|Cases],X-G,[E|Cases2]):-
	extend_cases(Cases,X-G,Cases2).

cleanup_test(A,A) :- var(A), !.
cleanup_test((A,B),A) :- B==true, !.
cleanup_test((A,B),(A,B2)) :- !, cleanup_test(B,B2).
cleanup_test((A;B),(A2;B2)) :- \+ A=(_->_), !,
	cleanup_test(A,A2), cleanup_test(B,B2).
cleanup_test(A,A).


% collect_test(((A;B),C),Cases,Casesout,A) :- !, % cannot occur
collect_test(A,Cases,Cases,A) :- var(A),!.
collect_test((A,B),Cases,Casesout,(A,B2)) :- var(A),!,
	collect_test(B,Cases,Casesout,B2).
collect_test(((A,B),C),Cases,Casesout,Tout) :- !,
	collect_test((A,(B,C)),Cases,Casesout,Tout).
collect_test((true,B),Cases,Casesout,B2) :- !,
	collect_test(B,Cases,Casesout,B2).
collect_test('!if',Cases,Cases2,X) :- !,
	extend_cases(Cases,X-true,Cases2).
collect_test(('!if',B),Cases,Cases2,X) :- !, % one_more_cut(B), !, % optimization
	extend_cases(Cases,X-B,Cases2).
collect_test((A,B),Cases,Casesout,(A,X)) :- !,
	collect_test(B,Cases,Casesout,X).
collect_test((A;B),Casesin,Casesout,(Aout;Bout)) :- \+ A=(_->_), !,
	collect_test(A,Casesin,Cases2,Aout),
	collect_test(B,Cases2,Casesout,Bout).
collect_test(A,Cases,Cases,A).

%                  mixtus_deterministic beh|vs ej, g|rs i remove_last_cut
change_last_if([(A->B)],AB) :- mixtus_deterministic(A), !, cleanup_conj((A,B),AB).
change_last_if([(A->B)],((A->B);fail)) :- !.
change_last_if([A],A) :- !.
change_last_if([T|T1s],(T;T2s)) :- change_last_if(T1s,T2s).
