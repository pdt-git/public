% Dan Sahlin, Copyright SICS 1991
% This file exists in two versions:
%       preisp: version before Industrial SICStus Prolog (<= SICStus 0.7)
%       isp:     version for Industrial SICStus Prolog    (>= SICStus 2.0)

/*
:- module(mixtus,[pconsult/1,pe/1,pe/2,pei/2,pei/3,
		    settings/0,set/1,set/2,unset/1,
		    pe_all/0, pe_all/1, erase_all/0
		    ]).
*/

:- meta_predicate(call_residue0(:,-)).

call_residue0(X,L) :-
	handle_freeze -> call_residue(X,L);
			 L=[], call(X).

:- op(1150, fx, wait). % for compatibility with preisp, can be removed

% :- compile(isp2).
/*
:- consult(files).

:- files(F), compile(F).
*/

