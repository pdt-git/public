% Dan Sahlin, Copyright SICS 1991
erase_to_top(T) :- stack_top(Top), erase_to_top(T,Top).

erase_to_top(T,T) :- !.
erase_to_top(T,Top) :- retract(saved_predicates(_,_,_,_,_,_,_,_,Top)),
		       erase_to_top(T).

stack_top(Num) :- clause(saved_predicates(_,_,_,_,_,_,_,_,Num),_), !.
stack_top(0).
