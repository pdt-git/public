% Dan Sahlin, Copyright SICS 1991
% all builtin predicates are listed here
% they are classified into three groups (see below):
% logical, sensitive and those with sideeffects (which is the default
% for unclassified builtin predicates).
% The "best" group is the first and the "worst" the last.

builtin(P,Class,Sols) :-
        builtin_data(P,Class2,Sols),
        (Class2=sensitive, is_ground(P) -> Class=logical; Class=Class2).

builtin_data(findall(_,G,_),Class2,[0,1]) :- % actually meta-predicate
       classify_goals(G,Class,_), class_disj(Class,sensitive,Class2).


% 4.1.1 reading in
builtin_data(consult(_),side,[1]).
builtin_data(reconsult(_),side,[1]).
builtin_data([_|_],side,[1]).
builtin_data(compile(_),side,[1]).
builtin_data(fcompile(_),side,[1]).
builtin_data(load(_),side,[1]).

% 4.1.2 Term I/O
builtin_data(read(_),side,[0,1]).
builtin_data(write(_),side,[1]).
builtin_data(display(_),side,[1]).
builtin_data(write_canonical(_),side,[1]).
builtin_data(writeq(_),side,[1]).
builtin_data(print(_),side,[1]).
builtin_data(portray(_),side,[1]).
builtin_data(portray_clause(_),side,[1]).
builtin_data(format(_,_),side,[1]).

% 4.1.3. Char I/O

builtin_data(nl,side,[1]).
builtin_data(get0(_),side,[0,1]).
builtin_data(get(_),side,[0,1]).
builtin_data(skip(_),side,[1]).
builtin_data(put(_),side,[1]).
builtin_data(tab(_),side,[1]).
builtin_data(ttynl,side,[1]).
builtin_data(ttyflush,side,[1]).
builtin_data(ttyget(_),side,[1]).
builtin_data(ttyget(_),side,[0,1]).
builtin_data(ttyput(_),side,[1]).
builtin_data(ttyskip(_),side,[1]).
builtin_data(ttytab(_),side,[1]).

% 4.1.4 Stream I/O

builtin_data(open(_,_,_),side,[1]).
builtin_data(close(_),side,[1]).
builtin_data(absolute_file_name(_,_),sensitive,[0,1]).
builtin_data(current_input(_),sensitive,[0,1]).
builtin_data(current_output(_),sensitive,[0,1]).
builtin_data(current_stream(_,_,_),sensitive,[0,1,2]).
builtin_data(set_input(_),side,[1]).
builtin_data(set_output(_),side,[1]).
builtin_data(flush_output(_),side,[1]).
builtin_data(library_directory(_),sensitive,[0,1,2]).
builtin_data(open_null_stream(_),side,[1]).
builtin_data(stream_code(_,_),sensitive,[0,1,2]).
builtin_data(fileerrors,side,[1]).
builtin_data(nofileerrors,side,[1]).

builtin_data(format(_,_,_),side,[1]).
builtin_data(get(_,_),side,[0,1]).
builtin_data(get0(_,_),side,[0,1]).
builtin_data(nl(_),side,[1]).
builtin_data(print(_,_),side,[1]).
builtin_data(put(_,_),side,[1]).
builtin_data(read(_,_),side,[0,1]).
builtin_data(skip(_,_),side,[1]).
builtin_data(tab(_,_),side,[1]).
builtin_data(write(_,_),side,[1]).
builtin_data(write_canonical(_,_),side,[1]).
builtin_data(writeq(_,_),side,[1]).

% 4.1.5 DEC10 I/O

builtin_data(see(_),side,[1]).
builtin_data(seeing(_),logical,[0,1]).
builtin_data(seen,side,[1]).
builtin_data(tell(_),side,[1]).
builtin_data(telling(_),logical,[0,1]).
builtin_data(told,side,[1]).

% 4.2 arithmetic

builtin_data(_ is _,Class,[0,1]) :- arithlogical(Class).
builtin_data(_ =:= _,Class,[0,1]) :- arithlogical(Class).
builtin_data(_ =\= _,Class,[0,1]) :- arithlogical(Class).
builtin_data(_ < _,Class,[0,1]) :- arithlogical(Class).
builtin_data(_ > _,Class,[0,1]) :- arithlogical(Class).
builtin_data(_ =< _,Class,[0,1]) :- arithlogical(Class).
builtin_data(_ >= _,Class,[0,1]) :- arithlogical(Class).


% 4.3 comparison

builtin_data(_ == _,sensitive,[0,1]).
builtin_data(_ \== _,sensitive,[0,1]).
builtin_data(_ @< _,sensitive,[0,1]).
builtin_data(_ @> _,sensitive,[0,1]).
builtin_data(_ @=< _,sensitive,[0,1]).
builtin_data(_ @>= _,sensitive,[0,1]).
builtin_data(compare(_,_,_),sensitive,[0,1]).
builtin_data(sort(_,_),sensitive,[0,1]).
builtin_data(keysort(_,_),sensitive,[0,1]).

% 4.4 control
% builtin_data((_,_),coded).
% builtin_data((_;_),coded).
builtin_data(true,logical,[1]).
builtin_data(otherwise,logical,[1]).
builtin_data(fail,logical,[0]).
builtin_data(false,logical,[0]).
builtin_data(_ = _,logical,[0,1]).
builtin_data(dif(_,_),logical,[0,1]).
builtin_data(prolog_flag(_,_,_),side,[0,1]).
builtin_data(!,side,[1]).
% builtin_data(\+ _,coded).          % meta-predicate
% builtin_data((P -> Q ; R),coded).  % meta-predicate
% builtin_data((P -> Q),coded).      % meta-predicate
% builtin_data(if(P,Q,R),coded).     %% ??? ej klar
builtin_data(repeat,Class,[2]) :-
        (preserve_loops ->
                Class = side;
                Class = logical).
builtin_data(freeze(_,G),Class,Sols) :- !,
        classify_goals(G,Class,Sols),
        (member(1,Sols) -> Sols2=Sols; Sols2=[1|Sols]).
builtin_data(freeze(G),Class2,Sols2) :- !,  % meta-predicate
        classify_goals(G,Class,Sols),
        (member(1,Sols) -> Sols2=Sols; Sols2=[1|Sols]),
        (Class=sensitive -> Class2=logical; % as G is ground when executed
                             Class2=Class).
builtin_data(frozen(_,_),sensitive,[0,1]).
%builtin_data(call(_,_),coded)       %% ??? ej klar

% 4.5 state of the program

builtin_data(listing,side,[1]).
builtin_data(listing(_),side,[1]).
builtin_data(ancestors(_),sensitive,[1]).     %%% ??? cannot really be handled at all
builtin_data(subgoal(_),sensitive,[0,1,2]).       %%% ??? ditto
builtin_data(current_atom(_),sensitive,[0,1,2]).
builtin_data(current_predicate(_),sensitive,[0,1,2]).  %%% ??? cannot really be handled
builtin_data(predicate_property(_,_),sensitive,[0,1,2]).

% 4.6 meta-logical

builtin_data(var(_),sensitive,[0,1]).
builtin_data(nonvar(_),sensitive,[0,1]).
builtin_data(atom(_),sensitive,[0,1]).
builtin_data(float(_),sensitive,[0,1]).
builtin_data(integer(_),sensitive,[0,1]).
builtin_data(number(_),sensitive,[0,1]).
builtin_data(atomic(_),sensitive,[0,1]).
builtin_data(functor(_,_,_),Class,[0,1]) :-
        ((functor_logical;isp) -> Class=logical; Class=sensitive).
        % functor(X,F,N),X=a fails, whereas
        % functor(a,F,N) succeeds
        % this can be overridden by setting "functor_logical"
builtin_data(arg(_,_,_),Class,[0,1]) :-  %%% arg(N,f(a),_),N=1 fails
                                         %% although arg(1,f(a),_) succeeds
        (arg_logical;isp -> Class=logical; Class=sensitive).
builtin_data(_ =.. _,logical,[0,1]).
builtin_data(name(_,_),logical,[0,1]).
builtin_data(atom_chars(_,_),logical,[0,1]).
builtin_data(number_chars(_,_),logical,[0,1]).
% builtin_data(call(_),coded).
% builtin_data(incore(_),coded).
% builtin_data((_),coded).

builtin_data(copy_term(_,_),sensitive,[0,1]).
%builtin_data(copy_term_nofail(_,_),sensitive,[1]).
builtin_data(numbervars(_,_,_),sensitive,[0,1]).

% 4.7 modification of the program

builtin_data(assert(_),side,[1]).
builtin_data(asserta(_),side,[1]).
builtin_data(assertz(_),side,[1]).
builtin_data(clause(_,_),logical,[0,1,2]).
builtin_data(clause(_,_,_),logical,[0,1,2]).
builtin_data(retract(_),side,[0,1,2]).
builtin_data(retractall(_),side,[1]).
builtin_data(abolish(_),side,[1]).
builtin_data(abolish(_,_),side,[1]).

% 4.8 internal database

builtin_data(recorded(_,_,_),logical,[0,1,2]).
builtin_data(recorda(_,_,_),side,[1]).
builtin_data(recordz(_,_,_),side,[1]).
builtin_data(erase(_),side,[1]).
builtin_data(instance(_,_),logical,[0,1,2]).
builtin_data(current_key(_,_),logical,[0,1,2]).

% 4.13

% builtin_data(setarg(_,_,_),???).   %%% ??? not able to handle setarg!
builtin_data(undo(_),side,[1]).
%builtin_data(length(_,_),logical,[0,1,2]). % special cases handled by "evaluable"
builtin_data(length(A,B),Class,[0,1|E]) :- % special cases handled by "evaluable"
        (var(B), open_list(A) ->
                E = [2],
                (preserve_loops ->
                        Class = side
                ;       Class = logical)
        ;       E = [],
                Class = logical).

% pseudo-predicate only used internally by the partial evaluator

builtin_data('!if',side,[1]).  %%

% if "arithlogical" is true then arithmetic expressions are considered
% logical assuming correct program
% i.e. expression will not contain unbound variables when executed
% (in earlier versions of SICStus "X<3" fails,
% whereas a warning is given in version 0.7)

:- dynamic arithlogical/0.

arithlogical.

arithlogical(logical) :- arithlogical,!.
arithlogical(sensitive).

:- dynamic functor_logical/0.
:- dynamic arg_logical/0.

open_list(A) :- var(A).
open_list(A) :- functor(A,F,2), F='.', arg(2,A,A2), open_list(A2).

