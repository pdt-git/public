% Dan Sahlin, Copyright SICS 1991
evaluable(fail).
evaluable(fail).
evaluable(true).
evaluable(otherwise).

% evaluable((X > Y)) see builtin2
% evaluable((X =< Y)) see builtin2
% evaluable((X < Y)) see builtin2
% evaluable((X >= Y)) see builtin2
% evaluable(var(X))     see evaluablel
% ??? evaluable(X = Y) :- \+ is_cyclic_unif(X,Y).
%%%%%%% (new) evaluable start

% 4.2
% evaluable(X is Y) see builtin2
% evaluable(X =:= Y) see builtin2
% see also builtin2

% 4.3

% 4.4 control
% the following predicates are handled specifically in the interpreter ???
% , ; ! \+ -> if( , , ) otherwise true false fail repeat
% freeze, call, incore, a variable,

evaluable(frozen(X,_)) :- nonvar(X).

% 4.5 information about the state of the program

% evaluable(predicate_property(G,_)) :- nonvar(G). % is actually always
%          % evaluable, but seems unreasonable to expand if G is var

% 4.6 meta-logical

% evaluable(nonvar(X)) see evaluablel
evaluable(atom(X)) :- nonvar(X).
evaluable(float(X)) :- nonvar(X).
evaluable(integer(X)) :- nonvar(X).
evaluable(number(X)) :- nonvar(X).
evaluable(atomic(X)) :- nonvar(X).
evaluable(functor(X,_,_)) :- nonvar(X).
evaluable(functor(_,F,N)) :- nonvar(F),nonvar(N).
evaluable(arg(ArgNo,Term,_)) :- integer(ArgNo),nonvar(Term).
evaluable(A =.. B) :- (nonvar(A) ; islist(B),B=[F|_],atom(F)).
evaluable(name(Const,_)) :- nonvar(Const).
evaluable(name(_,List)) :- isintlist(List), is_ground(List).
 %? name(X,[N]), N=a, N=b gives error mesg in peval but fails quietly in exec
evaluable(atom_chars(Const,List)) :- evaluable(name(Const,List)).
evaluable(number_chars(Const,List)) :- evaluable(name(Const,List)).

% 4.7
%% no longer used as clause is handled explicitly in pevalconj ???
%%evaluable(clause(H,_)) :- (nonvar(H) -> true ; warning_code_needed,fail).
			%% ?? provided H is not dynamically changed
			%% problem: only 'dynamic' files may
			%% be 'claused'!
% 4.8

% 4.9


% 4.13

evaluable(dif(_,_)) :- handle_freeze.
evaluable(length(X,Y)) :- \+ open_tail(X); integer(Y).

%%% end of evaluable

% evaluable(X == Y) see evaluablel
% evaluable(X \== Y) see evaluablel

evaluablel(sort(L,_),Ivarsl) :-
%        is_known(L,Ivarsl).
	\+ open_tail(L),
	\+ (member(X,L,Lrest), member(Y,Lrest), \+ comparable(X,Y,Ivarsl,_)).
evaluablel(keysort(L,_),Ivarsl) :-
%        ispairlist(L,Ivarsl).
	\+ open_tail(L),
	\+ (member(X-_,L,Lrest), member(Y-_,Lrest), \+ comparable(X,Y,Ivarsl,_)).


evaluablel(var(X),Ivarsl) :- nonvar(X); unboundvar(X,Ivarsl).
evaluablel(nonvar(X),Ivarsl) :- nonvar(X); unboundvar(X,Ivarsl).


unboundvar(X,Ivars) :- var(X), \+ varmember(X,Ivars).

islist(X) :- X==[]; nonvar(X), functor(X,F,2), F='.', arg(2,X,X2), islist(X2).

isintlist(X) :- X == [].
isintlist(X) :- nonvar(X), functor(X,F,2), F='.', arg(1,X,X1), integer(X1),
		arg(2,X,X2), isintlist(X2).

% ispairlist is used for 'keysort' which expects a list of Key-Value
% pairs. keysort is evaluated is all Keys are ground.
% ?? not used any longer
%ispairlist(X,_) :- X == [].
%ispairlist(X,Ivarsl) :- functor(X,F,2), F='.', arg(1,X,X1),
%                functor(X1,F1,2), F1='-', arg(1,X1,X11),
%                is_known(X11,Ivarsl),
%                arg(2,X,X2), ispairlist(X2,Ivarsl).

% is_ground(X) :- verify((numbervars(X,0,N),N=0)).
is_ground(X) :- nonvar(X),functor(X,_,N),
	     ground_args(1,N,X).

ground_args(I,N,_) :- I>N,!.
ground_args(I,N,X) :- arg(I,X,A),is_ground(A),
		 J is I+1,ground_args(J,N,X).

is_known(X,Ivarsl) :- unboundvar(X,Ivarsl), !.
is_known(X,Ivarsl) :- nonvar(X),functor(X,_,N),
	     known_args(1,N,X,Ivarsl).

known_args(I,N,_,_Ivarsl) :- I>N,!.
known_args(I,N,X,Ivarsl) :- arg(I,X,A),is_known(A,Ivarsl),
		 J is I+1,known_args(J,N,X,Ivarsl).

open_tail(T) :- var(T).
open_tail([_|T]) :- open_tail(T).
