% Dan Sahlin, Copyright SICS 1991
/*Added by Seb:
The algorithm for anti-unification given
in [Plot70] is implemented by anti_unify/3
Anti-Unification is the dual of unification, comparing
subterms at the same position and turning them into a variable if they differ.
*/
anti_unify(X,Y,Z) :- a_unify(X,Y,[],_,Z).

a_unify(X,Y,S,S,X) :- X==Y, !.
a_unify(X,Y,S,S,Z) :-
        member(subst(X2,Y2,Z),S), X==X2, Y==Y2, !.
a_unify(X,Y,S1,S2,Z) :-
        nonvar(X), nonvar(Y), % this line not needed for SICStus
        functor(X,FX,NX), functor(Y,FY,NY),
        FX=FY, NX=NY, !,
        functor(Z,FX,NX),
        a_unify_arg(NX,X,Y,S1,S2,Z).
a_unify(X,Y,S1,[subst(X,Y,Z)|S1],Z).

a_unify_arg(0,_,_,S,S,_).
a_unify_arg(N,X,Y,S1,S3,Z) :- N>0,
        arg(N,X,XN), arg(N,Y,YN),
        a_unify(XN,YN,S1,S2,ZN),
        arg(N,Z,ZN),
        N1 is N-1,
        a_unify_arg(N1,X,Y,S2,S3,Z).
