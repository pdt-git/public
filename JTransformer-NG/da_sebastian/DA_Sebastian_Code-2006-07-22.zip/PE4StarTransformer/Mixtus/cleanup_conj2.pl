% Dan Sahlin, Copyright SICS 1991
% must be able to handle (A,true,true) which may come from peval_after

cleanup_conj(A,A) :- var(A), !. % only when breaking out
cleanup_conj((X,C),D) :- nonvar(X), X=(A,B), !, cleanup_conj((A,B,C),D).
cleanup_conj((A,B),C) :- !, cleanup_conj(A,A2), cleanup_conj(B,B2),
			cons_conj(A2,B2,C).
cleanup_conj(A,A).
