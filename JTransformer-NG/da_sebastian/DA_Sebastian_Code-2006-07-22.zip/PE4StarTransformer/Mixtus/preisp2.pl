% Dan Sahlin, Copyright SICS 1991
call_residue0(X,L) :-
	handle_freeze -> call_residue(X,L);
			 L=[], call(X).

:- op(1150, fx, block). % for compatibility with isp, can be removed
