% Dan Sahlin, Copyright SICS 1991
may_cut(H,Rin) :-
	uniq_varlist(H),
	success(Rin).

do_cut(cut(TheCut,After),After,TheCut,Rin,(Rin,TheCut)).


