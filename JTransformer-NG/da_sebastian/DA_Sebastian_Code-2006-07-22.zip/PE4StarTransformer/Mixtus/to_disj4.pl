% Dan Sahlin, Copyright SICS 1991
to_disjunction([],_,fail) :- !.
to_disjunction(Cls,Gnew,Cls_or) :-
	anti_unify_heads(Cls,Gnewanti),
	to_disj2(Cls,Gnewanti,Disj),
	instance_unify(Gnew,Gnewanti,true,Unifs),
	cons_conj(Unifs,Disj,Cls_or).


% Ginst is an instance of G
% Perform all unifications possible in G=Ginst without binding a
% variable G to a nonvariable or to an other variable in G
instance_unify(G,Ginst,B,Unifs) :-
	extract_vars(G,Gvars),
	G=..[_|Gargs], Ginst=..[_|Ginstargs],
	inst_unify_list(Gargs,Ginstargs,Gvars,B,Unifs).

inst_unify_list([],[],_,B,B):-!.
inst_unify_list([Garg|Gargs],[Ginstarg|Ginstargs],Gvars,B,Unifs):-
	inst_unify(Garg,Ginstarg,Gvars,B,B2),
	inst_unify_list(Gargs,Ginstargs,Gvars,B2,Unifs).

inst_unify(Garg,Ginstarg,_,B,B) :-
	Garg == Ginstarg, !.
inst_unify(Garg,Ginstarg,Gvars,B,Unifs) :-
	var(Garg),
	!,
	(var(Ginstarg),
	 frozen0(Ginstarg,true), % simplified solution for frozen vars
	 \+varmember(Ginstarg,Gvars) ->
		Garg=Ginstarg, B=Unifs;
		add_equality(B,(Garg=Ginstarg),Unifs)).
inst_unify(Garg,Ginstarg,Gvars,B,Unifs) :-
	Garg =.. [_|Gargs], Ginstarg =.. [_|Ginstargs],
	inst_unify_list(Gargs,Ginstargs,Gvars,B,Unifs).

to_disj2([],_,fail) :- !.
to_disj2([(H :- B0)],G,B2B) :- !,
	instance_unify(G,H,true,B2),
	cons_conj(B2,B0,B2B).
to_disj2([(H :- B0)|Cls],G,(B2B;B3)) :-
	instance_unify(G,H,true,B2),
	cons_conj(B2,B0,B2B),
	to_disj2(Cls,G,B3).

cons_conj(A,B,A) :- B==true, !.
cons_conj(A,B,B) :- A==true, !.
cons_conj(A,B,(A,B)).

anti_unify_heads([(H:-_)|XR],Z) :-
	anti_unify_heads(XR,H,Z).

anti_unify_heads([],X,X).
anti_unify_heads([(H:-_)|XR],Y,Z) :- anti_unify(H,Y,W),
	anti_unify_heads(XR,W,Z).

add_equality(true,G,G) :- !.
add_equality((G1,G2),G,(G1,G3)) :- !,
	(G==G2 -> G3=G2;
		  add_equality(G2,G,G3)).
add_equality(G1,G,G2) :-
	(G==G1 -> G2 = G1;
		  G2 = (G1,G)).
