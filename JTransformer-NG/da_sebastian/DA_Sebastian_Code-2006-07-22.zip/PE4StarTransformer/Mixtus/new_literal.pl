% Dan Sahlin, Copyright SICS 1991
:- dynamic used_names/1.
:- dynamic indexargs/0.

indexargs.

new_literal(A,Surroundings,Ivars,Anew) :-
	vars_in_common_ordered(A,Surroundings,Vars),
	(indexargs ->
		ivars_first(Vars,Ivars,Vars_in_both)
	;       Vars_in_both = Vars),
	find_new_name(A,Vars_in_both,Anew).

find_new_name(A,Vars_in_both,Anew) :-
	length(Vars_in_both,N),
	new_name(A,N,Aname),!,
	Anew =.. [Aname|Vars_in_both].


new_literal(A,Anew) :-
	new_literal(A,A,Anew).

%new_literal(A,Anew) :- extract_vars(A,Vars),
%                       functor(A,_,N),
%                       new_name(A,N,Aname),!,
%                       Anew =.. [Aname|Vars].

new_name(A,N,NewF) :- var(A), !, new_name(unbound(A),N,NewF).
new_name(A,N,NewF) :- extract_functors(A,Flistlist),
		    flatten(Flistlist,Flist),
		    name(NewF,Flist),
		    functor(NewA,NewF,N),
		    \+ known_names(NewA),
		    trace_assert(used_names(NewA)).

extract_functors(X,[Flist|L]) :- nonvar(X), functor(X,F,N), !,
	name(F,Flist),
	(N>0 -> arg(1,X,X1), extract_functors(X1,L);
		L=[Extra], add_extra_num(Extra)).
extract_functors(_,[Extra]) :- add_extra_num(Extra).

add_extra_num(Num) :- gen_integer(1,N), name(N,Num).

gen_integer(N,N).
gen_integer(N,M) :- N1 is N+1, gen_integer(N1,M).
%add_extra_x([]).
%add_extra_x([H|T]) :- name('x',[H]), add_extra_x(T).

known_names(NewA) :- used_names(NewA);
		     predicate_property(NewA,_);
		     has_clauses(NewA).
