% use this file when working with Mixtus
% the command "consult" will load all changed files in interpreted mode
% so that the debugger can be used

:- [files].

:- prolog_flag(compiling, _, debugcode). % this will make SICStus load
			   % the files interpreted instead of compiled

:- meta_predicate(call_residue0(:,-)).

call_residue0(X,L) :-
	handle_freeze -> call_residue(X,L);
			 L=[], call(X).

consult :- files(L), ensure_loaded([executable|L]).
