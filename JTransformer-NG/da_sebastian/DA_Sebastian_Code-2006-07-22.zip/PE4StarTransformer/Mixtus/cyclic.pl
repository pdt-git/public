% Dan Sahlin, Copyright SICS 1991
:- dynamic cyclic/0.

cyclic.

is_cyclic_unif(X,Y) :- cyclic, X=Y, is_cyclic(X).

is_cyclic(X) :- cyclic, is_cyclic(X,[]).

is_cyclic(X,_) :- atomic(X), !, fail.
is_cyclic(X,_) :- var(X), !, fail.
is_cyclic(X,L) :- eq_member(X,L), !.
is_cyclic(X,L) :- functor(X,_,A),
		  is_cyclic_arg(A,X,[X|L]).

is_cyclic_arg(0,_,_) :- !, fail.
is_cyclic_arg(N,X,L) :-
	arg(N,X,XN),
	is_cyclic(XN,L).
is_cyclic_arg(N,X,L) :-
	N1 is N-1,
	is_cyclic_arg(N1,X,L).

eq_member(X,[Y|_]) :- eq(X,Y).
eq_member(X,[_|L]) :- eq_member(X,L).

eq(X,Y) :- 'SYSCALL'('$eq'(X,Y)).  % sicstus special predicate


unify_cyclic(X,Y,Unifs) :-
	u_cyclic(X,Y,true,Unifs).

u_cyclic(X,Y,U,U) :- (atomic(X); atomic(Y)), !, X=Y.
u_cyclic(X,Y,U,U2) :- var(X), !,
	u_cyclic_var(Y,X,U,U2).
u_cyclic(X,Y,U,U2) :- var(Y), !,
	u_cyclic_var(X,Y,U,U2).
u_cyclic(X,Y,U,U2) :-
	functor(X,F,N), functor(Y,F,N),
	u_cyclic_arg(N,X,Y,U,U2).

u_cyclic_arg(0,_,_,U,U).
u_cyclic_arg(N,X,Y,U,U2) :-
	arg(N,X,XN), arg(N,Y,YN),
	N1 is N-1,
	u_cyclic(XN,YN,U,U1),
	u_cyclic_arg(N1,X,Y,U1,U2).

% u_cyclic_var(Term,Var,Uin,Uout)
u_cyclic_var(X,Y,U,U) :- var(X), !, X=Y.
u_cyclic_var(X,Y,U,(U,X=Y)) :- occurs_in(X,Y), !.
u_cyclic_var(X,X,U,U).

% occurs_in(Term, Var) succeeds if Var occurs in Term
occurs_in(X,_Y) :- atomic(X), !, fail.
occurs_in(X,Y) :- var(X), !, X==Y.
occurs_in(X,Y) :- functor(X,_,N),
	occurs_in_arg(N,X,Y).

% occurs_in_arg(Argnumber, Term, Var)
occurs_in_arg(0,_,_) :- !, fail.
occurs_in_arg(N,X,Y) :-
	arg(N,X,XN),
	occurs_in(XN,Y), !.
occurs_in_arg(N,X,Y) :-
	N1 is N-1,
	occurs_in_arg(N1,X,Y).


/************
test(R) :-
	unify_cyclic(
	s(C1,C2,C3,C4,C5,C6,C7,C8,C9),
	s(pos(_, C7, out, C2, CC1),
	  pos(_, out, C3, C1, CC2),
	  pos(_, C9, C2, C4, CC3),
	  pos(_, out, C5, C3, CC4),
	  pos(_, C11, C4, out, CC5),
	  pos(_, C13, out, C7, CC6), % ok
	  pos(_, C1, C8, C6, CC7),
	  pos(_, C15, C7, C9, CC8),
	  pos(_, C3, C10, C8, CC9)),   % problem
	R).
**********/
