t1(A, B, C) :-
	t11(A, B, C).

% t11('$VAR'(0), '$VAR'(1), '$VAR'(2)):-t1('$VAR'(0), '$VAR'(1), '$VAR'(2))
t11(1, A, B) :-
	write(in_t41),
	write(in_t51),
	(   A=1,
	    write(in_t51),
	    (   B=1,
		write(test1),
		nl
	    ;   B=4,
		write(test2),
		nl
	    )
	;   A=3,
	    B=1,
	    write(test1),
	    nl
	;   A=3,
	    B=4,
	    write(test2),
	    nl
	;   A=2,
	    B=1,
	    write(test1),
	    nl
	;   A=2,
	    B=4,
	    write(test2),
	    nl
	;   A=4,
	    B=1,
	    write(test1),
	    nl
	;   A=4,
	    B=4,
	    write(test2),
	    nl
	;   A=6,
	    B=1,
	    write(test1),
	    nl
	;   A=6,
	    B=4,
	    write(test2),
	    nl
	;   A=8,
	    B=1,
	    write(test1),
	    nl
	;   A=8,
	    B=4,
	    write(test2),
	    nl
	;   A=10,
	    B=1,
	    write(test1),
	    nl
	;   A=10,
	    B=4,
	    write(test2),
	    nl
	).
t11(3, A, B) :-
	write(bla),
	(   A=1,
	    write(in_t51),
	    (   B=1,
		write(test1),
		nl
	    ;   B=4,
		write(test2),
		nl
	    )
	;   A=3,
	    B=1,
	    write(test1),
	    nl
	;   A=3,
	    B=4,
	    write(test2),
	    nl
	;   A=2,
	    B=1,
	    write(test1),
	    nl
	;   A=2,
	    B=4,
	    write(test2),
	    nl
	;   A=4,
	    B=1,
	    write(test1),
	    nl
	;   A=4,
	    B=4,
	    write(test2),
	    nl
	;   A=6,
	    B=1,
	    write(test1),
	    nl
	;   A=6,
	    B=4,
	    write(test2),
	    nl
	;   A=8,
	    B=1,
	    write(test1),
	    nl
	;   A=8,
	    B=4,
	    write(test2),
	    nl
	;   A=10,
	    B=1,
	    write(test1),
	    nl
	;   A=10,
	    B=4,
	    write(test2),
	    nl
	).
