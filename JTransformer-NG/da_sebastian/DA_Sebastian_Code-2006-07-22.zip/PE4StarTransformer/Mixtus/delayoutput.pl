% Dan Sahlin, Copyright SICS 1991
:- dynamic delayoutput/0.

% ??? bug, cannot handle variables as a goal!
% delayoutput.

delay_output_unifs(Cls,Anew,Ivarslist,Cls2) :- delayoutput, !,
	delay_output_cls(Cls,Anew,Ivarslist,Cls2).
delay_output_unifs(Cls,_,_,Cls).

delay_output_cls([],_,_,[]).
delay_output_cls([Cl|R],Anew,Ivarslist,[Cl2|R2]) :-
	delay_unifs_cl(Cl,Anew,Ivarslist,Cl2),
	delay_output_cls(R,Anew,Ivarslist,R2).

delay_unifs_cl((H:-true),_Anew,_Ivarslist,(H:-true)) :- !. % optimization
delay_unifs_cl((H:-B),Anew,Ivarslist,(H2:-B3)) :-
	H =.. [F|Hargs],
	Anew =.. [_|Aargs],
	delay_unifs_arg(Hargs,true,Aargs,Ivarslist,Hargs2,Unifs),
	(insert_later(B,Unifs,B2,yes) -> % succeeded to move past a call
		cleanup_conj(B2,B3),
		H2 =.. [F|Hargs2];
		H2=H, B3=B
	).
delay_unifs_arg([],B,_,_,[],B).
delay_unifs_arg([V|Vs],B,[A|As],Ivarslist,[V|V2s],B2) :-
	(var(V); varmember(A,Ivarslist)), !,
	delay_unifs_arg(Vs,B,As,Ivarslist,V2s,B2).
delay_unifs_arg([V|Vs],B,[_|As],Ivarslist,[X|V2s],B2) :-
	delay_unifs_arg(Vs,(B,X=V),As,Ivarslist,V2s,B2).


% insert the unifications later in the body
% let the unifications move past all mixtus_deterministic calls
% but for the last call move past it only if it is a built-in as
% tail-recursion optimization otherwise might be lost.
% insert_later is called with its last argument set to "yes", so
% it will only succeed if the unifications have move past at least one call

insert_later(B,true,B,no) :- !. % optimization for Unifs empty
insert_later(true,Unifs,Unifs,no) :- !.
insert_later((A,B),Unifs,(A,B2),yes) :- mixtus_deterministic(A),!,
	insert_later(B,Unifs,B2,_).
insert_later(A,Unifs,(A,Unifs),yes) :- mixtus_deterministic(A),
	predicate_property(A,built_in), !.
insert_later(A,Unifs,(Unifs,A),no).
