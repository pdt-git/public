% Dan Sahlin, Copyright SICS 1991
:- dynamic fold_instance/0.

fold_instance.

gs(gs(A2,Anew2,Ivarslist2,IsRec,Depth1,Top,A,Info),
      A2,Anew2,Ivarslist2,IsRec,Depth1,Top,A,Info).

gs_depth(GS_item,Depth) :-
	gs(GS_item,_A,_Anew,_Ivarslist,_IsRec,Depth,_Top,_,_Info).

gs_isrec(GS_item,IsRec) :-
	gs(GS_item,_A,_Anew,_Ivarslist,IsRec,_Depth,_Top,_,_Info).

gs_info(GS_item,Info) :-
	gs(GS_item,_A,_Anew,_Ivarslist,_IsRec,_Depth,_Top,_,Info).

gs_goal(gs(Goal,_Anew,_Ivarslist,_IsRec,_Depth1,_Top,_A,_Info),Goal).

gs_orig_goal(gs(_Goal,_Anew,_Ivarslist,_IsRec,_Depth1,_Top,A,_Info),A).

gs_member(A2,Anew2,Ivars2list,Info,GS) :-
	member(gs(A2,Anew2,Ivars2list,true,_Depth,_Top,_A,Info),GS).

get_last_two(GR,Goal1,Goal2,Depth1,Top1) :-
	append(_,[gs(Goal2,_Goalnew2,_Ivars2,_IsRec2,_Depth2,_Top2,_,_Info2),
		  gs(Goal1,_,_,_IsRec1,Depth1,Top1,_,_Info1)],GR).

push_gs(GS,A,Anew,Ivarslist,IsRec,Restart,
	[GS_item|GS]) :-
	gs(GS_item,A2,Anew2,Ivarslist2,IsRec,Depth1,Top,A,Info),
	(
	(fold_instance;
	 Restart==true) -> restart_info(Info);
			  gs_info_init(Info)),
	gs_new_depth(GS,Depth1),
	copy_term(t(A,Anew,Ivarslist),t(A2,Anew2,Ivarslist2)),
	stack_top(Top),
	write_gs([GS_item|GS]),
	(gs_info_init(Info) -> Text='** variable variant'; Text=''),
	write_goalstack(A,GS,Text).


gs_new_depth([],1).
gs_new_depth([GS_item|_],Depth1) :-
	gs_depth(GS_item,Depth), Depth1 is Depth+1.

extract_isrecs([GS_item|GS],[IsRec|IsRecs]) :-
	       gs_isrec(GS_item,IsRec), extract_isrecs(GS,IsRecs).
extract_isrecs([],[]).

new_breakoutgoal(NewGoal,NewIvars,Depth1,Top1,GS_item) :-
	gs(GS_item,NewGoal,NewGoal,NewIvars,_IsRec,Depth1,Top1,_A,_Info).

new_instancegoal(GS,GS_item) :-
	append(_,[GS_item0],GS),
	gs(GS_item0,A2,Anew2,Ivarslist2,IsRec,Depth1,Top,A,Info0),
	gs_info_init(Info0), % test if info_init
	gs(GS_item,A2,Anew2,Ivarslist2,IsRec,Depth1,Top,A,_Info).

:- dynamic mixtus_tracing/0.

clear_screen :- format("~c[H~c[2J",[27,27]).
write_gs(GS) :- (mixtus_tracing -> clear_screen, write_gs2(GS); true).

write_gs2([]).
write_gs2([GS_item|R]) :-
	gs_goal(GS_item,A2),
	gs_info(GS_item,Info),
	write_gs2(R),
	difwrite(A2),
	(gs_info_init(Info) -> write('varvar'); true),
	nl.


gs_info_init(info(varvariant)).

restart_info(info(instance)).

:- dynamic tracegoalstack/0.
write_goalstack(Goal,GS, Text) :-
	tracegoalstack,!,
	length(GS,GS_length),
	indent(GS_length),
	difwrite(Goal),
	write(Text),
	nl.
write_goalstack(_,_,_).

indent(0).
indent(N) :- N>0, write('  '), N1 is N-1, indent(N1).

:- dynamic writedif/0.

writedif.

difwrite(G) :- handle_freeze, writedif, !,
	reify_difs((G:-true),(A3:-B)),
	 write(A3),
	(B=true -> true; write(', '), write(B)).
difwrite(G) :- write(G).
