% Dan Sahlin, Copyright SICS 1991
peval_findall(findall(X,G,List),State) :- !,
	State=state(_C,GS,_H,Ivars,Level,Cut,Break,Last,_Reval,_Rin,_Rout),
	peval_goals((G,'PSEUDO ASSERT'(X)),GS,[X,Ivars],Ivars,!,Level,G_or,_CutDone,Break,Last),
	normalize_ivars(State,_Ivarsl,State2),
% get_continuation(State2,State3,C),
	(is_breakingout(GS,Break) -> Cut=cut(0,true);
	  extract_asserts((G_or;fail),L,[],Newgoal) ->
	  shield_cut(Newgoal,Newgoal2),
	  p((Newgoal2,L=List),State2);
	% otherwise reevaluate without 'PSEUDO ASSERT'
	  peval_goals(G,GS,[X,Ivars],Ivars,!,Level,G_or2,_CutDone,Break,Last),
% more efficient to remove PSEUDO ASSERT from G_or and recompute that instead:
% (routine missing for removing PSEUDO ASSERT)
%          peval_goals(G_or,GS,[X,Ivars],Ivars,!,Level,G_or2,_CutDone,Break,Last),
	  entergoal(findall(X,G_or2,List),State2)
	).

peval_bagof(bagof(X,G,List),State) :- !,
	State=state(_C,GS,_H,Ivars,Level,Cut,Break,Last,_Reval,_Rin,_Rout),
	free_variables(X^G,[],[],Freevars), % added
	peval_goals((G,'PSEUDO ASSERT'(Freevars-X)),GS,[X,G],Ivars,!,Level,G_or,_CutDone,Break,Last),
	(is_breakingout(GS,Break) -> Cut=cut(0,true);
	 normalize_ivars(State,Ivarsl,State2),
	 extract_vars((X,G),XGvars),
	 subtract_vars(XGvars,Freevars,Boundvars),
	 vars_in_both(Ivarsl,Boundvars,BoundIvars),
	 vars_in_both(Ivarsl,Freevars,FreeIvars),
	 (
	  ((FreeIvars=[]; BoundIvars=[]), % no aliasing possible
	   extract_newer((G_or;fail),Ivars,Newgoal,Fout),
	     Fout=Pairsorted ) -> %%
		list_to_disj(Pairsorted,Freevars-List,Disj),
		peval_goals(Newgoal,GS,[X,G,Disj],Ivars,!,Level,Newgoal2,_CutDone,_Break,Last),
		(classify_goals(Newgoal2,logical) ->
			p((Disj,Newgoal2,List\==[]),State2);
			shield_cut(Newgoal2,Newgoal3),
			p((Newgoal3,Disj,List\==[]),State2));
	 %       (is_known(List,Ivarsl) ->
	 %               p((List=L2,Xexpr,List \== []),State3);
	 %               p((Xexpr,List=L2,List \== []),State3));
	  peval_goals(G,GS,[X,G],Ivars,!,Level,G_or2,_CutDone,Break,Last),
	  adjust_freevars(X,G_or2,G_or_adj,Freevars),
	  entergoal(bagof(X,G_or_adj,List),State2)
	)).

peval_setof(setof(X,G,List),State) :- !,
	p((bagof(X,G,List2),sort(List2,List)),State).

adjust_freevars(X,G_or,G_or_adj,Freevars) :-
	 free_variables(X^G_or,[],[],Freevars2),
	 vars_in_both(Freevars,Freevars2,Freevarsboth),

	 subtract_vars(Freevars2,Freevarsboth,Newfreevars),
	 exist_quantify(Newfreevars,G_or,G_or2),

	 subtract_vars(Freevars,Freevarsboth,Removedfreevars),
	 extract_vars(G_or,G_or_vars),
	 vars_in_common(G_or_vars,Removedfreevars,Capturedvars),
	 free_the_variables(Capturedvars,G_or2,G_or_adj).

exist_quantify([],G,G).
exist_quantify([V|R],G,G2) :- exist_quantify(R,V^G,G2).

free_the_variables([],G,G).
free_the_variables([V|R],G,G2) :- free_the_variables(R,(V=V,G),G2).

%all_items_known(Pairlist,Freevars,Ivars) :-
% temporarily unify Freevars with the first item in all "-"pairs
%        \+ (member(Freevars-_,Pairlist,Restpairlist),
% helt lika eller olika (f|r alla v{rden p} Ivars..

% as the variables in Ivars may become bound, the variables are extracted
%            member(Freevars-_,Restpairlist),
%            \+ uniq_varlist(Ivars)
%           ).

bagof2(X,G,L) :-
	free_variables(X^G,[],[],Freevars),
	findall(Freevars-X,G,List),
	keysort(List,Listsorted),
	group_pairs(Listsorted,Listgrouped),
	member(Freevars-L,Listgrouped).

group_pairs(Listsorted,Listgrouped) :-
	group_pairs(Listsorted,_,dymmyvalue,Listgrouped).

group_pairs([Vars-X|List],[X|RestXList],PreviousVars,Outlist) :-
	variable_variants(PreviousVars,Vars), !, % dif-hantering??
	PreviousVars=Vars,
	group_pairs(List,RestXList,PreviousVars,Outlist).
group_pairs([Vars-X|List],[],_PreviousVars,[Vars-[X|RestXList]|Outlist]) :-
	group_pairs(List,RestXList,Vars,Outlist).
group_pairs([],[],_PreviousVars,[]).

% The code below is written by R O'Keefe and taken from the net:
% Here is the public-domain code for free_variables/4.  I warn you, the mistake
% is present in this version.  I did think about writing a new version with the
% mistake corrected and broadcasting it, but since WG17 Prolog hasn't got
% setof/3 or bagof/3 it didn't seem worth the trouble.
%   In order to handle variables properly, we have to find all the
%   universally quantified variables in the Generator.  All variables
%   as yet unbound are universally quantified, unless
%       a)  they occur in the template
%       b)  they are bound by X^P, setof, or bagof
%   free_variables(Generator, Template, OldList, NewList)
%   finds this set, using OldList as an accumulator.


% Felaktig, tar ej h{nsyn till att STRUKTUREN X^Y kan f|rekomma,
% vilken inte inneb{r n}gon kvantifiering.

free_variables(Term, Bound, VarList, [Term|VarList]) :-
	var(Term),
	term_is_free_of(Bound, Term),
	list_is_free_of(VarList, Term),
	!.
free_variables(Term, _, VarList, VarList) :-
	var(Term),
	!.
free_variables(Term, Bound, OldList, NewList) :-
	explicit_binding(Term, Bound, NewTerm, NewBound),
	!,
	free_variables(NewTerm, NewBound, OldList, NewList).
free_variables(Term, Bound, OldList, NewList) :-
	functor(Term, _, N),
	free_variables(N, Term, Bound, OldList, NewList).


free_variables(N, Term, Bound, OldList, NewList) :-
	(   N =:= 0 -> NewList = OldList
	;   arg(N, Term, Argument),
	    free_variables(Argument, Bound, OldList, MidList),
	    M is N-1,
	    free_variables(M, Term, Bound, MidList, NewList)
	).

 
%   explicit_binding checks for goals known to existentially quantify
%   one or more variables.  In particular \+ is quite common.  It is
%   known that the first argument is instantiated.
 
explicit_binding(\+ _,                 Bound, fail,     Bound    ).
explicit_binding(Var^Goal,             Bound, Goal,     Bound+Var).
explicit_binding(setof(Var,Goal,Set),  Bound, Goal-Set, Bound+Var).
explicit_binding(bagof(Var,Goal,Bag),  Bound, Goal-Bag, Bound+Var).
explicit_binding(findall(_,_,Bag),     Bound, Bag,      Bound    ).
 
 
term_is_free_of(Term, Var) :-
	(   var(Term) ->
	    Term \== Var
	;   functor(Term, _, N),
	    term_is_free_of(N, Term, Var)
	).

term_is_free_of(N, Term, Var) :-
	(   N =:= 0 -> true
	;   arg(N, Term, Argument),
	    term_is_free_of(Argument, Var),
	    M is N-1,
	    term_is_free_of(M, Term, Var)
	).


list_is_free_of([], _).
list_is_free_of([Head|Tail], Var) :-
	Head \== Var,
	list_is_free_of(Tail, Var).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

convert_to_list(G,_X,_GNIorig,_GNI,_,_,_) :- var(G), !, fail.
convert_to_list((_^G),X,GNIorig,GNI,Xexprs,Lin,Lout) :- !,
	convert_to_list(G,X,GNIorig,GNI,Xexprs,Lin,Lout).
convert_to_list((G,_GR),_X,_GNIorig,_GNI,_Xexprs,_Lin,_Lout) :- var(G), !, fail.
convert_to_list(((G1,G2),GR),X,GNIorig,GNI,Xexprs,Lin,Lout) :- !,
	convert_to_list((G1,(G2,GR)),X,GNIorig,GNI,Xexprs,Lin,Lout).
convert_to_list((G,GR),X,GNIorig,GNI,Xexprs,Lin,Lout) :-
	simple_goal(G), !,
	copy_term((X,GNI,G,GR),(X2,GNI2,G2,GR)), call(G2),
	convert_to_list(GR,X2,GNIorig,GNI2,Xexprs,Lin,Lout).
/***
convert_to_list((G,GR),X,GNIorig,GNI,Xexprs,Lin,Lout) :-
	classify_goals(G,Gclass), Gclass \== side,
	sols_goals(G,Sols,HasCut), \+ member(2,Sols), !,
	convert_to_list3(
***/
convert_to_list(G,X,GNIorig,GNI,Xexprs,Lin,Lout) :-
	convert_to_list_disj(G,X,GNIorig,GNI,Xexprs,Lin,Lout).

convert_to_list_disj(G,_X,_GNIorig,_GNI,_,_,_) :- var(G), !, fail.
convert_to_list_disj(fail,_,_GNIorig,_GNI,[],Lin,Lin) :- !. % empty list
convert_to_list_disj((G;R),X,GNIorig,GNI,[Xexpr|Xexprs],Lin,Lout) :- !,
	convert_to_list2(G,X,GNIorig,GNI,Xexpr,Lin,L2),
	convert_to_list_disj(R,X,GNIorig,GNI,Xexprs,L2,Lout).
convert_to_list_disj(G,X,GNIorig,GNI,[Xexpr],Lin,Lout) :-
	convert_to_list2(G,X,GNIorig,GNI,Xexpr,Lin,Lout).

convert_to_list2(G,_X,_GNIorig,_GNI,_,_,_) :- var(G), !, fail.
convert_to_list2((_^G),X,GNIorig,GNI,Xexpr,Lin,Lout) :- !,
	convert_to_list_disj(G,X,GNIorig,GNI,Xexpr,Lin,Lout).
convert_to_list2((G,GR),X,GNIorig,GNI,Xexpr,Lin,Lout) :-
	simple_goal(G), !,
	copy_term((X,GNI,G,GR),(X2,GNI2,G2,GR)), call(G2),
	convert_to_list2(GR,X2,GNIorig,GNI2,Xexpr,Lin,Lout).
convert_to_list2(G,X,GNIorig,GNI,Xexpr,_Lin,_Lout) :-
	simple_goal(G), !,
	copy_term((X,GNI,G),(Xval,GNI2,G2)), call(G2),
	extract_vars(Xval,Xrelevant),
	only_relevant_vars(GNIorig,GNI2,GNI2,Xrelevant,GNIorigrel,GNI2rel),
    % 1. list2term...      (vid reeval)
    % 2. tag bort testet
    % 3. tag bort hela copy_term  (vid reeval)
	% classify is not capable of determining that copy_term succeeds
	Xexpr = copy_term(GNIorigrel,GNI2rel)+Xval,
%        (uniq_varlist(GNI2rel) ->
%                Xexpr = copy_term(GNIorigrel,GNI2rel), Lin = [Xval|Lout];
%                Xexpr = (copy_term(GNIorigrel,GNI2rel) -> Lin = [Xval|Lout];
%                                                          Lin = Lout)
%        ),
	true.
%        uniq_varlist(GNI2).  % problems with difs!!! (optimizations prevented?)
%       vars_in_common(Xval,GNI2,[]). % t(457


simple_goal(true).
simple_goal(_=_).
%simple_goal((user:true)). % for ISP
%simple_goal((user:_=_)).  % for ISP

only_relevant_vars([],[],_,_,[],[]).
only_relevant_vars([_|As],[B|Bs],Blist,Xrelevant,A2s,B2s) :-
% irrelevant only if
%  it is a variable (otherwise unification might fail)
%  and it does not occur anywhere else in the input vars list
%  and it does not occur in the X-generator
	var(B),
%        frozen(B,true),  %!!
	varmember(B,Blist,Brest),
	extract_vars(Brest,Brestvars),  % t(461
	\+ (varmember(B,Brestvars); varmember(B,Xrelevant)),!,
	only_relevant_vars(As,Bs,Blist,Xrelevant,A2s,B2s).
only_relevant_vars([A|As],[B|Bs],Blist,Xrelevant,[A|A2s],[B|B2s]) :-
	only_relevant_vars(As,Bs,Blist,Xrelevant,A2s,B2s).



get_nonIvars(G,Ivars,GNonIvars) :-
	extract_vars(G,Gvars),
	vars_in_common(Gvars,Ivars,GIvars),
	subtract_vars(Gvars,GIvars,GNonIvars).

all_different_keys(Pairlist) :-
	\+ (member(F-_,Pairlist,Pairlist2),
	    member(F-_,Pairlist2)).

list_to_copy_terms([],_,true).
list_to_copy_terms([X2|Xs],X,(copy_term(X,X2),Copy_terms)) :-
	list_to_copy_terms(Xs,X,Copy_terms).

get_freevars([],[]).
get_freevars([(Goal+(Freevars-X))|R],[Freevars-(Goal+X)|R2]) :-
	get_freevars(R,R2).

convert_to_expression([],[],C,C).
/****
convert_to_expression([G+X|R],Lin,(Xexpr,Xexprs),C) :-
	G = copy_term(_GNIorig,GNI2),
	(uniq_varlist(GNI2) ->
		Xexpr = G, Lin=[X|Lout];
		Xexpr = (G -> Lin = [X|Lout]; Lin=Lout)
	),
	convert_to_expression(R,Lout,Xexprs,C).
****/
convert_to_expression([G+X|R],Lin,Xexpr,C) :-
	G = copy_term(_GNIorig,GNI2),
	(uniq_varlist(GNI2) ->
		Xexpr = (G, Lin=[X|Lout],Xexprs);
		Xexpr = (G -> Lin = [X|Lout],Xexprs; Lin=Lout,Xexprs)
	),
	convert_to_expression(R,Lout,Xexprs,C).

% extract_asserts(G_or,List,Newgoal).

extract_asserts(X,_,_,_) :- var(X), !, fail.
extract_asserts(fail,L,L,true) :- !.
extract_asserts('PSEUDO ASSERT'(X),L,R,L=[X|R]) :- !.
extract_asserts((G1;G2),L1C,L3,
		(copy_term(t(R1,L1,L2),t(R1C,L1C,L2C)),R1C,R2)) :- !,
	extract_asserts(G1,L1,L2,R1),
	extract_asserts(G2,L2C,L3,R2).

extract_asserts((G1,G2),L2,L3,(G1->L2=LA, L3=LB, G2new; L2=L3)) :- !,
	mixtus_deterministic(G1),
	extract_asserts(G2,LA,LB,G2new).

extract_free(X,_,_,_,_) :- var(X), !, fail.
extract_free(fail,_,true,Fin,Fin) :- !.
extract_free('PSEUDO ASSERT'(FreeX-X),Ivars,G,Fin,Fout) :- !,
	% leta upp l{mplig lista att stoppa in X i map Free
	% is_ground(FreeX),
	extract_vars(Ivars,Ivarsl),
	enter_value(Fin,Ivarsl,FreeX,X,Fout,G).
extract_free((G1;G2),Ivars,(copy_term(t(R1,F1,F2),t(R1C,F1,F2)),R1C,R2),
	F1,F5) :- !,
	extract_free(G1,Ivars,R1,F1,F2),
	new_flist(F2,F3),
	extract_free(G2,Ivars,R2,F3,F4),
	join_flists(F2,F4,F5).

extract_free((G1,G2),Ivars,(G1->Unifstrue, G2new; Unifsfalse),F,F3) :- !,
	mixtus_deterministic(G1),
	extract_free(G2,[G1|Ivars],G2new,F,F2),
	get_changed(F2,Unifstrue,Unifsfalse,F3).

new_flist([],[]) :- !.
new_flist([Free-(_,_)|Frest1],[Free-(L,L)|Frest2]) :-
	new_flist(Frest1,Frest2).

enter_value([],_Ivarsl,FreeX,X,[FreeX-(H,R)],(H=[X|R])) :- !.
enter_value([Free-(H,R)|Frest],Ivarsl,FreeX,X,[Free-(H2,R2)|Frest2],G) :-
	comparable(Free,FreeX,Ivarsl,Tout), % may fail here if not comparable
	(Tout=(=) ->
		H=H2, G=(R=[X|R2]),
		Frest=Frest2;
		H=H2, R=R2,
		enter_value(Frest,Ivarsl,FreeX,X,Frest2,G)).

get_changed([],true,true,[]) :- !.
get_changed([Free-(H,R)|Frest1],((H3=H),Unifstrue),
	((H3=R),Unifsfalse),[Free-(H3,R)|Frest2]) :-
	get_changed(Frest1,Unifstrue,Unifsfalse,Frest2).

% join_flists(+F1,+F2,-F3). F2 is never shorter than F1
join_flists([],Frest,Frest).
join_flists([Free1-(H1,R1)|Frest1],[Free2-(H2,R2)|Frest2],
	    [Free3-(H3,R3)|Frest3]) :-
	variable_variants(Free1,Free2), !,
	Free3=Free2,
	H1=H3, R1=H2, R2=R3,
	join_flists(Frest1,Frest2,Frest3).
join_flists(Flist,[F|Frest1],[F|Flist2]) :-
	join_flists(Flist,Frest1,Flist2).


% join_free(+,-,-).
join_free([Free1-(H1,R1)|Frest1],[Free2-(H2,R2)|Frest2],
	[Free3-(H3,R3)|Frest3]) :- !,
	Free3=Free1, Free2=Free1, /* or Free2 */
	H1=H3, R1=H2, R2=R3,
	join_free(Frest1,Frest2,Frest3).
join_free([],[],[]).


/****
remove_pseudo_assert(X,X) :- var(X), !.
remove_pseudo_assert('PSEUDO ASSERT'(_),true) :- !.
remove_pseudo_assert((A,'PSEUDO ASSERT'(_)),A) :- !.
remove_pseudo_assert((A,B),(A,B2)) :- !, remove_pseudo_assert(B,B2).
remove_pseudo_assert(A,A2) :-
	functor(A,F,N), functor(Apattern,F,N), pred_parts(Apattern), !,
	remove_pseudo_assert_args(A,Apattern,N,A2).

remove_pseudo_assert....
***/

f_to_list([],[]) :- !.
f_to_list([Free-(H,R)|Frest1],[Free-H|Frest2]) :-
	R=[],
	f_to_list(Frest1,Frest2).

list_to_disj([],_,fail) :- !.
list_to_disj([X|Xs],Y,(Y=X;G)) :- list_to_disj(Xs,Y,G).

copy_variable_variants(X,Y) :-
	copy_term(X,X2), variable_variants(X2,Y).

enter_freevars([],Freevars,_Ivarsl,[Freevars]).
enter_freevars([Freevars1|Frest],Freevars,Ivarsl,[Freevars1|Freel2]) :-
	comparable(Freevars,Freevars1,Ivarsl,Tout), % may fail
	(Tout=(=) -> Freel2=[Freevars1|Frest];
		enter_freevars(Frest,Freevars,Ivarsl,Freel2)).

extract_new(G,Ivars,Newgoal,Foutp2) :-
	collect_freevars(G,Ivars,[],Freel), % may fail
	extract_free2(G,Newgoal,Freel,Fout,Frest),
	close_lists(Freel,Frest),
	pairlists(Freel,Fout,Foutp),
	keysort(Foutp,Foutp2).

collect_freevars(X,_,_,_):- var(X),!,fail.
collect_freevars(fail,_,Freel,Freel) :- !.
collect_freevars('PSEUDO ASSERT'(Freevars-_X),Ivars,Freel,Freel2) :- !,
	extract_vars(Ivars,Ivarsl),
	enter_freevars(Freel,Freevars,Ivarsl,Freel2). % may fail
collect_freevars((G1,G2),Ivars,Freel,Freel2) :- !,
	collect_freevars(G2,[G1|Ivars],Freel,Freel2).
collect_freevars((G1;G2),Ivars,Freel,Freel2) :- !,
	collect_freevars(G1,Ivars,Freel,Freel1),
	collect_freevars(G2,Ivars,Freel1,Freel2).


/* add_solution(FreeX-X,[Free-[X|L]|R],[Free-L|R]) :-
	variable_variants(FreeX,Free),!.
add_solution(FreeX-X,[FreeH|R],[FreeH|R2]) :-
	add_solution(FreeX-X,R,R2). */

add_solution(FreeX-X,[Free|_],[[X|L]|R],[L|R]) :-
	variable_variants(FreeX,Free),!.
add_solution(FreeX-X,[_|FreeR],[F|R],[F|R2]):-
	add_solution(FreeX-X,FreeR,R,R2).


% extract_free2(G,Gout,Fin,Fout)
extract_free2(X,_,_,_,_) :- var(X), !, fail.
extract_free2(fail,true,_,Fin,Fin) :- !.
extract_free2('PSEUDO ASSERT'(FreeX-X),true,Freel,Fin,Fout) :- !,
	% leta upp l{mplig lista att stoppa in X i map Free
	% is_ground(FreeX),
	add_solution(FreeX-X,Freel,Fin,Fout).
extract_free2((G1;G2),
	      (copy_term(t(R1,L1,L2),t(R1C,L1C,L2C)),R1C,R2),
	     Freel,L1C,L3) :- !,
	extract_free2(G1,R1,Freel,L1,L2),
	extract_free2(G2,R2,Freel,L2C,L3).
extract_free2((G1,G2),(G1->L2=LA, L3=LB, G2new; L2=L3),Freel,L2,L3) :- !,
	mixtus_deterministic(G1),
	createlist(Freel,L2), createlist(Freel,L3),
	extract_free2(G2,G2new,Freel,LA,LB).

close_lists([],[]).
close_lists([_|Ar],[[]|R]) :- close_lists(Ar,R).

pairlists([],[],[]).
pairlists([A|Ar],[B|Br],[A-B|Cr]) :-
	pairlists(Ar,Br,Cr).

createlist(A,B) :-
	length(A,N), length(B,N).


extract_newer(G,Ivars,Newgoal,Foutp2) :-
	collect_freevars(G,Ivars,[],Freel), % may fail
	close_lists(Freel,Frest),
	extract_free3(G,Newgoal,_,Freel,Fout,Frest),
	pairlists(Freel,Fout,Foutp),
	keysort(Foutp,Foutp2).



% extract_free3(G,Gout,Fin,Fout)
extract_free3(X,_,_,_,_,_) :- var(X), !, fail.
extract_free3(fail,true,true,_,Fin,Fin) :- !.
extract_free3('PSEUDO ASSERT'(FreeX-X),Gtrue,Gfalse,Freel,Fin,Fout) :- !,
	% leta upp l{mplig lista att stoppa in X i map Free
	% is_ground(FreeX),
	add_solution(FreeX-X,Freel,Fin,Fout,Gtrue,Gfalse).
extract_free3((G1;G2),
	      (copy_term(t(G1true,L1,L2),t(R1C,L1,L2)),R1C,G2true),
	      (G1false,G2false),
	     Freel,L1,L3) :- !,
	extract_free3(G1,G1true,G1false,Freel,L1,L2),
	extract_free3(G2,G2true,G2false,Freel,L2,L3).

extract_free3((G1;G2),
	      (copy_term(t(G1true,L1,L2),t(R1C,L1C,L2C)),R1C,G2true),
	      (G1false,G2false),
	     Freel,L1C,L3) :- !,
	extract_free3(G1,G1true,G1false,Freel,L1,L2),
	extract_free3(G2,G2true,G2false,Freel,L2C,L3).
extract_free3((G1,G2),(G1->Gtrue; Gfalse),Gfalse,Freel,L2,L3) :- !,
	mixtus_deterministic(G1),
%        createlist(Freel,L2), createlist(Freel,L3),
	extract_free3(G2,Gtrue,Gfalse,Freel,L2,L3).


add_solution(FreeX-X,[Free|_],[L|Rest],[R|Rest],L=[X|R],L=R) :-
	variable_variants(FreeX,Free),!.
add_solution(FreeX-X,[_|FreeR],[F|R],[F|R2],Gtrue,Gfalse):-
	add_solution(FreeX-X,FreeR,R,R2,Gtrue,Gfalse).

shield_cut(G,call(G)) :- has_cut(G),!.
shield_cut(G,G).
