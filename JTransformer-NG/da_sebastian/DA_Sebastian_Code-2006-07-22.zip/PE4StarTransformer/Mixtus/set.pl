% Dan Sahlin, Copyright SICS 1991
set(S,X) :- setting(S,Min), X>=Min,
	    T0=..[S,_], retractall(T0),
	    T=..[S,X], assert(T).

setting(maxrec,1).
setting(max_depth,2).
setting(maxnondeterm,1).
setting(maxpropleft,0).
setting(maxlevel,0).
setting(maxfinite,0).
setting(quickpe,0).
% quickpe values: 0=normal pe,
% 1=always fail if recursive call does not fold => generalized restart
% 2=all predicate calls without specialization




is_flag(mixtus_tracing).
is_flag(delayoutput).
%is_flag(lexical).
is_flag(handle_freeze).
is_flag(cyclic).
is_flag(comments).
is_flag(tracegoalstack).
is_flag(arithopt).
is_flag(fold_instance).
is_flag(preserve_loops).
is_flag(unfold_cut).
is_flag(unfold_cut2).
is_flag(functor_logical) :- \+ isp.
is_flag(arg_logical) :- \+ isp.
is_flag(print_settings).
is_flag(if2cut).
is_flag(rename_VAR).
is_flag(indexargs).

set(Flag) :- \+ is_flag(Flag),!,
	      write(Flag), write(' is an unknown flag'), nl.
set(Flag) :- Flag -> write(Flag), write(' is already set'), nl;
		     assert(Flag),
		     write(Flag), write(' set'), nl.

unset(Flag) :- \+ is_flag(Flag),!,
	      write(Flag), write(' is an unknown flag'), nl.
unset(Flag) :- \+ Flag -> write(Flag), write(' is already unset'), nl;
		     retract(Flag),
		     write(Flag), write(' unset'), nl.

settings :-
	setting(X,_),
	write(X), T=..[X,Arg],
	T, write(': '), write(Arg), nl, fail.
settings :-
	is_flag(X),
	write(X), write(': '),
	(X -> true;write('un')), write('set'), nl, fail.
settings.

:- predicate_property(call_residue(_,_),built_in) ->
	true; unset(handle_freeze).
