% Dan Sahlin, Copyright SICS 1991
:- dynamic maxnondeterm/1.

maxnondeterm(10).

ok_determ(Cls) :-
	length(Cls,N),
	maxnondeterm(M),
	N=<M.
