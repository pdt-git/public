% Dan Sahlin, Copyright SICS 1991
:- dynamic pclause_consult/3, pdynamic/2, p_op/4.
:- dynamic pmultifile/2.
:- dynamic static_struct/1.
:- dynamic pblock_consult/2.
:- dynamic mixtus_term_expansion/3.

%Seb 29.11.: Auskommentierung
isp :- /*predicate_property(meta_predicate(_),built_in)*/true, !.

remove_user_module(H0,H1) :- isp, nonvar(H0), H0=user:H1, !.

% simple (and portable?) way of turning some variable calls X into call(X)
:- dynamic adjust_calls/1.
adjust_calls(H,B,H2,B2) :-
        isp, !,
        trace_assert(user:(adjust_calls(H) :- B)),
        retract(user:(adjust_calls(H2) :- B2)).

mixtus_call(A) :- isp, !, call(user:A).
mixtus_call(A) :- call(A).

mixtus_executable(X) :- isp, !, user:executable(X).
mixtus_executable(X) :- executable(X).

difgoal(A,X,Y) :- isp, !, A=prolog:dif(X,Y).
difgoal(A,X,Y) :- A=dif(X,Y).



clause_disj(A,A_body) :- clauselist(A,Cls),
        to_disjunction(Cls,A,A_body).

% for accessing code that is to be executed
clauselist(Goal,Clauses) :-
        findall((GoalW :- BodyW),
                call_wash_difs(has_clause(Goal,_Body),
                               has_clause(GoalW, BodyW)),
                Clauses).

% for accessing code that is used as data
clauselist_data(Goal,Clauses) :-
        findall((HeadW:-BodyW),
                call_wash_difs(has_clause(Goal,_Head,_Body),
                               has_clause(_GoalW,HeadW,BodyW)),
                Clauses).

pconsult(X) :- var(X), !, write('% pconsult error: uninstantiated variable'), nl.
pconsult([]) :- !.
pconsult([H|R]) :- !, pconsult(H), pconsult(R).
pconsult(File) :- absolute_file_name(File,File1),
        erase_old_file(File1),
        open(File1,read,Stream),
        write('{consulting for mixtus: '), write(File1),
        write('}'), nl,
        readdefs(Stream,File1), close(Stream).

erase_old_file(File1) :- retractall2(pclause_consult(_,_,File1)),
                    retractall2(pdynamic(_,File1)),
                    retractall2(p_op(_,_,_,File1)),
                    retractall2(pblock_consult(_,File1)),
                    retractall2(mixtus_term_expansion(File1,_,_)).

erase_old_pred(P) :- retractall2(pclause_consult(P,_,_)),
                    retractall2(pdynamic(P,_)),
                    retractall2(p_op(P,_,_,_)), %? not correct, may have
                                               % several op-declarations
                    retractall2(pblock_consult(P,_)).

readdefs(Stream,File1) :-
        read(Stream,Term0),
        (mixtus_term_expansion(_File,Term0,Term1) ->
                true
        ;       Term0=Term1),
         expand_term(Term1,Term),

        (Term=end_of_file -> true;
         Term=(term_expansion(From,To):-Body) ->
                % ??? if term_expansion calls other predicates, these
                % must also be loaded by consulting the file
                assertz((mixtus_term_expansion(File1,From,To):-Body)),
                readdefs(Stream,File1);
         Term=term_expansion(From,To) ->
                assertz((mixtus_term_expansion(File1,From,To):-true)),
                readdefs(Stream,File1);
         (Term= (:- X); Term= (?- X)) ->
                directive(X,File1),readdefs(Stream,File1);
                save_clause(Term,File1), readdefs(Stream,File1)).

save_clause((H:-B),File) :- !, assert_clause(H,B,File).
save_clause(H,File) :- assert_clause(H,true,File).

assert_clause(H,B,File) :-
        make_skeleton(H,Hskel),
        (pclause_consult(Hskel,_,File2), File2\==File,
                \+ pmultifile(Hskel,_) ->
                make_skeleton(H,Hskel2),
                write('% '), write(Hskel2), write(' already defined in file '),
                write(File2), write(' is now removed'), nl,
                erase_old_pred(Hskel2);
                true),
        adjust_calls(H,B,H2,B2),
        save_structures((H:-B)), % prolongs pconsult time with 20%
        trace_assert(pclause_consult(H2,B2,File)).

directive((G1,G2),File) :- !, directive(G1,File), directive(G2,File).
directive((wait(Preds)),File) :- !, read_wait(Preds,File). % preisp
directive((block(Preds)),File) :- !, read_block(Preds,File). % isp
directive((dynamic Preds),File) :- !, read_dynamic(Preds,File).
directive([H|T],_) :- !, pconsult([H|T]).
directive(compile(F),_) :- !, pconsult(F).
directive(op(X,Y,Z),File) :- !, op(X,Y,Z), trace_assert(p_op(X,Y,Z,File)).
directive((multifile Preds),File) :- !, read_multifile(Preds,File).
directive(_,_).

read_dynamic(Name/Args,File) :- !, functor(F,Name,Args),
        trace_assert(pdynamic(F,File)).
read_dynamic((A,B),File) :- read_dynamic(A,File), read_dynamic(B,File).

read_wait(Name/Args,File) :- !, functor(F,Name,Args),
        set_wait_arguments(Args,F),
        trace_assert(pblock_consult(F,File)).
read_wait((A,B),File) :- read_wait(A,File), read_wait(B,File).

read_block((A,B),File) :- !, read_block(A,File), read_block(B,File).
read_block(G,File) :- !,
        functor(G,F,N), functor(G2,F,N),
        cleanup_block_args(N,G,G2),
        trace_assert(pblock_consult(G2,File)).

read_multifile(Name/Args,File) :- !, functor(F,Name,Args),
        (\+ pmultifile(F,File) ->
                trace_assert(pmultifile(F,File))
                ;true),
        write('% multifile declared predicate '), write(F),
        write(' ([S.L.25.1.06] not )removed :)'),nl.
        /*S.L.18.1.06*/ %erase_old_pred(F) /*End S.L.: auskommentierung*/.
read_multifile((A,B),File) :- read_multifile(A,File), read_dynamic(B,File).

set_wait_arguments(0,F) :- !,
        write('% predicate without arguments being wait-declared: '),
        write(F/0), nl.
set_wait_arguments(1,F) :- !,
        arg(1,F,'-').
set_wait_arguments(I,F) :-
        arg(I,F,'?'),
        I1 is I-1,
        set_wait_arguments(I1,F).

erase_all :- reset_all,
            retractall2(pclause_consult(_,_,_)),
            retractall2(pdynamic(_,_)),
            retractall2(p_op(_,_,_,_)),
            retractall2(pblock_consult(_,_)),
            retractall2(static_struct(_)).
%           retractall2(executable(_)),
%           retractall2(classify_goal(_,_,_)).

is_dynamic(Goal) :- pdynamic(Goal,_).

is_multifile(Goal) :- pmultifile(Goal,_).

has_block(Goal,Block) :-
        findall(Blockitem, has_current_block(Goal,Blockitem),Block).

has_current_block(Goal,Blockitem) :-
        functor(Goal,F,N),
        functor(Blockitem,F,N),
        pblock(Blockitem), % nonmixtus_deterministic
        has_block_args(N,Goal,Blockitem).

% succeeds only if all '-' contains variables
has_block_args(0,_,_) :- !.
has_block_args(I,Goal,Blockitem) :-
        arg(I,Blockitem,AI),
        (AI = '-' ->
                arg(I,Goal,ArgI),
                var(ArgI)
        ;       true),
        I1 is I-1,
        has_block_args(I1,Goal,Blockitem).

pblock(Goal) :- pblock_builtin(Goal);
                pblock_saved(Goal);
                pblock_consult(Goal,_).

pblock_builtin(freeze('-','?')).

cleanup_block_args(0,_,_) :- !.
cleanup_block_args(I,G,G2) :-
        arg(I,G,GI),
        (GI=='-' ->
                arg(I,G2,'-')
        ;       arg(I,G2,'?')
        ),
        I1 is I-1,
        cleanup_block_args(I1,G,G2).

has_clauses(Goal) :- make_skeleton(Goal,Goalskel),
        has_clause(Goalskel,_),!. % mixtus_deterministic

% for accessing code that is executed, the unification is made explicit,
% so that it can be handled separately
has_clause(Goal,Body) :-
        cyclic -> make_skeleton(Goal,Goalskel),
                   pclause(Goalskel,Body2),
                   verify(Goal=Goalskel),
                   Body = (Goal=Goalskel,Body2);
                   pclause(Goal,Body).

% for accessing code that is used as data
has_clause(Goal,Head,Body) :- make_skeleton(Goal,Head),
        pclause_consult(Head,Body,_). % nonmixtus_deterministic

pclause(Head,Body) :- pclause_consult(Head,Body,_).
pclause(Head,Body) :- pclause_builtin(Head,Body).

check_clause(A) :- is_dynamic(A), !, write('predicate is dynamic'), nl, fail.
check_clause(A) :- save_structures(A), % also save the structures
                has_clauses(A), !.
check_clause(_) :- write('predicate undefined'), nl, fail.

make_skeleton(A,Askel) :-
        functor(A,F,N), functor(Askel,F,N).


save_structures(T) :- var(T), !.
save_structures(T) :-
        functor(T,F,N),
        functor(Tskel,F,N),
        save_struct(Tskel),
        save_struct_arg(N,T).

save_struct_arg(0,_T) :- !.
save_struct_arg(N,T) :-
        arg(N,T,TN),
        save_structures(TN),
        N1 is N-1,
        save_struct_arg(N1,T).

save_struct(Tskel) :- (integer(Tskel); % don't save integers (only to speed up "testall")
                       static_struct(Tskel)), !.
save_struct(Tskel) :- trace_assert(static_struct(Tskel)).
retractall2(X) :- retract(X), fail.
retractall2(_).

consulted_predlist(Predlist) :-
        setof(P,consulted_pred(P),Preds), !,
        convert_preds(Preds,Predlist).
consulted_predlist([]).

consulted_pred(N/A) :-
        pclause_consult(P1,_,_),
        functor(P1,N,A).

convert_preds( [], []).
convert_preds( [N/A|R], [F|R1]) :-
        functor( F, N, A),
        convert_preds( R, R1).

call_wash_difs(A,Awashed) :- handle_freeze, !,
        call(A),
        call_residue(copy_term(A,Awashed),_).
call_wash_difs(A,A) :- call(A).

