% Author: Sebastian Lorenz
% Date: 6/29/2006
/*
  This File lists all predicates which have been extended with an argument
  for language indication.
  Theoretically, all these predicates could be partially evaluated with respect
  to their new argument. This is not advisable, if you prefer to obtain a
  readable evaluated version. The results of the evaluation of some predicates
  grow immensely huge and do not provide speedups that are wortwhile.
  
  WHAT SHOULD BE EVALUATED?
  In every case:
  - All predicates that are part of the AST access layer
  Eventually:
  - Language parameterised predicates in higher layers
  - Predicates with built-ins which could be evaluated
*/



/* peConfigBase(+Lang,+Pred,+TargetFile)
 *   Controls the specialisation process for a language.
 *   When the first argument is a variable, the corresponding predicate is
 *   evaluated for every Language.
 *   When the first argument is a constant, it's possible to describe
 *   language-specific directives.
 */


%Layer1:
%peConfigBase(Lang,ast_node_data(Lang,_,_,_,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
peConfigBase(Lang,ast_node_signature(Lang,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
peConfigBase('Java',ast_node_signature('JavaAttributes',_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
/*peConfigBase(Lang,ast_node_term(Lang,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
%Layer2
peConfigBase(Lang,ast_node_data(Lang,_,_,_,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
peConfigBase(Lang,ast_node_argument(Lang,_,_,_,_,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
peConfigBase(Lang,ast_node_argument(Lang,_,_,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
peConfigBase(Lang,ast_node_edge(Lang,_,_,_,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
peConfigBase(Lang,ast_node_edge(Lang,_,_,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
peConfigBase(Lang,ast_node_attribute(Lang,_,_,_,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
peConfigBase(Lang,ast_node_attribute(Lang,_,_,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
%Layer3
peConfigBase(Lang,ast_node_data_value(Lang,_,_,_,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
peConfigBase(Lang,ast_node_argument_value(Lang,_,_,_,_,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
peConfigBase(Lang,ast_node_argument_value(Lang,_,_,_,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
peConfigBase(Lang,ast_node_argument_value(Lang,_,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
peConfigBase(Lang,ast_node_edge_value(Lang,_,_,_,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
peConfigBase(Lang,ast_node_attribute_value(Lang,_,_,_,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').
*/

%GETTER:

%peConfigBase(Lang,get_ast_node_argument(Lang,_,_,_,_,_,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
%peConfigBase(Lang,get_ast_node_argument(Lang,_,_,_,_,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
%peConfigBase(Lang,get_ast_node_argument(Lang,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
%peConfigBase(Lang,get_ast_node_argument(Lang,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
peConfigBase(Lang,get_ast_node_argument(Lang,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').

%peConfigBase(Lang,get_ast_node_edge(Lang,_,_,_,_,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
%peConfigBase(Lang,get_ast_node_edge(Lang,_,_,_,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
%peConfigBase(Lang,get_ast_node_edge(Lang,_,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
%peConfigBase(Lang,get_ast_node_edge(Lang,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
peConfigBase(Lang,get_ast_node_edge(Lang,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').

%peConfigBase(Lang,get_ast_node_attribute(Lang,_,_,_,_,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
%peConfigBase(Lang,get_ast_node_attribute(Lang,_,_,_,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
%peConfigBase(Lang,get_ast_node_attribute(Lang,_,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
%peConfigBase(Lang,get_ast_node_attribute(Lang,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
peConfigBase(Lang,get_ast_node_attribute(Lang,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').

%peConfigBase(Lang,get_ast_node_parent(Lang,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
%peConfigBase(Lang,get_ast_node_parent(Lang,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
peConfigBase(Lang,get_ast_node_parent(Lang,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').

%peConfigBase(Lang,get_ast_node_enclosing(Lang,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
%peConfigBase(Lang,get_ast_node_enclosing(Lang,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').
peConfigBase(Lang,get_ast_node_enclosing(Lang,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').

peConfigBase(Lang,get_ast_node_label(Lang,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').

peConfigBase(Lang,get_ast_node_id(Lang,_,_),'st.java/pl/org/cs3/java/astOperations/ast_getter.pl').

peConfigBase(Lang,get_ast_node_sub_trees(Lang,_,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').

peConfigBase(Lang,get_ast_node_term(Lang,ID,_),ID,'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').

%SETTER:
peConfigBase(Lang,set_ast_node_argument(Lang,_,_,_,_,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_setter.pl').
%peConfigBase(Lang,set_ast_node_parent(Lang,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_setter.pl').
%peConfigBase(Lang,set_ast_node_parent(Lang,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_setter.pl').
peConfigBase(Lang,set_ast_node_parent(Lang,_,_),'st.java/pl/org/cs3/java/astOperations/ast_setter.pl').

%peConfigBase(Lang,set_ast_node_enclosing(Lang,_,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_setter.pl').
%peConfigBase(Lang,set_ast_node_enclosing(Lang,_,_,_),'st.java/pl/org/cs3/java/astOperations/ast_setter.pl').
peConfigBase(Lang,set_ast_node_enclosing(Lang,_,_),'st.java/pl/org/cs3/java/astOperations/ast_setter.pl').

%Miscellaneous
peConfigBase(Lang,checkIfTopLevel(Lang,_),'st.java/pl/org/cs3/java/astSpec/javaSyntax.pl').


%---------------------------------
/*
  If you want to insert specialisations of these predicates in higher layers,
  just uncomment the directives.
  WARNING: Resulting Code might get big; time checks have to be done individually
*/


%garbage_collect.pl
peConfigBase(Lang,delete_ast_node(Lang,_),'engine/apply/garbage_collect.pl').
peConfigBase(Lang,retract_ast_node(Lang,_),'engine/apply/garbage_collect.pl').
%peConfigBase(Lang,retract_ast_nodes(Lang,_),'engine/apply/garbage_collect.pl').
/*
peConfigBase(Lang,deepDeleteIfNotReferenced(Lang,_,_),'engine/apply/garbage_collect.pl').
peConfigBase(Lang,deepDeleteIfParentCorrect(Lang,_,_),'engine/apply/garbage_collect.pl').
peConfigBase(Lang,garbageCollection(Lang),'engine/apply/garbage_collect.pl').
peConfigBase(Lang,deleteSubElements(Lang,_,_,_),'engine/apply/garbage_collect.pl').

%transaction.pl
peConfigBase(Lang,markEnclAsDirty(Lang,_),'engine/apply/transaction.pl').
%ct_apply.pl
peConfigBase(Lang,add(Lang,_),'engine/apply/ct_apply.pl').
peConfigBase(Lang,delete(Lang,_),'engine/apply/ct_apply.pl').
peConfigBase(Lang,replace(Lang,_),'engine/apply/ct_apply.pl').

 %tree_modifications.pl
peConfigBase(Lang,replaceId(Lang,_,_,_),'engine/ast/java/javaAstOperations/tree_modifications.pl').
peConfigBase(Lang,deepDelete(Lang,_),'engine/ast/java/javaAstOperations/tree_modifications.pl').
peConfigBase(Lang,set_ast_node_enclosing(Lang,_,_),'engine/ast/java/javaAstOperations/tree_modifications.pl').
peConfigBase(Lang,rec_set_ast_node_enclosing(Lang,_,_),'engine/ast/java/javaAstOperations/tree_modifications.pl').
peConfigBase(Lang,rec_set_ast_node_parent(Lang,_,_),'engine/ast/java/javaAstOperations/tree_modifications.pl').
peConfigBase(Lang,set_ast_node_parent(Lang,_,_),'engine/ast/java/javaAstOperations/tree_modifications.pl').
peConfigBase(Lang,removeEdgeFromPEF(Lang,_,_,_,_),'engine/ast/java/javaAstOperations/tree_modifications.pl').
peConfigBase(Lang,addEdgeToPEF(Lang,_,_,_,_),'engine/ast/java/javaAstOperations/tree_modifications.pl').
 %tree_queries.pl
peConfigBase(Lang,tree_attributes(Lang,_,_,_),'engine/ast/java/javaAstOperations/tree_queries.pl').
 %tree_checks.pl



peConfigBase(Lang,checkConstraints(Lang,_,_),'engine/check/treechecks.pl').
peConfigBase(Lang,checkConstraints(Lang,_,_,_,_,_),'engine/check/treechecks.pl').
peConfigBase(Lang,checkConstraintList(Lang,_,_),'engine/check/treechecks.pl').
peConfigBase(Lang,checkTreeLinks(Lang,_,_),'engine/check/treechecks.pl').
peConfigBase(Lang,checkTreeLinks(Lang,_,_,_,_),'engine/check/treechecks.pl').
peConfigBase(Lang,checkParentLink(Lang,_,_,_),'engine/check/treechecks.pl').
peConfigBase(Lang,checkTreeLinks(Lang),'engine/check/treechecks.pl').


%clone.pl

peConfigBase(Lang,cloneTree(Lang,_,_),'engine/ast/java/javaAstOperations/clone.pl').
peConfigBase(Lang,cloneTree(Lang,_,_,_,_),'engine/ast/java/javaAstOperations/clone.pl').
peConfigBase(Lang,clone(Lang,_,_,_,_),'engine/ast/java/javaAstOperations/clone.pl').
*/

