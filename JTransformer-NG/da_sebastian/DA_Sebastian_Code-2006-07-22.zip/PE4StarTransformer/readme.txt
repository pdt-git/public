Anleitung:
---------

   Anf�ngliche Anpassungen:
   ------------------
     - Ausgangspfad anpassen in "conf_paths.pl" Zeile 20

  Einfach peEnvironment.pl consulten und dann kann's losgehen. 
  StarTransformer ist komplett in Mixtus geladen. 
  Einfache partielle Auswertungen kann man mit <pe/1> starten. 
  Das Ergebnis wird in die Konsole geschrieben.

  Beispiel: pe(get_ast_node_label('Java',_,_)).

  Um eine komplette spezialisierte Version mit den Auswertungsdirektiven in peConfigBase
  zu generieren, verwende <specialisePTS(+Language,+TargetDirectory)>
  
  Beispiel: specialisePTS('Java',pe_results('/STforJava/')).  




�bersicht �ber Verzeichnisse und Dateien:
-----------------------------------------

  - JTransformer   : entspricht der Version aus dem CVS vom 02.02.2006
  - Mixtus         : Partieller Auswerter Mixtus
  - PE_Results     : Testverzeichnis f�r partielle Auswertungen
  - StarTransformer: verallgemeinerte JTransformer-Version
      Eine Kompatibilit�tsdatei zu den alten JT-Pr�dikaten liegt in
      /StarTransformer/engine/compatabilityJT.pl 



  conf_paths.pl    : Pfadeinstellungen
  conf_mixtus.pl   : * Mixtus laden
                     * Einstellungen von Mixtus
                     * StarTransformer in Mixtus laden  
  peConfigBase.pl  : Auswertungsanweisungen f�r spezialisierte Versionen
->peEnvironment.pl : Einstiegspr�dikat
  peManagement.pl  : Verwaltungsframework f�r die partielle Auswertung