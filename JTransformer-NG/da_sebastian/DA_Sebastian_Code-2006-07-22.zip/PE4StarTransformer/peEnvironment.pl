% Author: Sebastian Lorenz
% Date: 2/9/2006
% Last updated: 6/29/2006

/* Drei Zeitmessungen sind f�r Pr�dikate von N�ten:
   1. JTransformer Pr�dikate
   2. StarTransformer Pr�dikate
   4. StarJavaTransformer Pr�dikate
*/
:- style_check(-singleton).


:- consult(conf_paths).                            %Pfad-Konfigurationen
:- consult(conf_mixtus).                           %Mixtus laden und konfigurieren
:- consult(conf_stransformer).                     %StarTransformer consulten und in Mixtus laden

%Alte, urspr�ngliche JT-Pr�dikate f�r Vergleiche laden:
%:- consult(jtransformer('changed_predicates')).
%:- consult(jtransformer('removed_predicates')).


:- consult(home('peManagement')).   %Verwaltungsframework f�r PE
:- consult(home('peConfigBase')).       %Steuerungsdatei f�r Auswertung
:- consult(home('funktionstest1')).     %Tests zwischen alter und verallgemeinerter Version
:- consult(home('timetests')).

testSpecialisation :-
  specialisePTS('Java',pe_results('/STforJava/')).


