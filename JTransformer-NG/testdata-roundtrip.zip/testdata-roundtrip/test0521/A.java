package test0521;

public class A {
   public void method() {
   }
}