package test0220;
import java.util.*;
public class Test {
	  {}/**/
}