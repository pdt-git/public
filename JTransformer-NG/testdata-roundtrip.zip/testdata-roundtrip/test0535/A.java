package test05;
import java.util.*;
public class Test {
	static {
		System.out.println("Hello" + " world")
	}
}