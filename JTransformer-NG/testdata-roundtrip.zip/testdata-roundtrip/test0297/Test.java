package test0297;

import java.util.List;

public class Test {
	public List fList;
	
	public void foo() {
		int i= 10;
		switch (i) {
			case 1:
				List l= null;
				break;
			default:
		}
	}
}
