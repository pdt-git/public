package test0464;

public class A {

	public static int foo() {
		return null;
	}

}