package test0383;

public class A {
    public static class B {
        public void foo() {
        }		
    }
}
