package test0281;

public class Test {
	Object o= /*]*/new Object()/*[*/;
}
