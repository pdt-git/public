package test0329;

public class Test {
	static void ___run(java.lang.String[] args) throws Throwable {
		java.lang.Object[] obj= new Object[] {};
	}
}
