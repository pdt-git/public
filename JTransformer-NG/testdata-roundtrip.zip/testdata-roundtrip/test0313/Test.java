package test0313;

public class Test {
 	void m(int i, int j){
 		int u= i+j;
 	}
}
