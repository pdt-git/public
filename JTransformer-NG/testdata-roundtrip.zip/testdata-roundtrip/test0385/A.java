package test0385;

public class A {

	int getClass() {
		return 0;
	}
}
