package test0090;
import java.util.*;
public class Test {
	public void foo() {
		int[] tab = {1, 2};
	}

}