package test0289;
import java.util.*;
public class Test {
	String[] tab1 = new String[] { null} ;		
	String s = /**/tab1[0]/**/;
}
