package test0213;
import java.util.*;
  // Line comment
public class Test {
  int i;
}/**/