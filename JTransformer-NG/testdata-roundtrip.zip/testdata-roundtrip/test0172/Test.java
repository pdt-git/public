package test0172;
import java.util.*;
import java.io.IOException;

public class Test {
	
	void foo(int[] i) throws IOException {
	}

	public static void main(String[] args) {
	}
	
	private String bar(String s) throws NullPointerException {
		return s;
	}
}