package test0136;
import java.util.*;
public class Test {
  /* Multiple lines comment
  */
  int i;

}