package test0386;

public class A {

	void foo(int i) {
		switch(i) {
			case 1: 
				System.out.println();
				break;
			default :
				return;
		}
	}
}
