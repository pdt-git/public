package test0425;

public class A{
    void f(){
        int i= 1 + 4 * ( 2 + 3 );
    }
}