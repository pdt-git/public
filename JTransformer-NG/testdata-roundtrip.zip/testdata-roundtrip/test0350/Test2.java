package test0350;

import java.util.Vector;

public class Test2 {
	Vector editors[]= null;
}