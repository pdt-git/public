package test0256;
import java.util.*;
public class Test {
	public void bar() {
		foo((Object) null);
	}
	
	void foo(String[] arg) {
	}
	
	void foo(Object arg) {
	}
}

