package test0514;

public class A {
	public A() {	}
	{ // <- insert '{' before comment
	public static void main(String[] args) { }
}