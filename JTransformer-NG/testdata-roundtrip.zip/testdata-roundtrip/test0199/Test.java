package test0199;
import java.util.*;
public class Test {
	public void foo() {
		int i= 20 + /*]*/10 * 30/*[*/ + 10;
	}
}