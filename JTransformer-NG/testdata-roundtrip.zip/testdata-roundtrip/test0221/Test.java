package test0221;
import java.util.*;
public class Test {
  static {}/**/

}