package test0359;

class A {
	public void mdd(int y) throws Exception{
	}
}