package test0209;
import java.util.*;
public class Test {
  // Line comment
  void foo(final int i) {}/**/

}