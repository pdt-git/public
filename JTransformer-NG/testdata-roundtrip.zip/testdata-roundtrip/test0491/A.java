package test0491;

public class A {

	public void method(String loginName) {
		assert(loginName != null);
	}
}