package test0223;
import java.util.*;
public class Test {

	/** JavaDoc Comment*/
  {}/**/
}