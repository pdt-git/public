package test0175;
import java.util.*;
public class Test {
	int i = 0;
}