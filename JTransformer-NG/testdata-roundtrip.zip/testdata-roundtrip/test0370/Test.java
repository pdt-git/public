package test0370;

public class Test {
	public void foo() {
		do ; while(true);
	}

}