package test0290;

public class Test {
	Object o = /*]*/new java.lang.Object()/*[*/;
}
