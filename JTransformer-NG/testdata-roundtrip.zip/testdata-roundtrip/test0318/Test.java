package test0318;

public class Test {
	static void ___run(java.lang.String[] args) throws Throwable {
		private int x;
	}
}
