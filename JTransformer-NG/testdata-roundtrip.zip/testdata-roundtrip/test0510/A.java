package test0510;

public class A {
	public void foo() {
		new Y();
	}
}