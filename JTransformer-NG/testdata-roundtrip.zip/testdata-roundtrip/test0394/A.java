package test0394;

class A {
	String foo() {
		return null;
	}
}