package test0360;

public class X {
	public void foo() {
		for (int i=0, j=0, k=0; i<10 ; i++,j++,k++) {
  			System.out.println("L");
	  	}
	}
}