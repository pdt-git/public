package test0285;

public class Test {
	Object o = /*]*/Object.class/*[*/;
}
