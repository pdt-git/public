package test0257;
import java.util.*;
public class Test {
	public void bar() {
		foo((int) 0);
	}
	
	void foo(int arg) {
	}
	
	void foo(long arg) {
	}
}