package test0179;
import java.util.*;
public class Test {
	public void foo() {
		Test t = new Test();
		System.out.println(t);
	}
}