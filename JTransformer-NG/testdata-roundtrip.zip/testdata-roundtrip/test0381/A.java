package test0381;

public class A {
	/** Method theMethod.*/
	void theMethod() {
	}
}