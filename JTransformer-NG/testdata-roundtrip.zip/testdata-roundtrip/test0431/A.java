package test0431;

public class A {
	private A() {
		this(fCoo);
	}
	
	private A(int i) {
	}

	private int fCoo= 8;
}