package test0496;

public class A {
      Class[][][][] cls;
}