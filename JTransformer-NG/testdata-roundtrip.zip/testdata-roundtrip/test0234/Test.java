package test0234;
public class Test {
	List field;
}