package test0392;

class A {
	String[] foo() {
		return null;
	}
}