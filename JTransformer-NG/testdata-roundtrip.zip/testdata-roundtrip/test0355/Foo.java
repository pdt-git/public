package test0355;

public class Foo {
	public Object bar() {
		if ( ((Object)null).toString() == null ) {
			return (Object)null;
		}
		return null;
	}
}
