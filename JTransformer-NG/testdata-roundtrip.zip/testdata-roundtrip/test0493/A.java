package test0493;

public class A {
      Class[][] cls;
}