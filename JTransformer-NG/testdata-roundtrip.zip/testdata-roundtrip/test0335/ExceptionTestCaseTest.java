package test0335;

public class ExceptionTestCaseTest extends junit.framework.TestCase {

	public ExceptionTestCaseTest(String s) {
		super(s);
	}
}