package test0092;

public class Test {
	public void foo(final String s) {
	}

}