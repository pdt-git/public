package test0300;

public class Test {
	boolean b = /**/true/**/;
}