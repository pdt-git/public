package test0317;

import java.util.Vector;

public class Test {
	public boolean foo(Object x) {
		return x instanceof Vector;
	}
}