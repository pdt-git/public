package test0315;
public class Test {
  boolean foo() {
    return "abc" instanceof java.io.Serializable;
  }
}
