package test0417;

public class A {
  void foo() {
    A.NewClass c;
  }
}