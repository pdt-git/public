package test0245;
import java.util.*;
public class Test {
	public int a() {
		int i= 0;
		return i;
	}
}
