package test0224;
import java.util.*;
public class Test {

	/* JavaDoc Comment
	 */
  {}/**/
}