package test0110;
import java.util.*;
public class Test {
	public int foo(int i ) {
		return 2;
	}

}