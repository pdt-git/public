package test0091;
import java.util.*;
public class Test {
	public void foo(String s) {
	}

}