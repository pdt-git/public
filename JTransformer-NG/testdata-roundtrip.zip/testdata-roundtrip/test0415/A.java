package test0415;

public class A {
	public void foo(int i) {
		switch(i) {
			case 2: 
				System.out.println();
				break;
			default:
				System.out.println();
		}
	}
}