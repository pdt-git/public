package test0537;
public class C {
	boolean thru;
}