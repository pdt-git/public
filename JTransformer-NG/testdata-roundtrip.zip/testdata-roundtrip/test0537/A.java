package test0537;
public class A {
	Object clons;
}