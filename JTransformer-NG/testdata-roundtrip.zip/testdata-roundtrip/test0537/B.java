package test0537;
public class B {
	int flals;
}