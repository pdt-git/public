package test0156;
import java.util.*;
public class Test {
	int foo(int i) {
		i++;
		return i;
	}
}