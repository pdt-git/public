package test0377;

class A {
	void f() {
		final int i;
	}
}