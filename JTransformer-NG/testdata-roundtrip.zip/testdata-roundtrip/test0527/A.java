package test0527;

public class A {
	
	/**
	 * 
	 * 
	 */
	public A() {
		Runnable runnable = new Runnable() {
			public void run() {
				System.out.println();
			}
		};
	} // comment
}