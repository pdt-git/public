package test0395;

class A {
	String[] foo()[] {
		return null;
	}
}