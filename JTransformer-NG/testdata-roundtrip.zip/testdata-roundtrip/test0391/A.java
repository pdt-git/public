package test0391;

class A {
	int[] foo() {
		return null;
	}
}