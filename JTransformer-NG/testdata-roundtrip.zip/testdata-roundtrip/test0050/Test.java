package test0050;
import java.util.*;
public class Test {
	public static void main(String[] args) {
		System.out.println(2147483648L);
	}

}