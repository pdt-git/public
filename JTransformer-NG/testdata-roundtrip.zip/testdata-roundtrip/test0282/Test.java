package test0282;
public class Test {
	boolean b = /*]*/true/*[*/;
}
