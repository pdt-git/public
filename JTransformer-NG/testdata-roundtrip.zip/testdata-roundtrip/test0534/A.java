package test0534;
import java.util.*;
public class Test {
	public static final String s = "NULL", s2
}