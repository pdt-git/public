package test0330;

public class Test {
	public foo() {
 		return 0;
	}
}

class A {
	void bar() {
		new Test().foo();
	}
}
