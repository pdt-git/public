package test0414;

public class A {
	B foo() {
		return null;
	}

	A bar() {
		return null;
	}
}