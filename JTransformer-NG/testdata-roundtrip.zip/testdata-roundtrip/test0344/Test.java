package test0344;

public class Test {

    public void bugTest() {
        System.out.println("bla");
        System.out.println("blubb");
    }

    private void containsAssert() {
        assert true;
    }

}