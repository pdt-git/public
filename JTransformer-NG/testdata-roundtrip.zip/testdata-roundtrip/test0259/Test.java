//cannot rename to i, i
package test0259;
public class Test {
	int m(){
		int i, /*[*/int j/*]*/;
		return 0;
	}
}
