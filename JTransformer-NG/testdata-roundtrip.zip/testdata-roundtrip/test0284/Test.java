package test0284;

public class Test {
	Object o = /*]*/null/*[*/;
}
