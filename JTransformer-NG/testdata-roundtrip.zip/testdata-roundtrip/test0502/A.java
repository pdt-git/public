package test0502;

public class A {
	{
		int i = 1;
		if (i == 1) {
			int j = 1;
		}
	}

	void foo() {
		int i = 2;
		if (i == 2) {
			int j = 2;
		} else {
			int j = 3;
		}
		new Object() {
		};
		class B {
			int field;
			void bar() {
			}
		}
		new Object() {
		};
	}
}
