package test0342;

public class Test {

	public int junk1(int i) {
		return 0;
	}

	public long junk2() {
		return 0;
	}

	public Object junk3() {
		return null;
	}
	
	Test(int i) {
	}
}