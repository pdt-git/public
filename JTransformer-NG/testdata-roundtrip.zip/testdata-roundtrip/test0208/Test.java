package test0208;
import java.util.*;
public class Test {
  /* Multiple line Comment
  */
  void foo(final int i) {}/**/

}