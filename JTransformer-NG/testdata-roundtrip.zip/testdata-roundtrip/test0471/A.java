package test0471;

public class A {
		
    private void foo(){
 // missing closing bracket
    /*
     *
     */
    private void foo1(){
    }

    private void foo2(){
    }	
}
