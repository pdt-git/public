package test0294;

public class Test {
	public void fails() {
		foo()
	}
	public void foo() {
		foo();
	}
}
