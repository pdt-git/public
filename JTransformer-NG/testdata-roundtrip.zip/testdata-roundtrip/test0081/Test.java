package test0081;
import java.util.*;
public class Test {
	public void foo() {
		this.bar(4);
	}

}