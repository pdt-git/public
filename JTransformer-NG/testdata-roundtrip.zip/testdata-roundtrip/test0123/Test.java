package test0123;
import java.util.*;
public class Test {
	public int foo(Exception e) {
		if (true) return 2;
		else return 3;
	}

}