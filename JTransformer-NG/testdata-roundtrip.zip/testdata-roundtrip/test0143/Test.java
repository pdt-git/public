package test0143;
import java.util.*;
public class Test {
	// Line comment
  public static class B {}

}