package test0393;

class A {
	String foo()[] {
		return null;
	}
}