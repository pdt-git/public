package test0347;

import java.util.Vector;

public class Test2 {
  public static void main(String[] arguments) {
    Vector[] editors[]= null;
  }
}