package test0149;
import java.util.*;
public class Test {

	/* JavaDoc Comment
	 */
  {}
}