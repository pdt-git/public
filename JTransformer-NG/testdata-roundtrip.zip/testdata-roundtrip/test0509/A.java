package test0509;

public class A {
	public void foo() {
		new B();
	}
}