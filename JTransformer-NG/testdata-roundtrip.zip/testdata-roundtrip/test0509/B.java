package test0509;

public class B {
	B() {
	}
}