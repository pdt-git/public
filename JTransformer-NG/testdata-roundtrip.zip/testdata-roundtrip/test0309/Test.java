package test0309;

public class Test {
	void f(int y){
		int i= (y==7) ? 1 : 2 ;
	}
}
