package test0356;

public class A {
	
}

class ActionFactory {
}