package test0356;

public class X {
	public void foo() {
		ActionFactory af=new MyActionFactory();		
	}
}
