package test0292;

public class Test {
  int bar() throws Throwable {
    return Test.x;
  }
  static int x;
}
