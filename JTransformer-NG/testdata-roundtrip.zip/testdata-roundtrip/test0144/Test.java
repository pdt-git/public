package test0144;
import java.util.*;
public class Test {
  public static class B {}
}