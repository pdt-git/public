package test0438_a;

class W {
}