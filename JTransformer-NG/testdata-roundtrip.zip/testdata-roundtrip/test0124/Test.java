package test0124;
import java.util.*;
public class Test {
	public int foo(Exception e) {
		int x= 10, z[] = null, i, j[][];
	}
}