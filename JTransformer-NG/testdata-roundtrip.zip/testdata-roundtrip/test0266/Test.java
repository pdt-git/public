package test0266;
import java.util.*;
public class Test {
	public static class Inner{}
	public static void m(){
		Inner\u005b] i;
	}
}