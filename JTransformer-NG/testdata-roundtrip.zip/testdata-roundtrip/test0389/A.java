package test0389;

class A {
	class B {
	}
}