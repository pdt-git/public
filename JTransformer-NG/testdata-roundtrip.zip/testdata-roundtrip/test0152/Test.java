package test0152;
import java.util.*;
public class Test {
 publicccc voidd foo(() {} 
}