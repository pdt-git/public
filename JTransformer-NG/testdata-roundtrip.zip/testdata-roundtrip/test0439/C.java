package test0439;

public class C {
    private class CInner {
    }		
}