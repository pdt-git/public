package test0181;
import java.util.*;
public class Test {
	public void foo() {
		Test[] t = {};
		System.out.println(t);
	}
}