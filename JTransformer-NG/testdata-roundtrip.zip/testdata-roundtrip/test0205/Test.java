package test0205;
import java.util.*;
public class Test {
	void f(){
		/*[*/class AA extends Test {}/*]*/
	}
}