package test0069;
import java.util.*;
public class Test {

	public static void main(String[] args) {
		boolean b = true;
		boolean b1 = true;
		boolean b2 = b != b1;
	}
}