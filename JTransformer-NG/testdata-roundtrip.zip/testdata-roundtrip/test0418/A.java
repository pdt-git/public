package test0418;

public class A {
  private void foo() {
  }
  
  private static void goo() {
  	foo();
  }
}