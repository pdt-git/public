package test0162;
import java.util.*;
public interface Test {
	
}