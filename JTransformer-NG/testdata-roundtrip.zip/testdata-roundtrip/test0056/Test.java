package test0056;
import java.util.*;
public class Test {
	public static void main(String[] args) {
		boolean b = true;
		boolean b2 = true;
		boolean b3 = b == b2;
	}

}