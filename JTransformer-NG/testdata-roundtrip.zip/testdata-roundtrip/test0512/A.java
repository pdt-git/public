package test0512;

public interface A {
	public A();
}