package test0354;

public class Test {

	protected void primExecute() {
		this.toString();
	}

	if (image != null) {
		Object loc = null;
	}
}