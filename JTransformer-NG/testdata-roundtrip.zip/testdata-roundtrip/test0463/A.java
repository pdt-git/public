package test0463;

public class A {
    public String foo() {
        return "\012\015\u0061";
    }
}	
