package test0243;
import java.util.*;
public class Test {
	void m(){
		try{
		} catch (Exception e){m();}
	}
}
