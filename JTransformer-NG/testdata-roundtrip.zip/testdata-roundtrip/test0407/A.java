package test0407;

public class A {
	void foo() {
	}
	void bar() {
	}

}