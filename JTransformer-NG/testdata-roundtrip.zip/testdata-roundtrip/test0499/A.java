class A {
  public void foo() {
     int x= 10;
     x= x + 1;
  }
}