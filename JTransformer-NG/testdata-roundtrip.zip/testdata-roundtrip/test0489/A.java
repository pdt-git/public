package test0489;

import test0489.Y;
import test0489.Zork;

public class A {
	class B {
		public void bar(Y y) {
			Y y = new Y();
			System.out.println(y.toString());
		}
	}
}