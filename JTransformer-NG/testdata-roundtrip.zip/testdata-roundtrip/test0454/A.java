package test0454;

public class A {

	public A() {
		int a= 2;
		int b= (int) (3.14f * a);
	}

}