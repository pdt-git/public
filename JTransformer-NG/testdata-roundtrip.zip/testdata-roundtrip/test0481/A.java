package test0481;

public class A {
	void test() throws CloneNotSupportedException {
		Runnable runnable = new Runnable() {
			public void run() {
				System.out.println();
			}
		};
	}
}