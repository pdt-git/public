package test0399;

public class A {
	public A() {
   		int i;
   		int k;
   }
}