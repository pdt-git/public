package test0270;
import java.util.*;
public class Test {
	public static class Inner{}
	public static void m(){
		test0270.Test.Inner i[];
	}
}