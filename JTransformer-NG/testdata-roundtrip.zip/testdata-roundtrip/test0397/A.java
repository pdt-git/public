package test0397;

public class A {
	public void foo(final String[] \u0073\u005B][]) {
	}

}