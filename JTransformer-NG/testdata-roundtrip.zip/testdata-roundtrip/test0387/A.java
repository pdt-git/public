package test0387;

class A {
	void f() {
		A a = (\u0020A\u0020) this;
	}
}