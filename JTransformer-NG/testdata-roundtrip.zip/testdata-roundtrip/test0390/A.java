package test0390;

class A {
	int foo() {
		return 0;
	}
}