package test0235;

import java.awt.List;

public class Test {
	List field;
}