package test0304;

interface Test {
	public void foo(int arg);
}
