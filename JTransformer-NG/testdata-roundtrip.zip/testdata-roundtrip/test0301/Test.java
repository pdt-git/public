package test0301;

public class Test {
	Object o = /**/null/**/;
}