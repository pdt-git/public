package test0272;

public class Test {
	public void foo() {
		for (int i= 0; i < 10; i++) foo();
	}
}
