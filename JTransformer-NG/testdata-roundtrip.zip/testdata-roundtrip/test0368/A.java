package test0368;

/* Regression test for bug 23048 */

public class A {
	void foo() {
		test:;
	}
}