package test0400;

public class A {
	public A() {
   		super();
   		int i;
   		int k;

   }
}