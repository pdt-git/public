package test0165;
import java.util.*;
public class Test {
	void foo() {
		class C {
		}
	}
}