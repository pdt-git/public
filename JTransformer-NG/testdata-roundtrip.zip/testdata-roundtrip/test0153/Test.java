package test0153;
import java.util.*;
public class Test {
 public void foo() {
 	int i
 } 
}