package test0444;

public class A {
   public void foo() {
   		return;
   }

   public void foo() {
   		return;
   }
}