package test0449;

public class A {
	A() {
		super();
	}
}