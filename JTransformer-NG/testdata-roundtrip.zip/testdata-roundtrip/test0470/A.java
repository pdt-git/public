package test0470;

public class A {

	public void foo() {
		for (int i= 0, j= goo(3); i < 0; i++) {
		}		
	}
	
	int goo(int i) {
		return 0;
	}
}