package test0404;

class A{
  void f() {
     A a= new A();
     a.clone();
  }
}