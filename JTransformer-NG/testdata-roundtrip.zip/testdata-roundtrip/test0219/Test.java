package test0219;
import java.util.*;
public class Test {
  public static class B {}/**/
}