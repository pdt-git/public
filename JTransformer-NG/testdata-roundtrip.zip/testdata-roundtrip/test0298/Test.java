package test0298;
import java.util.*;
public class Test {
	boolean m(){
		return /*[*/a().length != 3/*]*/;
	}
	int[] a(){
		return null;
	}
}
