package test0078;
import java.util.*;
public class Test {
	public void foo() {
		super.bar();
	}

}