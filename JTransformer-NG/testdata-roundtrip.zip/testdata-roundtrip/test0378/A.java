package test0378;

public class A {
    public static class B {
        public void foo() {
        }		
    }
}
