package test0513;

public interface A {
   void playerJoined(final final Object player);
   void playerLeft(final Object player);
}