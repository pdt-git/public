package test0448;

public class A {
	A() {
	}
}