package test0140;
import java.util.*;
/** JavaDoc Comment*/
public class Test {
  int i;
}