package test0314;
public class Test {
public static void main(String args[]) { int x= 3;}}