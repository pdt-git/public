package test0299;

public class Test {
	int i = (/**/2/**/);
}