package test0148;
import java.util.*;
public class Test {

	/** JavaDoc Comment*/
  {}
}