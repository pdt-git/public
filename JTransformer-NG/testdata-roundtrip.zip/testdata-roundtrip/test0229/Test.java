package test0229;
public class Test {
	public void foo() {
		System.err.println();
	}
}