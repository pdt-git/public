package test0494;

public class A {
      Class[][][] cls;
}