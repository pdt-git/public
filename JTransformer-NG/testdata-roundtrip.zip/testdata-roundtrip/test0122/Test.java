package test0122;
import java.util.*;
public class Test {
	public int foo(Exception e) {
		if (true) return 2\u003B
	}

}