package test0044;
import java.util.*;
public class Test {

	public static void main(String[] args) {
		System.out.println(null);
	}
}