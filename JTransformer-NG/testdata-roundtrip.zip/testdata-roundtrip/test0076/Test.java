package test0076;
import java.util.*;
public class Test {
	public static void main(String[] args) {
		boolean b = args != null ? true : false;
	}

}