package test0253;
import java.util.*;
public class Test {
	public StringBuffer foo() {
		return new StringBuffer("");
	}
}
