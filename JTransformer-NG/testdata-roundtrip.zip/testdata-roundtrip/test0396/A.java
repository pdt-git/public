package test0396;

public class A {
	public void foo(final String s[]) {
	}

}