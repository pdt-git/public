package test0171;
import java.util.*;

class A {
}

public class Test {
}