package test0232;
import java.util.*;
public class Test {
	void foo(String[] array) {
		int i = array.length;
		System.out.println(i);
	}
}