package test0288;

public class Test {
	String[] tab = /**/{ }/**/;
}
