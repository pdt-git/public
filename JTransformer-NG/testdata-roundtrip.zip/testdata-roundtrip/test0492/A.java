package test0492;

public class A {

	public void method(String loginName) {
		assert loginName != null;
	}
}