package test0473;

import java.math.BigDecimal;

public class A {
	public static void main(String[] args) {
		assert(true);
		BigDecimal f = null;
	}
}