package test0154;
import java.util.*;
class Test {
	int[] tab;
	String[] t;
	Test[] t2;
}