package test0139;
import java.util.*;
/* Line comment
 */
public class Test {
  int i;
}