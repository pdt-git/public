package test0485;

public class A {
	/*
	 * 
	 * 
	 */
	public class B {
		void test() throws CloneNotSupportedException {
			Runnable runnable = new Runnable() {
				public void run() {
					System.out.println();
				}
			};
		}
	}
}