package test0349;

import java.util.Vector;

public class Test2 {
	Vector[][] editors[]= null;
}