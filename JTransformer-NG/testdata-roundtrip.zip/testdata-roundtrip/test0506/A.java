package test0506;

public class A {
	public void foo() {
		new A();
	}
}