package test0269;
import java.util.*;
public class Test {
	public static class Inner{}
	public static void m(){
		test0269.Test.Inner[/**/] i;
	}
}