package test0251;
import java.util.*;
public class Test {
	void foo() {
		java.lang.System.out.println();
	}
}
