package test0268;
import java.util.*;
public class Test {
	public static class Inner{}
	public static void m(){
		test0268.Test.Inner[] i;
	}
}