package test0108;
import java.util.*;
public class Test {
	public static void main(String[] args) {
		System.out.println("4" + 5 + 6 + 4);
	}

}