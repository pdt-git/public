package test0230;
import java.io.PrintStream;
public class Test {
	PrintStream err = System.err;
	public void foo() {
		err.println();
	}
}