package test0455;

public class A {

	public void foo() {
	   for (int i = 0; i < 10; i++)  // for 1
	        for (int j = 0; j < 10; j++)  // for 2
	            if (true) { }
	}
}