package test0388;

class A {
}