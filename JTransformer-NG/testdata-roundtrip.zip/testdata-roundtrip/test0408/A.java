package test0408;

public class A {
	java.lang.Object foo() {
		return null;
	}
}