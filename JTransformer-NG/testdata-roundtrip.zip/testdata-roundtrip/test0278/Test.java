package test0278;

public class Test {
	Class c = java.lang.String.class;
}
