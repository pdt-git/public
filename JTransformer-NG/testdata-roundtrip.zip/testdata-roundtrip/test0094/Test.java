package test0094;
import java.util.*;
public class Test {
	public void foo(String s) {
     for (int i = 0; i < 10; i++) {
	     continue;
	   }
	}

}