package test0440;

public class A {
    void test() {
        String i= 2 * 3 + "" + (true);
    }  
}