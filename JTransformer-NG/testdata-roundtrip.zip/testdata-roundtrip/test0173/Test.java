package test0173;
import java.util.*;
public class Test {
	int foo() {
		int i = 0;
		i++;
		return i;
	}
}