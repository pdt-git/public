package test0412;

interface A {
	void m();
}