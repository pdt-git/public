package test0320;

public class Test {
	static void ___run(java.lang.String[] args) throws Throwable {
		int[] tab = new int[10];
	}
}
