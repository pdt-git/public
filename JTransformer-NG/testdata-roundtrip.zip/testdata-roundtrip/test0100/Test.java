package test0100;
import java.util.*;
public class Test {
	public void foo(int i ) {
		while(true);
	}

}