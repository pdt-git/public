package test0260;
import java.util.*;
public interface Test {
	 void m(int i, int j);
}
