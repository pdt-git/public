package test0322;

public class Test {
	Object fField= null;
}
