package test0086;
import java.util.*;
public class Test {
	public void foo() {
		for (; i < 10; i++);
	}

}