package test0249;
import java.util.*;
public class Test {
        int k;
        static class j{
                static int k;
        }
        void m(){
                int y= 0;
                j.k= 0;
        }
}