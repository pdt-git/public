package test0432;

class C {
  private int fCoo;
}

public class A extends C {
  public void goo(C c) {
    fCoo= 1;
  }
}