package test0447;

public class A {
	public static void collectCorrections() {
		processors= null;
	}		
		try {
			int id= 2;
		} catch (CoreException e) {
		}
	}
}