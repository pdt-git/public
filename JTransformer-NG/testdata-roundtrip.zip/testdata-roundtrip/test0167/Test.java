package test0167;
import java.util.*;
public class Test {
        void f() {
                int f = new Test[1+2].length;
        }
}