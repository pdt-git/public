package test0192;
import java.util.*;
public class Test {
	public void foo() {
		int i= /*]*/0/*[*/;
	}
}