package test0477;

public class A {
	public A(String name) {
	}

	public A() {
		this(undef());
	}
	
	void bar(String s) {
	}
	
	void bar() {
	}
	
	void bar(int i) {
	}
}