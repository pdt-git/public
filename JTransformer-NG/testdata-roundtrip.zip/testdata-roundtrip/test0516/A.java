package test0516;
import java.util.*;
public class Test {
	/**
	 * Javadoc comment
	 */
	public static void main(String[] args) {
		/* method main */
		System.out.println("Hello" + " world"); // comment
	}
}