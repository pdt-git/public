package test0191;
import java.util.*;
public class Test {
	public void foo() {
		boolean b;
		b= 1 < 10 && /*]*/2 < 20/*[*/;
	}
}