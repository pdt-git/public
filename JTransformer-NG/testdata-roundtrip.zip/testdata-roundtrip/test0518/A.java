package test0518;
import java.util.*;
public class Test {
	/**
	 * Javadoc
	 */
	static {
		/* */
		System.out.println("Hello" + " world"); // line comment
	}
}