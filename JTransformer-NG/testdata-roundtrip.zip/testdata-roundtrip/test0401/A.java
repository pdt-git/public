package test0401;

public class A {
	correctThis() {
	    return 1;
	}
}