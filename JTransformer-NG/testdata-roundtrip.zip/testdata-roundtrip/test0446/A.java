package test0446;

public class A {
	void foob() {
		int b = b;
	}
}