package test0202;
import java.util.*;
public class Test {
	int f= (2);
}