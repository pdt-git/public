package test0460;

public class A {
	public void foo() {
		final int bar;

		bar = 1;
	}
}