package test0526;

public class A {
	public class B {
		void test() throws CloneNotSupportedException {
			Runnable runnable = new Runnable() {
				public void run() {
					System.out.println();
				}
			};
		}
	}
}