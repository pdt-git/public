package test0351;

public class Test2 {
	void m1(int a, int[] b){}	
	void m(int a, int b[]){}
}
