package test0413;

class E extends Exception {
}

interface A {
	void m() throws IOException, E;
}