package test0211;
import java.util.*;
public class Test {
  /* Multiple lines comment
  */
  int i;/**/

}