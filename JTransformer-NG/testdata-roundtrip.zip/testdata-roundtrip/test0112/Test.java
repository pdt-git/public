package test0112;
import java.util.*;
public class Test {
	public int foo(int i ) {
		synchronized(this) {
		}
	}

}