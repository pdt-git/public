package test0406_a;

public class A {
	protected A foo(String s) {
	}
}
