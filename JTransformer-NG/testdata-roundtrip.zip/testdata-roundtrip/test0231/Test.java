package test0231;
import java.util.*;
public class Test {
	public void foo() {
		System.err.println();
	}
}