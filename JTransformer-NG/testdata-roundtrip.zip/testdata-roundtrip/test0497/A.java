package test0497;

public class A {
      Class[] cls;
}