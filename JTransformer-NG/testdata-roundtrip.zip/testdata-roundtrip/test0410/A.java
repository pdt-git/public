package test0410;

public class A {
	int foo() {
		return 1 + 2 + 3 + 4 + 3;
	}
}