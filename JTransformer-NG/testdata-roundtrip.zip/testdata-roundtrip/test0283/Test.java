package test0283;

public class Test {
	char c = /*]*/'c'/*[*/;
}
