package test0508;

public class A {
	A() {
	}
	public void foo() {
		new A();
	}
}