package test0131;
import java.util.*;
public class Test {
  void foo(final int i) {}

}