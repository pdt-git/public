package test0352;

public class Test2 {
	void m1(final int a, final int[] b){}	
	void m(final int a, final int b[]){}
}
