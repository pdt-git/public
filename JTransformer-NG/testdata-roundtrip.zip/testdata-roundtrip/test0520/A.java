package test0519;
import java.util.*;
public class Test {
	/**
	 * Javadoc
	 */
	public static void main(String[] args) {
		System.out.println("Hello" + /* */ " world");
	}
}