package test0367;

/* Regression test for bug 23048 */

public class A {
	void theMethod(int i) {
		while(i == 2);
	}
}