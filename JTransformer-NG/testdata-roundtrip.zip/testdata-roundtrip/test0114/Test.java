package test0114;
import java.util.*;
public class Test {
	public int foo(int i ) {
		try {
		} catch(Exception e) {
		}
	}

}