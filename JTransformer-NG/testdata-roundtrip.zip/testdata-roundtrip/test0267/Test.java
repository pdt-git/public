package test0267;
import java.util.*;
public class Test {
	public static class Inner{}
	public static void m(){
		Inner[] i;
	}
}