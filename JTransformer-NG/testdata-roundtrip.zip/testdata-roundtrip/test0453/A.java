package test0453;

public class A {
	public String foo() {
		return super.toString();
	}
}
