package test0089;
import java.util.*;
public class Test {
	public void foo() {
		java.lang.String s;
	}

}