package test0085;
import java.util.*;
public class Test {
	public void foo() {
		for (int i = 0;; i++);
	}

}