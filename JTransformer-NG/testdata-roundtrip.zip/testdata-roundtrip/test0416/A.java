package test0416;

interface I {
    int CONST= 1;
}

public class A {
  void foo() {
    int x= I.CONST;
  }
}