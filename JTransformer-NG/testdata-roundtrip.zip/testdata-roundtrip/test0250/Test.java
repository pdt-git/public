package test0250;
import java.util.*;
interface Test {
         void m(int i, int j);
}