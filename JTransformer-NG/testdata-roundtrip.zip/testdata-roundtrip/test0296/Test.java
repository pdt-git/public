package test0296;

public class Test {
	public void fails() {
		foo()
	}
	public void foo() {
		foo();
	}
}
