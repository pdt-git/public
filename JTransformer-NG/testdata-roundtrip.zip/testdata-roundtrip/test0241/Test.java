package test0241;
import java.util.*;
public class Test {

	public int i;
	
	public void foo() {}
	
	class B {
	}
	
	class D {
	}
	
	public void bar() {
	}
	
	int j;
	
	public static int foo3() {
		return 3;
	}	
	public static int k = foo3();
	
	Object l, n, m;
	
	public void foo2() {
	}
	
	class D {
	}
}
