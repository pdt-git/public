package test0380;

public class A {
    public String toString() {
    	return super.toString();	
    }
}
