package test0286;

public class Test {
	int i = /**/(2)/**/;
}
