package test0327;

import java.util.Vector;

public class Test {
	public static void goo(Object o) {
		Vector s= (String) ooo;
	}
}
