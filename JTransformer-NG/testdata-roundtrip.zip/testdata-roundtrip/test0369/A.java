package test0369;

/* Regression test for bug 23048 */

public class A {
	void foo() {
		test:\u003B
	}
}