package test0406;

import test0406_a.A;

class Test {
	void test() {
		A a = new A();
		a.foo("");
	}
}