package test0406;

import test0406.a.A;

class Test {
	void test() {
		A a = new A();
		a.foo("");
	}
}
