package test0406.a;

public class A {
	protected A foo(String s) {
	}
}
