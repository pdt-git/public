package test0145;
import java.util.*;
public class Test {
	  {}
}