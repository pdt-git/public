package test0420;

public class A{
    void f(){
        int i= 1 + (2 + 3) + 4;
    }
}