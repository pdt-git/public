package test0080;
import java.util.*;
public class Test {
	public void foo() {
		bar(4);
	}

}