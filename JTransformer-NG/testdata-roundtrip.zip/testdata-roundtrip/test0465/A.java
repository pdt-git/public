package test0465;

public class A {

	int i;
	
	public int foo() {
		return this.i;
	}

}