package test0236;
import java.util.*;
public class Test {
	int i= 0, k = 1;
}