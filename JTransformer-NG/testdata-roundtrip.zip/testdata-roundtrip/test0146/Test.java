package test0146;
import java.util.*;
public class Test {
  static {}

}