package test0331;

public class Test {
	public static void main(String[] args) {
    		int i = args.length;
    	}
}
