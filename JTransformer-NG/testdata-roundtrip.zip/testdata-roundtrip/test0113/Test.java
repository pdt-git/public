package test0113;
import java.util.*;
public class Test {
	public int foo(int i ) {
		try {
		} catch(Exception e) {
		} finally {
		}
	}

}