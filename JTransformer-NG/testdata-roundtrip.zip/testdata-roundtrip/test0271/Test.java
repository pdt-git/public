package test0271;
import java.util.*;
public class Test {
	public static class Inner{}
	public static void m(){
		test0271.Test.Inner[] i[];
	}
}