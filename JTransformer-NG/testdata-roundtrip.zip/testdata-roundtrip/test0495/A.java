package test0495;

public class A {
      Class[][] cls[];
}