package test0507;

public class B {
}