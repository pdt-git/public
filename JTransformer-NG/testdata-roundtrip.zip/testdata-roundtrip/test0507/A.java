package test0507;

public class A {
	public void foo() {
		new B();
	}
}