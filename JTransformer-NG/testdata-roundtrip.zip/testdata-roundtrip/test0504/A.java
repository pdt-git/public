package test0504;

public class A
{
   public A()
   {
      
   }

}
interface B
{
   public method(final int parameter);
}