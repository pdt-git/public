package test0119;
import java.util.*;
public class Test {
	public int foo(Exception e) {
		if (true)\u003B
	}

}