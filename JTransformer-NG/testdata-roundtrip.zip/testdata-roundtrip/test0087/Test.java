package test0087;
import java.util.*;
public class Test {
	public void foo() {
		for (;;i++);
	}

}