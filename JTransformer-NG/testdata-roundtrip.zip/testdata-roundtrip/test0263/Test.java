package test0263;
import java.util.*;
public class Test {
	void m(int i){
		m(i);
	}
}
