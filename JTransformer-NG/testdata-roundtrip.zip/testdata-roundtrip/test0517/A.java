package test0517;
import java.util.*;
public class Test {
	/**
	 * Javadoc
	 */
	public static final /* */ String s = "NULL", s2;// line comment
}