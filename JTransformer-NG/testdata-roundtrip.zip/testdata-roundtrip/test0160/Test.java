package test0160;
import java.util.*;
public class Test {
	
	Test[] t, g[] = null;
}