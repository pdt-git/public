package test0375;

import test0375.A.*;

/* Regression test for bug 23052 */

public class A {
}