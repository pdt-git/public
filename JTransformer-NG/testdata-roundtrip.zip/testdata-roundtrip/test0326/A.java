package test0326;

public class A {
	A f;
	public A a() {
		a().f= a();
		return null;
	}
}
