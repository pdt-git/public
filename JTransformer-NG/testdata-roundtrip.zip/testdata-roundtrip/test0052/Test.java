package test0052;
import java.util.*;
public class Test {
	public static void main(String[] args) {
		System.out.println(-9223372036854775808L);
	}

}