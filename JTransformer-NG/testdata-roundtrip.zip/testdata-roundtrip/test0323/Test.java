package test0323;

public class Test {
  void foo() {
    String x;
    x = (java.lang.Object) "s";
  }
}
