package test0115;
import java.util.*;
public class Test {
	public int foo(int i ) {
		try {
			return 2;
		} catch(Exception e) {
		}
	}

}