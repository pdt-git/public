package test0443;

public class A {
   public abstract void foo() {
   		return;
   }
}