package test0422;

public class A{
    void f(){
        int i= ( 1 + 2 ) + 3;
    }
}