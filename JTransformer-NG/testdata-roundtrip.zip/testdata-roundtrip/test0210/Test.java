package test0210;
import java.util.*;
public class Test {
  /** JavaDoc Comment*/
  int i;/**/

}