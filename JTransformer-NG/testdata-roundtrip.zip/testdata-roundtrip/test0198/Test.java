package test0198;
import java.util.*;
public class Test {
	public int foo() {
		return 10 + /*]*/20 * 30/*[*/ + 10;
	}
}