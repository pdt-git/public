package test0490;

public class A {

	public void method() {
		switch(1) {
			 case B.ONE : break;
			 case B.TWO : break;
		}
	}
}