package test0490;

public interface B {
	int ONE = 1;
	int TWO = 2;
}