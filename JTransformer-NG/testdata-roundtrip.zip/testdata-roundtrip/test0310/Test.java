package test0310;

class Test {
	private static final String G = I.GR;

	public static void c(){
		Object cp = null;
	}
}

interface I {
	String GR= "l";
}