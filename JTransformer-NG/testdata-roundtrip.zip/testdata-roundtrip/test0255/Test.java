package test0255;
import java.util.*;
public class Test {
	public void bar() {
		foo((String[]) null);
	}
	
	void foo(String[] arg) {
	}
	
	void foo(Object arg) {
	}
}
