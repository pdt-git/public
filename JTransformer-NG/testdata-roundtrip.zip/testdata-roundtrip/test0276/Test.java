package test0276;

public class Test {
	public void foo() {
		foo();
	}
}
