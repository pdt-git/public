package test0212;
import java.util.*;
public class Test {
  // Line comment
  int i;/**/

}