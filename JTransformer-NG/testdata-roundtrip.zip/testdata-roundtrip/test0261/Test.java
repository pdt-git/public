package test0261;
import java.util.*;
public class Test {
  public int foo(int variable) {
    return varble; // <-- Unable to resolve binding here
  }
}
