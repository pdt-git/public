package test0451;

public class A {
	private int A()[]{
	}
}
