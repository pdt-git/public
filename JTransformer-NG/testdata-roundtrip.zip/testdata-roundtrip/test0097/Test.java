package test0097;
import java.util.*;
public class Test {
	public void foo(int i ) {
		switch(i) {
			case 1: 
              break;
			case 2:
				System.out.println(2);
              break;
          default:
				System.out.println("default");
		}
	}
}