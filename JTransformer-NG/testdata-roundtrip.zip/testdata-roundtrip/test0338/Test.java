package test0338;

import java.io.IOException;

public class Test {
	public void foo() throws IOException {
	}
}
