package test0382;

public class A {
}