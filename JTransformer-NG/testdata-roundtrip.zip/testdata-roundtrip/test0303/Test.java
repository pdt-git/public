package test0303;
import java.util.*;
public class Test {
  void foo() {
    char x;
    x = (char)3;
  }
}
