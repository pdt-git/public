package test0445;

import java.io.IOException;
	
public class A {
    public void goo() throws IOException {
    }		
    public void foo() {
        goo();
    }
}