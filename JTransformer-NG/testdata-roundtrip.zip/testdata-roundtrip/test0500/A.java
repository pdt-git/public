package test0500;
/**
 * Test for bug 45436
 */
public class A {
	/**
	 * @param b 
	 *        comment on second line.
	 * @param c
	 */
	public void foo(int a, int b, int c) { }

}