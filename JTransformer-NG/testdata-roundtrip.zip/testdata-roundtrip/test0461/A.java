package test0461;

public class A {
    public void foo() {
        z= foo().y.toList();
    }
}	
