package test0180;
import java.util.*;
public class Test {
	public void foo() {
		Test[] t = new Test[0];
		System.out.println(t);
	}
}