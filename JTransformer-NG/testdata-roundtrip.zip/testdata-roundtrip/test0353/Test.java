package test0353;

import java.io.InputStream;

public class Test {
        void foo() {
                InputStream i = null;
                while (true);
        }
}