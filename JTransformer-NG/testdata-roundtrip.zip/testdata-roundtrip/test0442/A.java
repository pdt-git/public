package test0442;

public class A {
    void test() {
        int i= 2 + (2 * 3) + 1;
    }  
}