package test0121;
import java.util.*;
public class Test {
	public int foo(Exception e) {
		if (true) {}
		else ;
	}

}