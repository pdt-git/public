package test0279;

public class Test {
	void foo() {
		Class c = java.lang.String.class;
	}
}
