package test0483;

public class A {
	
	/**
	 * 
	 * 
	 */
	public A() {
		Runnable runnable = new Runnable() {
			public void run() {
				System.out.println();
			}
		};
	} // comment
}