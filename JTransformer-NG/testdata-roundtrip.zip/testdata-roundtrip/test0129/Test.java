package test0129;
import java.util.*;
public class Test {
  int i;
}