package test0082;
import java.util.*;
public class Test {
	public void foo() {
		for (;;);
	}

}