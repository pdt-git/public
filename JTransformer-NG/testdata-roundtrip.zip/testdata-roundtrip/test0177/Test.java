package test0177;
import java.util.*;
public class Test {
	void bar() {
		double i = 1.0;
		System.out.println(i);
	}
	
	int foo() {
		int i = 0;
		i++;
		return i;
	}
}