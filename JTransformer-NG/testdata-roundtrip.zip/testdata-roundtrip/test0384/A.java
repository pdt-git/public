package test0384;

public class A {
    public static class B {
        public class D {
        }		
    }
}
