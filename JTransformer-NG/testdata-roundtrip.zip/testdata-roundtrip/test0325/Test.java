package test0325;

public class Test {
  void foo() {
    Object x;
    x = (int[]) null;
  }
}