package test0218;
import java.util.*;
public class Test {
	// Line comment
  public static class B {}/**/

}