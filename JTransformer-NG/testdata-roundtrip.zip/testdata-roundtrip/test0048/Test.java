package test0048;
import java.util.*;
public class Test {

	public static void main(String[] args) {
		System.out.println(30000);
	}
}